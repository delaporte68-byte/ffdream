# 🎯 DIFFÉRENCE : Tour vs Round

## 📖 Définitions

### 🔹 TOUR (Turn)
- **1 joueur** joue
- Utilise ses actions
- Clique "Terminer mon tour"
- Passe au **joueur suivant**
- **PAS de récupération de PA**

### 🔄 ROUND
- **TOUS les joueurs** ont joué
- Foundry détecte automatiquement
- **+1 Grand PA pour TOUS**
- Déplacements réinitialisés
- Retour au premier joueur

---

## 📊 Schéma Visuel

```
╔═══════════════════════════════════════════════╗
║              🎮 ROUND 1                       ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  🔹 TOUR 1 : Joueur A (Initiative 95)        ║
║     ├─ Utilise technique (coûte 1 Grand PA)  ║
║     ├─ Utilise Esquive (coûte 1 Petit PA)    ║
║     └─ Clique "Terminer mon tour"            ║
║        → nextTurn() → Passe à Joueur B       ║
║                                               ║
║  🔹 TOUR 2 : Joueur B (Initiative 80)        ║
║     ├─ Utilise 2 techniques                  ║
║     └─ Clique "Terminer mon tour"            ║
║        → nextTurn() → Passe au PNJ           ║
║                                               ║
║  🔹 TOUR 3 : PNJ Goblin (Initiative 50)      ║
║     ├─ MJ utilise une technique              ║
║     └─ MJ clique "Next Turn" dans tracker    ║
║        → nextTurn() → Dernier combattant !   ║
║                                               ║
╚═══════════════════════════════════════════════╝
                     ⬇️
         🔄 CHANGEMENT DE ROUND !
                     ⬇️
╔═══════════════════════════════════════════════╗
║              🎮 ROUND 2                       ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  ✨ Système détecte : changed.round = 2      ║
║  ✨ Appelle newRound()                        ║
║                                               ║
║  ⚡ Joueur A : +1 Grand PA récupéré           ║
║  ⚡ Joueur B : +1 Grand PA récupéré           ║
║  ⚡ PNJ Goblin : +1 Grand PA récupéré         ║
║                                               ║
║  🚶 Déplacements gratuits réinitialisés       ║
║  🔓 Tous les joueurs débloqués                ║
║                                               ║
║  🔹 TOUR 1 : Retour à Joueur A               ║
║     └─ Débloqué automatiquement               ║
║                                               ║
╚═══════════════════════════════════════════════╝
```

---

## 🎮 En Pratique

### Joueur A finit son tour :
```
1. Sélectionne son token
2. Clique "Terminer mon tour"
3. Dialogue : "Voulez-vous terminer votre tour ?"
4. Clique "Oui"

→ Flag actionBlocked = true (bloqué)
→ Message chat : "🔒 Joueur A a terminé son tour"
→ combat.nextTurn() → Passe à Joueur B
→ Notification : "▶️ C'est le tour de Joueur B !"
```

**PAS de récupération de PA** car ce n'est qu'**UN** tour, pas tout le round !

### Dernier joueur finit son tour :
```
PNJ Goblin (dernier dans l'initiative)
MJ clique "Next Turn"

→ Foundry détecte : Plus personne après
→ Foundry incrémente : round = 1 → round = 2
→ Hook détecte : changed.round = 2
→ Système appelle newRound()
→ TOUS récupèrent +1 Grand PA
→ Retour au premier (Joueur A)
```

---

## 🔧 Boutons MJ

### 🔄 Nouveau Round (Récupérer PA)
**Utilité :** Forcer manuellement un nouveau round
- Récupère +1 Grand PA pour TOUS
- Réinitialise déplacements
- Débloque tout le monde

**Quand l'utiliser :**
- Si la détection automatique ne marche pas
- Pour corriger une erreur
- Pour avancer rapidement

### 🔓 Débloquer Tous les Joueurs
**Utilité :** Retirer le flag `actionBlocked`
- Permet à tous de rejouer
- Sans changer de round
- Sans récupérer de PA

**Quand l'utiliser :**
- Joueur a cliqué trop tôt
- Erreur de manipulation
- Besoin de laisser quelqu'un rejouer

---

## ⚙️ Code - Comment ça Marche

### Macro "Terminer mon tour" :
```javascript
// Bloque le joueur
await actor.setFlag('ffdreame', 'actionBlocked', true);

// Passe AU SUIVANT (pas au nouveau round)
await combat.nextTurn();
```

### Hook détection changement :
```javascript
// Hook appelé à CHAQUE changement dans le combat
Hooks.on("updateCombat", (combat, changed) => {
  
  // Changement de ROUND (tous ont joué)
  if (changed.round !== undefined) {
    console.log('🔄 Nouveau ROUND détecté !');
    newRound(combat); // Récupère PA
  }
  
  // Changement de TOUR (joueur suivant)
  if (changed.turn !== undefined) {
    console.log('▶️ Nouveau TOUR détecté !');
    startTurn(combat.combatant.actor); // Débloque
  }
});
```

---

## 📋 Résumé

| Action | Déclencheur | Effet |
|--------|-------------|-------|
| **Terminer mon tour** | Joueur clique macro | Bloque + nextTurn() |
| **Nouveau tour** | Combat change de combattant | Débloque le joueur actif |
| **Nouveau round** | Tous ont joué | +1 Grand PA pour TOUS |

---

## ✅ Checklist de Test

Pour vérifier que tout fonctionne :

- [ ] Joueur A clique "Terminer mon tour"
  → Passe à Joueur B (pas de PA récupéré)

- [ ] Joueur B clique "Terminer mon tour"  
  → Passe au PNJ (pas de PA récupéré)

- [ ] MJ clique "Next Turn" sur le PNJ
  → Foundry détecte fin de round
  → Console : "🔄 Nouveau round détecté: 2"
  → TOUS récupèrent +1 Grand PA
  → Retour à Joueur A

- [ ] Joueur A voit ses PA augmentés
  → Confirmation que ça marche !

---

Maintenant c'est clair : **TOUR** ≠ **ROUND** ! 🎯
