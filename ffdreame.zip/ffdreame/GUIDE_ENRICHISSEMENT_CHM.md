# 🎯 GUIDE : Enrichissement du Style CHM

## 🎯 Nouvelles Fonctionnalités

Chaque variante CHM peut maintenant avoir :
- ✅ **2 Effets** (comme les techniques normales)
- ✅ **Animation JB2A** spécifique
- ✅ **Style MULTI** (zone/ligne)
- ✅ **Portée** personnalisée

---

## 📋 Fichiers à Modifier

### 1. **Template JSON (Déjà fait ✅)**
Le fichier `template.json` a été mis à jour avec les nouveaux champs.

### 2. **Template HTML** ⚠️ À FAIRE MANUELLEMENT

**Fichier :** `templates/item/technique-sheet-v2.html`

**Actions :**
1. Localisez la section CHM (ligne ~575)
2. Remplacez chaque slot (slot1 à slot5) par le template enrichi
3. Utilisez le fichier `TEMPLATE_CHM_SLOT_ENRICHI.html` comme modèle

**⚠️ IMPORTANT :** Pour chaque slot, changez :
- `slot1` → `slot2`, `slot3`, `slot4`, `slot5`
- Le numéro dans `<span class="chm-slot-number">1</span>`
- Le placeholder de l'icône (🔥, ❄️, ⚡, 💨, 🌟)

### 3. **Code JavaScript** ⚠️ À FAIRE MANUELLEMENT

**Fichier :** `module/sheets/actor-sheet.js`

**Actions :**
1. Trouvez la fonction `_executeTechniqueCHMVariante` (ligne ~2958)
2. Remplacez-la par le code dans `CODE_CHM_ENRICHI.js`

---

## 🎮 Exemple d'Utilisation

### Technique : "Maîtrise Élémentaire" (CHM)

**Variante 1 : Flammes** 🔥
```
Style : MAG
Portée : 10m
Dégâts : 30

Effet 1 : Dégâts sur la durée
- Type : deg
- Valeur : 5 / Fixe
- Durée : 3 tours
- Condition : 80%

Effet 2 : Malus défense
- Type : malus_defense
- Valeur : 15 / %
- Durée : 2 tours
- Condition : 100%

Animation : jb2a.fire_bolt.orange
```

**Variante 2 : Blizzard** ❄️
```
Style : MULTI (Zone)
Portée : N/A (géré par MULTI)
Dégâts : 25

Config MULTI :
- Type : Zone (Cercle)
- Distance max : 8m
- Rayon : 3m

Effet 1 : Malus aux jets
- Type : malus_jet
- Valeur : 20 / %
- Durée : 2 tours
- Condition : 100%

Animation : jb2a.ice_spikes.radial.white
```

**Variante 3 : Éclair** ⚡
```
Style : MULTI (Ligne)
Portée : N/A
Dégâts : 35

Config MULTI :
- Type : Ligne Droite
- Distance max : 12m
- Largeur : 1.5m

Effet 1 : Aucun

Animation : jb2a.lightning_bolt.narrow.blue
```

**Variante 4 : Tornade** 💨
```
Style : PUI
Portée : 6m
Dégâts : 40

Effet 1 : Bonus jets (allié)
- Type : bonus_jet
- Valeur : 10 / %
- Durée : 3 tours
- Condition : 100%

Animation : jb2a.whirlwind.bluepurple
```

**Variante 5 : Lumière** 🌟
```
Style : CUR (Soins)
Portée : 10m
Dégâts : 0 (Soins : 50)

Effet 1 : Soins sur la durée
- Type : soin
- Valeur : 10 / Fixe
- Durée : 3 tours
- Condition : 100%

Animation : jb2a.healing_generic.400px.blue
```

---

## 🔧 Workflow en Jeu

### Étape 1 : Le joueur utilise la technique CHM
→ Dialogue avec les 5 variantes s'affiche

### Étape 2 : Le joueur choisit une variante
→ Ex: "Blizzard" (MULTI Zone)

### Étape 3 : Si MULTI
→ Le système MULTI se lance
→ Clic pour placer la zone
→ Jet de dés
→ Animation JB2A spécifique (Blizzard)
→ Dégâts appliqués avec effets

### Étape 4 : Si style normal (MAG, CAC, etc.)
→ Vérification de portée
→ Jet de dés
→ Animation JB2A spécifique
→ Dégâts + Effets appliqués

---

## 💡 Avantages du CHM Enrichi

### Polyvalence Tactique
- **Une technique = 5 options différentes**
- Adaptable à chaque situation
- Économie de slots de techniques

### Styles Mixtes
- Combiner CAC, MAG, MULTI dans une seule technique
- Ex: Version mêlée + Version zone + Version soin

### Animations Cohérentes
- Chaque variante a sa propre animation
- Flammes = orange, Glace = bleu, etc.

### Effets Riches
- Chaque variante peut avoir ses propres effets
- Pas limité au style principal

---

## ⚠️ Notes Importantes

### Portée
- Pour les styles normaux (CAC, MAG, etc.) → Utilise le champ "Portée"
- Pour le style MULTI → Utilise la "Distance max" de la config MULTI

### Coût
- Le coût PM/PA est celui de la technique principale
- Toutes les variantes coûtent le même prix

### Burste
- Chaque variante génère de la Burste normalement
- Les MULTI génèrent +10 par cible

---

## 🐛 Dépannage

### "La variante MULTI ne se lance pas"
- Vérifiez que le style est bien "multi"
- Vérifiez la config MULTI (type, distance, largeur)

### "L'animation ne se joue pas"
- Vérifiez Sequencer + JB2A actifs
- Vérifiez le chemin de l'animation
- Utilisez la console (F12) pour voir les erreurs

### "Les effets ne s'appliquent pas"
- Vérifiez que les effets sont configurés
- Vérifiez la condition (% de réussite)

---

## 📦 Fichiers Fournis

1. **`TEMPLATE_CHM_SLOT_ENRICHI.html`** - Template HTML d'un slot
2. **`CODE_CHM_ENRICHI.js`** - Code JavaScript à insérer
3. **`GUIDE_ENRICHISSEMENT_CHM.md`** - Ce guide

---

## 🚀 Résultat Final

Avec ces modifications, vos techniques CHM deviennent des **couteaux suisses** :
- 5 styles différents possibles
- 10 effets par technique (2 par variante x 5)
- 5 animations différentes
- Support MULTI intégré

Parfait pour les personnages polyvalents ! 🎯✨
