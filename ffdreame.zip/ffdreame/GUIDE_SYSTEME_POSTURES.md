# 🎮 FFdreame System v3.0 - SYSTÈME POSTURES & TECHNIQUES COMPLET

## 📦 Installation

1. **IMPORTANT: Sauvegardez vos anciens personnages** si vous en avez
2. Extrayez `ffdreame-system-FINAL-v3.zip`
3. Remplacez les fichiers dans `Data/systems/ffdreame/`
4. Redémarrez Foundry VTT
5. **Note:** Les anciennes postures (posture1, posture2) ne sont plus utilisées

## 🎯 NOUVEAU SYSTÈME - Postures & Techniques en ITEMS

### 🥋 POSTURES (Nouvel Item)

Les postures sont maintenant des **Items** indépendants et réutilisables !

**Comment créer une posture :**
1. Menu Items → Créer un Item → Type: "Posture"
2. Remplir :
   - **Nom** : Ex: "Style du Dragon"
   - **Description** : Philosophie du style de combat
   - **Attaque Base** : Bonus aux dégâts (ex: +20)
   - **Effet Posture** : Type d'effet spécial
   - **Condition** : Quand l'effet se déclenche

**Types d'effets disponibles :**
- ✨ **Bonus de dégâts %** → Augmente les dégâts après X actions
- 🔄 **Régénération PA** → Récupère des points d'action
- 🛡️ **Contre** → Défense sans consommer de PA
- 💨 **Esquive** → Évite l'attaque sans PA
- ⚡ **Initiative** → Joue toujours en premier

**Sur la fiche personnage :**
- Les postures apparaissent automatiquement
- Bouton **ACTIVE/Inactive** pour les activer
- Seule la posture active affiche ses techniques
- **Attaque de Base** = Aptitude Attaque + Base posture

### ⚡ TECHNIQUES (Modifiées)

Les techniques s'associent maintenant aux postures !

**Comment créer une technique :**
1. Menu Items → Créer un Item → Type: "Technique"
2. Remplir :
   - **Nom** : Ex: "Poing du Dragon"
   - **Style** : CAC, MG, P, EHa, EHm, EF, BUFF
   - **Coût PM** : Points magiques consommés
   - **Base Dégâts** : Dégâts de base
   - **Effets** : Effets spéciaux (stun, paralysie, etc.)
   - **Posture Associée** : Nom EXACT de la posture

**IMPORTANT :** La technique apparaît automatiquement dans la posture si le nom correspond !

**Sur la fiche personnage :**
- Affiche : Nom + Coût PM + Dégâts
- Cliquable seulement si la posture est active
- Consomme automatiquement PM + 1 Grand PA

## 🎮 Utilisation en jeu

### Activation d'une posture

1. Sur la fiche, cliquez **TOGGLE** sur la posture
2. Elle passe en **ACTIVE** (vert)
3. Ses techniques deviennent cliquables
4. Vous pouvez activer plusieurs postures en même temps

### Utiliser l'Attaque de Base

1. Posture doit être **ACTIVE**
2. Cliquez **⚔️ ATTAQUE DE BASE**
3. Consomme **1 petit PA**
4. Lance le jet automatiquement
5. Dégâts = **Aptitude Attaque + Base posture**

**Exemple :**
```
Aptitude Attaque: 150
Base posture: +20
→ Dégâts de l'attaque: 170
```

### Utiliser une Technique

1. Posture doit être **ACTIVE**
2. Cliquez sur la technique
3. Vérifie PM et Grand PA disponibles
4. Consomme **PM + 1 Grand PA**
5. Lance le jet
6. Calcule les dégâts selon le style
7. Affiche les effets si réussite

**Formules de dégâts par style :**
- **CAC** : ATQ + (PM ÷ 2) + Base
- **MG** : (ATQ ÷ 2) + PM + Base
- **P** : ATQ + PM + Base
- **EHa** : ATQ + Base (+ 3 jets consécutifs)
- **EHm** : PM + Base (+ 3 jets consécutifs)
- **EF** : PM + Base + (ATQ ÷ 2)
- **BUFF** : Valeur en % (soins, bouclier, bonus)

## 📋 Workflow complet

### Pour le MJ : Création d'un style de combat

1. **Créer la Posture**
   ```
   Nom: "Poing de Fer"
   Attaque Base: +15
   Effet: Bonus dégâts 20%
   Condition: Après 3 attaques réussies
   ```

2. **Créer les Techniques**
   ```
   Technique 1:
   - Nom: "Frappe Tonnerre"
   - Style: CAC
   - PM: 10
   - Base Dégâts: 50
   - Posture Associée: "Poing de Fer"
   
   Technique 2:
   - Nom: "Bouclier de Fer"
   - Style: BUFF
   - PM: 15
   - Buff Type: Réduction dégâts
   - Buff Value: 30%
   - Posture Associée: "Poing de Fer"
   ```

3. **Glisser dans l'inventaire du joueur**
   - Les techniques apparaissent automatiquement dans la posture

### Pour le Joueur : Combat

1. **Début du tour** → Cliquez "🔄 NOUVEAU TOUR"
2. **Activer posture** → Toggle la posture voulue
3. **Actions possibles** :
   - Attaque de base (1 petit PA)
   - Technique (PM + 1 grand PA)
4. **Fin du tour** → Pertes PV automatiques si blessures 7-8

## ✨ Toutes les fonctionnalités v3.0

### ✅ Système de base (v2.1)
- Puissance Magique (Perception + Agilité + Magie)
- Jets inversés (bas = réussite)
- Bonus 1d6/1d12 soustraits
- Multiplicateurs rang sur PV/PM
- Bases d'aptitudes éditables (GM)
- Critiques modifiés automatiques
- Malus fatigue/blessures
- Nouveau tour automatique
- Pertes PV automatiques

### ✅ NOUVEAU : Système Postures & Techniques

- 🥋 **Postures en Items** - Modulaires et réutilisables
- ⚡ **Techniques en Items** - Associées aux postures
- 🔄 **Activation/Désactivation** - Toggle postures
- ⚔️ **Attaque de Base** - Aptitude + Base posture
- 📊 **Calcul automatique** - Dégâts selon style
- 🎯 **Gestion PA/PM** - Consommation automatique
- ✨ **Effets de posture** - 6 types différents
- 🛡️ **Techniques BUFF** - Soins, boucliers, bonus

## 🎨 Avantages du nouveau système

### Pour le MJ
- ✅ Créer des postures réutilisables
- ✅ Partager des styles entre PNJ
- ✅ Modifier depuis le menu Items
- ✅ Pas de limite de postures/techniques
- ✅ Système évolutif et flexible

### Pour les Joueurs
- ✅ Interface claire et organisée
- ✅ Voir seulement la posture active
- ✅ Clic = Action automatique
- ✅ Pas besoin de calculer manuellement
- ✅ Gestion PA/PM automatisée

## 🔧 Conseils d'utilisation

**Nommage des postures :**
- Utilisez des noms uniques et clairs
- La technique doit avoir le **nom EXACT** de la posture

**Organisation :**
- Créez des "packs" : 1 posture + 3-5 techniques
- Utilisez les effets de posture pour le gameplay

**Équilibrage :**
- Base attaque : 10-30 pour postures normales
- PM techniques : 5-20 pour usage fréquent
- Effets posture : Gardez les conditions raisonnables

## 📝 Exemple complet

```
POSTURE: "Danse de l'Ombre"
- Attaque Base: +25
- Effet: Esquive sans PA
- Condition: Si touché par une attaque

TECHNIQUE 1: "Lame Fantôme"
- Style: CAC
- PM: 12
- Base: 40
- Effets: -10% défense ennemi
- Posture: "Danse de l'Ombre"

TECHNIQUE 2: "Voile d'Ombre"
- Style: BUFF
- PM: 15
- Buff: Réduction dégâts 25%
- Posture: "Danse de l'Ombre"
```

---

**Version:** 3.0 FINALE  
**Date:** 1 Février 2026  
**Compatibilité:** Foundry VTT v11+

Bon jeu ! 🎲✨
