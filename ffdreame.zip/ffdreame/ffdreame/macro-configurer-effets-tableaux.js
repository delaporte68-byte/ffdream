// ============================================
// MACRO : Configurer les effets de tableaux
// ============================================
// Cette macro permet de configurer facilement
// les effets passifs de vos tableaux de combat
// ============================================

const actor = game.user.character;

if (!actor) {
  ui.notifications.warn("Vous devez avoir un personnage sélectionné !");
  return;
}

// Types d'effets disponibles avec leurs paramètres par défaut
const typesEffets = {
  "bonus_degats_apres_reussites": {
    nom: "Bonus dégâts après X réussites",
    seuilDefaut: 5,
    bonusDefaut: 50,
    needsSeuil: true,
    needsBonus: true,
    description: "Après {seuil} techniques réussies, +{bonus} dégâts à la prochaine"
  },
  "bonus_pm_apres_reussites": {
    nom: "Récupération PM après X réussites",
    seuilDefaut: 3,
    bonusDefaut: 30,
    needsSeuil: true,
    needsBonus: true,
    description: "Après {seuil} techniques réussies, récupère {bonus} PM"
  },
  "parade_apres_reussites": {
    nom: "Parade après X réussites",
    seuilDefaut: 4,
    bonusDefaut: 0,
    needsSeuil: true,
    needsBonus: false,
    description: "Après {seuil} techniques réussies, jet de parade automatique"
  },
  "initiative_automatique": {
    nom: "Initiative automatique",
    seuilDefaut: 0,
    bonusDefaut: 0,
    needsSeuil: false,
    needsBonus: false,
    description: "Prend l'initiative en début de combat (permanent)"
  },
  "bonus_degats_permanent": {
    nom: "Bonus dégâts permanent",
    seuilDefaut: 0,
    bonusDefaut: 20,
    needsSeuil: false,
    needsBonus: true,
    description: "+{bonus} dégâts à toutes les attaques (permanent)"
  },
  "bonus_pm_permanent": {
    nom: "Bonus PM permanent",
    seuilDefaut: 0,
    bonusDefaut: 50,
    needsSeuil: false,
    needsBonus: true,
    description: "+{bonus} PM max (permanent)"
  },
  "bonus_burste_technique": {
    nom: "Bonus Burste par technique",
    seuilDefaut: 0,
    bonusDefaut: 15,
    needsSeuil: false,
    needsBonus: true,
    description: "+{bonus} Burste par technique au lieu de +10 (permanent)"
  },
  "aucun": {
    nom: "Aucun effet",
    seuilDefaut: 0,
    bonusDefaut: 0,
    needsSeuil: false,
    needsBonus: false,
    description: "Désactive l'effet du tableau"
  }
};

// Contenu du dialogue
const content = `
<form>
  <div class="form-group" style="margin-bottom: 15px;">
    <label><strong>Tableau à configurer</strong></label>
    <select name="tableau" style="width: 100%;">
      <option value="1">Tableau 1 (${actor.system.combat.tableau1.nom})</option>
      <option value="2">Tableau 2 (${actor.system.combat.tableau2.nom})</option>
    </select>
  </div>
  
  <div class="form-group" style="margin-bottom: 15px;">
    <label><strong>Type d'effet</strong></label>
    <select name="type" id="type-effet" style="width: 100%;">
      ${Object.entries(typesEffets).map(([key, data]) => 
        `<option value="${key}">${data.nom}</option>`
      ).join('')}
    </select>
  </div>
  
  <div class="form-group" id="seuil-group" style="margin-bottom: 15px;">
    <label><strong>Seuil (réussites nécessaires)</strong></label>
    <input type="number" name="seuil" value="5" min="1" max="10" style="width: 100%;"/>
    <small style="color: #888;">Nombre de techniques réussies pour activer l'effet</small>
  </div>
  
  <div class="form-group" id="bonus-group" style="margin-bottom: 15px;">
    <label><strong>Bonus</strong></label>
    <input type="number" name="bonus" value="50" min="0" style="width: 100%;"/>
    <small style="color: #888;">Montant du bonus (dégâts, PM, Burste...)</small>
  </div>
  
  <div class="form-group" style="margin-bottom: 15px;">
    <label><strong>Description</strong></label>
    <textarea name="description" rows="3" style="width: 100%;"></textarea>
    <small style="color: #888;">Description personnalisée (optionnelle)</small>
  </div>
  
  <div id="effet-info" style="background: #f0f0f0; padding: 10px; border-radius: 5px; margin-top: 15px;">
    <strong>ℹ️ Info:</strong> <span id="effet-desc"></span>
  </div>
</form>

<style>
  .form-group label {
    display: block;
    margin-bottom: 5px;
    color: #333;
  }
  .form-group input, .form-group select, .form-group textarea {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
  }
</style>
`;

// Créer le dialogue
const dialog = new Dialog({
  title: "⚙️ Configuration des effets de tableau",
  content: content,
  buttons: {
    reset: {
      icon: '<i class="fas fa-undo"></i>',
      label: "Réinitialiser",
      callback: async (html) => {
        const tableau = html.find('[name="tableau"]').val();
        
        await actor.update({
          [`system.combat.tableau${tableau}.effet`]: {
            type: "",
            seuil: 0,
            compteur: 0,
            bonus: 0,
            description: ""
          }
        });
        
        ui.notifications.info(`✅ Effet du tableau ${tableau} réinitialisé`);
      }
    },
    ok: {
      icon: '<i class="fas fa-check"></i>',
      label: "Appliquer",
      callback: async (html) => {
        const tableau = html.find('[name="tableau"]').val();
        const type = html.find('[name="type"]').val();
        const seuil = parseInt(html.find('[name="seuil"]').val()) || 0;
        const bonus = parseInt(html.find('[name="bonus"]').val()) || 0;
        let description = html.find('[name="description"]').val().trim();
        
        // Si pas de description, utiliser celle par défaut
        if (!description && type !== "aucun") {
          description = typesEffets[type].description
            .replace('{seuil}', seuil)
            .replace('{bonus}', bonus);
        }
        
        if (type === "aucun") {
          await actor.update({
            [`system.combat.tableau${tableau}.effet`]: {
              type: "",
              seuil: 0,
              compteur: 0,
              bonus: 0,
              description: ""
            }
          });
          ui.notifications.info(`✅ Effet désactivé sur le tableau ${tableau}`);
        } else {
          await actor.update({
            [`system.combat.tableau${tableau}.effet`]: {
              type: type,
              seuil: seuil,
              compteur: 0,
              bonus: bonus,
              description: description
            }
          });
          
          ui.notifications.info(`✅ Effet "${typesEffets[type].nom}" configuré sur le tableau ${tableau}`);
          
          // Message dans le chat
          ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor }),
            content: `<div style="background: rgba(100, 150, 255, 0.1); padding: 10px; border-left: 3px solid #6496ff;">
                        <h3>⚙️ Configuration d'effet</h3>
                        <p><strong>Tableau ${tableau}</strong> : ${actor.system.combat[`tableau${tableau}`].nom}</p>
                        <p><strong>Effet</strong> : ${typesEffets[type].nom}</p>
                        ${seuil > 0 ? `<p><strong>Seuil</strong> : ${seuil} réussites</p>` : ''}
                        ${bonus > 0 ? `<p><strong>Bonus</strong> : ${bonus}</p>` : ''}
                        <p style="font-style: italic;">${description}</p>
                      </div>`
          });
        }
      }
    },
    cancel: {
      icon: '<i class="fas fa-times"></i>',
      label: "Annuler"
    }
  },
  default: "ok",
  render: (html) => {
    // Fonction pour mettre à jour les champs selon le type sélectionné
    const updateFields = () => {
      const type = html.find('#type-effet').val();
      const typeData = typesEffets[type];
      
      // Afficher/masquer les champs selon le type
      if (typeData.needsSeuil) {
        html.find('#seuil-group').show();
        html.find('[name="seuil"]').val(typeData.seuilDefaut);
      } else {
        html.find('#seuil-group').hide();
      }
      
      if (typeData.needsBonus) {
        html.find('#bonus-group').show();
        html.find('[name="bonus"]').val(typeData.bonusDefaut);
      } else {
        html.find('#bonus-group').hide();
      }
      
      // Mettre à jour la description
      html.find('#effet-desc').text(typeData.description
        .replace('{seuil}', typeData.seuilDefaut)
        .replace('{bonus}', typeData.bonusDefaut)
      );
    };
    
    // Écouter les changements de type
    html.find('#type-effet').on('change', updateFields);
    
    // Initialiser l'affichage
    updateFields();
  }
}, {
  width: 500,
  height: "auto"
});

dialog.render(true);
