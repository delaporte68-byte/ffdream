// ============================================
// MACRO : Configurer Animation de Technique
// ============================================

const actor = game.user.character;

if (!actor) {
  ui.notifications.warn("Sélectionnez un personnage !");
  return;
}

// Liste des techniques du personnage
const techniques = actor.items.filter(i => i.type === "technique");

if (techniques.length === 0) {
  ui.notifications.warn("Aucune technique trouvée !");
  return;
}

// Bibliothèque d'animations rapides
const PRESETS = {
  // PROJECTILES
  "Trait de feu": {
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.fire_bolt.orange",
    scale: 0.8,
    stretchTo: true
  },
  "Rayon de givre": {
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.ray_of_frost.blue",
    scale: 0.8,
    stretchTo: true
  },
  "Éclair": {
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.lightning_bolt.narrow.blue",
    scale: 1.0,
    stretchTo: true
  },
  "Missile magique": {
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.magic_missile.blue",
    scale: 0.7,
    stretchTo: true
  },
  "Flèche": {
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.arrow.physical.white",
    scale: 1.0,
    stretchTo: true
  },
  
  // EXPLOSIONS
  "Boule de feu": {
    library: "jb2a_free",
    type: "explosion",
    path: "jb2a.fireball.beam.orange",
    scale: 1.2,
    stretchTo: false
  },
  "Explosion": {
    library: "jb2a_free",
    type: "explosion",
    path: "jb2a.explosion.orange",
    scale: 1.0,
    stretchTo: false
  },
  "Onde de choc": {
    library: "jb2a_free",
    type: "explosion",
    path: "jb2a.thunderwave.center.blue",
    scale: 1.5,
    stretchTo: false
  },
  "Pics de glace": {
    library: "jb2a_free",
    type: "zone",
    path: "jb2a.ice_spikes.radial.white",
    scale: 1.3,
    stretchTo: false
  },
  
  // MELEE
  "Slash": {
    library: "jb2a_free",
    type: "melee",
    path: "jb2a.melee_generic.slash.01",
    scale: 1.0,
    stretchTo: false
  },
  "Coup": {
    library: "jb2a_free",
    type: "melee",
    path: "jb2a.melee_generic.bludgeoning.01",
    scale: 1.0,
    stretchTo: false
  },
  
  // SOINS/BUFFS
  "Soin": {
    library: "jb2a_free",
    type: "healing",
    path: "jb2a.healing_generic.burst.greenorange",
    scale: 1.0,
    stretchTo: false,
    attachTo: true
  },
  "Bouclier": {
    library: "jb2a_free",
    type: "buff",
    path: "jb2a.shield.01.intro.blue",
    scale: 1.0,
    stretchTo: false,
    attachTo: true
  }
};

// Interface
const content = `
<form>
  <div class="form-group" style="margin-bottom: 15px;">
    <label><strong>Technique</strong></label>
    <select name="technique" style="width: 100%;">
      ${techniques.map(t => `<option value="${t.id}">${t.name}</option>`).join('')}
    </select>
  </div>
  
  <div class="form-group" style="margin-bottom: 15px;">
    <label><strong>Preset d'animation</strong></label>
    <select name="preset" id="preset-select" style="width: 100%;">
      <option value="">-- Personnalisé --</option>
      ${Object.keys(PRESETS).map(name => `<option value="${name}">${name}</option>`).join('')}
    </select>
  </div>
  
  <div id="custom-fields" style="display: none;">
    <div class="form-group" style="margin-bottom: 15px;">
      <label><strong>Bibliothèque</strong></label>
      <select name="library" style="width: 100%;">
        <option value="jb2a_free">JB2A Free</option>
        <option value="eski_free">Eski Effect Free</option>
      </select>
    </div>
    
    <div class="form-group" style="margin-bottom: 15px;">
      <label><strong>Type</strong></label>
      <select name="type" style="width: 100%;">
        <option value="projectile">Projectile</option>
        <option value="explosion">Explosion</option>
        <option value="melee">Corps à corps</option>
        <option value="buff">Buff</option>
        <option value="healing">Soin</option>
        <option value="zone">Zone</option>
      </select>
    </div>
    
    <div class="form-group" style="margin-bottom: 15px;">
      <label><strong>Chemin (path)</strong></label>
      <input type="text" name="path" placeholder="jb2a.fire_bolt.orange" style="width: 100%;"/>
      <small style="color: #888;">Ex: jb2a.fire_bolt.orange</small>
    </div>
    
    <div class="form-group" style="margin-bottom: 15px;">
      <label><strong>Taille (scale)</strong></label>
      <input type="number" name="scale" value="1.0" min="0.1" max="5" step="0.1" style="width: 100%;"/>
      <small style="color: #888;">1.0 = normal, 2.0 = double</small>
    </div>
  </div>
</form>

<style>
  .form-group label {
    display: block;
    margin-bottom: 5px;
    color: #333;
    font-weight: bold;
  }
  .form-group input, .form-group select {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
  }
</style>
`;

const dialog = new Dialog({
  title: "🎬 Configuration Animation",
  content: content,
  buttons: {
    desactiver: {
      icon: '<i class="fas fa-eye-slash"></i>',
      label: "Désactiver",
      callback: async (html) => {
        const techniqueId = html.find('[name="technique"]').val();
        const technique = actor.items.get(techniqueId);
        
        await technique.update({
          'system.animation.enabled': false
        });
        
        ui.notifications.info(`❌ Animation désactivée pour ${technique.name}`);
      }
    },
    ok: {
      icon: '<i class="fas fa-check"></i>',
      label: "Configurer",
      callback: async (html) => {
        const techniqueId = html.find('[name="technique"]').val();
        const technique = actor.items.get(techniqueId);
        const presetName = html.find('[name="preset"]').val();
        
        let config;
        
        if (presetName) {
          // Utiliser un preset
          const preset = PRESETS[presetName];
          config = {
            enabled: true,
            library: preset.library,
            type: preset.type,
            path: preset.path,
            options: {
              scale: preset.scale || 1.0,
              duration: 1000,
              delay: 0,
              repeats: 1,
              opacity: 1.0,
              tint: "",
              anchor: "center",
              waitUntilFinished: -500
            },
            targeting: {
              source: "caster",
              target: "target",
              stretchTo: preset.stretchTo || false,
              attachTo: preset.attachTo || false,
              moveTowards: false,
              teleport: false
            },
            sound: {
              enabled: false,
              file: "",
              volume: 0.8,
              delay: 0
            }
          };
        } else {
          // Configuration personnalisée
          const library = html.find('[name="library"]').val();
          const type = html.find('[name="type"]').val();
          const path = html.find('[name="path"]').val();
          const scale = parseFloat(html.find('[name="scale"]').val()) || 1.0;
          
          if (!path) {
            ui.notifications.warn("Veuillez entrer un chemin d'animation !");
            return;
          }
          
          config = {
            enabled: true,
            library: library,
            type: type,
            path: path,
            options: {
              scale: scale,
              duration: 1000,
              delay: 0,
              repeats: 1,
              opacity: 1.0,
              tint: "",
              anchor: "center",
              waitUntilFinished: -500
            },
            targeting: {
              source: "caster",
              target: "target",
              stretchTo: type === "projectile",
              attachTo: type === "buff" || type === "healing",
              moveTowards: false,
              teleport: false
            },
            sound: {
              enabled: false,
              file: "",
              volume: 0.8,
              delay: 0
            }
          };
        }
        
        await technique.update({
          'system.animation': config
        });
        
        ui.notifications.info(`✅ Animation configurée pour ${technique.name} !`);
        
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div style="background: rgba(100, 150, 255, 0.1); padding: 10px; border-left: 3px solid #6496ff;">
                      <h3>🎬 Animation configurée</h3>
                      <p><strong>Technique</strong> : ${technique.name}</p>
                      <p><strong>Type</strong> : ${config.type}</p>
                      <p><strong>Animation</strong> : ${config.path}</p>
                    </div>`
        });
      }
    },
    cancel: {
      icon: '<i class="fas fa-times"></i>',
      label: "Annuler"
    }
  },
  default: "ok",
  render: (html) => {
    // Toggle custom fields
    const presetSelect = html.find('#preset-select');
    const customFields = html.find('#custom-fields');
    
    presetSelect.on('change', () => {
      if (presetSelect.val() === "") {
        customFields.show();
      } else {
        customFields.hide();
      }
    });
  }
}, {
  width: 500
});

dialog.render(true);
