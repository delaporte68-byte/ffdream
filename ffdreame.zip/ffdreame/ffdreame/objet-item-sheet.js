/**
 * Fiche d'item personnalisée pour les Objets/Techniques
 * @extends {ItemSheet}
 */
export class ObjetItemSheet extends ItemSheet {
    
    /** @override */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["objet-sheet", "sheet", "item"],
            template: "systems/votre-systeme/templates/item/item-objet-sheet.html",
            width: 600,
            height: 700,
            tabs: [{
                navSelector: ".sheet-tabs",
                contentSelector: ".sheet-body",
                initial: "description"
            }]
        });
    }

    /** @override */
    getData() {
        const context = super.getData();
        
        // Récupérer les données de l'item
        const itemData = context.item;
        
        // Ajouter les données système
        context.system = itemData.system;
        context.data = itemData.system; // Pour compatibilité
        
        // Ajouter des helpers
        context.config = CONFIG.OBJET;
        
        return context;
    }

    /** @override */
    activateListeners(html) {
        super.activateListeners(html);

        // Tout est éditable, donc on active tous les listeners
        if (!this.isEditable) return;

        // Bouton pour lancer l'objet/technique
        html.find('.item-use').click(this._onItemUse.bind(this));
    }

    /**
     * Gérer l'utilisation de l'objet/technique
     * @param {Event} event
     * @private
     */
    async _onItemUse(event) {
        event.preventDefault();
        const item = this.item;

        // Vérifier si l'item est possédé par un acteur
        if (!item.actor) {
            ui.notifications.warn("Cet objet doit être possédé par un personnage pour être utilisé.");
            return;
        }

        // Consommer les points de magie
        const coutMagie = item.system.coutMagie || 0;
        const magieActuelle = item.actor.system.magie?.valeur || 0;

        if (magieActuelle < coutMagie) {
            ui.notifications.error("Pas assez de points de magie !");
            return;
        }

        // Calculer les dégâts selon le style
        const degats = this._calculerDegats(item);

        // Lancer le jet de dés
        const roll = await new Roll("1d100").roll({async: true});
        const resultat = roll.total;

        // Déterminer quels effets s'activent
        const effetsActifs = this._determinerEffetsActifs(item, resultat);

        // Afficher le résultat dans le chat
        this._afficherResultatChat(item, degats, resultat, effetsActifs);

        // Consommer les ressources
        await this._consommerRessources(item);

        // Jouer l'animation
        await this._jouerAnimation(item);
    }

    /**
     * Calculer les dégâts selon le style
     * @param {Item} item
     * @returns {number}
     * @private
     */
    _calculerDegats(item) {
        const actor = item.actor;
        const degatsBase = item.system.degatsBase || 0;
        const attaque = actor.system.attaque?.valeur || 0;
        const aptitudeAttaque = actor.system.aptitudeAttaque?.valeur || 0;
        const puissanceMagique = actor.system.puissanceMagique?.valeur || 0;
        
        const style = item.system.styleCalcul || 'cac';
        let degatsFinaux = degatsBase;

        switch(style) {
            case 'cac':
                // Attaque de base + Aptitude attaque + (Puissance magique ÷ 2)
                degatsFinaux += attaque + aptitudeAttaque + Math.floor(puissanceMagique / 2);
                break;
            case 'mag':
                // Attaque de base + Puissance magique + (Attaque ÷ 2)
                degatsFinaux += attaque + puissanceMagique + Math.floor(attaque / 2);
                break;
            case 'pui':
                // Attaque de base + Attaque + Puissance magique
                degatsFinaux += attaque + attaque + puissanceMagique;
                break;
            case 'aoe':
                // Attaque de base + (Attaque ÷ 2) + (Puissance magique ÷ 2)
                degatsFinaux += attaque + Math.floor(attaque / 2) + Math.floor(puissanceMagique / 2);
                break;
        }

        return degatsFinaux;
    }

    /**
     * Déterminer quels effets s'activent selon le résultat du jet
     * @param {Item} item
     * @param {number} resultat
     * @returns {Array}
     * @private
     */
    _determinerEffetsActifs(item, resultat) {
        const effetsActifs = [];

        // Vérifier Effet 1
        if (item.system.effet1?.type) {
            const condition = item.system.effet1.condition || 100;
            if (resultat <= condition) {
                effetsActifs.push({
                    nom: "Effet 1",
                    type: item.system.effet1.type,
                    valeur: item.system.effet1.valeur
                });
            }
        }

        // Vérifier Effet 2
        if (item.system.effet2?.type) {
            const condition = item.system.effet2.condition || 100;
            if (resultat <= condition) {
                effetsActifs.push({
                    nom: "Effet 2",
                    type: item.system.effet2.type,
                    valeur: item.system.effet2.valeur
                });
            }
        }

        return effetsActifs;
    }

    /**
     * Afficher le résultat dans le chat
     * @param {Item} item
     * @param {number} degats
     * @param {number} resultat
     * @param {Array} effetsActifs
     * @private
     */
    async _afficherResultatChat(item, degats, resultat, effetsActifs) {
        const actor = item.actor;
        
        let contenuHTML = `
            <div class="objet-utilisation">
                <h3>${item.name}</h3>
                <p><strong>Utilisé par:</strong> ${actor.name}</p>
                <p><strong>Style:</strong> ${item.system.styleCalcul?.toUpperCase()}</p>
                <p><strong>Dégâts:</strong> ${degats}</p>
                <p><strong>Jet de dés:</strong> ${resultat}</p>
        `;

        if (effetsActifs.length > 0) {
            contenuHTML += `<h4>Effets activés:</h4><ul>`;
            for (const effet of effetsActifs) {
                contenuHTML += `<li><strong>${effet.nom}:</strong> ${effet.type} (${effet.valeur}%)</li>`;
            }
            contenuHTML += `</ul>`;
        }

        contenuHTML += `</div>`;

        ChatMessage.create({
            speaker: ChatMessage.getSpeaker({ actor: actor }),
            content: contenuHTML,
            type: CONST.CHAT_MESSAGE_TYPES.OTHER
        });
    }

    /**
     * Consommer les ressources (magie, actions)
     * @param {Item} item
     * @private
     */
    async _consommerRessources(item) {
        const actor = item.actor;
        const coutMagie = item.system.coutMagie || 0;

        if (coutMagie > 0) {
            const magieActuelle = actor.system.magie?.valeur || 0;
            await actor.update({
                "system.magie.valeur": magieActuelle - coutMagie
            });
        }

        // Gérer les points d'action si nécessaire
        // (à implémenter selon votre système)
    }

    /**
     * Jouer l'animation avec Sequencer ou JB2A
     * @param {Item} item
     * @private
     */
    async _jouerAnimation(item) {
        // Vérifier si Sequencer est disponible
        if (!game.modules.get("sequencer")?.active) {
            console.warn("Sequencer n'est pas activé");
            return;
        }

        const token = item.actor?.getActiveTokens()[0];
        if (!token) return;

        // Animation JB2A
        if (item.system.animation?.jb2a) {
            try {
                new Sequence()
                    .effect()
                    .file(item.system.animation.jb2a)
                    .atLocation(token)
                    .play();
            } catch (error) {
                console.error("Erreur lors de l'animation:", error);
            }
        }

        // Animation Sequencer personnalisée
        if (item.system.animation?.sequencer) {
            try {
                new Sequence()
                    .effect()
                    .file(item.system.animation.sequencer)
                    .atLocation(token)
                    .play();
            } catch (error) {
                console.error("Erreur lors de l'animation Sequencer:", error);
            }
        }
    }
}
