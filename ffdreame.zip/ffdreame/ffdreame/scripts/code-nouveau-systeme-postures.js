/* ================================
   NOUVEAU SYSTÈME POSTURES
   Ajout dans actor-sheet.js
   ================================ */

// Dans getData(), ajouter les helpers Handlebars
async getData() {
  const context = super.getData();
  
  const actorData = this.actor.toObject(false);
  context.system = actorData.system;
  context.flags = actorData.flags;

  // Passer les items
  context.items = this.actor.items.contents;
  context.actor = this.actor;

  context.isGM = game.user.isGM;
  context.rangInfo = this._getRangInfo(context.system.rang);

  return context;
}

// Dans activateListeners(), ajouter les nouveaux écouteurs
activateListeners(html) {
  super.activateListeners(html);

  if (!this.isEditable) return;

  // ... tous les écouteurs existants ...

  // ⭐ NOUVEAU : Bouton "Gérer les techniques"
  html.find('.btn-add-techniques').on('click', this._onOpenTechniqueManager.bind(this));

  // ⭐ NOUVEAU : Bouton délier une technique
  html.find('.btn-unlink-technique').on('click', this._onUnlinkTechnique.bind(this));
}

/* ================================
   OUVRIR LE GESTIONNAIRE DE TECHNIQUES
   ================================ */
async _onOpenTechniqueManager(event) {
  event.preventDefault();
  const button = event.currentTarget;
  const postureId = button.dataset.postureId;
  const postureName = button.dataset.postureName;
  
  // Récupérer toutes les techniques disponibles
  const allTechniques = this.actor.items.filter(i => i.type === "technique");
  
  // Récupérer les techniques déjà liées à cette posture
  const linkedTechniques = allTechniques.filter(t => t.system.postureAssociee === postureName);
  
  // Récupérer les techniques non liées
  const unlinkedTechniques = allTechniques.filter(t => !t.system.postureAssociee || t.system.postureAssociee === "");
  
  // Construire le contenu HTML de la fenêtre
  let content = `
    <div class="technique-manager">
      <h3>Gérer les techniques de : <strong>${postureName}</strong></h3>
      
      <div class="techniques-sections">
        <!-- Techniques déjà liées -->
        <div class="linked-section">
          <h4>✅ Techniques liées (${linkedTechniques.length})</h4>
          <div class="techniques-list">
  `;
  
  if (linkedTechniques.length > 0) {
    linkedTechniques.forEach(tech => {
      content += `
        <div class="technique-row linked" data-tech-id="${tech.id}">
          <span class="tech-name">${tech.name}</span>
          <span class="tech-stats">💎 ${tech.system.coutPM} PM • ⚔️ ${tech.system.baseDegats} dmg</span>
          <button type="button" class="btn-unlink-tech-dialog" data-tech-id="${tech.id}">
            ✖ Délier
          </button>
        </div>
      `;
    });
  } else {
    content += `<p class="no-techniques">Aucune technique liée</p>`;
  }
  
  content += `
          </div>
        </div>
        
        <!-- Techniques disponibles -->
        <div class="available-section">
          <h4>📚 Techniques disponibles (${unlinkedTechniques.length})</h4>
          <div class="techniques-list">
  `;
  
  if (unlinkedTechniques.length > 0) {
    unlinkedTechniques.forEach(tech => {
      content += `
        <div class="technique-row available" data-tech-id="${tech.id}">
          <span class="tech-name">${tech.name}</span>
          <span class="tech-stats">💎 ${tech.system.coutPM} PM • ⚔️ ${tech.system.baseDegats} dmg</span>
          <button type="button" class="btn-link-tech-dialog" data-tech-id="${tech.id}">
            ➕ Lier
          </button>
        </div>
      `;
    });
  } else {
    content += `<p class="no-techniques">Aucune technique disponible</p>`;
  }
  
  content += `
          </div>
        </div>
      </div>
      
      <style>
        .technique-manager h3 { margin-bottom: 15px; color: #667eea; }
        .techniques-sections { display: flex; flex-direction: column; gap: 20px; }
        .linked-section, .available-section { 
          border: 2px solid #e0e0e0; 
          border-radius: 8px; 
          padding: 15px; 
        }
        .linked-section h4 { color: #28a745; margin-bottom: 10px; }
        .available-section h4 { color: #667eea; margin-bottom: 10px; }
        .technique-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px;
          margin: 5px 0;
          border-radius: 5px;
          background: #f8f9fa;
        }
        .technique-row.linked { border-left: 4px solid #28a745; }
        .technique-row.available { border-left: 4px solid #667eea; }
        .tech-name { font-weight: bold; flex: 1; }
        .tech-stats { color: #666; margin: 0 10px; }
        .btn-link-tech-dialog, .btn-unlink-tech-dialog {
          padding: 5px 15px;
          border: none;
          border-radius: 5px;
          font-weight: bold;
          cursor: pointer;
        }
        .btn-link-tech-dialog { background: #51cf66; color: white; }
        .btn-unlink-tech-dialog { background: #ff6b6b; color: white; }
        .no-techniques { color: #999; font-style: italic; text-align: center; padding: 20px; }
      </style>
    </div>
  `;
  
  // Créer le dialog
  new Dialog({
    title: `Gérer les techniques - ${postureName}`,
    content: content,
    buttons: {
      fermer: {
        label: "Fermer",
        callback: () => {}
      }
    },
    render: (html) => {
      // Boutons pour lier une technique
      html.find('.btn-link-tech-dialog').on('click', async (e) => {
        const techId = e.currentTarget.dataset.techId;
        const technique = this.actor.items.get(techId);
        
        if (technique) {
          await technique.update({
            'system.postureAssociee': postureName
          });
          
          ui.notifications.info(`${technique.name} liée à ${postureName}`);
          
          // Fermer et rouvrir le dialog pour rafraîchir
          html.closest('.app').find('.dialog-button.fermer').click();
          setTimeout(() => this._onOpenTechniqueManager(event), 100);
        }
      });
      
      // Boutons pour délier une technique
      html.find('.btn-unlink-tech-dialog').on('click', async (e) => {
        const techId = e.currentTarget.dataset.techId;
        const technique = this.actor.items.get(techId);
        
        if (technique) {
          await technique.update({
            'system.postureAssociee': ''
          });
          
          ui.notifications.info(`${technique.name} déliée de ${postureName}`);
          
          // Fermer et rouvrir le dialog pour rafraîchir
          html.closest('.app').find('.dialog-button.fermer').click();
          setTimeout(() => this._onOpenTechniqueManager(event), 100);
        }
      });
    },
    default: "fermer"
  }, {
    width: 600,
    height: 500
  }).render(true);
}

/* ================================
   DÉLIER UNE TECHNIQUE (depuis la fiche)
   ================================ */
async _onUnlinkTechnique(event) {
  event.preventDefault();
  const button = event.currentTarget;
  const techId = button.dataset.techId;
  const technique = this.actor.items.get(techId);
  
  if (technique) {
    const confirmed = await Dialog.confirm({
      title: "Délier la technique",
      content: `<p>Voulez-vous délier <strong>${technique.name}</strong> de cette posture ?</p>`,
      yes: () => true,
      no: () => false
    });
    
    if (confirmed) {
      await technique.update({
        'system.postureAssociee': ''
      });
      
      ui.notifications.info(`${technique.name} déliée`);
    }
  }
}

/* ================================
   GESTION DES SLOTS DE POSTURES
   ================================ */

// Surcharger _onDropItem pour gérer l'assignation aux slots
async _onDropItem(event, data) {
  if (!this.actor.isOwner) return false;
  
  const item = await Item.implementation.fromDropData(data);
  const itemData = item.toObject();
  
  // Si c'est une posture, vérifier le slot
  if (itemData.type === "posture") {
    const dropZone = event.target.closest('[data-posture-slot]');
    
    if (dropZone) {
      const slot = parseInt(dropZone.dataset.postureSlot);
      
      // Vérifier si le slot est déjà occupé
      const posturesInSlot = this.actor.items.filter(i => 
        i.type === "posture" && i.system.slot === slot
      );
      
      if (posturesInSlot.length > 0) {
        ui.notifications.warn(`Le slot ${slot} est déjà occupé`);
        return false;
      }
      
      // Assigner le slot à la posture
      itemData.system.slot = slot;
    }
  }
  
  // Créer l'item sur l'acteur
  return await this.actor.createEmbeddedDocuments("Item", [itemData]);
}

/* ================================
   HELPERS HANDLEBARS À AJOUTER
   ================================ */

// Dans ffdreame.js, ajouter ces helpers :

Handlebars.registerHelper('getPostureInSlot', function(items, slot) {
  if (!items) return null;
  return items.find(i => i.type === "posture" && i.system.slot === slot);
});

Handlebars.registerHelper('countTechniquesForPosture', function(items, postureName) {
  if (!items || !postureName) return 0;
  return items.filter(i => 
    i.type === "technique" && 
    i.system.postureAssociee === postureName
  ).length;
});
