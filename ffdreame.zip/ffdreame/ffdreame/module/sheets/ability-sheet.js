export default class FFdreameAbilitySheet extends ItemSheet {
  /** @override */
  static get defaultOptions() {
    return mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "item", "ability-sheet"],
      width: 800,
      height: 700,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "description" }],
      dragDrop: [{ dragSelector: null, dropSelector: null }]
    });
  }

  /** @override */
  get template() {
    return `systems/ffdreame/templates/item/ability-sheet.html`;
  }

  /** @override */
  async getData() {
    const context = super.getData();
    context.system = this.item.system;
    return context;
  }

  /** @override */
  activateListeners(html) {
    super.activateListeners(html);

    if (!this.isEditable) return;

    // Aucun événement spécial pour l'instant
    // Tout est géré par le système de formulaire standard de Foundry
  }
}
