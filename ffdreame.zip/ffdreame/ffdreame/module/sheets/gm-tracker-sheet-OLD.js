/**
 * Feuille GM Tracker pour FFdreame
 * Affiche tous les personnages joueurs en temps réel
 */
export class FFdreameGMTrackerSheet extends ActorSheet {

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "gm-tracker"],
      template: "systems/ffdreame/templates/actor/gm-tracker-sheet.html",
      width: 900,
      height: 600,
      resizable: true
    });
  }

  async getData() {
    const context = super.getData();
    
    // Récupérer tous les personnages joueurs
    const characters = game.actors.filter(a => a.type === "character");
    
    // Trier par initiative si elle existe, sinon par nom
    const sortedCharacters = characters.sort((a, b) => {
      const initA = a.system.initiative || 0;
      const initB = b.system.initiative || 0;
      
      if (initA !== initB) {
        return initB - initA; // Initiative décroissante
      }
      
      return a.name.localeCompare(b.name);
    });
    
    // Préparer les données de chaque joueur
    context.trackedPlayers = sortedCharacters.map(actor => {
      return this._preparePlayerData(actor);
    });
    
    return context;
  }

  _preparePlayerData(actor) {
    const system = actor.system;
    
    // PV
    const pvCurrent = system.aptitudes?.pv?.value || 0;
    const pvMax = system.aptitudes?.pv?.max || 1;
    const pvPercent = Math.round((pvCurrent / pvMax) * 100);
    const pvStatus = this._getHealthStatus(pvPercent);
    
    // PM
    const pmCurrent = system.aptitudes?.pm?.value || 0;
    const pmMax = system.aptitudes?.pm?.max || 1;
    const pmPercent = Math.round((pmCurrent / pmMax) * 100);
    const pmStatus = this._getHealthStatus(pmPercent);
    
    // Points d'Action
    const pa = {
      g1p1: system.combat?.actionPoints?.grand1?.petit1 || false,
      g1p2: system.combat?.actionPoints?.grand1?.petit2 || false,
      g2p1: system.combat?.actionPoints?.grand2?.petit1 || false,
      g2p2: system.combat?.actionPoints?.grand2?.petit2 || false,
      g3p1: system.combat?.actionPoints?.grand3?.petit1 || false,
      g3p2: system.combat?.actionPoints?.grand3?.petit2 || false
    };
    
    // Statut global (prend le pire entre PV et PM)
    const healthStatus = this._getWorstStatus(pvStatus, pmStatus);
    
    return {
      id: actor.id,
      name: actor.name,
      initiative: system.initiative || null,
      pvCurrent,
      pvMax,
      pvPercent,
      pvStatus,
      pmCurrent,
      pmMax,
      pmPercent,
      pmStatus,
      pa,
      healthStatus
    };
  }

  _getHealthStatus(percent) {
    if (percent > 70) return 'green';
    if (percent > 30) return 'yellow';
    if (percent > 10) return 'orange';
    return 'red';
  }

  _getWorstStatus(status1, status2) {
    const hierarchy = { 'green': 0, 'yellow': 1, 'orange': 2, 'red': 3 };
    const worst = Math.max(hierarchy[status1] || 0, hierarchy[status2] || 0);
    return Object.keys(hierarchy).find(key => hierarchy[key] === worst);
  }

  activateListeners(html) {
    super.activateListeners(html);
    
    if (!this.isEditable) return;
    
    // Bouton rafraîchir
    html.find('.btn-refresh-tracker').on('click', this._onRefresh.bind(this));
    
    // Clic sur une ligne de joueur pour ouvrir sa fiche
    html.find('.player-row').on('click', this._onPlayerClick.bind(this));
  }

  async _onRefresh(event) {
    event.preventDefault();
    this.render(false);
    ui.notifications.info("🔄 Tracker rafraîchi");
  }

  async _onPlayerClick(event) {
    event.preventDefault();
    const actorId = event.currentTarget.dataset.actorId;
    const actor = game.actors.get(actorId);
    
    if (actor) {
      actor.sheet.render(true);
    }
  }
}
