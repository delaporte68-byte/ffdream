/**
 * CODE JAVASCRIPT À AJOUTER À actor-sheet.js
 * Section : Gestion des cadres d'objets et styles d'attaque
 */

// ===== DANS LA SECTION activateListeners(html) =====
// Ajouter ces lignes après les événements existants :

    // ─── CADRES D'OBJETS : Activation/Désactivation ───
    html.find('input[name^="system.combat.cadreObjets"]').on('change', this._onToggleCadre.bind(this));

    // ─── CADRES D'OBJETS : Utiliser un objet ───
    html.find('.btn-use-objet').on('click', this._onUseObjet.bind(this));

    // ─── CADRES D'OBJETS : Retirer un objet du slot ───
    html.find('.btn-remove-from-slot').on('click', this._onRemoveFromSlot.bind(this));

    // ─── CADRES D'OBJETS : Drag & Drop pour ajouter des objets ───
    html.find('.objet-slot').on('drop', this._onDropObjetInSlot.bind(this));
    html.find('.objet-slot').on('dragover', (ev) => ev.preventDefault());

    // ─── STYLE ATTAQUE : Attaque de base ───
    html.find('.btn-attaque-style').on('click', this._onAttaqueStyle.bind(this));

    // ─── STYLE ULTIME : Lancer l'ultime ───
    html.find('.btn-use-ultimate').on('click', this._onUseUltimeStyle.bind(this));

// ===== MÉTHODES À AJOUTER À LA FIN DE LA CLASSE =====

  /* ================================
     CADRES : Toggle Activation
     ================================ */
  async _onToggleCadre(event) {
    event.preventDefault();
    const input = event.currentTarget;
    const fieldName = input.name;
    const isChecked = input.checked;
    
    await this.actor.update({
      [fieldName]: isChecked
    });
    
    ui.notifications.info(isChecked ? "Cadre activé" : "Cadre désactivé");
  }

  /* ================================
     CADRES : Utiliser un objet
     ================================ */
  async _onUseObjet(event) {
    event.preventDefault();
    const button = event.currentTarget;
    const itemId = button.dataset.itemId;
    
    if (!itemId) return;
    
    const item = this.actor.items.get(itemId);
    if (!item) {
      ui.notifications.warn("Objet introuvable");
      return;
    }
    
    // Vérifier si c'est une technique ou un objet équipement
    if (item.type === "technique") {
      return this._executeTechnique(item);
    } else if (item.type === "equipement") {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        content: `<div class="ffdreame-chat-card">
          <h3>🎒 ${item.name}</h3>
          <p>${item.system.description || "Utilisation de l'objet"}</p>
          ${item.system.bonus ? `<p><strong>Bonus :</strong> ${item.system.bonus}</p>` : ''}
        </div>`
      });
    }
  }

  /* ================================
     CADRES : Retirer un objet du slot
     ================================ */
  async _onRemoveFromSlot(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const button = event.currentTarget;
    const cadre = button.dataset.cadre;
    const slot = parseInt(button.dataset.slot);
    
    const fieldPath = `system.combat.cadreObjets${cadre}.slots.${slot}`;
    
    await this.actor.update({
      [`${fieldPath}.itemId`]: "",
      [`${fieldPath}.itemName`]: "",
      [`${fieldPath}.itemImg`]: ""
    });
    
    ui.notifications.info("Objet retiré du cadre");
  }

  /* ================================
     CADRES : Drop objet dans slot
     ================================ */
  async _onDropObjetInSlot(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const slotElement = event.currentTarget;
    const cadre = slotElement.dataset.cadre;
    const slot = parseInt(slotElement.dataset.slot);
    
    let data;
    try {
      data = JSON.parse(event.dataTransfer.getData('text/plain'));
    } catch (err) {
      return;
    }
    
    if (data.type !== "Item") return;
    
    // Récupérer l'item
    let item;
    if (data.pack) {
      const pack = game.packs.get(data.pack);
      item = await pack.getDocument(data.id);
    } else {
      item = this.actor.items.get(data.id);
    }
    
    if (!item) {
      ui.notifications.warn("Impossible de trouver l'objet");
      return;
    }
    
    // Vérifier que c'est une technique ou un équipement
    if (item.type !== "technique" && item.type !== "equipement") {
      ui.notifications.warn("Seuls les techniques et équipements peuvent être ajoutés aux cadres");
      return;
    }
    
    // Ajouter l'item au slot
    const fieldPath = `system.combat.cadreObjets${cadre}.slots.${slot}`;
    
    await this.actor.update({
      [`${fieldPath}.itemId`]: item.id,
      [`${fieldPath}.itemName`]: item.name,
      [`${fieldPath}.itemImg`]: item.img || "icons/svg/item-bag.svg"
    });
    
    ui.notifications.info(`${item.name} ajouté au Cadre ${cadre}`);
  }

  /* ================================
     STYLE ATTAQUE : Attaque de base
     ================================ */
  async _onAttaqueStyle(event) {
    event.preventDefault();
    
    const degatsBase = parseInt(this.actor.system.combat.styleAttaque.degatsBase) || 0;
    const attaqueTotal = parseInt(this.actor.system.aptitudes.attaque.total) || 0;
    const degatsTotal = degatsBase + attaqueTotal;
    const styleType = this.actor.system.combat.styleAttaque.type || "epee";
    
    // Icônes par type
    const icones = {
      epee: "⚔️",
      baton: "🥢",
      flingue: "🔫",
      arc: "🏹"
    };
    
    const icone = icones[styleType] || "⚔️";
    
    // Consommer 1 point d'action
    const apConsumed = await this._consumeActionPoint();
    if (!apConsumed) {
      ui.notifications.warn("Plus de points d'action disponibles !");
      return;
    }
    
    // Augmenter le Burste
    const nouveauBurste = Math.min((this.actor.system.combat.burste || 0) + 10, 100);
    await this.actor.update({ 'system.combat.burste': nouveauBurste });
    
    // Message de chat
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: `<div class="ffdreame-chat-card attaque-card">
        <h3>${icone} Attaque de Base - ${styleType.charAt(0).toUpperCase() + styleType.slice(1)}</h3>
        <div class="degats-display">
          <i class="fas fa-burst"></i>
          <strong>${degatsTotal} dégâts</strong>
          ${attaqueTotal > 0 ? `<span class="bonus-detail">(${degatsBase} + ${attaqueTotal} attaque)</span>` : ''}
        </div>
        <p class="burste-info">Burste : ${nouveauBurste}/100 (+10)</p>
      </div>`
    });
  }

  /* ================================
     STYLE ULTIME : Lancer l'ultime
     ================================ */
  async _onUseUltimeStyle(event) {
    event.preventDefault();
    
    const burste = this.actor.system.combat.burste || 0;
    if (burste < 100) {
      ui.notifications.warn("Burste insuffisant ! (100 requis)");
      return;
    }
    
    const ultimate = this.actor.system.combat.styleUltime;
    if (!ultimate.nom) {
      ui.notifications.warn("Aucun ultime configuré");
      return;
    }
    
    // Réinitialiser le Burste
    await this.actor.update({ 'system.combat.burste': 0 });
    
    // Icônes
    const iconesMap = {
      "fa-burst": "💥",
      "fa-fire": "🔥",
      "fa-bolt": "⚡",
      "fa-star": "⭐"
    };
    
    const icone = iconesMap[ultimate.icone] || "💥";
    
    // Message de chat
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: `<div class="ffdreame-chat-card ultimate-card-chat">
        <h2 class="ultimate-title">${icone} ${ultimate.nom} ${icone}</h2>
        <p class="ultimate-description">${ultimate.description}</p>
        <div class="ultimate-degats-mega">
          <i class="fas fa-explosion"></i>
          <strong>${ultimate.degats} DÉGÂTS</strong>
        </div>
        <p class="burste-reset">💫 Burste réinitialisé à 0</p>
      </div>`,
      sound: "sounds/combat/ultimate.ogg"
    });
    
    ui.notifications.info(`🔥 ${ultimate.nom} déclenché !`);
  }

  /* ================================
     HELPER : Consommer un point d'action
     ================================ */
  async _consumeActionPoint() {
    const actionPoints = this.actor.system.combat.actionPoints;
    
    // Chercher le premier point d'action disponible
    for (let i = 1; i <= 3; i++) {
      const grand = actionPoints[`grand${i}`];
      if (grand.petit1) {
        await this.actor.update({
          [`system.combat.actionPoints.grand${i}.petit1`]: false
        });
        return true;
      } else if (grand.petit2) {
        await this.actor.update({
          [`system.combat.actionPoints.grand${i}.petit2`]: false
        });
        return true;
      }
    }
    
    return false;
  }

  /* ================================
     HELPER : Exécuter une technique
     ================================ */
  async _executeTechnique(item) {
    const coutPM = parseInt(item.system.coutPM) || 0;
    const pmActuels = parseInt(this.actor.system.aptitudes.pm.value) || 0;
    
    if (pmActuels < coutPM) {
      ui.notifications.warn("PM insuffisants !");
      return;
    }
    
    // Consommer les PM
    await this.actor.update({
      'system.aptitudes.pm.value': pmActuels - coutPM
    });
    
    // Consommer un point d'action
    const apConsumed = await this._consumeActionPoint();
    if (!apConsumed) {
      ui.notifications.warn("Plus de points d'action disponibles !");
      // Rembourser les PM
      await this.actor.update({
        'system.aptitudes.pm.value': pmActuels
      });
      return;
    }
    
    // Calculer les dégâts
    const baseDegats = parseInt(item.system.baseDegats) || 0;
    const puissanceMagique = parseInt(this.actor.system.aptitudes.puissanceMagique.total) || 0;
    const degatsTotal = baseDegats + puissanceMagique;
    
    // Augmenter le Burste
    const nouveauBurste = Math.min((this.actor.system.combat.burste || 0) + 10, 100);
    await this.actor.update({ 'system.combat.burste': nouveauBurste });
    
    // Message de chat
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      content: `<div class="ffdreame-chat-card technique-card">
        <h3>✨ ${item.name}</h3>
        <p>${item.system.description || ''}</p>
        <div class="technique-info">
          <span class="pm-cost">💙 -${coutPM} PM</span>
          <span class="degats">${degatsTotal} dégâts</span>
          <span class="style">Style : ${item.system.style}</span>
        </div>
        ${item.system.effets ? `<p class="effets"><strong>Effets :</strong> ${item.system.effets}</p>` : ''}
        <p class="burste-info">Burste : ${nouveauBurste}/100 (+10)</p>
      </div>`
    });
  }
