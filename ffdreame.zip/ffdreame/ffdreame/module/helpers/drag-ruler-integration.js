/**
 * ============================================
 * INTÉGRATION DRAG RULER POUR FFDREAME
 * ============================================
 * Configure Drag Ruler pour utiliser l'athlétisme FFdreame
 * et afficher visuellement les limites de déplacement
 */

export class FFdreameDragRulerIntegration {
  
  /**
   * Initialiser l'intégration Drag Ruler
   */
  static init() {
    // Attendre que Drag Ruler soit chargé
    Hooks.once('dragRuler.ready', (SpeedProvider) => {
      console.log('FFdreame | Configuration de Drag Ruler...');
      
      class FFdreameSpeedProvider extends SpeedProvider {
        
        /**
         * Définit les couleurs pour les zones de déplacement
         */
        get colors() {
          return [
            { 
              id: "normal", 
              default: 0x00FF00, // Vert
              name: "ffdreame.movement.normal" 
            },
            { 
              id: "warning", 
              default: 0xFFAA00, // Orange
              name: "ffdreame.movement.warning" 
            },
            { 
              id: "blocked", 
              default: 0xFF0000, // Rouge
              name: "ffdreame.movement.blocked" 
            }
          ];
        }
        
        /**
         * Calcule les zones de déplacement pour un token
         * @param {Token} token - Le token à vérifier
         * @returns {Array} - Tableau de zones avec distances et couleurs
         */
        getRanges(token) {
          const actor = token.actor;
          
          // ==================================
          // PAS DE LIMITE POUR NON-PJ
          // ==================================
          if (!actor || (actor.type !== "character" && actor.type !== "cyberpunk")) {
            return [
              { range: 9999, color: "normal" }
            ];
          }
          
          // ==================================
          // VÉRIFIER SI LE PERSONNAGE EST MORT
          // ==================================
          const pvActuel = actor.system.aptitudes?.pv?.value || 0;
          if (pvActuel <= 0) {
            console.log(`FFdreame | ${actor.name} est mort → Déplacement: 0`);
            return [
              { range: 0, color: "blocked" }
            ];
          }
          
          // ==================================
          // VÉRIFIER LE DÉPLACEMENT GRATUIT
          // ==================================
          const deplacementGratuitUtilise = actor.system.combat?.deplacementGratuitUtilise || false;
          const marcheActive = actor.system.combat?.reactions?.marche || false;
          
          if (deplacementGratuitUtilise && !marcheActive) {
            console.log(`FFdreame | ${actor.name} a déjà utilisé son déplacement gratuit → Déplacement: 0`);
            return [
              { range: 0, color: "blocked" }
            ];
          }
          
          // ==================================
          // CALCULER LA DISTANCE MAXIMALE
          // ==================================
          const athletisme = actor.system.physique?.athletisme?.value || 0;
          const deplacementMetres = 2 + athletisme; // Formule: 2m base + Athlétisme
          
          // Convertir en unités de grille
          const gridDistance = canvas.scene.grid.distance || 1.5;
          const distanceMaxUnites = deplacementMetres / gridDistance;
          
          // Zone de sécurité (90% = vert)
          const zoneSafe = distanceMaxUnites * 0.9;
          
          console.log(`FFdreame | ${actor.name} - Athlétisme: ${athletisme} → Déplacement max: ${deplacementMetres}m (${distanceMaxUnites.toFixed(2)} unités)`);
          
          // ==================================
          // RETOURNER LES ZONES
          // ==================================
          return [
            { 
              range: zoneSafe, 
              color: "normal" // Vert : OK
            },
            { 
              range: distanceMaxUnites, 
              color: "warning" // Orange : Proche de la limite
            },
            { 
              range: 9999, 
              color: "blocked" // Rouge : Interdit
            }
          ];
        }
      }
      
      // Enregistrer le provider FFdreame
      dragRuler.registerSystem("ffdreame", FFdreameSpeedProvider);
      console.log("FFdreame | Drag Ruler configuré avec succès ✅");
    });
  }
}
