/* ============================================
   BIBLIOTHÈQUE D'ANIMATIONS COMPLÈTE
   JB2A Free, JB2A Patreon, Eski Effect Free
   ============================================ */

export const ANIMATION_LIBRARY = {
  
  /* ================================
     JB2A FREE - Animations gratuites
     ================================ */
  jb2a_free: {
    
    // PROJECTILES
    projectiles: {
      "Éclair": {
        path: "jb2a.lightning_bolt.narrow.blue",
        type: "projectile",
        color: "blue"
      },
      "Rayon de givre": {
        path: "jb2a.ray_of_frost.blue",
        type: "projectile",
        color: "blue"
      },
      "Trait de feu": {
        path: "jb2a.fire_bolt.orange",
        type: "projectile",
        color: "orange"
      },
      "Missile magique": {
        path: "jb2a.magic_missile.blue",
        type: "projectile",
        color: "blue"
      },
      "Rayon scorchant": {
        path: "jb2a.scorching_ray.01.orange",
        type: "projectile",
        color: "orange"
      },
      "Flèche": {
        path: "jb2a.arrow.physical.white",
        type: "projectile",
        color: "white"
      },
      "Projectile d'acide": {
        path: "jb2a.acid_splash.01.green",
        type: "projectile",
        color: "green"
      }
    },
    
    // EXPLOSIONS
    explosions: {
      "Explosion de feu": {
        path: "jb2a.explosion.orange",
        type: "explosion",
        color: "orange"
      },
      "Explosion de glace": {
        path: "jb2a.explosion.blue",
        type: "explosion",
        color: "blue"
      },
      "Boule de feu": {
        path: "jb2a.fireball.beam.orange",
        type: "explosion",
        color: "orange"
      },
      "Impact": {
        path: "jb2a.impact.ground_crack.blue",
        type: "explosion",
        color: "blue"
      },
      "Onde de choc": {
        path: "jb2a.thunderwave.center.blue",
        type: "explosion",
        color: "blue"
      }
    },
    
    // CORPS À CORPS
    melee: {
      "Slash": {
        path: "jb2a.melee_generic.slash.01",
        type: "melee",
        color: "white"
      },
      "Coup": {
        path: "jb2a.melee_generic.bludgeoning.01",
        type: "melee",
        color: "white"
      },
      "Piqûre": {
        path: "jb2a.melee_generic.piercing.01",
        type: "melee",
        color: "white"
      }
    },
    
    // BUFFS / SOINS
    buffs: {
      "Soin": {
        path: "jb2a.healing_generic.burst.greenorange",
        type: "buff",
        color: "green"
      },
      "Bouclier": {
        path: "jb2a.shield.01.intro.blue",
        type: "buff",
        color: "blue"
      },
      "Bénédiction": {
        path: "jb2a.bless.400px.intro.blue",
        type: "buff",
        color: "blue"
      }
    },
    
    // ZONES
    zones: {
      "Mur de feu": {
        path: "jb2a.wall_of_fire.100ft.orange",
        type: "zone",
        color: "orange"
      },
      "Tempête de grêle": {
        path: "jb2a.sleet_storm.blue",
        type: "zone",
        color: "blue"
      },
      "Pics de glace": {
        path: "jb2a.ice_spikes.radial.white",
        type: "zone",
        color: "white"
      }
    }
  },
  
  /* ================================
     ESKI EFFECT FREE - Animations 3D
     ================================ */
  eski_free: {
    
    // PROJECTILES MAGIQUES
    projectiles: {
      "Orbe d'énergie": {
        path: "modules/eskieffects-free/effects/magic/energy_orb_01_regular_blue_30ft_1000x400.webm",
        type: "projectile",
        color: "blue"
      },
      "Rayon de lumière": {
        path: "modules/eskieffects-free/effects/magic/light_ray_01_regular_white_30ft_1600x400.webm",
        type: "projectile",
        color: "white"
      },
      "Projectile de feu": {
        path: "modules/eskieffects-free/effects/magic/fire_bolt_01_regular_orange_30ft_1600x400.webm",
        type: "projectile",
        color: "orange"
      }
    },
    
    // EXPLOSIONS 3D
    explosions: {
      "Explosion magique": {
        path: "modules/eskieffects-free/effects/magic/explosion_01_regular_blue_400x400.webm",
        type: "explosion",
        color: "blue"
      },
      "Explosion de flammes": {
        path: "modules/eskieffects-free/effects/magic/fire_explosion_01_regular_orange_400x400.webm",
        type: "explosion",
        color: "orange"
      }
    },
    
    // BUFFS / AURAS
    buffs: {
      "Aura de protection": {
        path: "modules/eskieffects-free/effects/magic/shield_01_regular_blue_400x400.webm",
        type: "buff",
        color: "blue"
      },
      "Soin divin": {
        path: "modules/eskieffects-free/effects/magic/healing_01_regular_green_400x400.webm",
        type: "buff",
        color: "green"
      }
    }
  }
};

/* ================================
   PRESETS PAR STYLE DE TECHNIQUE
   ================================ */
export const ANIMATION_PRESETS = {
  
  // ATTA - Attaque physique
  atta: {
    recommended: [
      { lib: "jb2a_free", category: "melee", name: "Slash" },
      { lib: "jb2a_free", category: "melee", name: "Coup" },
      { lib: "jb2a_free", category: "projectiles", name: "Flèche" }
    ]
  },
  
  // ATTM - Attaque magique
  attm: {
    recommended: [
      { lib: "jb2a_free", category: "projectiles", name: "Trait de feu" },
      { lib: "jb2a_free", category: "projectiles", name: "Rayon de givre" },
      { lib: "jb2a_free", category: "projectiles", name: "Éclair" },
      { lib: "eski_free", category: "projectiles", name: "Orbe d'énergie" }
    ]
  },
  
  // MULTI - Multi-cibles
  multi: {
    recommended: [
      { lib: "jb2a_free", category: "explosions", name: "Boule de feu" },
      { lib: "jb2a_free", category: "explosions", name: "Onde de choc" },
      { lib: "jb2a_free", category: "zones", name: "Pics de glace" },
      { lib: "eski_free", category: "explosions", name: "Explosion magique" }
    ]
  },
  
  // CUR - Soins
  cur: {
    recommended: [
      { lib: "jb2a_free", category: "buffs", name: "Soin" },
      { lib: "eski_free", category: "buffs", name: "Soin divin" }
    ]
  },
  
  // DEF - Défense
  def: {
    recommended: [
      { lib: "jb2a_free", category: "buffs", name: "Bouclier" },
      { lib: "eski_free", category: "buffs", name: "Aura de protection" }
    ]
  },
  
  // ULTIM - Ultimate
  ultim: {
    recommended: [
      { lib: "jb2a_free", category: "explosions", name: "Explosion de feu" },
      { lib: "jb2a_free", category: "zones", name: "Tempête de grêle" },
      { lib: "eski_free", category: "explosions", name: "Explosion de flammes" }
    ]
  }
};

/* ================================
   HELPER: OBTENIR CONFIGURATION COMPLÈTE
   ================================ */
export function getAnimationConfig(library, category, name) {
  const anim = ANIMATION_LIBRARY[library]?.[category]?.[name];
  
  if (!anim) {
    console.warn(`Animation non trouvée: ${library} / ${category} / ${name}`);
    return null;
  }
  
  return {
    path: anim.path,
    type: anim.type,
    color: anim.color,
    library: library
  };
}

/* ================================
   HELPER: OBTENIR RECOMMANDATIONS PAR STYLE
   ================================ */
export function getRecommendedAnimations(style) {
  return ANIMATION_PRESETS[style]?.recommended || [];
}
