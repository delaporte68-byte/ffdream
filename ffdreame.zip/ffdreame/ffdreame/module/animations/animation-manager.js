export class AnimationManager {
  
  static async playAnimation(technique, sourceToken, targetToken = null) {
    const animation = technique.system.animation;
    
    if (!animation || !animation.enabled || !animation.path) return;
    if (!game.modules.get("sequencer")?.active) return;
    
    try {
      const sequence = new Sequence();
      const effect = sequence.effect().file(animation.path);
      
      // Source et cible
      effect.atLocation(sourceToken);
      
      if (targetToken && animation.targeting.stretchTo) {
        effect.stretchTo(targetToken);
      }
      
      if (targetToken && animation.targeting.attachTo) {
        effect.attachTo(targetToken);
      }
      
      // Options
      if (animation.options.scale !== 1.0) effect.scale(animation.options.scale);
      if (animation.options.duration) effect.duration(animation.options.duration);
      if (animation.options.delay) effect.delay(animation.options.delay);
      if (animation.options.opacity !== 1.0) effect.opacity(animation.options.opacity);
      
      await sequence.play();
    } catch (error) {
      console.warn("⚠️ Erreur animation:", error);
    }
  }
}
