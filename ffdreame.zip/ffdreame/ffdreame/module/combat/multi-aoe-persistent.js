/**
 * ============================================
 * SYSTÈME MULTI-AOE PERSISTANT
 * ============================================
 * Zones d'effet qui restent sur le terrain pendant
 * N rounds. Chaque token qui commence son tour
 * à l'intérieur subit les dégâts ou reçoit le buff.
 *
 * Stockage : MeasuredTemplate + flags ffdreame.multiaoe
 * Animation : Sequencer .persist() + .name() pour cleanup
 *
 * Hooks :
 *   updateCombat → startTurn → vérifier zones actives
 *   updateCombat → newRound  → décrémenter durées + supprimer expirées
 */

export class FFdreameMultiAOE {

  /* ─── Clé de préfixe pour nommer les animations Sequencer ─── */
  static ANIM_PREFIX = "ffdreame-multiaoe-";

  /* ============================================
     INIT — Enregistrer les hooks Foundry
     ============================================ */
  static init() {
    console.log("FFdreame | Initialisation MultiAOE persistant...");
    Hooks.on("updateCombat", this._onUpdateCombat.bind(this));
    console.log("FFdreame | MultiAOE activé ✅");
  }

  /* ============================================
     POINT D'ENTRÉE — Depuis actor-sheet.js
     ============================================ */
  static async useTechniqueMultiAOE(actor, technique) {
    const config = technique.system.multiaoe || {};
    const token  = actor.getActiveTokens()[0];

    if (!token) {
      ui.notifications.warn("❌ Aucun token trouvé !");
      return { success: false, consumed: false };
    }

    const forme = config.forme || "cercle";

    // ── Placement avec preview live ──
    let placement = null;
    if (forme === "ligne") {
      placement = await this._placerLigne(token, config);
    } else {
      placement = await this._placerCercle(token, config);
    }

    if (!placement) {
      return { success: false, consumed: false };
    }

    // ── Jet de dés ──
    const jetResult = await this._lancerDe(actor);
    await this._chatJet(actor, technique, jetResult, config, placement);

    if (!jetResult.success) {
      ui.notifications.warn("❌ Technique ratée !");
      return { success: false, failed: true, consumed: true };
    }

    // ── Créer la zone persistante ──
    const zoneId = await this._creerZone(actor, technique, placement, config, jetResult);

    // ── Message de confirmation ──
    const duree = config.duree || 3;
    const typeZone = config.typeEffet === "buff" ? "Zone de Buff" : "Zone de Dégâts";
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div style="background:rgba(138,43,226,.15);border-left:4px solid #8a2be2;padding:10px 14px;border-radius:7px">
          <h3 style="color:#c084fc;margin:0 0 6px">🌀 ZONE PERSISTANTE — ${technique.name}</h3>
          <p style="color:#aaa;font-size:11px;margin:0 0 4px">${typeZone} | ${forme} | Durée : <b>${duree} round${duree>1?'s':''}</b></p>
          <p style="color:#aaa;font-size:11px;margin:0">⚠️ Tout token commençant son tour dans la zone
          ${config.typeEffet === "buff" ? "reçoit le buff" : `subit <b>${technique.system.baseDegats || 0} dégâts</b>`}
          </p>
        </div>
      `
    });

    return { success: true, consumed: true };
  }

  /* ============================================
     PLACEMENT CERCLE — Preview PIXI live
     ============================================ */
  static async _placerCercle(sourceToken, config) {
    const distMax  = config.distanceMax || 8;
    const taille   = config.taille  || 3;
    const gridSize = canvas.grid.size;
    const rayonPx  = taille * gridSize;

    const preview = this._buildPreviewCercle();
    canvas.stage.addChild(preview);

    ui.notifications.info(`🌀 Zone persistante — Placez le cercle (rayon ${taille} cases, max ${distMax}) | Clic droit = annuler`);

    return new Promise(resolve => {
      let lastPos = null;

      const onMove = e => {
        lastPos = e.data.getLocalPosition(canvas.stage);
        const dist = this._dist(sourceToken.center, lastPos, gridSize);
        this._updatePreviewCercle(preview, lastPos, rayonPx, dist <= distMax, dist, distMax);
      };

      const onClick = async () => {
        if (!lastPos) return;
        const dist = this._dist(sourceToken.center, lastPos, gridSize);
        cleanup();
        if (dist > distMax) {
          ui.notifications.warn(`❌ Trop loin (${dist.toFixed(1)} / ${distMax})`);
          resolve(null);
          return;
        }
        resolve({ forme: "cercle", x: lastPos.x, y: lastPos.y, taille, rayonPx });
      };

      const onCancel = () => { cleanup(); ui.notifications.info("❌ Annulé"); resolve(null); };
      const onKey    = e => { if (e.key === "Escape") onCancel(); };

      const cleanup = () => {
        canvas.stage.off("pointermove", onMove);
        canvas.stage.off("click",       onClick);
        canvas.stage.off("rightclick",  onCancel);
        window.removeEventListener("keydown", onKey);
        try { preview.destroy(); } catch(e) {}
      };

      canvas.stage.on("pointermove", onMove);
      canvas.stage.on("click",       onClick);
      canvas.stage.on("rightclick",  onCancel);
      window.addEventListener("keydown", onKey);
    });
  }

  /* ============================================
     PLACEMENT LIGNE — Preview PIXI live
     ============================================ */
  static async _placerLigne(sourceToken, config) {
    const distMax    = config.distanceMax || 8;
    const largeur    = config.taille      || 2;
    const gridSize   = canvas.grid.size;
    const largeurPx  = largeur * gridSize;
    const src        = sourceToken.center;

    const preview = this._buildPreviewLigne();
    canvas.stage.addChild(preview);

    ui.notifications.info(`🌀 Zone persistante — Orientez la ligne (largeur ${largeur} cases, max ${distMax}) | Clic droit = annuler`);

    return new Promise(resolve => {
      let lastPos = null;

      const onMove = e => {
        lastPos = e.data.getLocalPosition(canvas.stage);
        const dist = this._dist(src, lastPos, gridSize);
        this._updatePreviewLigne(preview, src, lastPos, largeurPx, dist <= distMax, dist, distMax);
      };

      const onClick = async () => {
        if (!lastPos) return;
        const dist = this._dist(src, lastPos, gridSize);
        const targetToken = canvas.tokens.hover;
        const targetPos   = targetToken ? targetToken.center : lastPos;
        cleanup();
        if (dist > distMax) {
          ui.notifications.warn(`❌ Trop loin (${dist.toFixed(1)} / ${distMax})`);
          resolve(null);
          return;
        }
        // angle pour le template ray
        const dx  = targetPos.x - src.x;
        const dy  = targetPos.y - src.y;
        const dir = (Math.atan2(dy, dx * 180 / Math.PI));
        resolve({ forme: "ligne", x: src.x, y: src.y, tx: targetPos.x, ty: targetPos.y,
                  taille: largeur, largeurPx, direction: dir, distance: dist });
      };

      const onCancel = () => { cleanup(); ui.notifications.info("❌ Annulé"); resolve(null); };
      const onKey    = e => { if (e.key === "Escape") onCancel(); };

      const cleanup = () => {
        canvas.stage.off("pointermove", onMove);
        canvas.stage.off("click",       onClick);
        canvas.stage.off("rightclick",  onCancel);
        window.removeEventListener("keydown", onKey);
        try { preview.destroy(); } catch(e) {}
      };

      canvas.stage.on("pointermove", onMove);
      canvas.stage.on("click",       onClick);
      canvas.stage.on("rightclick",  onCancel);
      window.addEventListener("keydown", onKey);
    });
  }

  /* ============================================
     CRÉER LA ZONE PERSISTANTE
     ============================================ */
  static async _creerZone(actor, technique, placement, config, jetResult) {
    const duree      = config.duree      || 3;
    const roundActuel = game.combat?.round ?? 0;
    const zoneId     = foundry.utils.randomID(12);
    const typeEffet  = config.typeEffet  || "degats";
    const couleur    = typeEffet === "buff" ? "#00d9ff" : "#8a2be2";

    // ── Template Foundry (visible sur la carte) ──
    const templateData = {
      user: game.user.id,
      fillColor: couleur,
      borderColor: couleur,
      flags: {
        ffdreame: {
          multiaoeZone: true,
          zoneId,
          lanceurId:    actor.id,
          techniqueId:  technique.id,
          techniqueName: technique.name,
          // Dégâts
          baseDegats:   technique.system.baseDegats || 0,
          // Buff (si typeEffet = buff)
          typeEffet,
          buffType:     config.buffType  || null,
          buffValeur:   config.buffValeur|| 0,
          buffDuree:    config.buffDuree || 1,
          // Durée de la zone
          roundCreation:  roundActuel,
          roundExpiration: roundActuel + duree,
          dureeRestante:   duree,
          // Pour animation
          animation:    technique.system.animation?.jb2a || null,
          animDuree:    technique.system.animation?.duree || 3,
          // Géométrie
          forme: placement.forme,
          taille: placement.taille || config.taille || 3
        }
      }
    };

    if (placement.forme === "cercle") {
      templateData.t        = "circle";
      templateData.x        = placement.x;
      templateData.y        = placement.y;
      templateData.distance = placement.taille;
    } else {
      templateData.t        = "ray";
      templateData.x        = placement.x;
      templateData.y        = placement.y;
      templateData.distance = placement.distance;
      templateData.width    = placement.taille;
      templateData.direction= placement.direction;
    }

    const docs = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]);
    const tpl  = docs[0];
    console.log(`✅ MultiAOE zone créée : ${zoneId} | expiration round ${roundActuel + duree}`);

    // ── Animation Sequencer persistante ──
    await this._lancerAnimationPersistante(tpl, zoneId, technique, placement);

    return zoneId;
  }

  /* ============================================
     ANIMATION PERSISTANTE (Sequencer .persist())
     ============================================ */
  static async _lancerAnimationPersistante(template, zoneId, technique, placement) {
    const jb2a = technique.system.animation?.jb2a;
    if (!jb2a || typeof Sequence === "undefined") return;

    try {
      const pos     = { x: template.x, y: template.y };
      const taille  = (template.distance || 3) * canvas.grid.size;
      const animNom = this.ANIM_PREFIX + zoneId;

      await new Sequence()
        .effect()
          .file(jb2a)
          .atLocation(pos)
          .size(taille * 2, { gridUnits: false })
          .persist()               // ← reste actif indéfiniment
          .name(animNom)           // ← permet de la stopper avec endEffects
          .fadeIn(400)
          .opacity(0.75)
        .play();

      console.log(`🎬 Animation persistante démarrée : ${animNom}`);
    } catch (e) {
      console.error("FFdreame | MultiAOE animation :", e);
    }
  }

  /* ============================================
     STOPPER L'ANIMATION D'UNE ZONE
     ============================================ */
  static async _stopperAnimation(zoneId) {
    if (typeof Sequence === "undefined") return;
    try {
      await Sequencer.EffectManager.endEffects({ name: this.ANIM_PREFIX + zoneId });
      console.log(`🛑 Animation stoppée : ${this.ANIM_PREFIX + zoneId}`);
    } catch (e) {
      console.warn("FFdreame | MultiAOE stop anim :", e);
    }
  }

  /* ============================================
     HOOK updateCombat
     Déclenché à chaque changement de tour/round
     ============================================ */
  static async _onUpdateCombat(combat, changed, options, userId) {
    // ── Changement de tour → appliquer effets au combattant actif ──
    if (changed.turn !== undefined) {
      const combatant = combat.combatant;
      if (combatant?.actor) {
        await this._appliquerEffetsZones(combatant.actor, combat);
      }
    }

    // ── Nouveau round → décrémenter durées ──
    if (changed.round !== undefined && changed.round > (combat.previous?.round ?? 0)) {
      await this._decrementerZones(combat);
    }
  }

  /* ============================================
     APPLIQUER EFFETS AU TOKEN QUI COMMENCE SON TOUR
     ============================================ */
  static async _appliquerEffetsZones(actor, combat) {
    if (!canvas.templates) return;

    const zones = canvas.templates.placeables.filter(t =>
      t.document.getFlag("ffdreame", "multiaoeZone")
    );

    if (zones.length === 0) return;

    const token = actor.getActiveTokens()[0];
    if (!token) return;

    for (const zone of zones) {
      const zoneData = zone.document.flags?.ffdreame;
      if (!zoneData) continue;

      // Le lanceur n'est jamais affecté par sa propre zone
      if (zoneData.lanceurId === actor.id) continue;

      if (!this._tokenDansZone(token, zone.document)) continue;

      console.log(`🌀 ${actor.name} est dans la zone ${zoneData.techniqueName}`);

      // ── Dégâts ──
      if (zoneData.typeEffet !== "buff") {
        const degats    = zoneData.baseDegats || 0;
        const pvActuel  = actor.system.aptitudes.pv.value;
        const pvApres   = Math.max(0, pvActuel - degats);
        await actor.update({ "system.aptitudes.pv.value": pvApres });

        ChatMessage.create({
          speaker: { alias: zoneData.techniqueName },
          content: `
            <div style="background:rgba(138,43,226,.12);border-left:3px solid #8a2be2;padding:7px 11px;border-radius:6px">
              <b>🌀 ${zoneData.techniqueName}</b>
              — <b>${actor.name}</b> subit <span style="color:#ff4444"><b>${degats} dégâts</b></span>
              <span style="color:#555"> | PV : ${pvActuel}→${pvApres}</span>
              ${pvApres === 0 ? " 💀 <b>K.O.</b>" : ""}
            </div>
          `
        });
      }

      // ── Buff ──
      if (zoneData.typeEffet === "buff" || zoneData.typeEffet === "both") {
        await this._appliquerBuff(actor, zoneData);
      }
    }
  }

  /* ── Appliquer le buff selon buffType ── */
  static async _appliquerBuff(actor, zoneData) {
    const type  = zoneData.buffType;
    const val   = zoneData.buffValeur  || 0;
    const duree = zoneData.buffDuree   || 1;
    if (!type) return;

    if (type === "soins") {
      const pvActuel = actor.system.aptitudes.pv.value;
      const pvMax    = actor.system.aptitudes.pv.max;
      const pvApres  = Math.min(pvMax, pvActuel + val);
      await actor.update({ "system.aptitudes.pv.value": pvApres });
      ChatMessage.create({
        speaker: { alias: zoneData.techniqueName },
        content: `<div style="background:rgba(68,255,136,.1);border-left:3px solid #44ff88;padding:6px 10px;border-radius:5px;font-size:11px">
          💚 <b>${actor.name}</b> récupère <b>${val} PV</b> (zone ${zoneData.techniqueName})
        </div>`
      });
    }

    if (type === "bufpa") {
      // Utilise _appliquerBufPA de l'acteur via la sheet
      const sheet = actor.sheet;
      if (sheet && typeof sheet._appliquerBufPA === "function") {
        await sheet._appliquerBufPA(1, duree);
      }
    }

    if (type === "soins_pm") {
      const pmActuel = actor.system.aptitudes.pm.value;
      const pmMax    = actor.system.aptitudes.pm.max;
      const pmApres  = Math.min(pmMax, pmActuel + val);
      await actor.update({ "system.aptitudes.pm.value": pmApres });
      ChatMessage.create({
        speaker: { alias: zoneData.techniqueName },
        content: `<div style="background:rgba(0,217,255,.1);border-left:3px solid #00d9ff;padding:6px 10px;border-radius:5px;font-size:11px">
          💙 <b>${actor.name}</b> récupère <b>${val} PM</b> (zone ${zoneData.techniqueName})
        </div>`
      });
    }

    console.log(`✨ Buff ${type} appliqué à ${actor.name} depuis zone ${zoneData.techniqueName}`);
  }

  /* ============================================
     DÉCRÉMENTER DURÉES — appelé à chaque nouveau round
     ============================================ */
  static async _decrementerZones(combat) {
    if (!canvas.templates) return;

    const zones = canvas.templates.placeables.filter(t =>
      t.document.getFlag("ffdreame", "multiaoeZone")
    );

    for (const zone of zones) {
      const zoneData = zone.document.flags?.ffdreame;
      if (!zoneData) continue;

      const restant = (zoneData.dureeRestante || 1) - 1;
      console.log(`⏳ Zone ${zoneData.techniqueName} : ${zoneData.dureeRestante} → ${restant} round(s)`);

      if (restant <= 0) {
        // ── Expiration ──
        await this._stopperAnimation(zoneData.zoneId);
        await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [zone.id]);

        ChatMessage.create({
          speaker: { alias: zoneData.techniqueName },
          content: `<div style="background:rgba(100,100,100,.1);border-left:3px solid #666;padding:6px 10px;border-radius:5px;font-size:11px">
            ⏰ <b>${zoneData.techniqueName}</b> — Zone expirée.
          </div>`
        });
        console.log(`✅ Zone ${zoneData.zoneId} supprimée`);

      } else {
        // ── Mettre à jour le compteur ──
        await zone.document.update({
          [`flags.ffdreame.dureeRestante`]: restant
        });

        // Avertissement dernier round
        if (restant === 1) {
          ChatMessage.create({
            speaker: { alias: zoneData.techniqueName },
            content: `<div style="background:rgba(255,215,0,.08);border-left:3px solid #ffd700;padding:5px 10px;border-radius:5px;font-size:10px">
              ⚠️ <b>${zoneData.techniqueName}</b> — Zone : dernier round !
            </div>`
          });
        }
      }
    }
  }

  /* ============================================
     DÉTECTION — Token dans une zone
     ============================================ */
  static _tokenDansZone(token, templateDoc) {
    const gs = canvas.grid.size;

    if (templateDoc.t === "circle") {
      const dx = token.center.x - templateDoc.x;
      const dy = token.center.y - templateDoc.y;
      return Math.sqrt(dx*dx + dy*dy) <= templateDoc.distance * gs;
    }

    if (templateDoc.t === "ray") {
      const ax = templateDoc.x, ay = templateDoc.y;
      const dir = (templateDoc.direction * Math.PI) / 180;
      const len = templateDoc.distance * gs;
      const bx  = ax + Math.cos(dir) * len;
      const by  = ay + Math.sin(dir) * len;
      const dx  = bx - ax, dy = by - ay;
      const qx  = token.center.x - ax;
      const qy  = token.center.y - ay;
      const proj = (qx*dx + qy*dy) / len;
      if (proj < 0 || proj > len) return false;
      const perp = Math.abs((qx*dy - qy*dx) / len);
      return perp <= (templateDoc.width || 1) * gs / 2;
    }

    return false;
  }

  /* ============================================
     JET DE DÉS
     Même logique que _useTableTechniqueNormal :
     seuil rang + bonus effets tableau - malus fatigue/blessure
     ============================================ */
  static async _lancerDe(actor) {
    const rang  = actor.system.rang || "F";
    const seuil = actor._getRangModifier(rang).jetReussite;

    // Malus fatigue + blessure
    const fatigueMalus  = actor._calculateFatigueMalus();
    const blessureMalus = actor._calculateBlessureMalus();
    const totalMalus    = fatigueMalus + blessureMalus;

    // Malus Jet du Risque (si actif)
    let malusRisque = 0;
    const flagRisque = actor.getFlag('ffdreame', 'jetRisqueMalus');
    if (flagRisque && typeof flagRisque.then !== 'function' && flagRisque.tours > 0) {
      malusRisque = flagRisque.valeur || 0;
    }

    const seuilFinal = seuil - malusRisque;
    const formula    = totalMalus > 0 ? `1d100 + ${totalMalus}` : "1d100";
    const roll       = new Roll(formula);
    await roll.evaluate();
    const total   = roll.total;
    const success = total <= seuilFinal;

    return {
      roll, total, success,
      critSuccess: total <= 5,
      critFailure: total >= 95,
      formula, seuil: seuilFinal,
      malusInfo: (totalMalus > 0 || malusRisque > 0)
        ? `<p style="color:#ff6b6b;font-size:11px">⚠️ Malus dés : +${totalMalus}${malusRisque > 0 ? ` | Malus seuil : -${malusRisque}` : ''}</p>`
        : ""
    };
  }

  static async _chatJet(actor, technique, jet, config, placement) {
    let txt = jet.success ? "✓ Réussite" : "✗ Échec";
    let css = jet.success ? "success"    : "failure";
    if (jet.critSuccess) { txt = "⭐ SUCCÈS CRITIQUE !"; css = "critical-success"; }
    if (jet.critFailure) { txt = "💀 ÉCHEC CRITIQUE !";  css = "critical-failure"; }

    const formeLabel = placement.forme === "ligne" ? "🗡️ Ligne" : "💥 Cercle";
    const typeLabel  = config.typeEffet === "buff"  ? "Zone de Buff" : "Zone de Dégâts";

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor: `<h3>🌀 ${technique.name} — MULTI-AOE (${typeLabel})</h3>
               <p style="color:#aaa;font-size:11px">${formeLabel} | Taille ${placement.taille || config.taille || 3} cases | Seuil ≤ ${jet.seuil}</p>
               ${jet.malusInfo}`,
      content: `<div class="dice-roll">
        <div class="dice-result">
          <div class="dice-formula">${jet.formula}</div>
          <div class="dice-total ${css}">${jet.total} ${txt}</div>
        </div>
      </div>`
    });
  }

  /* ============================================
     UTILITAIRES GÉOMÉTRIE
     ============================================ */
  static _dist(a, b, gs) {
    return Math.sqrt(((b.x-a.x)/gs)**2 + ((b.y-a.y)/gs)**2);
  }

  /* ─── PIXI Preview Cercle ─── */
  static _buildPreviewCercle() {
    const g = new PIXI.Container();
    g._circle = new PIXI.Graphics();
    g._text   = new PIXI.Text("", { fontFamily:"Arial", fontSize:14, fill:0xffffff, stroke:0x000000, strokeThickness:3, align:"center" });
    g.addChild(g._circle); g.addChild(g._text);
    return g;
  }
  static _updatePreviewCercle(preview, pos, r, inRange, dist, distMax) {
    const col = inRange ? 0x8a2be2 : 0xff4444;
    const c = preview._circle;
    c.clear();
    c.lineStyle(2, col, 0.9);
    c.beginFill(col, inRange ? 0.15 : 0.06);
    c.drawCircle(pos.x, pos.y, r);
    c.endFill();
    c.lineStyle(1, col, 0.4);
    c.moveTo(pos.x-8,pos.y); c.lineTo(pos.x+8,pos.y);
    c.moveTo(pos.x,pos.y-8); c.lineTo(pos.x,pos.y+8);
    const t = preview._text;
    t.text = `${dist.toFixed(1)} / ${distMax}`;
    t.style.fill = inRange ? 0x8a2be2 : 0xff4444;
    t.x = pos.x - t.width/2; t.y = pos.y + r + 5;
  }

  /* ─── PIXI Preview Ligne ─── */
  static _buildPreviewLigne() {
    const g = new PIXI.Container();
    g._line = new PIXI.Graphics();
    g._text = new PIXI.Text("", { fontFamily:"Arial", fontSize:14, fill:0xffffff, stroke:0x000000, strokeThickness:3 });
    g.addChild(g._line); g.addChild(g._text);
    return g;
  }
  static _updatePreviewLigne(preview, src, dst, lPx, inRange, dist, distMax) {
    const col = inRange ? 0x8a2be2 : 0xff4444;
    const dx = dst.x-src.x, dy = dst.y-src.y;
    const len = Math.sqrt(dx*dx+dy*dy)||1;
    const px = -dy/len*lPx/2, py = dx/len*lPx/2;
    const l = preview._line;
    l.clear();
    l.lineStyle(2, col, 0.9);
    l.beginFill(col, inRange ? 0.15 : 0.06);
    l.moveTo(src.x+px,src.y+py); l.lineTo(dst.x+px,dst.y+py);
    l.lineTo(dst.x-px,dst.y-py); l.lineTo(src.x-px,src.y-py);
    l.closePath(); l.endFill();
    l.lineStyle(1, col, 0.6);
    l.moveTo(src.x,src.y); l.lineTo(dst.x,dst.y);
    const t = preview._text;
    t.text = `${dist.toFixed(1)} / ${distMax}`;
    t.style.fill = inRange ? 0x8a2be2 : 0xff4444;
    t.x = (src.x+dst.x)/2 - t.width/2;
    t.y = (src.y+dst.y)/2 - 20;
  }
}
