/* ============================================
   SYSTÈME DE DÉPLACEMENT BASÉ SUR ATHLÉTISME
   Formule : Déplacement Max = 2 + Athlétisme (en mètres)
   ============================================ */

export class FFdreameMovement {
  
  /* ================================
     INITIALISER LE SYSTÈME
     ================================ */
  static init() {
    Hooks.on("preUpdateToken", this._onPreUpdateToken.bind(this));
    Hooks.on("renderTokenHUD", this._onRenderTokenHUD.bind(this));
  }
  
  /* ================================
     CALCULER LA DISTANCE MAX DE DÉPLACEMENT
     ================================ */
  static getMaxMovement(actor) {
    if (!actor || actor.type !== "character") {
      return null; // Pas de limite pour les non-PJ
    }
    
    const athletisme = actor.system?.physique?.athletisme?.value || 0;
    return 2 + athletisme; // 2 mètres de base + athlétisme
  }
  
  /* ================================
     VÉRIFIER LE DÉPLACEMENT AVANT UPDATE
     ================================ */
  static _onPreUpdateToken(tokenDocument, change, options, userId) {
    // Ignorer les téléportations (elles ont leur propre limite de distance)
    if (options.isTeleportation) return true;
    
    // ===== LIMITE DE DÉPLACEMENT UNIQUEMENT EN COMBAT =====
    const inCombat = game.combat && game.combat.started;
    if (!inCombat) {
      // Hors combat : pas de limite de déplacement
      return true;
    }
    
    // Uniquement pour les déplacements effectués par le joueur actuel
    if (userId !== game.user.id) return true;
    
    // Uniquement si on change la position
    if (!change.x && !change.y) return true;
    
    const token = tokenDocument.object;
    if (!token) return true;
    
    const actor = token.actor;
    if (!actor) return true;
    
    const maxMovement = this.getMaxMovement(actor);
    
    // Pas de limite pour les tokens sans acteur ou non-PJ
    if (maxMovement === null) return true;
    
    // Calculer la distance parcourue
    const gridSize = canvas.grid.size;
    const oldX = tokenDocument.x;
    const oldY = tokenDocument.y;
    const newX = change.x ?? oldX;
    const newY = change.y ?? oldY;
    
    const deltaX = (newX - oldX) / gridSize;
    const deltaY = (newY - oldY) / gridSize;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    // Vérifier si on dépasse la limite (EN COMBAT uniquement)
    if (distance > maxMovement) {
      ui.notifications.warn(`⚠️ Déplacement max en combat : ${maxMovement}m (Athlétisme: ${maxMovement - 2})`);
      
      // Limiter le déplacement au maximum autorisé
      const ratio = maxMovement / distance;
      change.x = oldX + (deltaX * ratio * gridSize);
      change.y = oldY + (deltaY * ratio * gridSize);
      
      return true; // Autoriser avec limitation
    }
    
    return true;
  }
  
  /* ================================
     AFFICHER LA LIMITE SUR LE TOKEN HUD
     ================================ */
  static _onRenderTokenHUD(app, html, data) {
    const token = app.object;
    if (!token || !token.actor) return;
    
    const actor = token.actor;
    const maxMovement = this.getMaxMovement(actor);
    
    if (maxMovement === null) return;
    
    // Créer l'indicateur visuel
    const athletisme = actor.system?.physique?.athletisme?.value || 0;
    const indicator = $(`
      <div class="control-icon" style="
        position: absolute;
        bottom: 36px;
        right: 36px;
        background: rgba(0, 150, 255, 0.8);
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
        pointer-events: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      ">
        🏃 ${maxMovement}m
      </div>
    `);
    
    indicator.attr('title', `Déplacement Max: ${maxMovement}m (Base: 2m + Athlétisme: ${athletisme})`);
    html.find('.col.right').append(indicator);
  }
  
  /* ================================
     AFFICHER UN APERÇU DE LA PORTÉE
     ================================ */
  static showMovementRange(token) {
    const actor = token.actor;
    if (!actor) return;
    
    const maxMovement = this.getMaxMovement(actor);
    if (maxMovement === null) return;
    
    const gridSize = canvas.grid.size;
    const radius = maxMovement * gridSize;
    
    // Créer un template circulaire temporaire
    const templateData = {
      t: "circle",
      user: game.user.id,
      distance: maxMovement,
      direction: 0,
      x: token.center.x,
      y: token.center.y,
      fillColor: "#0096FF",
      borderColor: "#0096FF"
    };
    
    canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]).then(templates => {
      // Supprimer après 3 secondes
      setTimeout(async () => {
        await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [templates[0].id]);
      }, 3000);
    });
  }
}
