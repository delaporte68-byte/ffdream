/**
 * Fichier d'initialisation du système - À ajouter dans votre main.js
 */

import { ObjetItemSheet } from "./sheets/objet-item-sheet.js";
import { ObjetItemData } from "./data/objet-item-data.js";

/**
 * Hook d'initialisation
 */
Hooks.once('init', async function() {
    console.log("Initialisation du système d'objets/techniques");

    // Configuration globale
    CONFIG.OBJET = {
        effetTypes: {
            soins: "Soins - Restaure PV",
            bufa: "BufA - Augmente Aptitude Attaque",
            bufj: "BufJ - Diminue Jet de Dés",
            bufd: "BufD - Diminue Dégâts Reçus",
            soinsg: "SoinsG - Augmente PV du Groupe",
            ponction: "Ponction - Absorbe PV",
            ponctionm: "PonctionM - Absorbe PM"
        },
        styleCalculs: {
            cac: "CAC - Corps à Corps",
            mag: "MAG - Magique",
            pui: "PUI - Puissance",
            aoe: "AOE - Zone d'Effet"
        }
    };

    // Enregistrer le modèle de données pour les items de type "objet"
    CONFIG.Item.dataModels.objet = ObjetItemData;

    // Désinscrire la fiche par défaut et inscrire notre fiche personnalisée
    Items.unregisterSheet("core", ItemSheet);
    Items.registerSheet("votre-systeme", ObjetItemSheet, {
        types: ["objet"],
        makeDefault: true,
        label: "Fiche Objet/Technique"
    });

    // Précharger les templates Handlebars
    await loadTemplates([
        "systems/votre-systeme/templates/item/item-objet-sheet.html"
    ]);

    // Enregistrer les helpers Handlebars personnalisés
    Handlebars.registerHelper('eq', function(a, b) {
        return a === b;
    });

    Handlebars.registerHelper('checked', function(value) {
        return value ? 'checked' : '';
    });
});

/**
 * Hook pour ajouter un bouton d'utilisation sur la fiche de personnage
 */
Hooks.on("renderActorSheet", (app, html, data) => {
    // Ajouter un bouton "Utiliser" à côté de chaque objet dans l'inventaire
    html.find('.item .item-name').each((i, elem) => {
        const itemId = $(elem).closest('.item').data('item-id');
        const item = app.actor.items.get(itemId);
        
        if (item && item.type === 'objet') {
            const useButton = $(`<a class="item-control item-use" title="Utiliser"><i class="fas fa-hand-sparkles"></i></a>`);
            
            useButton.click(async (event) => {
                event.preventDefault();
                event.stopPropagation();
                
                // Récupérer la fiche de l'item
                const itemSheet = item.sheet;
                
                // Appeler la fonction d'utilisation
                if (itemSheet._onItemUse) {
                    await itemSheet._onItemUse(event);
                }
            });
            
            $(elem).closest('.item').find('.item-controls').append(useButton);
        }
    });
});

/**
 * Macro pour utiliser un objet rapidement
 */
globalThis.utiliserObjet = async function(itemName) {
    const speaker = ChatMessage.getSpeaker();
    let actor;
    
    if (speaker.token) {
        actor = game.actors.tokens[speaker.token];
    }
    if (!actor) {
        actor = game.actors.get(speaker.actor);
    }
    
    if (!actor) {
        ui.notifications.warn("Aucun personnage sélectionné !");
        return;
    }
    
    const item = actor.items.getName(itemName);
    
    if (!item) {
        ui.notifications.error(`Objet "${itemName}" non trouvé !`);
        return;
    }
    
    if (item.type !== 'objet') {
        ui.notifications.warn("Cet item n'est pas un objet utilisable !");
        return;
    }
    
    // Utiliser l'objet
    const itemSheet = item.sheet;
    if (itemSheet._onItemUse) {
        await itemSheet._onItemUse(new Event('click'));
    }
};

console.log("Système d'objets/techniques chargé avec succès !");
