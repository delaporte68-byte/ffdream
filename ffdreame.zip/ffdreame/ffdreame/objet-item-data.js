/**
 * Modèle de données pour les items de type Objet/Technique
 */
export class ObjetItemData extends foundry.abstract.DataModel {
    
    static defineSchema() {
        const fields = foundry.data.fields;
        
        return {
            // Description
            description: new fields.HTMLField({
                required: false,
                blank: true
            }),

            // Coûts
            coutMagie: new fields.NumberField({
                required: true,
                initial: 0,
                min: 0,
                integer: true
            }),
            coutGrandAction: new fields.BooleanField({
                required: true,
                initial: false
            }),
            coutPetitAction: new fields.BooleanField({
                required: true,
                initial: false
            }),

            // Dégâts
            degatsBase: new fields.NumberField({
                required: true,
                initial: 0,
                min: 0,
                integer: true
            }),

            // Style de calcul
            styleCalcul: new fields.StringField({
                required: true,
                initial: "cac",
                choices: {
                    cac: "CAC - Corps à Corps",
                    mag: "MAG - Magique",
                    pui: "PUI - Puissance",
                    aoe: "AOE - Zone d'Effet"
                }
            }),

            // Effet 1
            effet1: new fields.SchemaField({
                type: new fields.StringField({
                    required: false,
                    blank: true,
                    choices: {
                        "": "Aucun",
                        soins: "Soins - Restaure PV",
                        bufa: "BufA - Augmente Aptitude Attaque",
                        bufj: "BufJ - Diminue Jet de Dés",
                        bufd: "BufD - Diminue Dégâts Reçus",
                        soinsg: "SoinsG - Augmente PV du Groupe",
                        ponction: "Ponction - Absorbe PV",
                        ponctionm: "PonctionM - Absorbe PM"
                    }
                }),
                valeur: new fields.NumberField({
                    required: false,
                    initial: 0,
                    min: 0
                }),
                condition: new fields.NumberField({
                    required: false,
                    initial: 100,
                    min: 0,
                    max: 100
                })
            }),

            // Effet 2
            effet2: new fields.SchemaField({
                type: new fields.StringField({
                    required: false,
                    blank: true,
                    choices: {
                        "": "Aucun",
                        soins: "Soins - Restaure PV",
                        bufa: "BufA - Augmente Aptitude Attaque",
                        bufj: "BufJ - Diminue Jet de Dés",
                        bufd: "BufD - Diminue Dégâts Reçus",
                        soinsg: "SoinsG - Augmente PV du Groupe",
                        ponction: "Ponction - Absorbe PV",
                        ponctionm: "PonctionM - Absorbe PM"
                    }
                }),
                valeur: new fields.NumberField({
                    required: false,
                    initial: 0,
                    min: 0
                }),
                condition: new fields.NumberField({
                    required: false,
                    initial: 100,
                    min: 0,
                    max: 100
                })
            }),

            // Animations
            animation: new fields.SchemaField({
                sequencer: new fields.StringField({
                    required: false,
                    blank: true
                }),
                jb2a: new fields.StringField({
                    required: false,
                    blank: true,
                    choices: {
                        "": "Aucune",
                        "jb2a.fire_bolt": "Boule de Feu",
                        "jb2a.magic_missile": "Projectile Magique",
                        "jb2a.healing_generic": "Soin",
                        "jb2a.shield": "Bouclier",
                        "jb2a.sword_slash": "Coup d'Épée"
                    }
                })
            })
        };
    }

    /**
     * Préparer les données dérivées
     */
    prepareDerivedData() {
        // Calculer des valeurs dérivées si nécessaire
    }
}
