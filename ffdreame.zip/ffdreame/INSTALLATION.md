# 🎮 INSTALLATION RAPIDE

## Étapes :
1. Renommez votre dossier `systems/ffdreame` en `ffdreame-backup`
2. Décompressez ffdreame-FINAL.zip
3. Renommez le dossier obtenu en `ffdreame`
4. Copiez-le dans `systems/`
5. Lancez Foundry

## Vérification :
Console (F12) doit afficher :
- ✅ FFdreame | Système prêt
- ✅ Système de combat activé
- ✅ Zones persistantes activées
- ✅ Système AOER activé

Si vous voyez ces 4 lignes → Tout fonctionne ! 🎉
