# Guide des Modifications FFdreame - Nouvelles Fonctionnalités

## Version : 4.0
## Date : 03 Février 2026

---

## 📋 RÉSUMÉ DES MODIFICATIONS

Ce document décrit les 3 principales modifications apportées au système FFdreame :

1. ✅ **Token Central Interactif** dans l'onglet Principal
2. ✅ **Suppression de la Grande Barre Burst** dans l'onglet Combat
3. ✅ **Système de Techniques dans les Postures** (déjà fonctionnel)

---

## 🎯 MODIFICATION 1 : TOKEN CENTRAL INTERACTIF

### Description
Dans l'onglet **Principal**, un token central a été ajouté au milieu de la disposition, avec les 4 cercles d'aptitudes positionnés autour (haut, bas, gauche, droite).

### Disposition
```
           [ATTAQUE]
               ↑
               |
[PM] ← [TOKEN CENTRAL] → [PUISSANCE MAGIQUE]
               |
               ↓
              [PV]
```

### Fonctionnalités du Token

#### Interaction de Base
- **Clic gauche** sur le token : Ouvre le sélecteur de fichier pour changer l'image
- **Clic droit** sur le token : Ouvre la configuration du Prototype Token

#### Effet Visuel
- Bordure dorée avec effet de lueur
- Animation au survol (agrandissement + effet lumineux)
- Overlay avec icône caméra au survol
- Image ronde (border-radius: 50%)

#### Fichiers Modifiés
1. **`templates/actor/character-sheet.html`** (lignes 166-216)
   - Ajout du conteneur `.token-aptitudes-container`
   - Ajout du `.character-token-wrapper` avec image
   - Repositionnement des aptitudes avec classes `.aptitude-top`, `.aptitude-right`, `.aptitude-bottom`, `.aptitude-left`

2. **`css/ffdreame.css`** (après ligne 550)
   - Section complète pour `.token-aptitudes-container`
   - Styles pour `.character-token-frame`
   - Overlay et effets hover
   - Positionnement en cercle des aptitudes

3. **`module/sheets/actor-sheet.js`** (lignes 173-174)
   - Ajout des event listeners pour `.character-token-frame`
   - Réutilisation des méthodes existantes `_onTokenImageClick` et `_onTokenConfigClick`

---

## 🔥 MODIFICATION 2 : SUPPRESSION DE LA GRANDE BARRE BURST

### Description
La grande section Burst (`.burste-section`) qui prenait beaucoup de place dans l'onglet Combat a été **supprimée**.

### Ce qui a été conservé
✅ La **petite barre Burst** en haut de l'onglet Combat (dans `.combat-orbs-wrapper`)
✅ Toute la logique de calcul et de gestion du Burst
✅ Les conditions d'ultimate basées sur Burst ≥ 100

### Ce qui a été supprimé
❌ La grande barre visuelle avec label "⚡ BURSTE"
❌ La barre de progression horizontale
❌ Le texte explicatif "+10 par attaque/technique réussie | +5 par coup reçu"

### Fichiers Modifiés
1. **`templates/actor/character-sheet.html`** (lignes 475-486 supprimées)
   - Section complète `.burste-section` retirée du HTML

2. **`css/ffdreame.css`** (ligne 2182)
   - Ajout de `display: none;` à `.burste-section`
   - Conservation du CSS pour éviter les erreurs si utilisé ailleurs

### Emplacement de la Petite Barre
La petite barre Burst est toujours visible dans :
```html
<div class="burste-wrapper">
  <!-- Petite barre avec orbe compact -->
</div>
```
Cette barre se trouve dans la section `combat-orbs-wrapper` en haut de l'onglet Combat.

---

## ⚔️ MODIFICATION 3 : SYSTÈME POSTURES/TECHNIQUES

### Description
Le système de postures avec techniques associées est **déjà fonctionnel** dans votre configuration actuelle.

### Comment ça Fonctionne

#### 1. Créer une Posture
1. Cliquer sur **"Créer un Item"** dans le menu
2. Sélectionner le type **"Posture"**
3. Remplir les informations :
   - Nom de la posture
   - Description
   - Attaque de base (bonus)
   - Effet de posture (optionnel)
   - Ultimate (optionnel)

#### 2. Créer une Technique
1. Cliquer sur **"Créer un Item"** dans le menu
2. Sélectionner le type **"Technique"**
3. Remplir les informations :
   - **Nom de la technique**
   - **Style** (CAC, MG, P, EHa, EHm, EF, BUFF)
   - **Coût PM**
   - **Base Dégâts**
   - **Posture Associée** : ⚠️ **IMPORTANT** - Entrer le nom **EXACT** de la posture

#### 3. Affichage dans la Fiche
Une fois créées, les techniques apparaissent automatiquement dans leur posture associée :

```
┌─────────────────────────────┐
│  🥊 POSTURE : Style Dragon  │
│  [✓] ACTIVE                 │
│                             │
│  [⚔️ ATTAQUE DE BASE]       │
│  170 dégâts                 │
│                             │
│  Techniques :               │
│  ┌─────────────────────┐   │
│  │ Griffe du Dragon    │   │
│  │ 15 PM | 50 dégâts   │   │
│  └─────────────────────┘   │
│  ┌─────────────────────┐   │
│  │ Souffle Enflammé    │   │
│  │ 25 PM | 80 dégâts   │   │
│  └─────────────────────┘   │
└─────────────────────────────┘
```

### Calcul des Dégâts selon le Style

Les techniques calculent automatiquement les dégâts selon leur style :

| Style | Formule | Description |
|-------|---------|-------------|
| **CAC** | ATQ + (PM ÷ 2) + Base | Corps à corps avec touche magique |
| **MG** | (ATQ ÷ 2) + PM + Base | Magie guidée dominante |
| **P** | ATQ + PM + Base | Fusion parfaite physique + magique |
| **EHa** | ATQ + Base | 3 jets consécutifs, seuil -10 par jet |
| **EHm** | PM + Base | 3 jets consécutifs, seuil -10 par jet |
| **EF** | PM + Base + (ATQ ÷ 2) | Puissance magique avec effets |
| **BUFF** | Pas de dégâts | Buffs/soins/bonus |

### Utilisation en Jeu

#### Activer une Posture
1. Dans l'onglet **Combat**
2. Cliquer sur le bouton **[ACTIVER]** de la posture
3. Une seule posture peut être active à la fois

#### Utiliser une Technique
1. La posture doit être **active**
2. Cliquer sur le bouton de la technique
3. Le système vérifie automatiquement :
   - ✅ Points Magiques suffisants
   - ✅ Points d'Action disponibles
   - ✅ Posture active
4. Lance le jet de dégâts avec la formule appropriée
5. Déduit les PM et PA
6. Augmente le Burst de +10

#### Utiliser l'Ultimate
1. Le Burst doit être à **100**
2. La posture doit être **active**
3. Cliquer sur **[🔥 LANCER ULTIMATE]**
4. Lance un jet massif de dégâts
5. Remet le Burst à **0**
6. Consomme 1 **Grand PA**

### Code Template Existant

Le système utilise déjà la bonne logique dans `character-sheet.html` (lignes 533-554) :

```handlebars
<!-- Techniques associées -->
<div class="posture-techniques-list {{#unless item.system.active}}disabled{{/unless}}">
  {{#each @root.actor.items as |tech|}}
    {{#if (and (eq tech.type "technique") (eq tech.system.postureAssociee ../item.name))}}
      <div class="technique-mini" data-item-id="{{tech.id}}">
        <button type="button" class="btn-use-technique" data-item-id="{{tech.id}}">
          <span class="tech-name">{{tech.name}}</span>
          <span class="tech-cost">{{tech.system.coutPM}} PM</span>
          <span class="tech-degats">{{tech.system.baseDegats}} dégâts</span>
        </button>
      </div>
    {{/if}}
  {{/each}}
</div>
```

### Debugging : Technique n'apparaît pas ?

Si une technique ne s'affiche pas dans sa posture :

1. **Vérifier le nom** : Le champ "Posture Associée" dans la technique doit contenir le nom **EXACT** de la posture
   - ✅ Correct : `"Style Dragon"`
   - ❌ Incorrect : `"style dragon"` ou `"Style dragon"` ou `"StyleDragon"`

2. **Vérifier le type** : L'item doit être de type **"technique"** (pas "talent" ou autre)

3. **Rafraîchir la fiche** : Fermer et rouvrir la fiche du personnage

4. **Console de développement** :
   ```javascript
   // Dans la console F12 de Foundry
   game.actors.getName("Nom du Personnage").items.filter(i => i.type === "technique")
   // Vérifier que la technique apparaît avec le bon `system.postureAssociee`
   ```

---

## 📁 FICHIERS MODIFIÉS - RÉCAPITULATIF

### Fichiers HTML
- ✅ `templates/actor/character-sheet.html`
  - Ajout du token central (lignes 166-216)
  - Suppression de `.burste-section` (lignes 475-486 supprimées)

### Fichiers CSS
- ✅ `css/ffdreame.css`
  - Styles token central (après ligne 550)
  - Masquage `.burste-section` (ligne 2182)

### Fichiers JavaScript
- ✅ `module/sheets/actor-sheet.js`
  - Event listeners token (lignes 173-174)

---

## 🔧 INSTALLATION DES MODIFICATIONS

### Méthode 1 : Remplacement Manuel
1. Remplacer les 3 fichiers modifiés dans votre dossier `systems/ffdreame/`
2. Redémarrer Foundry VTT
3. Rafraîchir la page (F5)

### Méthode 2 : Copier uniquement les sections modifiées
Utiliser les fichiers `.backup` créés pour comparer et copier uniquement les sections nécessaires.

### Fichiers de Sauvegarde Créés
- `templates/actor/character-sheet.html.backup`
- `css/ffdreame.css.backup`
- `module/sheets/actor-sheet.js.backup`

---

## 🎮 UTILISATION APRÈS INSTALLATION

### Tester le Token Central
1. Ouvrir une fiche personnage
2. Aller dans l'onglet **Principal**
3. Observer le token au centre avec les 4 aptitudes autour
4. Cliquer sur le token → sélectionner une nouvelle image
5. Clic droit sur le token → configurer le Prototype Token

### Tester la Suppression Burst
1. Ouvrir une fiche personnage
2. Aller dans l'onglet **Combat**
3. Vérifier que la grande barre Burst a disparu
4. Vérifier que la petite barre Burst en haut est toujours présente

### Tester les Techniques
1. Créer une posture : `"Style Élémentaire"`
2. Créer une technique : 
   - Nom : `"Boule de Feu"`
   - Style : `MG`
   - Coût PM : `20`
   - Base Dégâts : `30`
   - Posture Associée : `"Style Élémentaire"` (EXACTEMENT)
3. Activer la posture dans l'onglet Combat
4. Vérifier que "Boule de Feu" apparaît dans la posture
5. Cliquer sur la technique pour lancer le jet

---

## 🐛 DÉPANNAGE

### Le token ne s'affiche pas
- Vérifier que le fichier CSS a bien été modifié
- Vider le cache du navigateur (Ctrl+Shift+R)
- Vérifier dans les outils de développement (F12) si les styles sont chargés

### La grande barre Burst est toujours visible
- Vérifier que `display: none;` est bien ajouté à `.burste-section` dans le CSS
- Vider le cache

### Les techniques n'apparaissent pas
- Vérifier que le nom de la posture est **EXACTEMENT** le même (majuscules, espaces)
- Vérifier que l'item est bien de type "technique"
- Rouvrir la fiche personnage

### Le token ne s'ouvre pas au clic
- Vérifier que les event listeners sont bien ajoutés dans `actor-sheet.js`
- Vérifier la console (F12) pour des erreurs JavaScript

---

## 📝 NOTES IMPORTANTES

1. **Compatibilité** : Ces modifications sont compatibles avec toutes les fonctionnalités existantes
2. **Sauvegardes** : Des fichiers `.backup` ont été créés automatiquement
3. **Postures Maximum** : Le système supporte 2 postures maximum par personnage
4. **Burst** : La logique du Burst reste inchangée, seul l'affichage a changé

---

## 🎨 PERSONNALISATION FUTURE

### Modifier la taille du token
Dans `ffdreame.css`, section `.character-token-frame` :
```css
width: 140px;  /* Changer cette valeur */
height: 140px; /* Changer cette valeur */
```

### Modifier la couleur de la bordure du token
Dans `ffdreame.css`, section `.character-token-frame` :
```css
border: 4px solid var(--color-primary-gold); /* Changer la couleur */
```

### Ajouter plus de techniques par posture
Le système n'a pas de limite sur le nombre de techniques par posture. Créez autant de techniques que nécessaire avec la même "Posture Associée".

---

## ✅ LISTE DE VÉRIFICATION FINALE

- [ ] Token central visible dans l'onglet Principal
- [ ] Token cliquable (change d'image)
- [ ] Token clic droit (ouvre prototype token)
- [ ] 4 aptitudes positionnées en cercle autour
- [ ] Grande barre Burst supprimée de l'onglet Combat
- [ ] Petite barre Burst toujours visible en haut
- [ ] Postures affichables dans l'onglet Combat
- [ ] Techniques visibles dans leur posture associée
- [ ] Techniques cliquables et fonctionnelles
- [ ] Ultimate disponible à Burst = 100

---

## 📧 SUPPORT

Si vous rencontrez des problèmes :
1. Consulter la section **DÉPANNAGE** ci-dessus
2. Vérifier les fichiers `.backup` pour restaurer si nécessaire
3. Vérifier la console du navigateur (F12) pour les erreurs

---

**Fin du Guide de Modifications v4.0**
