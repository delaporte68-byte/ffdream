/* ============================================
   SYSTÈME D'EFFETS DE TABLEAUX
   Effets conditionnels liés aux tableaux 1 et 2
   ============================================ */

export class FFdreameTableauEffects {
  
  /* ================================
     OUVRIR LA FENÊTRE D'EFFET
     ================================ */
  static async openEffectConfig(actor, tableauNum) {
    const effet = actor.system.combat[`tableau${tableauNum}`]?.effet || {
      actif: false,
      nom: "",
      description: "",
      type: "degats",
      valeur: 10,
      condition: "techniques",
      conditionValeur: 2,
      progression: 0,
      declenchable: false
    };
    
    const html = await renderTemplate("systems/ffdreame/templates/dialogs/tableau-effet-config.html", {
      tableauNum,
      effet,
      types: this._getEffectTypes(),
      conditions: this._getConditionTypes()
    });
    
    new Dialog({
      title: `⚡ Effet du Tableau ${tableauNum}`,
      content: html,
      buttons: {
        save: {
          icon: '<i class="fas fa-save"></i>',
          label: "Sauvegarder",
          callback: (html) => this._saveEffect(actor, tableauNum, html)
        },
        cancel: {
          icon: '<i class="fas fa-times"></i>',
          label: "Annuler"
        }
      },
      default: "save"
    }, {
      width: 600,
      height: "auto"
    }).render(true);
  }
  
  /* ================================
     TYPES D'EFFETS DISPONIBLES
     ================================ */
  static _getEffectTypes() {
    return {
      degats: {
        label: "💥 Bonus de dégâts",
        description: "Augmente les dégâts de la prochaine technique"
      },
      pa_regen: {
        label: "⚡ Régénération PA",
        description: "Récupère 1 Petit PA"
      },
      initiative: {
        label: "🎯 Bonus Initiative",
        description: "Bonus au jet d'initiative en début de combat"
      },
      initiative_assuree: {
        label: "⚡ Initiative Assurée",
        description: "Le joueur joue toujours en premier au début du combat (une seule fois par combat)"
      },
      parade: {
        label: "🛡️ Parade gratuite",
        description: "La prochaine attaque reçue est annulée"
      },
      double_frappe: {
        label: "⚔️ Double frappe",
        description: "La prochaine technique frappe 2 fois"
      },
      pm_regen: {
        label: "💙 Régénération PM",
        description: "Récupère des PM"
      },
      critique_auto: {
        label: "⭐ Critique auto",
        description: "La prochaine technique est automatiquement critique"
      },
      cout_reduit: {
        label: "💎 Coût réduit",
        description: "La prochaine technique coûte 50% de PM en moins"
      }
    };
  }
  
  /* ================================
     TYPES DE CONDITIONS
     ================================ */
  static _getConditionTypes() {
    return {
      permanent: {
        label: "♾️ Permanent (actif dès le début du combat)",
        description: "L'effet est actif automatiquement, sans condition à remplir"
      },
      techniques: {
        label: "🎯 Réussir X techniques",
        description: "Nombre de techniques réussies de ce tableau"
      },
      degats_infliges: {
        label: "💥 Infliger X dégâts",
        description: "Total de dégâts infligés avec ce tableau"
      },
      tour_combat: {
        label: "⏱️ X tours de combat",
        description: "Nombre de tours écoulés"
      },
      combo: {
        label: "🔥 Combo de X",
        description: "Techniques consécutives réussies sans échec"
      },
      pm_depenses: {
        label: "💙 Dépenser X PM",
        description: "Total de PM dépensés avec ce tableau"
      }
    };
  }
  
  /* ================================
     SAUVEGARDER L'EFFET
     ================================ */
  static async _saveEffect(actor, tableauNum, html) {
    const form = html[0].querySelector("form");
    const formData = new FormData(form);
    
    const effet = {
      actif: true,
      nom: formData.get("nom"),
      description: formData.get("description"),
      type: formData.get("type"),
      valeur: parseInt(formData.get("valeur")),
      condition: formData.get("condition"),
      conditionValeur: parseInt(formData.get("conditionValeur")),
      progression: 0,
      declenchable: false
    };
    
    await actor.update({
      [`system.combat.tableau${tableauNum}.effet`]: effet
    });
    
    ui.notifications.info(`✨ Effet configuré pour le Tableau ${tableauNum} !`);
  }
  
  /* ================================
     INCRÉMENTER LA PROGRESSION
     ================================ */
  static async incrementProgress(actor, tableauNum, type, valeur = 1) {
    const tableau = actor.system.combat[`tableau${tableauNum}`];
    const effet = tableau?.effet;
    
    if (!effet || !effet.actif) return;
    
    // Vérifier si c'est le bon type de progression
    if (effet.condition !== type) return;
    
    const nouvelleProgression = effet.progression + valeur;
    
    // Vérifier si la condition est remplie
    if (nouvelleProgression >= effet.conditionValeur) {
      await actor.update({
        [`system.combat.tableau${tableauNum}.effet.progression`]: effet.conditionValeur,
        [`system.combat.tableau${tableauNum}.effet.declenchable`]: true
      });
      
      ui.notifications.info(`✨ Effet "${effet.nom}" prêt ! (Tableau ${tableauNum})`);
      
      // Animation visuelle
      this._showEffectReady(actor, tableauNum);
    } else {
      await actor.update({
        [`system.combat.tableau${tableauNum}.effet.progression`]: nouvelleProgression
      });
    }
  }
  
  /* ================================
     DÉCLENCHER L'EFFET
     ================================ */
  static async triggerEffect(actor, tableauNum, technique) {
    const effet = actor.system.combat[`tableau${tableauNum}`]?.effet;
    
    if (!effet || !effet.declenchable) return null;
    
    let resultat = null;
    
    switch (effet.type) {
      case "degats":
        resultat = {
          type: "degats_bonus",
          valeur: effet.valeur,
          message: `💥 +${effet.valeur}% dégâts !`
        };
        break;
        
      case "pa_regen":
        await this._regenererPA(actor);
        resultat = {
          type: "pa_regen",
          message: "⚡ +1 Petit PA régénéré !"
        };
        break;
        
      case "parade":
        await actor.update({ 'system.combat.parade_active': true });
        resultat = {
          type: "parade",
          message: "🛡️ Parade activée !"
        };
        break;
        
      case "double_frappe":
        resultat = {
          type: "double_frappe",
          message: "⚔️ Double frappe activée !"
        };
        break;
        
      case "pm_regen":
        const pmActuel = actor.system.aptitudes.pm.value;
        const pmMax = actor.system.aptitudes.pm.max;
        await actor.update({
          'system.aptitudes.pm.value': Math.min(pmMax, pmActuel + effet.valeur)
        });
        resultat = {
          type: "pm_regen",
          message: `💙 +${effet.valeur} PM régénérés !`
        };
        break;
        
      case "critique_auto":
        resultat = {
          type: "critique_auto",
          message: "⭐ Critique automatique !"
        };
        break;
        
      case "cout_reduit":
        resultat = {
          type: "cout_reduit",
          valeur: 50,
          message: "💎 Coût PM réduit de 50% !"
        };
        break;
        
      case "initiative_assuree":
        // Ce type est géré directement dans combat-system.js via le hook updateCombatant
        // Il ne devrait pas être déclenché manuellement (c'est automatique)
        resultat = {
          type: "initiative_assuree",
          message: "⚡ Initiative Assurée active !"
        };
        break;
    }
    
    // Reset l'effet
    await actor.update({
      [`system.combat.tableau${tableauNum}.effet.progression`]: 0,
      [`system.combat.tableau${tableauNum}.effet.declenchable`]: false
    });
    
    // Message dans le chat
    if (resultat) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<div style="background: rgba(255, 215, 0, 0.1); padding: 10px; border-left: 3px solid gold;">
                    <h3>✨ ${effet.nom}</h3>
                    <p>${resultat.message}</p>
                  </div>`
      });
    }
    
    return resultat;
  }
  
  /* ================================
     RÉGÉNÉRER 1 PETIT PA
     ================================ */
  static async _regenererPA(actor) {
    const actionPoints = actor.system.combat?.actionPoints || {};
    
    // Chercher le premier petit PA utilisé
    for (let i = 1; i <= 3; i++) {
      const grand = actionPoints[`grand${i}`];
      if (grand && !grand.petit1) {
        await actor.update({
          [`system.combat.actionPoints.grand${i}.petit1`]: true
        });
        return;
      } else if (grand && !grand.petit2) {
        await actor.update({
          [`system.combat.actionPoints.grand${i}.petit2`]: true
        });
        return;
      }
    }
  }
  
  /* ================================
     ANIMATION EFFET PRÊT
     ================================ */
  static _showEffectReady(actor, tableauNum) {
    const token = actor.getActiveTokens()[0];
    if (!token) return;
    
    // Animation de pulsation dorée
    if (game.modules.get("sequencer")?.active) {
      new Sequence()
        .effect()
        .atLocation(token)
        .file("jb2a.energy_field.02.above.yellow")
        .scale(0.5)
        .duration(2000)
        .fadeIn(200)
        .fadeOut(500)
        .play();
    }
  }
  
  /* ================================
     AFFICHER LA PROGRESSION
     ================================ */
  static getProgressionHTML(effet) {
    if (!effet || !effet.actif) {
      return '<span style="color: #888;">Aucun effet</span>';
    }
    
    const pourcentage = Math.floor((effet.progression / effet.conditionValeur) * 100);
    const color = effet.declenchable ? '#00ff00' : '#ffd700';
    
    return `
      <div class="effet-progression">
        <div class="effet-nom">${effet.nom}</div>
        <div class="effet-barre" style="background: rgba(0,0,0,0.3); border-radius: 5px; overflow: hidden;">
          <div style="width: ${pourcentage}%; height: 20px; background: ${color}; transition: all 0.3s;"></div>
        </div>
        <div class="effet-text">${effet.progression} / ${effet.conditionValeur}</div>
        ${effet.declenchable ? '<span style="color: #00ff00;">✨ PRÊT !</span>' : ''}
      </div>
    `;
  }

  /**
   * Vérifie si un acteur a l'effet "Initiative Assurée" actif sur son tableau actif
   * @param {Actor} actor
   * @returns {boolean}
   */
  /**
   * Vérifie si l'acteur a l'effet "Initiative Assurée" actif sur son tableau actif.
   * L'effet est reconnu si :
   *  - type === "initiative_assuree"
   *  - ET (actif === true  OU condition === "permanent")
   */
  static hasInitiativeAssuree(actor) {
    if (!actor?.system?.combat) return false;
    for (const tableauKey of ['tableau1', 'tableau2']) {
      const tableau = actor.system.combat[tableauKey];
      if (!tableau?.actif) continue;
      const effet = tableau.effet;
      if (!effet) continue;
      // Le type sauvegardé par le dialogue est 'initiative_first'
      if (effet.type !== 'initiative_first') continue;
      // Actif si permanent (toujours) ou condition reussites et actif=true
      if (effet.condition === 'permanent') return true;
      if (effet.condition === 'reussites' && effet.actif) return true;
    }
    return false;
  }
}
