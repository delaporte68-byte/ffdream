/**
 * ============================================
 * SYSTÈME DE CHARGE — FFdreame
 * ============================================
 * Universel : compatible avec tous les styles de technique.
 * Permet de charger 0, 1, 2 ou 3 tours pour multiplier les dégâts.
 * Pendant la charge : le token est bloqué (plus de mouvement, esquive, défense).
 * Si interrompu par une attaque : charge annulée.
 *
 * Stockage des tokens en charge : actor flags ffdreame.charge
 * Hook : updateCombat → début de tour → lancer automatiquement si prêt
 */

export class FFdreameChargeSystem {

  static init() {
    console.log("FFdreame | Initialisation Système de Charge...");
    Hooks.on("updateCombat", this._onUpdateCombat.bind(this));
    Hooks.on("updateActor", this._onActorDamage.bind(this));
    console.log("FFdreame | Charge activé ✅");
  }

  /* ============================================
     DIALOGUE DE CHOIX DE CHARGE
     Appelé depuis actor-sheet.js avant d'exécuter la technique
     ============================================ */
  static async demanderNiveauCharge(actor, technique) {
    const config = technique.system.charge || {};
    const mult = [
      config.multiplicateur0 ?? 1.0,
      config.multiplicateur1 ?? 1.5,
      config.multiplicateur2 ?? 2.0,
      config.multiplicateur3 ?? 3.0
    ];
    const baseDeg = technique.system.baseDegats || 0;

    return new Promise(resolve => {
      const content = `
        <div style="padding:10px; font-family: var(--font-primary, sans-serif);">
          <p style="color:#aaa; font-size:12px; text-align:center; margin:0 0 15px;">
            Choisissez votre niveau de charge. Plus vous attendez, plus les dégâts sont élevés.<br>
            <strong style="color:#ff4444;">⚠️ Pendant la charge : aucune action possible (mouvement, esquive, défense)</strong><br>
            <em style="color:#888; font-size:11px;">1 Round = quand TOUS les joueurs ont joué</em>
          </p>
          <table style="width:100%; border-collapse: collapse; margin-bottom:10px;">
            <tr>
              <td style="padding:8px; border:1px solid #444; text-align:center; background:rgba(100,100,100,0.2);">
                <div style="font-size:16px;">⚡</div>
                <div style="font-weight:bold;">Immédiat</div>
                <div style="color:#ffa500;">x${mult[0]}</div>
                <div style="color:#aaa; font-size:10px;">~${Math.round(baseDeg * mult[0])} dégâts</div>
              </td>
              <td style="padding:8px; border:1px solid #444; text-align:center; background:rgba(255,165,0,0.1);">
                <div style="font-size:16px;">🔸</div>
                <div style="font-weight:bold;">1 Round</div>
                <div style="color:#ffa500;">x${mult[1]}</div>
                <div style="color:#aaa; font-size:10px;">~${Math.round(baseDeg * mult[1])} dégâts</div>
              </td>
            </tr>
            <tr>
              <td style="padding:8px; border:1px solid #444; text-align:center; background:rgba(255,100,0,0.1);">
                <div style="font-size:16px;">🔶</div>
                <div style="font-weight:bold;">2 Rounds</div>
                <div style="color:#ff8c00;">x${mult[2]}</div>
                <div style="color:#aaa; font-size:10px;">~${Math.round(baseDeg * mult[2])} dégâts</div>
              </td>
              <td style="padding:8px; border:1px solid #444; text-align:center; background:rgba(255,50,0,0.15);">
                <div style="font-size:16px;">🔴</div>
                <div style="font-weight:bold;">3 Rounds</div>
                <div style="color:#ff4400;">x${mult[3]}</div>
                <div style="color:#aaa; font-size:10px;">~${Math.round(baseDeg * mult[3])} dégâts</div>
              </td>
            </tr>
          </table>
        </div>
      `;

      const dialog = new Dialog({
        title: `⚡ Charge — ${technique.name}`,
        content,
        buttons: {
          niveau0: {
            icon: '<i class="fas fa-bolt"></i>',
            label: "⚡ Immédiat (0 round)",
            callback: () => resolve(0)
          },
          niveau1: {
            icon: '<i class="fas fa-hourglass-start"></i>',
            label: "🔸 1 Round",
            callback: () => resolve(1)
          },
          niveau2: {
            icon: '<i class="fas fa-hourglass-half"></i>',
            label: "🔶 2 Rounds",
            callback: () => resolve(2)
          },
          niveau3: {
            icon: '<i class="fas fa-hourglass-end"></i>',
            label: "🔴 3 Rounds",
            callback: () => resolve(3)
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "❌ Annuler",
            callback: () => resolve(null)
          }
        },
        default: "niveau0",
        close: () => resolve(null)
      }, { width: 450, height: "auto" });
      dialog.render(true);
    });
  }

  /* ============================================
     DÉMARRER UNE CHARGE
     Stocke l'état dans les flags de l'actor
     ============================================ */
  static async demarrerCharge(actor, technique, niveau, multiplicateur) {
    if (niveau === 0) return null; // lancement immédiat, pas de charge à stocker

    const chargeData = {
      en_charge: true,
      techniqueId: technique.id,
      techniqueName: technique.name,
      toursRestants: niveau,
      toursTotal: niveau,
      multiplicateur: multiplicateur,
      roundDebut: game.combat?.round ?? 0
    };

    await actor.setFlag("ffdreame", "charge", chargeData);

    // ✅ Message avec bouton de libération manuelle (fiable même hors hook)
    // Le bouton "Libérer" décrémente ou libère la charge immédiatement
    const actorId = actor.id;
    const messageContent = `
      <div style="background:rgba(255,165,0,0.1);border-left:4px solid #ffa500;padding:10px 14px;border-radius:7px">
        <h3 style="color:#ffa500;margin:0 0 6px;">⚡ CHARGE EN COURS — ${technique.name}</h3>
        <p style="color:#aaa;font-size:12px;margin:0 0 4px;">
          <span id="charge-tours-${actorId}">${niveau}</span> round${niveau > 1 ? 's' : ''} restant${niveau > 1 ? 's' : ''} | 
          Multiplicateur : <strong style="color:#ffa500;">x${multiplicateur}</strong>
        </p>
        <p style="color:#ff4444;font-size:11px;margin:0 0 8px;">
          ⚠️ ${actor.name} est en charge — Aucune action possible !<br>
          ⚠️ Une attaque interrompt et annule la charge !
        </p>
        <div style="display:flex;gap:6px;margin-top:6px;">
          <button class="ffdreame-charge-next" data-actorid="${actorId}" 
            style="flex:1;background:rgba(255,165,0,0.2);border:1px solid #ffa500;border-radius:4px;color:#ffa500;padding:5px 8px;cursor:pointer;font-size:11px;">
            ⏩ Round suivant (-1 round)
          </button>
          <button class="ffdreame-charge-liberer" data-actorid="${actorId}"
            style="flex:1;background:rgba(255,100,0,0.3);border:1px solid #ff8c00;border-radius:4px;color:#ff8c00;padding:5px 8px;cursor:pointer;font-size:11px;font-weight:bold;">
            ⚡ Libérer maintenant !
          </button>
          <button class="ffdreame-charge-annuler" data-actorid="${actorId}"
            style="background:rgba(100,100,100,0.2);border:1px solid #555;border-radius:4px;color:#888;padding:5px 8px;cursor:pointer;font-size:11px;">
            ✕
          </button>
        </div>
      </div>
    `;

    const msg = await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: messageContent
    });

    // Écouter les clics sur les boutons du message
    Hooks.once("renderChatMessage", (chatMsg, html) => {
      if (chatMsg.id !== msg.id) return;
      FFdreameChargeSystem._attacherBoutonsCharge(html, actor, technique);
    });

    return chargeData;
  }

  /* ============================================
     ATTACHER LES BOUTONS DU MESSAGE DE CHARGE
     ============================================ */
  static _attacherBoutonsCharge(html, actor, technique) {
    html.find(".ffdreame-charge-next").on("click", async () => {
      const chargeData = actor.getFlag("ffdreame", "charge");
      if (!chargeData) return;
      const restant = chargeData.toursRestants - 1;
      if (restant <= 0) {
        await actor.unsetFlag("ffdreame", "charge");
        await FFdreameChargeSystem._lancerChargeAvecJet(actor, technique, chargeData.multiplicateur);
      } else {
        await actor.setFlag("ffdreame", "charge", { ...chargeData, toursRestants: restant });
        ui.notifications.info(`⚡ ${actor.name} — encore ${restant} round${restant > 1 ? "s" : ""} de charge`);
      }
    });

    html.find(".ffdreame-charge-liberer").on("click", async () => {
      const chargeData = actor.getFlag("ffdreame", "charge");
      const mult = chargeData?.multiplicateur ?? 1.0;
      await actor.unsetFlag("ffdreame", "charge");
      await FFdreameChargeSystem._lancerChargeAvecJet(actor, technique, mult);
    });

    html.find(".ffdreame-charge-annuler").on("click", async () => {
      await actor.unsetFlag("ffdreame", "charge");
      ui.notifications.info(`❌ Charge annulée pour ${actor.name}`);
    });
  }

  /* ============================================
     INTERROMPRE UNE CHARGE (attaque reçue)
     Appelé depuis le système de combat quand l'actor est touché
     ============================================ */
  static async interrompre(actor) {
    const chargeData = actor.getFlag("ffdreame", "charge");
    if (!chargeData || !chargeData.en_charge) return false;

    await actor.unsetFlag("ffdreame", "charge");

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div style="background:rgba(255,50,50,0.1);border-left:4px solid #ff4444;padding:8px 12px;border-radius:6px">
          <strong style="color:#ff4444;">💥 CHARGE INTERROMPUE !</strong>
          <p style="color:#aaa;font-size:12px;margin:4px 0 0;">
            La charge de <strong>${chargeData.techniqueName}</strong> de ${actor.name} est annulée !
          </p>
        </div>
      `
    });

    return true;
  }

  /* ============================================
     VÉRIFIER SI L'ACTOR EST EN CHARGE
     Bloque les actions si nécessaire
     ============================================ */
  static estEnCharge(actor) {
    const chargeData = actor.getFlag("ffdreame", "charge");
    return chargeData && chargeData.en_charge === true;
  }

  static getChargeData(actor) {
    return actor.getFlag("ffdreame", "charge") || null;
  }

  /* ============================================
     HOOK updateCombat
     Décrémente les ROUNDS de charge et lance automatiquement
     Un ROUND = quand TOUS les joueurs ont joué
     ============================================ */
  static async _onUpdateCombat(combat, changed, options, userId) {
    // Uniquement sur changement de ROUND (pas de turn)
    if (changed.round === undefined) return;
    if (!game.user.isGM) return;

    const currentRound = combat.round ?? 0;

    for (const combatant of combat.combatants) {
      const actor = combatant.actor;
      if (!actor) continue;

      const chargeData = actor.getFlag("ffdreame", "charge");
      if (!chargeData || !chargeData.en_charge) continue;

      // Calculer les rounds écoulés depuis le début de la charge
      const roundDebut = chargeData.roundDebut ?? currentRound;
      const roundsEcoules = currentRound - roundDebut;
      const roundsTotal = chargeData.toursTotal ?? 1; // "toursTotal" = nombre de rounds
      const restant = Math.max(0, roundsTotal - roundsEcoules);

      console.log(`🔋 Charge ${actor.name}: Round ${currentRound}, Début: ${roundDebut}, Écoulés: ${roundsEcoules}, Total: ${roundsTotal}, Restant: ${restant}`);

      if (restant <= 0) {
        // Charge terminée → lancer la technique automatiquement
        await actor.unsetFlag("ffdreame", "charge");

        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `
            <div style="background:rgba(255,100,0,0.15);border-left:4px solid #ff8c00;padding:10px 14px;border-radius:7px">
              <h3 style="color:#ff8c00;margin:0 0 6px;">⚡ CHARGE LIBÉRÉE — ${chargeData.techniqueName}</h3>
              <p style="color:#aaa;font-size:12px;margin:0 0 4px;">
                Multiplicateur appliqué : <strong style="color:#ff8c00;">x${chargeData.multiplicateur}</strong>
                (${chargeData.toursTotal} round${chargeData.toursTotal > 1 ? 's' : ''} de charge)
              </p>
              <p style="color:#aaa;font-size:11px;margin:0;">
                ⚡ La technique est automatiquement lancée avec le jet de dés !
              </p>
            </div>
          `
        });

        // Récupère la technique et lance avec multiplicateur
        const technique = actor.items.get(chargeData.techniqueId);
        if (technique) {
          await this._lancerChargeAvecJet(actor, technique, chargeData.multiplicateur);
        }

      } else {
        // Décrémente
        await actor.setFlag("ffdreame", "charge", {
          ...chargeData,
          toursRestants: restant
        });

        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `
            <div style="background:rgba(255,165,0,0.07);border-left:3px solid #ffa500;padding:6px 10px;border-radius:5px;font-size:11px">
              ⚡ <strong>${actor.name}</strong> charge <em>${chargeData.techniqueName}</em> —
              encore <strong>${restant} round${restant > 1 ? 's' : ''}</strong>...
              (x${chargeData.multiplicateur} en préparation)
            </div>
          `
        });
      }
    }
  }

  /* ============================================
     HOOK updateActor
     Annule la charge si l'acteur prend des dégâts
     ============================================ */
  static async _onActorDamage(actor, changed, options, userId) {
    // Vérifier si les PV ont changé (pris des dégâts)
    if (!changed.system?.aptitudes?.pv?.value) return;
    
    const chargeData = actor.getFlag("ffdreame", "charge");
    if (!chargeData || !chargeData.en_charge) return;

    const pvAvant = foundry.utils.getProperty(actor, "_source.system.aptitudes.pv.value");
    const pvApres = changed.system.aptitudes.pv.value;

    // Si les PV ont DIMINUÉ (pris des dégâts)
    if (pvApres < pvAvant) {
      await actor.unsetFlag("ffdreame", "charge");

      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `
          <div style="background:rgba(255,50,50,0.15);border-left:4px solid #ff4444;padding:10px 14px;border-radius:7px">
            <h3 style="color:#ff4444;margin:0 0 6px;">💥 CHARGE INTERROMPUE — ${chargeData.techniqueName}</h3>
            <p style="color:#aaa;font-size:12px;margin:0;">
              <strong>${actor.name}</strong> a pris des dégâts pendant la charge !<br>
              ⚠️ La charge est <strong>annulée</strong> et perdue.
            </p>
          </div>
        `
      });

      ui.notifications.warn(`💥 ${actor.name} : Charge interrompue par les dégâts !`);
    }
  }

  /* ============================================
     LANCER LE JET DE CHARGE — séparé pour clarté
     Fonctionne que la fiche soit ouverte ou non
     ============================================ */
  static async _lancerChargeAvecJet(actor, technique, multiplicateur) {
    // Tenter via la fiche si elle est ouverte
    const sheet = actor.sheet;
    if (sheet && sheet.rendered && typeof sheet._useTechniqueWithMultiplier === "function") {
      await sheet._useTechniqueWithMultiplier(technique, multiplicateur);
      return;
    }

    // ✅ Fallback direct : jet complet sans la fiche
    const rang           = actor.system.rang || "F";
    const rangModifier   = actor._getRangModifier?.(rang);
    const seuilReussite  = rangModifier?.jetReussite ?? 50;
    const pmActuel       = actor.system.aptitudes.pm.value;
    const coutPM         = technique.system.coutPM || 0;

    if (pmActuel < coutPM) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<div style="background:rgba(255,50,50,0.1);border-left:3px solid #ff4444;padding:8px;border-radius:5px">
          ⚠️ PM insuffisants pour déclencher <strong>${technique.name}</strong> ! (${pmActuel}/${coutPM} PM)
        </div>`
      });
      return;
    }

    // Calculer malus
    const fatigueMalus  = actor._calculateFatigueMalus?.()  ?? 0;
    const blessureMalus = actor._calculateBlessureMalus?.() ?? 0;
    const totalMalus    = fatigueMalus + blessureMalus;
    const formula       = totalMalus > 0 ? `1d100 + ${totalMalus}` : "1d100";

    const roll    = new Roll(formula);
    await roll.evaluate();
    const total   = roll.total;
    const success = total <= seuilReussite;
    const isCrit  = total <= 5;
    const isEchec = total >= 95;

    // Déduire les PM
    await actor.update({ "system.aptitudes.pm.value": pmActuel - coutPM });

    const degatsBase = Math.round((actor._calculateTechniqueDegats?.(technique) ?? technique.system.baseDegats ?? 0) * multiplicateur);
    let resultText = success ? `✓ Réussite` : "✗ Échec";
    if (isCrit)  resultText = "⭐ SUCCÈS CRITIQUE !";
    if (isEchec) resultText = "💀 ÉCHEC CRITIQUE !";
    const cssClass = isCrit ? "critical-success" : isEchec ? "critical-failure" : success ? "success" : "failure";

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor:  `<h3>⚡ ${technique.name} — Charge x${multiplicateur}</h3>
                <p style="color:#aaa;font-size:11px">Seuil ≤ ${seuilReussite}${totalMalus > 0 ? ` | +${totalMalus} malus` : ''}</p>`,
      content: `<div class="dice-roll"><div class="dice-result">
        <div class="dice-formula">${formula}</div>
        <div class="dice-total ${cssClass}">${total} — ${resultText}</div>
      </div></div>`
    });

    if (success) {
      // Appliquer dégâts à la cible
      const targets = Array.from(game.user.targets);
      const target  = targets[0];
      if (target?.actor) {
        const pvCible = target.actor.system.aptitudes.pv.value;
        const nvPV    = Math.max(0, pvCible - degatsBase);
        await target.actor.update({ "system.aptitudes.pv.value": nvPV });
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div style="background:rgba(255,100,0,0.1);border-left:3px solid #ff8c00;padding:6px 10px;border-radius:5px;font-size:11px">
            ⚡ <b>${target.actor.name}</b> subit <b>${degatsBase} dégâts</b> (charge x${multiplicateur}) | PV : ${pvCible} → ${nvPV}${nvPV === 0 ? " 💀 <b>K.O.</b>" : ""}
          </div>`
        });
      } else {
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div style="background:rgba(255,100,0,0.1);border-left:3px solid #ff8c00;padding:6px 10px;border-radius:5px;font-size:11px">
            ⚡ <b>${degatsBase} dégâts</b> (charge x${multiplicateur}) — Aucune cible sélectionnée.
          </div>`
        });
      }
    }
  }
}