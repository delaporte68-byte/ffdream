/**
 * ============================================
 * SYSTÈME AOER - AOE RETARDÉ
 * ============================================
 * Techniques de boss qui marquent une zone au sol
 * et se déclenchent au round suivant
 */

export class FFdreameAOER {
  
  /**
   * Utiliser une technique AOER
   */
  static async useTechniqueAOER(actor, technique) {
    console.log(`🔥 Technique AOER : ${technique.name}`);
    
    const aoerConfig = technique.system.aoer || {};
    const forme = aoerConfig.forme || "cercle";
    
    // Notification stylée d'alerte AOER
    if (window.FFdreameNotifications) {
      await window.FFdreameNotifications.showAOERWarning(actor.name, technique.name);
    } else {
      ui.notifications.info(`⚠️ ${actor.name} prépare ${technique.name} !`);
    }
    
    // Choisir où placer la zone
    let position = null;
    
    if (forme === "cercle") {
      position = await this._placerZoneCercle(actor, technique, aoerConfig);
    } else if (forme === "ligne") {
      position = await this._placerZoneLigne(actor, technique, aoerConfig);
    } else if (forme === "triangle") {
      position = await this._placerZoneTriangle(actor, technique, aoerConfig);
    }
    
    if (!position) {
      ui.notifications.warn("❌ Placement annulé");
      return { success: false };
    }
    
    // Créer la zone marquée
    await this._creerZoneMarquee(actor, technique, position, aoerConfig);
    
    // Message dans le chat
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `
        <div style="
          background: rgba(255, 0, 0, 0.2);
          padding: 15px;
          border-left: 4px solid #ff0000;
          border-radius: 8px;
          text-align: center;
        ">
          <h3 style="margin: 0; color: #ff0000;">⚠️ ZONE DE DANGER !</h3>
          <p><strong>${actor.name}</strong> prépare <strong>${technique.name}</strong></p>
          <p style="font-size: 14px; color: #ff6666;">
            Cette zone se déclenchera au prochain round !<br/>
            💥 Dégâts : ${technique.system.baseDegats}<br/>
            ⏱️ Déclenchement : Round ${(game.combat?.round || 0) + 1}
          </p>
        </div>
      `
    });
    
    return { success: true };
  }
  
  /**
   * Placer une zone cercle (clic sur la carte)
   */
  static async _placerZoneCercle(actor, technique, config) {
    const token = actor.getActiveTokens()[0];
    if (!token) return null;
    
    const distanceMax = config.distanceMax || 10;
    const gridDistance = canvas.scene.grid.distance || 1.5;
    const gridSize = canvas.grid.size;
    
    ui.notifications.info("🎯 Cliquez pour placer la zone circulaire");
    
    return new Promise((resolve) => {
      const clickHandler = (event) => {
        const pos = event.getLocalPosition(canvas.tokens); // v13: plus besoin de .data
        
        // Vérifier distance depuis le token
        const dx = (pos.x - token.center.x) / gridSize;
        const dy = (pos.y - token.center.y) / gridSize;
        const distance = Math.sqrt(dx * dx + dy * dy) * gridDistance;
        
        if (distance > distanceMax) {
          ui.notifications.warn(`⚠️ Trop loin ! Max : ${distanceMax}m`);
          return;
        }
        
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        resolve({ x: pos.x, y: pos.y, forme: "cercle" });
      };
      
      const cancelHandler = () => {
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        resolve(null);
      };
      
      canvas.stage.on("click", clickHandler);
      canvas.stage.on("contextmenu", cancelHandler);
    });
  }
  
  /**
   * Placer une zone ligne (depuis le token)
   */
  static async _placerZoneLigne(actor, technique, config) {
    const token = actor.getActiveTokens()[0];
    if (!token) return null;
    
    const distanceMax = config.distanceMax || 10;
    
    ui.notifications.info("🎯 Cliquez pour orienter la ligne");
    
    return new Promise((resolve) => {
      const clickHandler = (event) => {
        const pos = event.getLocalPosition(canvas.tokens); // v13: plus besoin de .data
        
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        
        // Calculer l'angle vers le point cliqué
        const dx = pos.x - token.center.x;
        const dy = pos.y - token.center.y;
        const angle = Math.atan2(dy, dx);
        
        resolve({
          x: token.center.x,
          y: token.center.y,
          forme: "ligne",
          direction: angle
        });
      };
      
      const cancelHandler = () => {
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        resolve(null);
      };
      
      canvas.stage.on("click", clickHandler);
      canvas.stage.on("contextmenu", cancelHandler);
    });
  }
  
  /**
   * Placer une zone triangle (depuis le token)
   */
  static async _placerZoneTriangle(actor, technique, config) {
    const token = actor.getActiveTokens()[0];
    if (!token) return null;
    
    const distanceMax = config.distanceMax || 10;
    
    ui.notifications.info("🎯 Cliquez pour orienter le triangle");
    
    return new Promise((resolve) => {
      const clickHandler = (event) => {
        const pos = event.getLocalPosition(canvas.tokens); // v13: plus besoin de .data
        
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        
        // Calculer l'angle vers le point cliqué
        const dx = pos.x - token.center.x;
        const dy = pos.y - token.center.y;
        const angle = Math.atan2(dy, dx);
        
        resolve({
          x: token.center.x,
          y: token.center.y,
          forme: "triangle",
          direction: angle
        });
      };
      
      const cancelHandler = () => {
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        resolve(null);
      };
      
      canvas.stage.on("click", clickHandler);
      canvas.stage.on("contextmenu", cancelHandler);
    });
  }
  
  /**
   * Créer la zone marquée au sol (template rouge)
   */
  static async _creerZoneMarquee(actor, technique, position, config) {
    const forme = position.forme;
    const taille = config.taille || 3;
    const distanceMax = config.distanceMax || 10;
    const angle = config.angle || 90;
    
    let templateData = {
      user: game.user.id,
      fillColor: "#ff0000",
      borderColor: "#ff0000",
      flags: {
        ffdreame: {
          aoerZone: true,
          lanceurId: actor.id,
          techniqueId: technique.id,
          techniqueName: technique.name,
          baseDegats: technique.system.baseDegats || 0,
          effet1: technique.system.effet1,
          effet2: technique.system.effet2,
          animation: technique.system.animation,
          roundCreation: game.combat?.round || 0,
          roundDeclenchement: (game.combat?.round || 0) + 1
        }
      }
    };
    
    if (forme === "cercle") {
      templateData.t = "circle";
      templateData.x = position.x;
      templateData.y = position.y;
      templateData.distance = taille;
    } else if (forme === "ligne") {
      templateData.t = "ray";
      templateData.x = position.x;
      templateData.y = position.y;
      templateData.distance = distanceMax;
      templateData.width = taille;
      templateData.direction = (position.direction * 180) / Math.PI;
    } else if (forme === "triangle") {
      templateData.t = "cone";
      templateData.x = position.x;
      templateData.y = position.y;
      templateData.distance = distanceMax;
      templateData.angle = angle;
      templateData.direction = (position.direction * 180) / Math.PI;
    }
    
    const templates = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]);
    const template = templates[0];
    
    console.log(`✅ Zone AOER créée : ${template.id}`);
    
    // Animation de placement (flash rouge)
    if (typeof Sequence !== 'undefined') {
      try {
        new Sequence()
          .effect()
          .file("jb2a.energy_field.02.above.red")
          .atLocation({ x: position.x, y: position.y })
          .size(taille * 2 * canvas.grid.size, { gridUnits: false })
          .duration(2000)
          .fadeIn(500)
          .fadeOut(500)
          .play();
      } catch (error) {
        console.warn("Animation placement AOER:", error);
      }
    }
    
    return template;
  }
  
  /**
   * Initialiser le système (hook pour détecter les nouveaux rounds)
   */
  static init() {
    console.log('FFdreame | Initialisation du système AOER...');
    
    Hooks.on("updateCombat", this._onCombatUpdate.bind(this));
    
    console.log('FFdreame | Système AOER activé ✅');
  }
  
  /**
   * Détecter le changement de round et déclencher les zones
   */
  static async _onCombatUpdate(combat, changed, options, userId) {
    if (changed.round === undefined) return;
    
    const roundActuel = changed.round;
    console.log(`🔥 AOER : Vérification des zones pour round ${roundActuel}`);
    
    // Récupérer toutes les zones AOER
    const zones = canvas.templates.placeables.filter(t => 
      t.document.getFlag('ffdreame', 'aoerZone')
    );
    
    if (zones.length === 0) return;
    
    for (const zone of zones) {
      const zoneData = zone.document.getFlag('ffdreame', 'aoerZone');
      const roundDeclenchement = zone.document.getFlag('ffdreame', 'roundDeclenchement');
      
      if (roundActuel >= roundDeclenchement) {
        await this._declencherZone(zone);
      }
    }
  }
  
  /**
   * Déclencher une zone AOER
   */
  static async _declencherZone(zoneTemplate) {
    const zoneFlags = zoneTemplate.document.flags.ffdreame;
    const lanceur = game.actors.get(zoneFlags.lanceurId);
    
    console.log(`💥 Déclenchement zone AOER : ${zoneFlags.techniqueName}`);
    
    // Jouer l'animation
    await this._jouerAnimationDeclenchement(zoneTemplate, zoneFlags);
    
    // Trouver les tokens dans la zone
    const tokensInZone = this._getTokensInZone(zoneTemplate);
    
    console.log(`   ${tokensInZone.length} token(s) dans la zone`);
    
    // Appliquer dégâts et effets
    for (const token of tokensInZone) {
      // Ne pas blesser le lanceur
      if (token.actor.id === zoneFlags.lanceurId) {
        console.log(`   Ignoré: ${token.name} (lanceur)`);
        continue;
      }
      
      const degats = zoneFlags.baseDegats || 0;
      const pvActuel = token.actor.system.aptitudes?.pv?.value || 0;
      const nouveauPV = Math.max(0, pvActuel - degats);
      
      await token.actor.update({
        'system.aptitudes.pv.value': nouveauPV
      });
      
      console.log(`   💥 ${token.name}: ${pvActuel} → ${nouveauPV} (-${degats})`);
      
      // Message de dégâts
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: lanceur }),
        content: `
          <div style="background: rgba(255, 0, 0, 0.2); padding: 10px; border-left: 3px solid #ff0000;">
            <strong>💥 ${zoneFlags.techniqueName}</strong><br/>
            <strong>${token.name}</strong> subit <strong>${degats} dégâts</strong> !<br/>
            <small>PV: ${pvActuel} → ${nouveauPV}</small>
          </div>
        `
      });
      
      // TODO: Appliquer les effets (effet1, effet2)
      // Utiliser le même système que les techniques normales
    }
    
    // Supprimer la zone
    await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [zoneTemplate.id]);
    
    ui.notifications.info(`💥 ${zoneFlags.techniqueName} déclenché !`);
  }
  
  /**
   * Jouer l'animation de déclenchement
   */
  static async _jouerAnimationDeclenchement(template, zoneFlags) {
    if (typeof Sequence === 'undefined') return;
    if (!zoneFlags.animation?.jb2a) return;
    
    try {
      const duree = (zoneFlags.animation.duree || 3) * 1000;
      
      new Sequence()
        .effect()
        .file(zoneFlags.animation.jb2a)
        .atLocation({ x: template.x, y: template.y })
        .size(template.distance * 2 * canvas.grid.size, { gridUnits: false })
        .duration(duree)
        .fadeIn(500)
        .fadeOut(500)
        .play();
    } catch (error) {
      console.warn("Animation déclenchement AOER:", error);
    }
  }
  
  /**
   * Récupérer les tokens dans une zone
   */
  static _getTokensInZone(zoneTemplate) {
    const tokens = [];
    const template = zoneTemplate.document;
    
    for (const token of canvas.tokens.placeables) {
      if (this._isTokenInTemplate(token, template)) {
        tokens.push(token);
      }
    }
    
    return tokens;
  }
  
  /**
   * Vérifier si un token est dans un template
   */
  static _isTokenInTemplate(token, template) {
    const gridSize = canvas.grid.size;
    
    if (template.t === "circle") {
      const dx = token.center.x - template.x;
      const dy = token.center.y - template.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const radius = template.distance * gridSize;
      return distance <= radius;
    }
    else if (template.t === "ray") {
      // Ligne droite
      // TODO: Implémenter si nécessaire
      return false;
    }
    else if (template.t === "cone") {
      // Cône/Triangle
      const dx = token.center.x - template.x;
      const dy = token.center.y - template.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const maxDistance = template.distance * gridSize;
      
      if (distance > maxDistance) return false;
      
      // Vérifier l'angle
      const angleToToken = Math.atan2(dy, dx) * (180 / Math.PI);
      const templateAngle = template.direction || 0;
      const coneAngle = template.angle || 90;
      
      let angleDiff = Math.abs(angleToToken - templateAngle);
      if (angleDiff > 180) angleDiff = 360 - angleDiff;
      
      return angleDiff <= coneAngle / 2;
    }
    
    return false;
  }
}
