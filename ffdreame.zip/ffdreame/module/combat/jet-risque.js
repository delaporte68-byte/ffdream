/**
 * ============================================
 * SYSTÈME JET DU RISQUE — FFdreame
 * ============================================
 * Universel : compatible avec tous les styles de technique.
 * Après une réussite normale, propose au joueur de relancer
 * pour tenter d'obtenir un bonus de dégâts, au risque d'un malus.
 *
 * - Succès → bonus de dégâts défini dans la config
 * - Échec  → malus % sur le prochain jet pendant N tours
 *
 * Stockage malus : actor flag ffdreame.jetRisqueMalus
 */

export class FFdreameJetRisque {

  /* ============================================
     PROPOSER LE JET DU RISQUE
     Appelé depuis actor-sheet.js après une réussite
     Retourne { tente: bool, success: bool, bonusDegats: number }
     ============================================ */
  static async proposer(actor, technique, jetOriginal) {
    const config = technique.system.jetRisque || {};
    if (!config.actif) return { tente: false };

    const bonusDegats = config.bonusDegats ?? 20;
    const malusEchec  = config.malusEchec  ?? 15;
    const malusDuree  = config.malusDuree  ?? 1;

    // Afficher bouton dans le chat via un message interactif
    const accepted = await this._dialogRisque(actor, technique, bonusDegats, malusEchec, malusDuree);

    if (!accepted) {
      return { tente: false };
    }

    // Relancer le dé avec les mêmes paramètres
    const seuilBase = actor._getRangModifier(actor.system.rang || "F").jetReussite;
    const fatigueMalus  = actor._calculateFatigueMalus?.() ?? 0;
    const blessureMalus = actor._calculateBlessureMalus?.() ?? 0;
    const totalMalus = fatigueMalus + blessureMalus;
    const formula = totalMalus > 0 ? `1d100 + ${totalMalus}` : "1d100";

    const roll = new Roll(formula);
    await roll.evaluate();
    const total = roll.total;
    const success = total <= seuilBase;

    if (success) {
      // Bonus !
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor: `<h3>🎲 JET DU RISQUE — ${technique.name}</h3>`,
        content: `
          <div class="dice-roll">
            <div class="dice-result">
              <div class="dice-formula">${formula}</div>
              <div class="dice-total critical-success">${total} — ⭐ RÉUSSI !</div>
            </div>
          </div>
          <div style="background:rgba(68,255,136,0.1);border-left:3px solid #44ff88;padding:8px 12px;border-radius:5px;margin-top:6px">
            <strong style="color:#44ff88;">🎉 Jet du Risque réussi !</strong>
            <p style="color:#aaa;font-size:12px;margin:4px 0 0;">
              <strong>+${bonusDegats} dégâts bonus</strong> en plus des dégâts de la technique !
            </p>
          </div>
        `
      });

      return { tente: true, success: true, bonusDegats };

    } else {
      // Malus sur prochain jet
      await this._appliquerMalus(actor, malusEchec, malusDuree);

      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        flavor: `<h3>🎲 JET DU RISQUE — ${technique.name}</h3>`,
        content: `
          <div class="dice-roll">
            <div class="dice-result">
              <div class="dice-formula">${formula}</div>
              <div class="dice-total critical-failure">${total} — ❌ RATÉ !</div>
            </div>
          </div>
          <div style="background:rgba(255,50,50,0.1);border-left:3px solid #ff4444;padding:8px 12px;border-radius:5px;margin-top:6px">
            <strong style="color:#ff4444;">💥 Jet du Risque raté !</strong>
            <p style="color:#aaa;font-size:12px;margin:4px 0 0;">
              Malus de <strong>+${malusEchec}%</strong> sur le prochain jet pendant <strong>${malusDuree} tour${malusDuree > 1 ? 's' : ''}</strong>.
            </p>
          </div>
        `
      });

      return { tente: true, success: false, bonusDegats: 0 };
    }
  }

  /* ============================================
     DIALOGUE — Propose de tenter le jet du risque
     ============================================ */
  static async _dialogRisque(actor, technique, bonusDegats, malusEchec, malusDuree) {
    return new Promise(resolve => {
      const content = `
        <div style="padding:12px; text-align:center;">
          <h3 style="color:#ffd700; margin:0 0 10px;">🎲 Jet du Risque</h3>
          <p style="color:#aaa; font-size:12px; margin:0 0 15px;">
            La technique a réussi ! Veux-tu tenter le <strong style="color:#ffd700;">Jet du Risque</strong> ?
          </p>
          <div style="display:flex; gap:10px; justify-content:center;">
            <div style="background:rgba(68,255,136,0.1); border:1px solid #44ff88; border-radius:6px; padding:10px 15px; font-size:11px; flex:1;">
              <div style="color:#44ff88; font-size:20px; margin-bottom:4px;">✅</div>
              <div style="font-weight:bold; color:#44ff88; margin-bottom:4px;">OUI — Je tente !</div>
              <div style="color:#aaa;">→ Réussite : <strong>+${bonusDegats} dégâts bonus</strong></div>
              <div style="color:#aaa;">→ Échec : Malus <strong>+${malusEchec}%</strong> (${malusDuree} tour${malusDuree > 1 ? 's' : ''})</div>
            </div>
            <div style="background:rgba(100,100,100,0.1); border:1px solid #555; border-radius:6px; padding:10px 15px; font-size:11px; flex:1;">
              <div style="font-size:20px; margin-bottom:4px;">🛡️</div>
              <div style="font-weight:bold; color:#aaa; margin-bottom:4px;">NON — Je reste</div>
              <div style="color:#666;">→ Garde les dégâts normaux</div>
              <div style="color:#666;">→ Aucun malus</div>
            </div>
          </div>
        </div>
      `;

      new Dialog({
        title: `🎲 Jet du Risque — ${technique.name}`,
        content,
        buttons: {
          oui: {
            label: "🎲 OUI, je tente !",
            callback: () => resolve(true)
          },
          non: {
            label: "🛡️ Non, je garde",
            callback: () => resolve(false)
          }
        },
        default: "non",
        close: () => resolve(false)
      }, { width: 380, height: "auto" }).render(true);
    });
  }

  /* ============================================
     APPLIQUER LE MALUS SUR L'ACTOR
     Stocké dans les flags et décrémenté à chaque tour
     ============================================ */
  static async _appliquerMalus(actor, valeur, duree) {
    await actor.setFlag("ffdreame", "jetRisqueMalus", {
      valeur,
      tours: duree
    });
    console.log(`FFdreame | JetRisque malus appliqué à ${actor.name} : +${valeur}% pendant ${duree} tour(s)`);
  }

  /* ============================================
     DÉCRÉMENTER LE MALUS À CHAQUE TOUR
     Appelé depuis le hook updateCombat (actor-sheet ou ffdreame.js)
     ============================================ */
  static async decrementerMalus(actor) {
    const malus = actor.getFlag("ffdreame", "jetRisqueMalus");
    if (!malus || malus.tours <= 0) return;

    const nouveauTours = malus.tours - 1;
    if (nouveauTours <= 0) {
      await actor.unsetFlag("ffdreame", "jetRisqueMalus");
      console.log(`FFdreame | JetRisque malus expiré pour ${actor.name}`);
    } else {
      await actor.setFlag("ffdreame", "jetRisqueMalus", {
        ...malus,
        tours: nouveauTours
      });
    }
  }

  /* ============================================
     LIRE LE MALUS ACTUEL D'UN ACTOR
     Utilisé dans _lancerDe de multi-aoe-persistent.js
     et actor-sheet.js pour ajuster le seuil
     ============================================ */
  static getMalus(actor) {
    const malus = actor.getFlag("ffdreame", "jetRisqueMalus");
    if (malus && malus.tours > 0) return malus.valeur;
    return 0;
  }
}
