/**
 * ============================================
 * SYSTÈME DE COMBAT FFDREAME
 * ============================================
 * Gère le Combat Tracker personnalisé avec :
 * - Initiative (1d100 + bonus "Prend l'Initiative")
 * - Gestion des tours (bloquer/débloquer tableaux)
 * - Récupération de 1 Grand PA par tour
 * - Affichage PV/PM/PA/Fatigue/Blessure
 */

import { FFdreameTableauEffects } from "./tableau-effets.js";

export class FFdreameCombatSystem {
  
  /**
   * Initialiser le système de combat
   */
  static init() {
    console.log('FFdreame | Initialisation du système de combat...');
    
    // Hook pour personnaliser le Combat Tracker
    Hooks.on("renderCombatTracker", this._onRenderCombatTracker.bind(this));
    
    // Hook pour gérer le changement de tour
    Hooks.on("updateCombat", this._onUpdateCombat.bind(this));
    
    // Hook pour gérer le début de combat
    Hooks.on("createCombat", this._onCreateCombat.bind(this));
    
    // Hook pour gérer la fin de combat
    Hooks.on("deleteCombat", this._onDeleteCombat.bind(this));
    
    // Note: l'Initiative Assurée est gérée directement dans gm-tracker-sheet.js après rollAll()
    
    console.log('FFdreame | Système de combat activé ✅');
  }
  
  /**
   * Personnaliser l'affichage du Combat Tracker
   */
  static _onRenderCombatTracker(app, html, data) {
    console.log('FFdreame | Personnalisation du Combat Tracker');
    
    // Vérifier que le combat existe
    if (!app.combat) {
      console.log('FFdreame | Pas de combat actif');
      return;
    }
    
    // Injecter le CSS pour limiter la taille des tokens
    if (!document.getElementById('ffdreame-combat-tracker-css')) {
      const style = document.createElement('style');
      style.id = 'ffdreame-combat-tracker-css';
      style.textContent = `
        /* Combat Tracker - Limiter taille tokens */
        #combat-tracker .combatant,
        #combat-popout .combatant {
          max-height: 60px !important;
          min-height: 40px !important;
        }
        
        #combat-tracker .combatant-controls,
        #combat-popout .combatant-controls {
          flex: 0 0 auto;
        }
        
        #combat-tracker .token-image,
        #combat-popout .token-image {
          max-width: 36px !important;
          max-height: 36px !important;
          flex-shrink: 0;
        }
        
        #combat-tracker .token-name,
        #combat-popout .token-name {
          font-size: 13px;
          flex: 1 1 auto;
          min-width: 0;
        }
        
        /* Encounters sidebar - Tokens petits */
        .directory .directory-item img.thumbnail {
          max-width: 36px !important;
          max-height: 36px !important;
        }
        
        .directory .directory-item {
          max-height: 50px !important;
          padding: 4px 8px !important;
        }
        
        #combat-tracker .combatant.active,
        #combat-popout .combatant.active {
          box-shadow: 0 0 8px 2px rgba(255, 68, 0, 0.5);
        }
        
        /* Boutons MJ visibles */
        #combat-tracker .ffdreame-gm-buttons {
          margin-top: 8px;
          padding: 8px;
          border-top: 1px solid #444;
        }
        
        #combat-tracker .ffdreame-gm-buttons button {
          width: 100%;
          margin: 4px 0;
          padding: 6px 12px;
          font-size: 12px;
        }
      `;
      document.head.appendChild(style);
    }
    
    // Parcourir chaque combattant
    html.find('.combatant').each((i, el) => {
      const combatantId = el.dataset.combatantId;
      const combatant = app.combat?.combatants.get(combatantId);
      
      if (!combatant || !combatant.actor) return;
      
      const actor = combatant.actor;
      
      // Personnaliser les personnages joueurs ET les NPC
      if (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc" && actor.type !== "npc") return;
      
      // Récupérer les infos
      const pv = actor.system.aptitudes?.pv?.value || 0;
      const pvMax = actor.system.aptitudes?.pv?.max || 0;
      const pm = actor.system.aptitudes?.pm?.value || 0;
      const pmMax = actor.system.aptitudes?.pm?.max || 0;
      
      // Compter les PA disponibles
      const actionPoints = actor.system.combat?.actionPoints || {};
      let paDisponibles = 0;
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand && grand.petit1 && grand.petit2) {
          paDisponibles++;
        }
      }
      
      // Compter Fatigue et Blessures
      const fatigues = actor.system.combat?.fatigues || {};
      let nbFatigues = 0;
      for (let key in fatigues) {
        if (fatigues[key] === true) nbFatigues++;
      }
      
      const blessures = actor.system.combat?.blessures || {};
      let nbBlessures = 0;
      for (let key in blessures) {
        if (blessures[key] === true) nbBlessures++;
      }
      
      // Vérifier si les actions sont bloquées
      const actionBlocked = actor.getFlag('ffdreame', 'actionBlocked') || false;
      
      // Créer l'affichage personnalisé
      const infoHtml = `
        <div class="ffdreame-combat-info" style="
          font-size: 10px;
          padding: 2px 4px;
          display: flex;
          gap: 6px;
          align-items: center;
          flex-wrap: wrap;
        ">
          <span style="color: ${pv <= pvMax / 4 ? '#ff0000' : pv <= pvMax / 2 ? '#ff9900' : '#00ff00'};" title="Points de Vie">
            ❤️ ${pv}/${pvMax}
          </span>
          <span style="color: #00d9ff;" title="Points de Magie">
            ✨ ${pm}/${pmMax}
          </span>
          <span style="color: #ffdd00;" title="Points d'Action">
            ⚡ ${paDisponibles}/3 PA
          </span>
          ${nbFatigues > 0 ? `<span style="color: #999;" title="Fatigue">😴 ${nbFatigues}</span>` : ''}
          ${nbBlessures > 0 ? `<span style="color: #ff6666;" title="Blessures">🩹 ${nbBlessures}</span>` : ''}
          ${actionBlocked ? `<span style="color: #ff0000;" title="Tour terminé">🔒</span>` : ''}
        </div>
      `;
      
      // Ajouter après le nom
      $(el).find('.token-name').after(infoHtml);
      
      // Ajouter une classe si bloqué
      if (actionBlocked) {
        $(el).addClass('ffdreame-turn-ended');
        $(el).css('opacity', '0.6');
      }
    });
    
    // Ajouter boutons MJ si GM
    if (game.user.isGM) {
      this._addGMButtons(html, app.combat);
    }
  }
  
  /**
   * Ajouter les boutons MJ au Combat Tracker
   */
  static _addGMButtons(html, combat) {
    if (!combat) return;
    
    const buttonsHtml = `
      <div class="ffdreame-gm-buttons" style="padding: 5px; border-top: 1px solid #444;">
        <button class="ffdreame-new-round" style="width: 100%; margin: 2px 0;">
          🔄 Nouveau Round (Récupérer PA)
        </button>
        <button class="ffdreame-unlock-all" style="width: 100%; margin: 2px 0;">
          🔓 Débloquer Tous les Joueurs
        </button>
      </div>
    `;
    
    html.find('.combat-controls').after(buttonsHtml);
    
    // Événements
    html.find('.ffdreame-new-round').on('click', async () => {
      await this.newRound(combat);
    });
    
    html.find('.ffdreame-unlock-all').on('click', async () => {
      await this.unlockAllPlayers(combat);
    });
  }
  
  /**
   * Gérer le changement de tour/round
   */
  static async _onUpdateCombat(combat, changed, options, userId) {
    console.log('🔍 updateCombat hook:', { changed, round: combat.round, previous: combat.previous });
    
    // Détecter le changement de round
    if (changed.round !== undefined && changed.round > (combat.previous?.round || 0)) {
      console.log(`🔄 Nouveau round détecté: ${changed.round}`);
      await this.newRound(combat);
    }
    
    // Détecter le changement de tour
    if (changed.turn !== undefined) {
      // ✅ Décrémenter TOUS les effets temporaires sur l'actor dont le tour vient de SE TERMINER
      // combat.combatant = nouveau combattant (tour qui commence)
      // combat.previous.turn = index du tour qui vient de finir
      const previousTurnIndex = combat.previous?.turn ?? -1;
      const previousCombatant = combat.turns[previousTurnIndex];
      if (previousCombatant?.actor) {
        await this._decrementerEffetsTemporaires(previousCombatant.actor);
      }

      // Démarrer le tour du nouveau combattant
      const currentCombatant = combat.combatant;
      if (currentCombatant && currentCombatant.actor) {
        console.log(`▶️ Tour de: ${currentCombatant.name}`);
        await this.startTurn(currentCombatant.actor);
      }
    }
  }

  /**
   * Décrémenter tous les effets temporaires d'un actor à la fin de son tour
   */
  static async _decrementerEffetsTemporaires(actor) {
    // Liste des flags d'effets à décrémenter
    const effetsFlags = [
      'jetRisqueMalus',
      'malusJet',
      'reducDegats',
      'bufAttaque',
      'bufJet',
      'bufDefense',
      'sautColonne',
      'eviterConfrontation'
    ];

    for (const flagName of effetsFlags) {
      const effet = actor.getFlag('ffdreame', flagName);
      if (!effet || !effet.tours) continue;

      const toursRestants = effet.tours - 1;

      if (toursRestants <= 0) {
        await actor.unsetFlag('ffdreame', flagName);
        console.log(`FFdreame | ✅ Effet ${flagName} expiré pour ${actor.name}`);
        ui.notifications.info(`✅ Effet ${flagName} expiré pour ${actor.name}`);
      } else {
        // Mettre à jour le nombre de tours restants
        const updatedEffet = { ...effet, tours: toursRestants };
        await actor.setFlag('ffdreame', flagName, updatedEffet);
        console.log(`FFdreame | ⏳ Effet ${flagName} : ${toursRestants} tour(s) restant(s) pour ${actor.name}`);
      }
    }
  }
  
  /**
   * Début du combat
   */
  // Initiative Assurée : gérée dans gm-tracker-sheet.js directement après rollAll()
  
  static async _onCreateCombat(combat, options, userId) {
    console.log('⚔️ Combat démarré !');
    
    // Initialiser tous les combattants
    for (const combatant of combat.combatants) {
      if (combatant.actor) {
        await this.initializeCombatant(combatant.actor);
      }
    }
    
    // Appliquer l'Initiative Assurée si déjà lancée (cas rare : combattants ajoutés avant démarrage)
    // Le cas principal est géré par _onCheckInitiativeAssuree via updateCombat
  }
  
  /**
   * Fin du combat
   */
  static async _onDeleteCombat(combat, options, userId) {
    console.log('🏁 Combat terminé !');
    
    // Débloquer tous les joueurs + effacer les parades + reset Initiative Assurée + reset grand4
    for (const combatant of combat.combatants) {
      if (combatant.actor) {
        await combatant.actor.unsetFlag('ffdreame', 'actionBlocked');
        await combatant.actor.unsetFlag('ffdreame', 'paradeActive');
        await combatant.actor.unsetFlag('ffdreame', 'initiativeAssureePrise');
        // Désactiver le grand4 bonus de fin de combat
        await combatant.actor.update({
          'system.combat.actionPoints.grand4.disponible': false,
          'system.combat.actionPoints.grand4.petit1': true,
          'system.combat.actionPoints.grand4.petit2': true
        });
      }
    }
  }
  
  /**
   * Initialiser un combattant au début du combat
   */
  static async initializeCombatant(actor) {
    if (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc") return;
    
    await actor.update({
      'system.combat.deplacementGratuitUtilise': false
    });
    
    await actor.unsetFlag('ffdreame', 'actionBlocked');
    await actor.unsetFlag('ffdreame', 'paradeActive');
    
    console.log(`✅ ${actor.name} initialisé pour le combat`);
  }
  
  /**
   * Démarrer le tour d'un acteur
   */
  static async startTurn(actor) {
    if (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc") return;

    // ── Bloquer TOUS les autres combattants sauf celui dont c'est le tour ──
    // Garantit qu'aucun joueur ne peut agir hors de son tour, même sans clic "Fin Tour"
    if (game.combat?.started) {
      const types = ["character", "cyberpunk", "npc"];
      for (const combatant of game.combat.combatants) {
        if (!combatant.actor || !types.includes(combatant.actor.type)) continue;
        if (combatant.actorId === actor.id) {
          // C'est son tour → débloquer
          await combatant.actor.unsetFlag('ffdreame', 'actionBlocked');
        } else {
          // Pas son tour → bloquer
          await combatant.actor.setFlag('ffdreame', 'actionBlocked', true);
        }
      }
    } else {
      await actor.unsetFlag('ffdreame', 'actionBlocked');
    }

    // Notification stylée
    if (window.FFdreameNotifications) {
      await window.FFdreameNotifications.showTurnStart(actor.name);
    } else {
      ui.notifications.info(`▶️ C'est le tour de ${actor.name} !`);
    }
  }
  
  /**
   * Nouveau round : Récupérer 1 Grand PA pour tous
   */
  static async newRound(combat) {
    console.log('🔄🔄🔄 === DÉBUT NOUVEAU ROUND === 🔄🔄🔄');
    console.log('Combat:', combat);
    console.log('Nombre de combattants:', combat.combatants.length);
    
    for (const combatant of combat.combatants) {
      const actor = combatant.actor;
      
      console.log(`\n--- Traitement de ${actor?.name || 'acteur inconnu'} ---`);
      console.log('Type acteur:', actor?.type);
      
      if (!actor || (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc")) {
        console.log(`⏭️ Ignoré (type: ${actor?.type})`);
        continue;
      }
      
      console.log(`🔍 ${actor.name} - Combat data:`, actor.system.combat);
      console.log(`🔍 ${actor.name} - ActionPoints:`, actor.system.combat?.actionPoints);
      
      // Récupérer 1 Grand PA (si pas au max de 3)
      const actionPoints = actor.system.combat?.actionPoints;
      
      if (!actionPoints) {
        console.error(`❌ ${actor.name} n'a pas de structure actionPoints !`);
        console.log('Structure system.combat:', actor.system.combat);
        continue;
      }
      
      let paRecuperes = 0;
      
      // Grand4 (bonus effet tableau) : prioritaire à la régénération si utilisé
      // On le vérifie EN PREMIER pour qu'il soit restauré avant les PA normaux
      const grand4 = actionPoints['grand4'];
      if (grand4?.disponible && (grand4.petit1 === false || grand4.petit2 === false)) {
        await actor.update({
          'system.combat.actionPoints.grand4.petit1': true,
          'system.combat.actionPoints.grand4.petit2': true
        });
        paRecuperes++;
        console.log(`✅ ${actor.name} - Grand PA bonus (grand4) restauré en priorité`);
      }
      
      // Si grand4 n'a pas consommé la régénération, chercher parmi grand1→grand3
      if (paRecuperes === 0) {
        for (let i = 1; i <= 3; i++) {
          const grand = actionPoints[`grand${i}`];
          
          console.log(`\n  🔍 Vérification Grand PA ${i}:`);
          console.log(`    - Existe:`, !!grand);
          
          if (!grand) {
            console.error(`    ❌ grand${i} n'existe pas !`);
            continue;
          }
          
          console.log(`    - petit1:`, grand.petit1);
          console.log(`    - petit2:`, grand.petit2);
          console.log(`    - Complet:`, grand.petit1 === true && grand.petit2 === true);
          
          if (grand.petit1 === false || grand.petit2 === false) {
            console.log(`    ✅ Restauration nécessaire !`);
            console.log(`    📝 Update en cours...`);
            const result = await actor.update({
              [`system.combat.actionPoints.grand${i}.petit1`]: true,
              [`system.combat.actionPoints.grand${i}.petit2`]: true
            });
            console.log(`    📝 Update résultat:`, result);
            paRecuperes++;
            console.log(`    ✅ Grand PA ${i} restauré !`);
            break; // On ne récupère qu'1 seul Grand PA
          } else {
            console.log(`    ⏭️ Déjà complet, on continue...`);
          }
        }
      }
      
      if (paRecuperes === 0) {
        console.log(`ℹ️ ${actor.name} - Tous les PA sont déjà au maximum`);
      } else {
        console.log(`✅ ${actor.name} - ${paRecuperes} Grand PA récupéré`);
      }
      
      // Réinitialiser le déplacement gratuit
      console.log(`📝 Réinitialisation déplacement...`);
      await actor.update({
        'system.combat.deplacementGratuitUtilise': false
      });
      
      // Désactiver les réactions
      console.log(`📝 Désactivation réactions...`);
      await actor.update({
        'system.combat.reactions.esquive': false,
        'system.combat.reactions.defense': false,
        'system.combat.reactions.marche': false
      });
      
      // Débloquer les actions
      console.log(`📝 Déblocage actions...`);
      await actor.unsetFlag('ffdreame', 'actionBlocked');
      
      console.log(`✅✅ ${actor.name} terminé: PA=${paRecuperes > 0 ? '+1' : 'max'}, Déplacement=OK, Réactions=OFF\n`);
    }
    
    console.log('🔄🔄🔄 === FIN NOUVEAU ROUND === 🔄🔄🔄\n');
    
    // Notification stylée nouveau round
    if (window.FFdreameTeleportation) {
      await window.FFdreameNotifications.showNewRound(combat.round);
    } else {
      ui.notifications.info('🔄 Nouveau tour ! Tous les joueurs ont récupéré 1 Grand PA et peuvent se déplacer.');
    }
  }
  
  /**
   * Débloquer tous les joueurs (bouton MJ)
   */
  static async unlockAllPlayers(combat) {
    for (const combatant of combat.combatants) {
      const actor = combatant.actor;
      if (!actor || (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc")) continue;
      
      await actor.unsetFlag('ffdreame', 'actionBlocked');
    }
    
    ui.notifications.info('🔓 Tous les joueurs ont été débloqués !');
  }
  
  /**
   * Calculer l'initiative pour un acteur
   * @param {Actor} actor - L'acteur
   * @returns {number} - Le résultat de l'initiative
   */
  static async rollInitiative(actor) {
    // Vérifier si le bonus "Prend l'Initiative" est actif
    const initiativeBonus = actor.system.combat?.initiativeBonus || false;
    
    if (initiativeBonus) {
      // Si le bonus est actif, initiative = 999 (toujours premier)
      return 999;
    }
    
    // Sinon, jet normal de 1d100
    const roll = new Roll("1d100");
    await roll.evaluate();
    
    return roll.total;
  }
}
