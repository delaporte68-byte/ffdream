/* ================================
   GESTIONNAIRE DE BUFFS ET EFFETS
   Gère tous les effets persistants des techniques
   ================================ */

export class FFdreameBuffManager {
  
  /* ================================
     APPLIQUER LES BUFFS AUX JETS
     ================================ */
  static applyBuffsToRoll(actor, baseFormula) {
    let formula = baseFormula;
    let buffsActifs = [];
    
    // BufJ - Réduit le résultat du jet (système inversé : - est mieux)
    const bufJet = actor.getFlag('ffdreame', 'bufJet');
    if (bufJet && bufJet.tours > 0) {
      const reduction = bufJet.unite === "pourcent" 
        ? Math.floor(100 * bufJet.valeur / 100)
        : bufJet.valeur;
      formula += ` - ${reduction}`;
      buffsActifs.push(`🎲 BufJ -${bufJet.valeur}${bufJet.unite === "pourcent" ? "%" : ""}`);
    }
    
    // Malus Jet (sur l'acteur, pas sur la cible)
    const malusJet = actor.getFlag('ffdreame', 'malusJet');
    if (malusJet && malusJet.tours > 0) {
      formula += ` + ${malusJet.valeur}`;
      buffsActifs.push(`📉 Malus Jet +${malusJet.valeur}%`);
    }
    
    return { formula, buffsActifs };
  }
  
  /* ================================
     APPLIQUER LES BUFFS AUX DÉGÂTS (ATTAQUE)
     ================================ */
  static applyBuffsToDamage(actor, baseDamage) {
    let degatsFinaux = baseDamage;
    let buffsActifs = [];
    
    // BufA - Bonus Attaque
    const bufAttaque = actor.getFlag('ffdreame', 'bufAttaque');
    if (bufAttaque && bufAttaque.tours > 0) {
      const bonus = bufAttaque.unite === "pourcent"
        ? Math.floor(baseDamage * bufAttaque.valeur / 100)
        : bufAttaque.valeur;
      degatsFinaux += bonus;
      buffsActifs.push(`⚔️ BufA +${bonus} dégâts`);
    }
    
    return { degatsFinaux, buffsActifs };
  }
  
  /* ================================
     APPLIQUER LES BUFFS AUX DÉGÂTS (DÉFENSE)
     ================================ */
  static applyBuffsToDefense(actor, incomingDamage) {
    let degatsFinaux = incomingDamage;
    let buffsActifs = [];
    
    // BufD - Bonus Défense (réduit dégâts reçus)
    const bufDefense = actor.getFlag('ffdreame', 'bufDefense');
    if (bufDefense && bufDefense.tours > 0) {
      const reduction = bufDefense.unite === "pourcent"
        ? Math.floor(incomingDamage * bufDefense.valeur / 100)
        : bufDefense.valeur;
      degatsFinaux = Math.max(0, incomingDamage - reduction);
      buffsActifs.push(`🛡️ BufD -${reduction} dégâts reçus`);
    }
    
    return { degatsFinaux, buffsActifs };
  }
  
  /* ================================
     DÉCRÉMENTER TOUS LES BUFFS (À CHAQUE TOUR)
     ================================ */
  static async decrementBuffs(actor) {
    const buffsADecremente = [
      'bufAttaque',
      'bufJet', 
      'bufDefense',
      'bufPA',
      'malusJet',
      'reducDegats',
      'sc',
      'ec'
    ];
    
    for (const buffName of buffsADecremente) {
      await this.decrementBuff(actor, buffName);
    }
  }
  
  /* ================================
     DÉCRÉMENTER UN BUFF SPÉCIFIQUE
     ================================ */
  static async decrementBuff(actor, buffName) {
    const buff = actor.getFlag('ffdreame', buffName);
    if (!buff || !buff.tours || buff.tours <= 0) return;
    
    const nouveauxTours = buff.tours - 1;
    
    if (nouveauxTours <= 0) {
      // Buff expiré
      await actor.unsetFlag('ffdreame', buffName);
      
      const buffLabels = {
        'bufAttaque': '⚔️ Bonus Attaque',
        'bufJet': '🎲 Bonus Jet',
        'bufDefense': '🛡️ Bonus Défense',
        'bufPA': '⚡ Point d\'Action Supplémentaire',
        'malusJet': '📉 Malus Jet',
        'reducDegats': '⚔️💔 Réduction Dégâts',
        'sc': '🎯 Succès Critique',
        'ec': '🛡️ Échec Critique'
      };
      
      const label = buffLabels[buffName] || buffName;
      
      if (window.FFdreameNotifications) {
        await window.FFdreameNotifications.showNotification({
          title: "⏱️ EFFET EXPIRÉ",
          subtitle: `${label} terminé`,
          color: "#888888",
          icon: "⏱️",
          duration: 2000
        });
      } else {
        ui.notifications.info(`⏱️ ${label} expiré pour ${actor.name}`);
      }
      
      // Cas spécial BufPA : supprimer le grand4
      if (buffName === 'bufPA') {
        await actor.update({
          'system.combat.actionPoints.grand4': {
            petit1: false,
            petit2: false
          },
          'system.combat.bufPA': {
            actif: false,
            tours: 0,
            nbPA: 0
          }
        });
      }
    } else {
      // Mettre à jour la durée
      await actor.setFlag('ffdreame', buffName, {
        ...buff,
        tours: nouveauxTours
      });
    }
  }
  
  /* ================================
     OBTENIR TOUS LES BUFFS ACTIFS
     ================================ */
  static getActiveBuffs(actor) {
    const buffsActifs = [];
    
    const bufAttaque = actor.getFlag('ffdreame', 'bufAttaque');
    if (bufAttaque && bufAttaque.tours > 0) {
      buffsActifs.push({
        type: 'bufAttaque',
        icon: '⚔️',
        label: `Attaque +${bufAttaque.valeur}${bufAttaque.unite === "pourcent" ? "%" : ""}`,
        tours: bufAttaque.tours
      });
    }
    
    const bufJet = actor.getFlag('ffdreame', 'bufJet');
    if (bufJet && bufJet.tours > 0) {
      buffsActifs.push({
        type: 'bufJet',
        icon: '🎲',
        label: `Jet -${bufJet.valeur}${bufJet.unite === "pourcent" ? "%" : ""}`,
        tours: bufJet.tours
      });
    }
    
    const bufDefense = actor.getFlag('ffdreame', 'bufDefense');
    if (bufDefense && bufDefense.tours > 0) {
      buffsActifs.push({
        type: 'bufDefense',
        icon: '🛡️',
        label: `Défense -${bufDefense.valeur}${bufDefense.unite === "pourcent" ? "%"}`,
        tours: bufDefense.tours
      });
    }
    
    const bufPA = actor.getFlag('ffdreame', 'bufPA');
    if (bufPA && bufPA.tours > 0 && bufPA.actif) {
      buffsActifs.push({
        type: 'bufPA',
        icon: '⚡',
        label: `PA Supplémentaire`,
        tours: bufPA.tours
      });
    }
    
    const malusJet = actor.getFlag('ffdreame', 'malusJet');
    if (malusJet && malusJet.tours > 0) {
      buffsActifs.push({
        type: 'malusJet',
        icon: '📉',
        label: `Malus Jet +${malusJet.valeur}%`,
        tours: malusJet.tours
      });
    }
    
    const reducDegats = actor.getFlag('ffdreame', 'reducDegats');
    if (reducDegats && reducDegats.tours > 0) {
      buffsActifs.push({
        type: 'reducDegats',
        icon: '⚔️💔',
        label: `Réduit Dégâts -${reducDegats.valeur}%`,
        tours: reducDegats.tours
      });
    }
    
    const sc = actor.getFlag('ffdreame', 'sc');
    if (sc && sc.tours > 0) {
      buffsActifs.push({
        type: 'sc',
        icon: '🎯',
        label: `Succès Critique augmenté`,
        tours: sc.tours
      });
    }
    
    const ec = actor.getFlag('ffdreame', 'ec');
    if (ec && ec.tours > 0) {
      buffsActifs.push({
        type: 'ec',
        icon: '🛡️',
        label: `Échec Critique réduit`,
        tours: ec.tours
      });
    }
    
    return buffsActifs;
  }
  
  /* ================================
     AFFICHER LES BUFFS DANS LE CHAT
     ================================ */
  static getBuffsHTML(actor) {
    const buffs = this.getActiveBuffs(actor);
    
    if (buffs.length === 0) return '';
    
    let html = '<div style="background: rgba(0, 217, 255, 0.1); padding: 10px; border-left: 3px solid #00d9ff; border-radius: 4px; margin-top: 10px;">';
    html += '<h4 style="margin: 0 0 8px 0; color: #00d9ff;">✨ Effets Actifs</h4>';
    html += '<ul style="margin: 0; padding-left: 20px; list-style: none;">';
    
    for (const buff of buffs) {
      html += `<li style="margin: 4px 0;">${buff.icon} ${buff.label} (${buff.tours} tour${buff.tours > 1 ? 's' : ''})</li>`;
    }
    
    html += '</ul></div>';
    
    return html;
  }
}

// Rendre disponible globalement
window.FFdreameBuffManager = FFdreameBuffManager;
