/**
 * ============================================
 * SYSTÈME DE TÉLÉPORTATION FFDREAME — v2.0
 * ============================================
 *
 * DEUX USAGES DISTINCTS :
 *
 * 1) ONGLET TÉLÉPORTATION (bonus de déplacement, tous styles)
 *    → Après réussite d'une technique (CAC, MAG, etc.)
 *    → Déplace automatiquement le lanceur d'un nombre de cases défini
 *    → Animations : dash, blink, warp, misty_step, wind_step, smoke
 *    → Pas de jet supplémentaire, pas de choix de destination
 *
 * 2) STYLE TP (technique de téléportation pure)
 *    → Jet de dés requis (1 Grand PA)
 *    → Preview PIXI pour choisir la destination (cercle de portée)
 *    → Clic = destination | Clic droit = annuler
 *    → Si le joueur se cible lui-même → il se téléporte
 *    → Si le joueur cible un ennemi → l'ennemi est téléporté
 *    → Animation départ + arrivée
 */

export class FFdreameTeleportation {

  static ANIMATIONS = {
    "dash_bleu":    { depart: "jb2a.wind_walk.01.blueyellow",          arrivee: null,                                  label: "💨 Dash Bleu" },
    "dash_blanc":   { depart: "jb2a.wind_walk.01.white",               arrivee: null,                                  label: "💨 Dash Blanc" },
    "dash_vert":    { depart: "jb2a.wind_walk.01.green",               arrivee: null,                                  label: "💨 Dash Vert" },
    "misty_step":   { depart: "jb2a.misty_step.01.blue",               arrivee: "jb2a.misty_step.02.blue",             label: "🌫️ Misty Step Bleu" },
    "misty_purple": { depart: "jb2a.misty_step.01.purple",             arrivee: "jb2a.misty_step.02.purple",           label: "🌫️ Misty Step Violet" },
    "misty_green":  { depart: "jb2a.misty_step.01.green",              arrivee: "jb2a.misty_step.02.green",            label: "🌫️ Misty Step Vert" },
    "smoke":        { depart: "jb2a.smoke.puff.centered.grey.0",       arrivee: "jb2a.smoke.puff.centered.grey.0",     label: "🌑 Fumée Grise" },
    "smoke_black":  { depart: "jb2a.smoke.puff.centered.black.0",      arrivee: "jb2a.smoke.puff.centered.black.0",    label: "🌑 Fumée Noire" },
    "warp_bleu":    { depart: "jb2a.portals.edges.round.blue.closed.01",  arrivee: "jb2a.portals.edges.round.blue.open.01",    label: "🌀 Portail Bleu" },
    "warp_violet":  { depart: "jb2a.portals.edges.round.purple.closed.01",arrivee: "jb2a.portals.edges.round.purple.open.01",  label: "🌀 Portail Violet" },
    "warp_vert":    { depart: "jb2a.portals.edges.round.green.closed.01", arrivee: "jb2a.portals.edges.round.green.open.01",   label: "🌀 Portail Vert" },
    "lightning":    { depart: "jb2a.lightning_bolt.narrow.blue",       arrivee: null,                                  label: "⚡ Éclair" },
    "aucune":       { depart: null,                                     arrivee: null,                                  label: "❌ Aucune" },
  };

  /* ============================================================
     1) DÉPLACEMENT BONUS (Onglet Téléportation, tous styles)
     Appelé depuis actor-sheet.js après réussite de n'importe quel style
     ============================================================ */
  static async appliquerDeplacementBonus(lanceurActor, cibleToken, config) {
    if (!config?.actif) return;

    const lanceurToken = lanceurActor.getActiveTokens()[0];
    if (!lanceurToken) return;

    const gridSize = canvas.grid.size;
    const distanceCases = config.distanceCases || 3;
    const type = config.type || "lanceur";
    const position = config.position || "derriere";
    const animKey = config.animation || "misty_step";

    let tokenADeplacer = null;
    let refToken = null;

    if (type === "lanceur") {
      tokenADeplacer = lanceurToken;
      refToken = cibleToken;
    } else if (type === "cible" && cibleToken) {
      tokenADeplacer = cibleToken;
      refToken = lanceurToken;
    }

    if (!tokenADeplacer) {
      ui.notifications.warn("⚠️ Déplacement bonus : aucun token cible.");
      return;
    }

    let newX = tokenADeplacer.x;
    let newY = tokenADeplacer.y;

    if (refToken) {
      switch (position) {
        case "derriere":
          newX = refToken.x;
          newY = refToken.y - distanceCases * gridSize;
          break;
        case "devant":
          newX = refToken.x;
          newY = refToken.y + distanceCases * gridSize;
          break;
        case "gauche":
          newX = refToken.x - distanceCases * gridSize;
          newY = refToken.y;
          break;
        case "droite":
          newX = refToken.x + distanceCases * gridSize;
          newY = refToken.y;
          break;
        case "derriere_cible": {
          const dx = refToken.x - lanceurToken.x;
          const dy = refToken.y - lanceurToken.y;
          const len = Math.sqrt(dx * dx + dy * dy) || 1;
          newX = refToken.x + (dx / len) * distanceCases * gridSize;
          newY = refToken.y + (dy / len) * distanceCases * gridSize;
          break;
        }
      }
    } else {
      newY = tokenADeplacer.y - distanceCases * gridSize;
    }

    newX = Math.max(0, Math.min(canvas.scene.width - gridSize, newX));
    newY = Math.max(0, Math.min(canvas.scene.height - gridSize, newY));

    const anim = this.ANIMATIONS[animKey] || this.ANIMATIONS["misty_step"];
    await this._jouerAnim(anim.depart, { x: tokenADeplacer.x + gridSize / 2, y: tokenADeplacer.y + gridSize / 2 });
    // ✅ FIX : ffdreameBypass=true pour ignorer les restrictions de déplacement
    await tokenADeplacer.document.update({ x: newX, y: newY }, { animate: false, teleport: true, ffdreameBypass: true });
    if (anim.arrivee) {
      await this._jouerAnim(anim.arrivee, { x: newX + gridSize / 2, y: newY + gridSize / 2 });
    }

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: lanceurActor }),
      content: `<div style="background:rgba(138,43,226,0.1);border-left:3px solid #8a2be2;padding:6px 10px;border-radius:5px;font-size:11px">
        ${anim.label} — <strong>${tokenADeplacer.name}</strong> se déplace de <strong>${distanceCases} case${distanceCases > 1 ? 's' : ''}</strong>
      </div>`
    });
  }

  /* ============================================================
     2) STYLE TP — Technique de téléportation pure avec jet
     Preview PIXI avec cercle de portée + destination au clic
     ============================================================ */
  static async executerTechniqueTP(lanceurActor, technique, seuilReussite) {
    const config = technique.system.teleportation || {};
    const distanceMaxCases = config.distanceMax || 5;
    const animKey = config.animation || "misty_step";

    const lanceurToken = lanceurActor.getActiveTokens()[0];
    if (!lanceurToken) {
      ui.notifications.warn("❌ Aucun token trouvé !");
      return { success: false };
    }

    const targets = Array.from(game.user.targets);
    const cibleToken = targets.length > 0 ? targets[0] : null;

    // Soi-même si pas de cible ou cible = lanceur
    const teleporteSoi = !cibleToken || cibleToken.actor?.id === lanceurActor.id;
    const tokenATeleporter = teleporteSoi ? lanceurToken : cibleToken;
    const originToken = tokenATeleporter; // portée calculée depuis le token qui bougera

    const gridSize = canvas.grid.size;
    const cibleLabel = teleporteSoi ? lanceurActor.name : (cibleToken?.name ?? "?");

    ui.notifications.info(
      teleporteSoi
        ? `🚀 ${lanceurActor.name} — Choisissez votre destination (≤ ${distanceMaxCases} cases) | Clic droit = annuler`
        : `🚀 Téléportation de ${cibleLabel} — Choisissez sa destination (≤ ${distanceMaxCases} cases) | Clic droit = annuler`
    );

    const preview = this._buildTPPreview();
    canvas.stage.addChild(preview);

    const destination = await new Promise(resolve => {
      let lastPos = null;

      const onMove = e => {
        lastPos = e.data.getLocalPosition(canvas.stage);
        const dist = this._distCases(originToken.center, lastPos, gridSize);
        this._updateTPPreview(preview, originToken.center, lastPos, distanceMaxCases * gridSize, dist <= distanceMaxCases, dist, distanceMaxCases);
      };

      const onClick = () => {
        if (!lastPos) return;
        const dist = this._distCases(originToken.center, lastPos, gridSize);
        cleanup();
        if (dist > distanceMaxCases) {
          ui.notifications.warn(`❌ Trop loin ! (${dist.toFixed(1)} / ${distanceMaxCases} cases)`);
          resolve(null);
          return;
        }
        const snapped = canvas.grid.getSnappedPosition(lastPos.x - gridSize / 2, lastPos.y - gridSize / 2);
        resolve({ x: snapped.x, y: snapped.y });
      };

      const onCancel = () => { cleanup(); ui.notifications.info("❌ Annulé"); resolve(null); };
      const onKey = e => { if (e.key === "Escape") onCancel(); };

      const cleanup = () => {
        canvas.stage.off("pointermove", onMove);
        canvas.stage.off("click", onClick);
        canvas.stage.off("rightclick", onCancel);
        window.removeEventListener("keydown", onKey);
        try { preview.destroy(); } catch(e) {}
      };

      canvas.stage.on("pointermove", onMove);
      canvas.stage.on("click", onClick);
      canvas.stage.on("rightclick", onCancel);
      window.addEventListener("keydown", onKey);
    });

    if (!destination) return { success: false, cancelled: true };

    // ── Jet de dés ──
    const fatigueMalus  = lanceurActor._calculateFatigueMalus?.()  ?? 0;
    const blessureMalus = lanceurActor._calculateBlessureMalus?.() ?? 0;
    const totalMalus = fatigueMalus + blessureMalus;
    const formula = totalMalus > 0 ? `1d100 + ${totalMalus}` : "1d100";

    const roll = new Roll(formula);
    await roll.evaluate();
    const total = roll.total;
    const success = total <= seuilReussite;
    const isCrit  = total <= 5;
    const isEchec = total >= 95;

    let resultText = success ? "✓ Réussite" : "✗ Échec";
    if (isCrit)  resultText = "⭐ SUCCÈS CRITIQUE !";
    if (isEchec) resultText = "💀 ÉCHEC CRITIQUE !";

    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: lanceurActor }),
      flavor: `<h3>🚀 ${technique.name}</h3>
               <p>Style TP — Cible : <strong>${cibleLabel}</strong> | Seuil ≤ ${seuilReussite}${totalMalus > 0 ? ` (+${totalMalus} malus)` : ''}</p>`,
      content: `<div class="dice-roll"><div class="dice-result">
        <div class="dice-formula">${formula}</div>
        <div class="dice-total ${isCrit ? 'critical-success' : isEchec ? 'critical-failure' : success ? 'success' : 'failure'}">
          ${total} ${resultText}
        </div>
      </div></div>`
    });

    if (!success) {
      ui.notifications.warn("❌ Jet raté — Téléportation échouée !");
      return { success: false };
    }

    // ── Téléportation ──
    const anim = this.ANIMATIONS[animKey] || this.ANIMATIONS["misty_step"];
    await this._jouerAnim(anim.depart, tokenATeleporter.center);
    // ✅ FIX : ffdreameBypass=true pour ignorer les restrictions de déplacement (movement-blocker)
    await tokenATeleporter.document.update({ x: destination.x, y: destination.y }, { animate: false, teleport: true, ffdreameBypass: true });

    const destCenter = { x: destination.x + (tokenATeleporter.w ?? gridSize) / 2, y: destination.y + (tokenATeleporter.h ?? gridSize) / 2 };
    if (anim.arrivee) {
      await this._jouerAnim(anim.arrivee, destCenter);
    } else if (anim.depart) {
      await this._jouerAnim(anim.depart, destCenter);
    }

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: lanceurActor }),
      content: `<div style="background:rgba(0,217,255,0.1);border-left:4px solid #00d9ff;padding:10px 14px;border-radius:7px">
        <h3 style="color:#00d9ff;margin:0 0 6px">🚀 TÉLÉPORTATION — ${technique.name}</h3>
        <p style="color:#aaa;font-size:12px;margin:0">
          <strong>${cibleLabel}</strong> est téléporté${teleporteSoi ? '' : 'e'} ! ${anim.label}
        </p>
      </div>`
    });

    return { success: true };
  }

  /* ── Utilitaires ── */
  static _distCases(a, b, gs) {
    return Math.sqrt(((b.x - a.x) / gs) ** 2 + ((b.y - a.y) / gs) ** 2);
  }

  static async _jouerAnim(fichier, pos) {
    if (!fichier) return;
    // ✅ FIX : vérifier Sequencer via game.modules ET typeof
    if (!game.modules.get("sequencer")?.active || typeof Sequence === "undefined") {
      console.warn("FFdreame | Téléportation : Sequencer non disponible, animation ignorée");
      return;
    }
    try {
      await new Sequence()
        .effect()
          .file(fichier)
          .atLocation(pos)
          .fadeIn(200)
          .fadeOut(200)
          .waitUntilFinished(-200)
        .play();
    } catch (e) {
      console.warn("FFdreame | TP anim (fichier ignoré) :", fichier, e.message);
    }
  }

  static _buildTPPreview() {
    const g = new PIXI.Container();
    g._ring  = new PIXI.Graphics();
    g._cross = new PIXI.Graphics();
    g._text  = new PIXI.Text("", { fontFamily: "Arial", fontSize: 13, fill: 0xffffff, stroke: 0x000000, strokeThickness: 3 });
    g.addChild(g._ring, g._cross, g._text);
    return g;
  }

  static _updateTPPreview(preview, origin, dest, rayonPx, inRange, dist, distMax) {
    const col = inRange ? 0x00d9ff : 0xff4444;

    preview._ring.clear();
    preview._ring.lineStyle(2, col, 0.35);
    preview._ring.beginFill(col, 0.04);
    preview._ring.drawCircle(origin.x, origin.y, rayonPx);
    preview._ring.endFill();
    preview._ring.lineStyle(1, col, 0.35);
    preview._ring.moveTo(origin.x, origin.y);
    preview._ring.lineTo(dest.x, dest.y);

    preview._cross.clear();
    preview._cross.lineStyle(2, col, 0.9);
    preview._cross.beginFill(col, inRange ? 0.22 : 0.06);
    preview._cross.drawCircle(dest.x, dest.y, 14);
    preview._cross.endFill();
    preview._cross.lineStyle(1.5, col, 0.9);
    preview._cross.moveTo(dest.x - 10, dest.y); preview._cross.lineTo(dest.x + 10, dest.y);
    preview._cross.moveTo(dest.x, dest.y - 10); preview._cross.lineTo(dest.x, dest.y + 10);

    preview._text.text = `${dist.toFixed(1)} / ${distMax} cases`;
    preview._text.style.fill = inRange ? 0x00d9ff : 0xff4444;
    preview._text.x = dest.x + 16;
    preview._text.y = dest.y - 8;
  }

  /* Compatibilité ancien code */
  static isTeleportationEnabled(technique) {
    return technique?.system?.teleportation?.actif || false;
  }
  static getTeleportationConfig(technique) {
    return technique?.system?.teleportation || null;
  }
  static async handleTeleportation(lanceur, cibleToken, teleportConfig) {
    return this.appliquerDeplacementBonus(lanceur, cibleToken, teleportConfig);
  }
}
