/**
 * ============================================
 * MIGRATION DES DONNÉES — FFdreame
 * ============================================
 * Ajoute les champs manquants sur les documents
 * existants en base sans écraser leurs valeurs.
 * S'exécute au démarrage, une seule fois par version.
 */

export class FFdreameMigration {

  static CURRENT_VERSION = "1.4.0"; // incrémenter à chaque ajout de champs

  static async run() {
    const worldVersion = game.settings.get('ffdreame', 'systemMigrationVersion') ?? "0.0.0";
    if (worldVersion >= FFdreameMigration.CURRENT_VERSION) return;

    if (!game.user.isGM) return;
    console.log(`FFdreame | Migration ${worldVersion} → ${FFdreameMigration.CURRENT_VERSION}`);
    ui.notifications.info("FFdreame | Migration des données en cours...");

    // ── 1. Acteurs : ajouter bufPA manquant
    for (const actor of game.actors.contents) {
      await FFdreameMigration._migrateActor(actor);
    }
    // Acteurs dans les scènes (tokens non liés)
    for (const scene of game.scenes.contents) {
      for (const tokenDoc of scene.tokens.contents) {
        if (tokenDoc.actorLink) continue; // lié = déjà traité
        if (tokenDoc.actor) await FFdreameMigration._migrateActor(tokenDoc.actor);
      }
    }

    // ── 2. Items (techniques) : ajouter champs manquants
    for (const item of game.items.contents) {
      if (item.type === 'technique') await FFdreameMigration._migrateTechnique(item);
    }
    // Items dans les acteurs
    for (const actor of game.actors.contents) {
      for (const item of actor.items.contents) {
        if (item.type === 'technique') await FFdreameMigration._migrateTechnique(item);
      }
    }

    await game.settings.set('ffdreame', 'systemMigrationVersion', FFdreameMigration.CURRENT_VERSION);
    ui.notifications.info(`✅ FFdreame | Migration terminée (v${FFdreameMigration.CURRENT_VERSION})`);
    console.log("FFdreame | Migration terminée");
  }

  // ── Acteur : s'assurer que bufPA existe
  static async _migrateActor(actor) {
    const updates = {};

    if (!actor.system.combat) return;

    // bufPA manquant
    if (!actor.system.combat.bufPA) {
      updates['system.combat.bufPA'] = { actif: false, tours: 0, nbPA: 0 };
    }

    if (Object.keys(updates).length > 0) {
      await actor.update(updates);
    }
  }

  // ── Technique : s'assurer que tous les nouveaux champs existent
  static async _migrateTechnique(item) {
    const updates = {};
    const s = item.system;

    // jetRisque manquant
    if (!s.jetRisque) {
      updates['system.jetRisque'] = { actif: false, malusEchec: 20, label: "" };
    }

    // tp manquant
    if (!s.tp) {
      updates['system.tp'] = {
        cible: "lanceur", distanceMax: 10,
        animType: "misty", animCustom: ""
      };
    }

    // teleportation manquant ou champs partiels
    if (!s.teleportation) {
      updates['system.teleportation'] = {
        actif: false, type: "lanceur", position: "contact",
        distanceMax: 5, animDeplacement: "aucune",
        dureeDeplacement: 0.4, animCustom: ""
      };
    } else {
      // Champs partiels ajoutés dans des patchs ultérieurs
      if (s.teleportation.animDeplacement === undefined)
        updates['system.teleportation.animDeplacement'] = "aucune";
      if (s.teleportation.dureeDeplacement === undefined)
        updates['system.teleportation.dureeDeplacement'] = 0.4;
      if (s.teleportation.animCustom === undefined)
        updates['system.teleportation.animCustom'] = "";
    }

    // multi.aoep manquant
    if (s.multi && !s.multi.aoep) {
      updates['system.multi.aoep'] = {
        actif: false, dureeTours: 3, effetType: "degats",
        valeurParTour: 10, animation: "", blesserLanceur: false
      };
    }

    if (Object.keys(updates).length > 0) {
      await item.update(updates);
    }
  }
}
