/**
 * Classe Combat personnalisée pour FFdreame
 *
 * Le système FFdreame utilise un d100 INVERSÉ :
 *   - 0   = réussite critique (meilleur résultat)
 *   - 100 = échec critique   (pire résultat)
 *
 * Donc pour l'initiative, le joueur avec le PLUS BAS score agit en PREMIER.
 *
 * Deux surcharges :
 *  1. _sortCombatants → tri CROISSANT (plus bas = premier)
 *  2. rollInitiative  → si l'acteur a l'effet "Initiative Assurée" (initiative_first
 *                       permanent ou actif), son initiative est forcée à -100
 */
export class FFdreameCombat extends Combat {

  /**
   * Trier les combattants : le PLUS BAS score d'initiative passe en PREMIER.
   */
  _sortCombatants(a, b) {
    const ia = a.initiative ?? 9999;
    const ib = b.initiative ?? 9999;
    if (ia !== ib) return ia - ib;
    return a.name.localeCompare(b.name);
  }

  /**
   * Surcharge de rollInitiative.
   * Avant de lancer le dé, on vérifie si l'acteur a l'effet Initiative Assurée.
   * Si oui, on force directement -100 sans lancer le dé.
   *
   * @param {string|string[]} ids   - ID(s) du/des combattant(s)
   * @param {object}          options
   */
  async rollInitiative(ids, options = {}) {
    // Normaliser en tableau
    const combatantIds = typeof ids === "string" ? [ids] : ids;

    const toRollNormally = [];

    for (const id of combatantIds) {
      const combatant = this.combatants.get(id);
      if (!combatant?.actor) {
        toRollNormally.push(id);
        continue;
      }

      if (FFdreameCombat._hasInitiativeAssuree(combatant.actor)) {
        console.log(`🏁 FFdreame | Initiative Assurée → ${combatant.actor.name} : forcée à -100`);
        // Mettre l'initiative directement à -100
        await combatant.update({ initiative: -100 });

        // Message dans le chat
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor: combatant.actor }),
          content: `
            <div style="background:rgba(255,215,0,0.08);border:1px solid #ffd700;border-radius:8px;padding:10px;">
              <h3 style="color:#ffd700;margin:0 0 5px;">⚡ Initiative Assurée !</h3>
              <p style="margin:0;color:#ddd;">
                <b>${combatant.actor.name}</b> agit toujours en premier.
              </p>
            </div>`
        });
      } else {
        toRollNormally.push(id);
      }
    }

    // Lancer le dé normalement pour tous les autres
    if (toRollNormally.length > 0) {
      return super.rollInitiative(toRollNormally, options);
    }

    return this;
  }

  /**
   * Vérifie si un acteur a l'effet "initiative_first" actif sur son tableau actif.
   * Méthode statique utilisable sans importer FFdreameTableauEffects
   * (pour éviter les dépendances circulaires).
   *
   * @param {Actor} actor
   * @returns {boolean}
   */
  static _hasInitiativeAssuree(actor) {
    if (!actor?.system?.combat) return false;
    for (const key of ['tableau1', 'tableau2']) {
      const tableau = actor.system.combat[key];
      if (!tableau?.actif) continue;
      const effet = tableau.effet;
      if (!effet) continue;
      if (effet.type !== 'initiative_first') continue;
      // Permanent = toujours actif
      if (effet.condition === 'permanent') return true;
      // Condition réussites = actif seulement si le compteur a été atteint
      if (effet.actif) return true;
    }
    return false;
  }
}
