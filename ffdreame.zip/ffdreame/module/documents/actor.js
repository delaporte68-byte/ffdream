/**
 * Extension de la classe Actor pour FFdreame
 */
export class FFdreameActor extends Actor {

  /* ================================
     PRÉPARATION DES DONNÉES
     ================================ */
  prepareData() {
    super.prepareData();
  }

  prepareBaseData() {
    super.prepareBaseData();
  }

  prepareDerivedData() {
    super.prepareDerivedData();
    
    if (this.type === "character") {
      this._prepareCharacterData();
    } else if (this.type === "npc") {
      this._prepareNPCData();
    }
  }

  /* ================================
     CALCULS POUR LES PERSONNAGES
     ================================ */
  _prepareCharacterData() {
    const system = this.system;

    // 1. Calculer les points de compétences et d'aptitudes selon le rang et le niveau
    this._calculatePoints(system);

    // 2. Calculer le modificateur de rang
    const rangModifier = this._getRangModifier(system.rang);

    // 3. Calculer les aptitudes (SANS modifier les compétences)
    this._calculateAptitudes(system, rangModifier);
  }

  /* ================================
     CALCULS POUR LES NPC
     ================================ */
  _prepareNPCData() {
    const system = this.system;

    // Pour les NPC, on calcule directement les totaux d'attaque et PM
    // sans passer par les compétences détaillées
    
    // Attaque totale = valeur de base
    system.aptitudes.attaque.total = system.aptitudes.attaque.value || 0;
    
    // Puissance Magique totale = valeur de base
    system.aptitudes.puissanceMagique.total = system.aptitudes.puissanceMagique.value || 0;
  }

  /* ================================
     CALCUL DES POINTS À DISTRIBUER (CUMULÉS)
     ================================ */
  _calculatePoints(system) {
    // ── Points d'aptitudes cumulés : 5 par niveau ──
    system.pointsAptitudesCumulees = system.lv * 5;

    // ── Points de compétences : 15 de base + cumulés par rang ──
    const rangPointsAdds = {
      'F': 0,   // rang initial, les 15 de base sont déjà dans pointsCompetencesCumulees
      'D': 5,
      'C': 5,
      'B': 10,
      'A': 5,
      'S': 10,
      'SS': 5
    };

    // On calcule le total théorique selon le rang actuel
    // 15 de base + somme des rangs atteints jusqu'au rang actuel
    const rangsOrdres = ['F', 'D', 'C', 'B', 'A', 'S', 'SS'];
    const indexRangActuel = rangsOrdres.indexOf(system.rang);
    let totalPointsComp = 15; // base de départ
    for (let i = 1; i <= indexRangActuel; i++) {
      totalPointsComp += rangPointsAdds[rangsOrdres[i]] || 0;
    }

    // On met à jour pointsCompetencesCumulees UNIQUEMENT si le calcul donne plus
    // que la valeur actuelle (pour ne jamais "retirer" des points déjà accordés)
    if (totalPointsComp > (system.pointsCompetencesCumulees || 0)) {
      system.pointsCompetencesCumulees = totalPointsComp;
    }

    // Le champ affiché comme "max" c'est pointsCompetencesCumulees
    system.pointsCompetences = system.pointsCompetencesCumulees;
  }

  /* ================================
     MODIFICATEURS DE RANG
     ================================ */
  _getRangModifier(rang) {
    const modifiers = {
      'F': { 
        jetReussite: 40, 
        multiplier: 1 
      },
      'D': { 
        jetReussite: 45, 
        multiplier: 1 
      },
      'C': { 
        jetReussite: 50, 
        multiplier: 1.2 
      },
      'B': { 
        jetReussite: 55, 
        multiplier: 1.5 
      },
      'A': { 
        jetReussite: 60, 
        multiplier: 1.7 
      },
      'S': { 
        jetReussite: 60, 
        multiplier: 2 
      },
      'SS': { 
        jetReussite: 65, 
        multiplier: 2 
      }
    };

    return modifiers[rang] || modifiers['F'];
  }

  /* ================================
     CONFRONTATION DE RANG
     Calcule le bonus/malus selon l'écart de rang entre cet acteur et sa cible.
     +10% par niveau de rang supérieur, -10% par niveau inférieur.
     Ex : S vs A → +10%  |  S vs F → +50%  |  F vs S → -50%
     ================================ */
  _getConfrontationRangBonus(rangCible) {
    const rangsOrdres = ['F', 'D', 'C', 'B', 'A', 'S', 'SS'];
    const indexAttaquant = rangsOrdres.indexOf(this.system.rang);
    const indexCible     = rangsOrdres.indexOf(rangCible);
    if (indexAttaquant === -1 || indexCible === -1) return 0;
    const ecart = indexAttaquant - indexCible;
    // +10% par rang supérieur, -10% par rang inférieur
    return ecart * 10;
  }

  /* ================================
     CALCUL DES APTITUDES
     ================================ */
  _calculateAptitudes(system, rangModifier) {
    const physique = system.physique;
    const dexterite = system.dexterite;
    const intelligence = system.intelligence;
    const charisme = system.charisme;

    // Calculer les réductions dues à la fatigue et aux blessures
    const fatigueReduction = this._calculateFatigueReduction(system);
    const blessureReduction = this._calculateBlessureReduction(system);

    // ATTAQUE = (Base[MJ] + Investissement[joueur] + Force + Agilité + Perception) × Mult rang × (1 - réductions)
    const attaqueBase = (system.aptitudes.attaque.base || 0) + (system.aptitudes.attaque.investissement || 0);
    const attaqueAvantReduction = Math.floor(
      (attaqueBase + 
      (physique.force.value || 0) + 
      (dexterite.agilite.value || 0) + 
      (dexterite.perception.value || 0)) * rangModifier.multiplier
    );
    system.aptitudes.attaque.total = Math.floor(attaqueAvantReduction * (1 - fatigueReduction.attaque - blessureReduction.attaque));

    // PUISSANCE MAGIQUE = (Base[MJ] + Investissement[joueur] + Perception + Agilité + Magie) × Mult rang × (1 - réductions)
    const pmBase = (system.aptitudes.puissanceMagique.base || 0) + (system.aptitudes.puissanceMagique.investissement || 0);
    const pmAvantReduction = Math.floor(
      (pmBase + 
      (dexterite.perception.value || 0) +
      (dexterite.agilite.value || 0) +
      (intelligence.magie.value || 0)) * rangModifier.multiplier
    );
    system.aptitudes.puissanceMagique.total = Math.floor(pmAvantReduction * (1 - fatigueReduction.puissanceMagique - blessureReduction.puissanceMagique));

    // PV = ((Base[MJ] + Investissement[joueur]) + (Volonté × 10) + (Endurance × 100)) × Mult rang × (1 - réductions)
    const pvBase = (system.aptitudes.pv.base || 0) + (system.aptitudes.pv.investissement || 0);
    const pvMaxAvantReduction = Math.floor((pvBase + 
                  ((intelligence.volonte.value || 0) * 10) + 
                  ((physique.endurance.value || 0) * 100)) * rangModifier.multiplier);
    const pvMax = Math.floor(pvMaxAvantReduction * (1 - fatigueReduction.pv - blessureReduction.pv));
    system.aptitudes.pv.max = pvMax;
    if (!system.aptitudes.pv.value || system.aptitudes.pv.value === 0) {
      system.aptitudes.pv.value = pvMax;
    }

    // PM = ((Base[MJ] + Investissement[joueur]) + (Magie × 100) + (Volonté × 10)) × Mult rang × (1 - réductions)
    const pointsMagiquesBase = (system.aptitudes.pm.base || 0) + (system.aptitudes.pm.investissement || 0);
    const pmMaxAvantReduction = Math.floor((pointsMagiquesBase + 
                  ((intelligence.magie.value || 0) * 100) + 
                  ((intelligence.volonte.value || 0) * 10)) * rangModifier.multiplier);
    const pmMax = Math.floor(pmMaxAvantReduction * (1 - fatigueReduction.pm));
    system.aptitudes.pm.max = pmMax;
    if (!system.aptitudes.pm.value || system.aptitudes.pm.value === 0) {
      system.aptitudes.pm.value = pmMax;
    }
  }

  /* ================================
     CALCUL DES RÉDUCTIONS DE FATIGUE
     ================================ */
  _calculateFatigueReduction(system) {
    const fatigue = system.combat.fatigue;
    let reduction = {
      attaque: 0,
      puissanceMagique: 0,
      pv: 0,
      pm: 0
    };
    
    // f4: -15% PV
    if (fatigue.f4) reduction.pv += 0.15;
    // f6: -25% Attaque et Puissance Magique
    if (fatigue.f6) {
      reduction.attaque += 0.25;
      reduction.puissanceMagique += 0.25;
    }
    // f7: -20% PM
    if (fatigue.f7) reduction.pm += 0.20;
    
    return reduction;
  }

  /* ================================
     CALCUL DES RÉDUCTIONS DE BLESSURES
     ================================ */
  _calculateBlessureReduction(system) {
    const blessures = system.combat.blessures;
    let reduction = {
      attaque: 0,
      puissanceMagique: 0,
      pv: 0,
      pm: 0
    };
    
    // b4: -15% Attaque et Puissance Magique
    if (blessures.b4) {
      reduction.attaque += 0.15;
      reduction.puissanceMagique += 0.15;
    }
    // b6: -30% Attaque et Puissance Magique
    if (blessures.b6) {
      reduction.attaque += 0.30;
      reduction.puissanceMagique += 0.30;
    }
    // b8: -20% Attaque et Puissance Magique
    if (blessures.b8) {
      reduction.attaque += 0.20;
      reduction.puissanceMagique += 0.20;
    }
    
    return reduction;
  }

  /* ================================
     JETS DE DÉS POUR LES COMPÉTENCES
     ================================ */
  async rollCompetence(competenceName, competenceValue) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    let seuilReussite = rangModifier.jetReussite;

    // Déterminer les bonus/malus de dés selon la valeur de la compétence
    // Valeurs positives:
    //   5 points = -1d6 au jet (soustrait du résultat)
    //   10 points = -1d12 au jet (soustrait du résultat)
    // Valeurs négatives:
    //   -5 points = +1d6 au jet (ajoute au résultat)
    //   -10 points = +1d12 au jet (ajoute au résultat)
    let bonusDice = '';
    let malusDice = '';
    
    if (competenceValue >= 10) {
      bonusDice = '1d12';
    } else if (competenceValue >= 5) {
      bonusDice = '1d6';
    } else if (competenceValue <= -10) {
      malusDice = '1d12';
    } else if (competenceValue <= -5) {
      malusDice = '1d6';
    }
    
    // Le seuil reste celui du rang (pas de réduction)

    // Récupérer les malus de fatigue et blessures
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;

    // Calculer les seuils de critiques modifiés
    const critiques = this._calculateCriticalThresholds();

    // Récupérer les bonus des talents actifs
    let bonusTalents = 0;
    let bonusTalentsDes = '';
    let talentsActifs = [];
    
    const talents = this.system.talents;
    if (talents) {
      for (const [key, talent] of Object.entries(talents)) {
        if (talent.actif && talent.nom) {
          talentsActifs.push(talent.nom);
          if (talent.typebonus === 'nombre') {
            bonusTalents += parseInt(talent.valeurbonus) || 0;
          } else if (talent.typebonus === 'des') {
            const nbDes = parseInt(talent.valeurbonus) || 0;
            if (nbDes > 0) {
              bonusTalentsDes += ` - ${nbDes}d6`;
            }
          }
        }
      }
    }

    // Construire la formule complète (système inversé: bonus se soustraient, malus s'ajoutent)
    let formula = `1d100`;
    if (bonusDice) {
      formula += ` - ${bonusDice}`;
    }
    if (malusDice) {
      formula += ` + ${malusDice}`;
    }
    if (bonusTalentsDes) {
      formula += bonusTalentsDes; // Les talents sont déjà formatés avec -
    }
    if (bonusTalents > 0) {
      formula += ` - ${bonusTalents}`;
    }
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    // ✨ APPLIQUER LES BUFFS ACTIFS AU JET
    let buffsJetActifs = [];
    if (window.FFdreameBuffManager) {
      const resultatBuffs = window.FFdreameBuffManager.applyBuffsToRoll(this, formula);
      formula = resultatBuffs.formula;
      buffsJetActifs = resultatBuffs.buffsActifs;
    }

    const roll = new Roll(formula);
    await roll.evaluate();

    // Déterminer la réussite (inversé: bas = réussite, haut = échec)
    const total = roll.total;
    const success = total <= seuilReussite;
    
    // Réussite/Échec critiques avec seuils modifiés
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;

    // Construire le message des bonus/malus de compétence
    let competenceInfo = '';
    if (bonusDice) {
      const diceType = competenceValue >= 10 ? '1d12' : '1d6';
      competenceInfo = `<p style="color: #00d9ff; font-size: 12px;">📊 Bonus compétence: -${diceType} au jet</p>`;
    } else if (malusDice) {
      const diceType = competenceValue <= -10 ? '1d12' : '1d6';
      competenceInfo = `<p style="color: #ff6b6b; font-size: 12px;">📊 Malus compétence: +${diceType} au jet</p>`;
    }

    // Construire le message des talents
    let talentsInfo = '';
    if (talentsActifs.length > 0) {
      talentsInfo = `<p style="color: var(--color-primary-gold); font-size: 12px;">
        ✨ Talents actifs : ${talentsActifs.join(', ')}
      </p>`;
    }

    // Construire le message des malus
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">
        ⚠️ Malus total : +${totalMalus}
      </p>`;
    }
    
    // ✨ Construire le message des buffs actifs
    let buffsInfo = '';
    if (buffsJetActifs.length > 0) {
      buffsInfo = `<p style="color: #00d9ff; font-size: 12px;">
        ✨ Buffs actifs : ${buffsJetActifs.join(', ')}
      </p>`;
    }

    // Construire le message des critiques modifiés
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">
        ⚠️ Réussite critique IMPOSSIBLE
      </p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">
        Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}
      </p>`;
    }

    // Afficher le résultat dans le chat
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';

    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>${competenceName}</h3>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               ${competenceInfo}
               ${talentsInfo}
               ${buffsInfo}
               ${malusInfo}
               ${critiquesInfo}`,
      content: `
        <div class="dice-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${roll.terms.map(t => t.results ? `<div class="dice-tooltip">${t.results.map(r => r.result).join(', ')}</div>` : '').join('')}
        </div>
      `
    };

    await roll.toMessage(messageData);
    return roll;
  }

  /* ================================
     CALCUL DES SEUILS DE CRITIQUES
     ================================ */
  _calculateCriticalThresholds() {
    const fatigue = this.system.combat.fatigue;
    const blessures = this.system.combat.blessures;
    
    let seuilReussiteCritique = 1;
    let seuilEchecCritique = 100;
    let reussitePossible = true;
    
    // f2: Échec critique +5% (passe de 100 à 95)
    if (fatigue.f2) {
      seuilEchecCritique = 95;
    }
    
    // f3: Réussite critique impossible
    if (fatigue.f3) {
      reussitePossible = false;
      seuilReussiteCritique = 0; // Impossible
    }
    
    // b2: Échec critique +5% (cumulé avec f2)
    if (blessures.b2) {
      seuilEchecCritique -= 5;
    }
    
    return {
      seuilReussiteCritique,
      seuilEchecCritique,
      reussitePossible
    };
  }

  /* ================================
     CALCUL DES MALUS DE FATIGUE
     ================================ */
  _calculateFatigueMalus() {
    const fatigue = this.system.combat?.fatigue;
    if (!fatigue) return 0; // NPC n'ont pas de fatigue
    
    let malus = 0;
    
    // f5: +5% au jet
    if (fatigue.f5) malus += 5;
    
    return malus;
  }

  /* ================================
     CALCUL DES MALUS DE BLESSURES
     ================================ */
  _calculateBlessureMalus() {
    const blessures = this.system.combat?.blessures;
    if (!blessures) return 0; // NPC n'ont pas de blessures
    
    let malus = 0;
    
    // b1: -5% au jet
    if (blessures.b1) malus += 5;
    // b3: -5% au jet (cumulé avec b1)
    if (blessures.b3) malus += 5;
    // b5: -5% au jet
    if (blessures.b5) malus += 5;
    
    return malus;
  }

  /* ================================
     LANCER ATTAQUE DE BASE
     ================================ */
  async lancerAttaqueBase(posture, rangCible = null) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    const seuilBase = rangModifier.jetReussite;
    
    // Confrontation de rang
    const confrontBonus = rangCible ? this._getConfrontationRangBonus(rangCible) : 0;
    const seuilReussite = seuilBase + confrontBonus;
    
    // Récupérer les dégâts de la posture
    const degats = this.system.combat[`posture${posture}`]?.attaqueDegats || 0;
    const nomPosture = this.system.combat[`posture${posture}`]?.nom || `Posture ${posture}`;
    
    // Calculer les malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    const critiques = this._calculateCriticalThresholds();
    
    // Formule de jet (système inversé)
    let formula = `1d100`;
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    const roll = new Roll(formula);
    await roll.evaluate();
    
    const total = roll.total;
    const success = total <= seuilReussite;
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;
    
    // Messages
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Malus total : +${totalMalus}</p>`;
    }
    
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Réussite critique IMPOSSIBLE</p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}</p>`;
    }
    
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';
    
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>⚔️ ATTAQUE DE BASE - ${nomPosture}</h3>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               ${malusInfo}
               ${critiquesInfo}`,
      content: `
        <div class="dice-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${success ? `<div class="degats-info"><strong>💥 Dégâts : ${degats}</strong></div>` : ''}
        </div>
      `
    };
    
    await roll.toMessage(messageData);
    return roll;
  }

  /* ================================
     LANCER ATTAQUE POSTURE (ITEM)
     ================================ */
  async lancerAttaquePosture(posture) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    const seuilReussite = rangModifier.jetReussite;
    
    // Calculer les dégâts : Aptitude Attaque + Base posture
    const attaqueAptitude = this.system.aptitudes.attaque.total || 0;
    const attaqueBase = posture.system.attaqueBase || 0;
    const degatsTotal = attaqueAptitude + attaqueBase;
    
    // Calculer les malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    const critiques = this._calculateCriticalThresholds();
    
    // Formule de jet
    let formula = `1d100`;
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    const roll = new Roll(formula);
    await roll.evaluate();
    
    const total = roll.total;
    const success = total <= seuilReussite;
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;
    
    // Messages
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Malus total : +${totalMalus}</p>`;
    }
    
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Réussite critique IMPOSSIBLE</p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}</p>`;
    }
    
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';
    
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>⚔️ ATTAQUE DE BASE - ${posture.name}</h3>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               <p style="color: #888; font-size: 11px;">Aptitude: ${attaqueAptitude} + Base: ${attaqueBase}</p>
               ${malusInfo}
               ${critiquesInfo}`,
      content: `
        <div class="dice-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${success ? `<div class="degats-info"><strong>💥 Dégâts : ${degatsTotal}</strong></div>` : ''}
        </div>
      `
    };
    
    await roll.toMessage(messageData);
    
    // Augmenter Burste +10 si réussite
    if (success) {
      const bursteCurrent = this.system.combat.burste || 0;
      const newBurste = Math.min(100, bursteCurrent + 10);
      await this.update({ 'system.combat.burste': newBurste });
      
      if (newBurste === 100) {
        ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
      }
    }
    
    return roll;
  }

  /* ================================
     LANCER TECHNIQUE
     ================================ */
  async lancerTechnique(technique, posture) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    const seuilReussite = rangModifier.jetReussite;
    
    // Calculer les dégâts selon le style
    const degats = this._calculateTechniqueDegats(technique);
    
    // Calculer les malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    const critiques = this._calculateCriticalThresholds();
    
    // Formule de jet
    let formula = `1d100`;
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    const roll = new Roll(formula);
    await roll.evaluate();
    
    const total = roll.total;
    const success = total <= seuilReussite;
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;
    
    // Messages
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Malus total : +${totalMalus}</p>`;
    }
    
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Réussite critique IMPOSSIBLE</p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}</p>`;
    }
    
    let effetsInfo = '';
    if (technique.system.effets) {
      effetsInfo = `<p style="color: #00d9ff; font-size: 12px;">✨ ${technique.system.effets}</p>`;
    }
    
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';
    
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>⚡ ${technique.name} - ${posture.name}</h3>
               <p>Style: ${technique.system.style.toUpperCase()} | Coût: ${technique.system.coutPM} PM</p>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               ${malusInfo}
               ${critiquesInfo}
               ${effetsInfo}`,
      content: `
        <div class="dice-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${success ? `<div class="degats-info"><strong>💥 Dégâts : ${degats}</strong></div>` : ''}
        </div>
      `
    };
    
    await roll.toMessage(messageData);
    
    // Augmenter Burste +10 si réussite
    if (success) {
      const bursteCurrent = this.system.combat.burste || 0;
      const newBurste = Math.min(100, bursteCurrent + 10);
      await this.update({ 'system.combat.burste': newBurste });
      
      if (newBurste === 100) {
        ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
      }
    }
    
    return roll;
  }

  /* ================================
     LANCER ULTIMATE
     ================================ */
  async lancerUltimate(posture) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    const seuilReussite = rangModifier.jetReussite;
    
    const degats = posture.system.ultimateDegats || 0;
    
    // Calculer les malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    const critiques = this._calculateCriticalThresholds();
    
    // Formule de jet
    let formula = `1d100`;
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    const roll = new Roll(formula);
    await roll.evaluate();
    
    const total = roll.total;
    const success = total <= seuilReussite;
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;
    
    // Messages
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Malus total : +${totalMalus}</p>`;
    }
    
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Réussite critique IMPOSSIBLE</p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}</p>`;
    }
    
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';
    
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>🔥🔥 ULTIMATE : ${posture.system.ultimateNom} 🔥🔥</h3>
               <p>${posture.name}</p>
               <p>${posture.system.ultimateDescription}</p>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               ${malusInfo}
               ${critiquesInfo}`,
      content: `
        <div class="dice-roll ultimate-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${success ? `<div class="degats-info"><strong>💥💥 DÉGÂTS ULTIMATE : ${degats} 💥💥</strong></div>` : ''}
          <div class="burste-reset-info">⚡ Burste réinitialisée à 0</div>
        </div>
      `
    };
    
    await roll.toMessage(messageData);
    return roll;
  }

  /* ================================
     LANCER TECHNIQUE EMBARQUÉE (depuis posture)
     Avec logique EHa/EHm : 3 jets consécutifs
     ================================ */
  async lancerTechniqueEmbedded(technique, posture) {
    const rang = this.system.rang;
    const rangModifier = this._getRangModifier(rang);
    const seuilReussite = rangModifier.jetReussite;
    
    const style = technique.style;
    
    // Styles à jets multiples : EHa et EHm
    if (style === 'eha' || style === 'ehm') {
      await this._lancerTechniqueMultiJets(technique, posture, seuilReussite);
      return;
    }
    
    // Styles normaux
    const degats = this._calculateTechniqueEmbeddedDegats(technique);
    
    // Malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    const critiques = this._calculateCriticalThresholds();
    
    // Formule
    let formula = `1d100`;
    if (totalMalus > 0) {
      formula += ` + ${totalMalus}`;
    }
    
    const roll = new Roll(formula);
    await roll.evaluate();
    
    const total = roll.total;
    const success = total <= seuilReussite;
    const critSuccess = critiques.reussitePossible && total <= critiques.seuilReussiteCritique;
    const critFailure = total >= critiques.seuilEchecCritique;
    
    // Messages
    let malusInfo = '';
    if (totalMalus > 0) {
      malusInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Malus total : +${totalMalus}</p>`;
    }
    
    let critiquesInfo = '';
    if (!critiques.reussitePossible) {
      critiquesInfo = `<p style="color: #ff6b6b; font-size: 12px;">⚠️ Réussite critique IMPOSSIBLE</p>`;
    }
    if (critiques.seuilReussiteCritique !== 1 || critiques.seuilEchecCritique !== 100) {
      critiquesInfo += `<p style="color: #ffa500; font-size: 12px;">Critiques: Réussite ≤${critiques.seuilReussiteCritique} / Échec ≥${critiques.seuilEchecCritique}</p>`;
    }
    
    let effetsInfo = '';
    if (technique.effets) {
      effetsInfo = `<p style="color: #00d9ff; font-size: 12px;">✨ ${technique.effets}</p>`;
    }
    
    let resultText = success ? '✓ Réussite' : '✗ Échec';
    if (critSuccess) resultText = '✓✓ RÉUSSITE CRITIQUE !';
    if (critFailure) resultText = '✗✗ ÉCHEC CRITIQUE !';
    
    const messageData = {
      speaker: ChatMessage.getSpeaker({ actor: this }),
      flavor: `<h3>⚡ ${technique.nom} - ${posture.name}</h3>
               <p>Style: ${technique.style.toUpperCase()} | Coût: ${technique.coutPM} PM</p>
               <p>Seuil de réussite : ≤ ${seuilReussite}</p>
               ${malusInfo}
               ${critiquesInfo}
               ${effetsInfo}`,
      content: `
        <div class="dice-roll">
          <div class="dice-result">
            <div class="dice-formula">${formula}</div>
            <div class="dice-total ${success ? 'success' : 'failure'}">
              ${total} ${resultText}
            </div>
          </div>
          ${success ? `<div class="degats-info"><strong>💥 Dégâts : ${degats}</strong></div>` : ''}
        </div>
      `
    };
    
    await roll.toMessage(messageData);
    
    // Augmenter Burste +10 si réussite
    if (success) {
      const bursteCurrent = this.system.combat.burste || 0;
      const newBurste = Math.min(100, bursteCurrent + 10);
      await this.update({ 'system.combat.burste': newBurste });
      
      if (newBurste === 100) {
        ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
      }
    }
    
    return roll;
  }

  /* ================================
     LANCER TECHNIQUE MULTI-JETS (EHa / EHm)
     3 jets consécutifs : 60, 50, 40
     Si un jet échoue, l'attaque s'arrête
     ================================ */
  async _lancerTechniqueMultiJets(technique, posture, seuilBase) {
    const style = technique.style;
    const degatsBase = this._calculateTechniqueEmbeddedDegats(technique);
    
    const seuils = [60, 50, 40];
    let degatsTotal = 0;
    let jetsReussis = 0;
    
    // Malus et critiques
    const fatigueMalus = this._calculateFatigueMalus();
    const blessureMalus = this._calculateBlessureMalus();
    const totalMalus = fatigueMalus + blessureMalus;
    
    let messageContent = `<div class="dice-roll multi-jets">`;
    messageContent += `<h3>⚡ ${technique.nom} - ${posture.name}</h3>`;
    messageContent += `<p>Style: ${style.toUpperCase()} - 3 JETS CONSÉCUTIFS</p>`;
    messageContent += `<p>Seuils: 60 → 50 → 40</p>`;
    
    // Lancer les 3 jets
    for (let i = 0; i < 3; i++) {
      let formula = `1d100`;
      if (totalMalus > 0) {
        formula += ` + ${totalMalus}`;
      }
      
      const roll = new Roll(formula);
      await roll.evaluate();
      
      const total = roll.total;
      const seuil = seuils[i];
      const success = total <= seuil;
      
      messageContent += `<div class="jet-item jet-${i + 1} ${success ? 'success' : 'failure'}">`;
      messageContent += `<strong>Jet ${i + 1} :</strong> ${total} / ${seuil} `;
      messageContent += success ? '✓ Réussite' : '✗ Échec';
      messageContent += `</div>`;
      
      if (success) {
        jetsReussis++;
        degatsTotal += degatsBase;
      } else {
        messageContent += `<p style="color: #ff6b6b;"><strong>⚠️ Jet ${i + 1} échoué ! L'attaque s'arrête.</strong></p>`;
        break;
      }
    }
    
    messageContent += `<div class="multi-jets-result">`;
    messageContent += `<p><strong>Jets réussis : ${jetsReussis} / 3</strong></p>`;
    if (degatsTotal > 0) {
      messageContent += `<p><strong>💥 Dégâts totaux : ${degatsTotal}</strong></p>`;
    }
    messageContent += `</div></div>`;
    
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: messageContent
    });
    
    // Augmenter Burste +10 si au moins 1 jet réussi
    if (jetsReussis > 0) {
      const bursteCurrent = this.system.combat.burste || 0;
      const newBurste = Math.min(100, bursteCurrent + 10);
      await this.update({ 'system.combat.burste': newBurste });
      
      if (newBurste === 100) {
        ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
      }
    }
  }

  /* ================================
     CALCUL DES DÉGÂTS DE TECHNIQUE EMBARQUÉE
     ================================ */
  _calculateTechniqueEmbeddedDegats(technique) {
    const atq = this.system.aptitudes.attaque.total || 0;
    const pm = this.system.aptitudes.puissanceMagique.total || 0;
    const base = technique.baseDegats || 0;
    const style = technique.style;
    
    switch (style) {
      case 'cac':
        return atq + Math.floor(pm / 2) + base;
      case 'mg':
        return Math.floor(atq / 2) + pm + base;
      case 'p':
        return atq + pm + base;
      case 'eha':
        return atq + base;
      case 'ehm':
        return pm + base;
      case 'ef':
        return pm + base + Math.floor(atq / 2);
      case 'buff':
        return base; // Valeur de buff en %
      default:
        return base;
    }
  }

  /* ================================
     CALCUL DES DÉGÂTS DE TECHNIQUE
     ================================ */
  _calculateTechniqueDegats(technique) {
    const atq = this.system.aptitudes.attaque.total || 0;
    const pm = this.system.aptitudes.puissanceMagique.total || 0;
    const base = technique.system.baseDegats || 0;
    const style = technique.system.style;
    
    let degats = 0;
    
    switch(style) {
      case 'cac':
        degats = atq + Math.floor(pm / 2) + base;
        break;
      case 'mag':
        degats = Math.floor(atq / 2) + pm + base;
        break;
      case 'pui':
        degats = atq + pm + base;
        break;
      case 'atta':
        // Style ATTA : Attaque physique (ATQ + base)
        degats = atq + base;
        break;
      case 'attm':
        // Style ATTM : Attaque magique (PM + base)
        degats = pm + base;
        break;
      case 'ultim':
        // Style ULTIM : Ultimate (ATQ + PM + base)
        degats = atq + pm + base;
        break;
      case 'multi':
        // Style MULTI : Zone d'effet (base + ATQ÷2 + PM÷2)
        degats = base + Math.floor(atq / 2) + Math.floor(pm / 2);
        break;
      case 'cur':
        // Style CUR (soins) : Dégâts de base uniquement
        degats = base;
        break;
      case 'aoe':
        // Style AOE : Calculé dans _useTableTechniqueAOE
        degats = Math.floor(atq / 2) + Math.floor(pm / 2) + base;
        break;
      case 'eha':
        degats = atq + base;
        break;
      case 'ehm':
        degats = pm + base;
        break;
      case 'ef':
        degats = pm + base + Math.floor(atq / 2);
        break;
      case 'buff':
        // Les buffs n'ont pas de dégâts, ils ont une valeur%
        degats = technique.system.buffValue || 0;
        break;
      default:
        degats = base;
    }
    
    let degatsFinaux = Math.floor(degats);
    
    // ✨ APPLIQUER LE BUFF ATTAQUE (BufA)
    if (window.FFdreameBuffManager) {
      const resultatBuffs = window.FFdreameBuffManager.applyBuffsToDamage(this, degatsFinaux);
      degatsFinaux = resultatBuffs.degatsFinaux;
      // Les buffs seront affichés dans le message de la technique
    }
    
    return degatsFinaux;
  }
}
