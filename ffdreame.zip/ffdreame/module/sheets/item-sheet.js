/**
 * Feuille d'item pour FFdreame (talents, techniques, équipement)
 */
export class FFdreameItemSheet extends ItemSheet {

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "item"],
      width: 700,
      height: 780,
      resizable: true,
      tabs: [{
        navSelector: ".item-sheet-tabs",
        contentSelector: ".item-sheet-body",
        initial: "base"
      }]
    });
  }

  get template() {
    const type = this.item.type;
    if (type === "technique") return "systems/ffdreame/templates/item/technique-sheet-v2.html";
    if (type === "posture")   return "systems/ffdreame/templates/item/posture-sheet.html";
    if (type === "attaque")   return "systems/ffdreame/templates/item/attaque-sheet.html";
    if (type === "ultimate")  return "systems/ffdreame/templates/item/ultimate-sheet.html";
    return "systems/ffdreame/templates/item/talent-sheet.html";
  }

  async getData() {
    const context = super.getData();
    const itemData = this.item.toObject(false);

    context.system = itemData.system;
    context.flags  = itemData.flags;
    context.item   = this.item;
    context.isGM   = game.user.isGM;

    if (this.item.type === "technique") {
      context.system.multiaoe = foundry.utils.mergeObject({
        forme: "cercle", distanceMax: 8, taille: 3, duree: 3,
        typeEffet: "degats", buffType: "soins", buffValeur: 10, buffDuree: 1
      }, context.system.multiaoe ?? {}, { inplace: false });

      context.system.charge = foundry.utils.mergeObject({
        actif: false, multiplicateur0: 1.0, multiplicateur1: 1.5,
        multiplicateur2: 2.0, multiplicateur3: 3.0
      }, context.system.charge ?? {}, { inplace: false });

      context.system.jetRisque = foundry.utils.mergeObject({
        actif: false, bonusDegats: 20, malusEchec: 15, malusDuree: 1
      }, context.system.jetRisque ?? {}, { inplace: false });

      context.system.teleportation = foundry.utils.mergeObject({
        actif: false, type: "lanceur", position: "derriere",
        distanceCases: 3, distanceMax: 5, animation: "misty_step"
      }, context.system.teleportation ?? {}, { inplace: false });

      context.system.aoer = foundry.utils.mergeObject({
        forme: "cercle", distanceMax: 10, taille: 3, angle: 90
      }, context.system.aoer ?? {}, { inplace: false });

      context.styleLabel = this._getStyleLabel(context.system.style);
    }

    if (this.item.type === "posture") {
      context.effetLabel = this._getEffetLabel(context.system.effetType);
    }

    return context;
  }

  _getStyleLabel(style) {
    const labels = {
      "cac":    "CAC — Corps à Corps",
      "mag":    "MAG — Magie",
      "pui":    "PUI — Puissance",
      "atta":   "ATTA — Attaque physique",
      "attm":   "ATTM — Attaque magique",
      "ultim":  "ULTIM — Ultimate",
      "multi":  "MULTI — Zone d'effet",
      "aoer":   "AOER — Zone retardée",
      "cur":    "CUR — Soins",
      "tp":     "TP — Téléportation",
      "aoe":    "AOE — 3 jets consécutifs",
      "chm":    "CHM — Choix multiple",
      "parade": "PARADE — Contre-attaque",
    };
    return labels[style] || style;
  }

  _getEffetLabel(effetType) {
    const labels = {
      "aucun":        "Aucun effet",
      "bonus_degats": "Bonus de dégâts %",
      "regen_pa":     "Régénération PA",
      "contre":       "Contre sans PA",
      "esquive":      "Esquive sans PA",
      "initiative":   "Prise d'initiative"
    };
    return labels[effetType] || effetType;
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.isEditable) return;

    html.find('.btn-add-technique').on('click',    this._onAddTechnique.bind(this));
    html.find('.btn-delete-technique').on('click', this._onDeleteTechnique.bind(this));
  }

  async _onAddTechnique(event) {
    event.preventDefault();
    const techniques = this.item.system.techniques || [];
    techniques.push({ nom: "", description: "", effets: "", style: "cac", coutPM: 10, baseDegats: 0 });
    await this.item.update({ "system.techniques": techniques });
  }

  async _onDeleteTechnique(event) {
    event.preventDefault();
    const index      = parseInt(event.currentTarget.dataset.index);
    const techniques = foundry.utils.duplicate(this.item.system.techniques || []);
    techniques.splice(index, 1);
    await this.item.update({ "system.techniques": techniques });
  }
}
