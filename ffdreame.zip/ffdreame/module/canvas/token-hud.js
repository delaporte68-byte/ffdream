/* ============================================
   TOKEN HUD PERSONNALISÉ - FFdreame
   Affichage : PA (haut), Burste (gauche), PM (droite)
   ============================================ */

export class FFdreameTokenHUD {
  
  static init() {
    console.log("FFdreame | Initialisation Token HUD personnalisé");
    
    // Hook quand un token est refresh
    Hooks.on("refreshToken", (token) => {
      FFdreameTokenHUD.updateTokenHUD(token);
    });
    
    // Hook quand le canvas est prêt
    Hooks.on("canvasReady", () => {
      canvas.tokens.placeables.forEach(token => {
        FFdreameTokenHUD.updateTokenHUD(token);
      });
    });
  }
  
  /* ================================
     MISE À JOUR DU HUD DU TOKEN
     ================================ */
  static updateTokenHUD(token) {
    if (!token.actor) return;
    
    // Vérifier si c'est un personnage FFdreame
    if (token.actor.type !== "character" && token.actor.type !== "cyberpunk") return;
    
    // Supprimer ancien HUD s'il existe
    const existingHUD = token.children.find(c => c.ffdreameHUD);
    if (existingHUD) {
      token.removeChild(existingHUD);
    }
    
    // Créer le nouveau HUD
    const hudContainer = new PIXI.Container();
    hudContainer.ffdreameHUD = true;
    
    // Récupérer les données
    const burste = token.actor.system.combat?.burste || 0;
    const pm = token.actor.system.aptitudes?.pm || { value: 0, max: 0 };
    const actionPoints = token.actor.system.combat?.actionPoints || {};
    
    // Créer les éléments
    FFdreameTokenHUD._createPADisplay(hudContainer, actionPoints, token);
    FFdreameTokenHUD._createBursteBar(hudContainer, burste, token);
    FFdreameTokenHUD._createPMBar(hudContainer, pm, token);
    
    // Ajouter au token
    token.addChild(hudContainer);
  }
  
  /* ================================
     CRÉER L'AFFICHAGE DES PA (HAUT)
     ================================ */
  static _createPADisplay(container, actionPoints, token) {
    const paContainer = new PIXI.Container();
    
    // Position en haut du token
    const tokenHeight = token.h;
    paContainer.position.set(token.w / 2, -35);
    
    // Calculer l'état des petits PA (6 normaux + 2 bonus si disponibles)
    const petitsPA = [];
    
    // PA normaux (grand1, grand2, grand3)
    for (let i = 1; i <= 3; i++) {
      const grand = actionPoints[`grand${i}`] || { petit1: false, petit2: false };
      petitsPA.push(grand.petit1);
      petitsPA.push(grand.petit2);
    }
    
    // PA bonus (grand4) - si disponible
    const grand4 = actionPoints.grand4;
    if (grand4 && grand4.disponible !== false) {
      petitsPA.push(grand4.petit1);
      petitsPA.push(grand4.petit2);
    }
    
    // Créer les ronds (6 ou 8 selon disponibilité de grand4)
    const dotSize = 12;
    const gap = 4;
    const totalWidth = (dotSize * petitsPA.length) + (gap * (petitsPA.length - 1));
    const startX = -totalWidth / 2;
    
    for (let i = 0; i < petitsPA.length; i++) {
      const dot = new PIXI.Graphics();
      const isActif = petitsPA[i];
      const isBonus = i >= 6; // Les 2 derniers sont les bonus
      
      // Cercle
      dot.lineStyle(2, isBonus ? 0xffd700 : 0x000000, 1);
      
      if (isActif) {
        // Vert = disponible (gold si bonus)
        const color = isBonus ? 0xffd700 : 0x00ff00;
        dot.beginFill(color, 1);
        dot.drawCircle(0, 0, dotSize / 2);
        dot.endFill();
        
        // Glow vert ou gold
        const glow = new PIXI.filters.GlowFilter({
          distance: 5,
          outerStrength: isBonus ? 3 : 2,
          color: color
        });
        dot.filters = [glow];
        
      } else {
        // Rouge = utilisé
        dot.beginFill(0xff0000, 1);
        dot.drawCircle(0, 0, dotSize / 2);
        dot.endFill();
        
        // Glow rouge
        const glow = new PIXI.filters.GlowFilter({
          distance: 5,
          outerStrength: 1,
          color: 0xff0000
        });
        dot.filters = [glow];
      }
      
      dot.position.set(startX + (i * (dotSize + gap)), 0);
      paContainer.addChild(dot);
    }
    
    container.addChild(paContainer);
  }
  
  /* ================================
     CRÉER LA BARRE BURSTE (GAUCHE)
     ================================ */
  static _createBursteBar(container, burste, token) {
    const barContainer = new PIXI.Container();
    
    // Position à gauche
    barContainer.position.set(-30, 0);
    
    // Icône ⚡
    const icon = new PIXI.Text("⚡", {
      fontSize: 14,
      fill: 0xffd700,
      dropShadow: true,
      dropShadowColor: 0xffd700,
      dropShadowBlur: 5,
      dropShadowDistance: 0
    });
    icon.anchor.set(0.5, 0);
    icon.position.set(12, 0);
    barContainer.addChild(icon);
    
    // Fond de la barre
    const barHeight = token.h - 30;
    const barWidth = 18;
    
    const barBg = new PIXI.Graphics();
    barBg.lineStyle(2, 0xffd700, 0.8);
    barBg.beginFill(0x000000, 0.7);
    barBg.drawRoundedRect(0, 20, barWidth, barHeight, 4);
    barBg.endFill();
    barContainer.addChild(barBg);
    
    // Remplissage de la barre
    const fillHeight = (barHeight * burste) / 100;
    const barFill = new PIXI.Graphics();
    
    // Gradient gold
    const isFull = burste >= 100;
    const color1 = isFull ? 0xff8c00 : 0xffd700;
    const color2 = isFull ? 0xffff00 : 0xfff59d;
    
    barFill.beginFill(color1, 1);
    barFill.drawRoundedRect(2, 20 + (barHeight - fillHeight), barWidth - 4, fillHeight, 2);
    barFill.endFill();
    
    // Glow si full
    if (isFull) {
      const glow = new PIXI.filters.GlowFilter({
        distance: 10,
        outerStrength: 3,
        color: 0xffd700
      });
      barFill.filters = [glow];
    }
    
    barContainer.addChild(barFill);
    
    // Valeur texte
    const valueText = new PIXI.Text(burste.toString(), {
      fontSize: 11,
      fontWeight: "bold",
      fill: 0xffd700,
      stroke: 0x000000,
      strokeThickness: 3,
      dropShadow: true,
      dropShadowColor: 0xffd700,
      dropShadowBlur: 5,
      dropShadowDistance: 0
    });
    valueText.anchor.set(0.5, 0);
    valueText.position.set(12, 20 + barHeight + 5);
    barContainer.addChild(valueText);
    
    container.addChild(barContainer);
  }
  
  /* ================================
     CRÉER LA BARRE PM (DROITE)
     ================================ */
  static _createPMBar(container, pm, token) {
    const barContainer = new PIXI.Container();
    
    // Position à droite
    barContainer.position.set(token.w + 6, 0);
    
    // Icône 💙
    const icon = new PIXI.Text("💙", {
      fontSize: 14,
      dropShadow: true,
      dropShadowColor: 0x007bff,
      dropShadowBlur: 5,
      dropShadowDistance: 0
    });
    icon.anchor.set(0.5, 0);
    icon.position.set(12, 0);
    barContainer.addChild(icon);
    
    // Fond de la barre
    const barHeight = token.h - 30;
    const barWidth = 18;
    
    const barBg = new PIXI.Graphics();
    barBg.lineStyle(2, 0x007bff, 0.8);
    barBg.beginFill(0x000000, 0.7);
    barBg.drawRoundedRect(0, 20, barWidth, barHeight, 4);
    barBg.endFill();
    barContainer.addChild(barBg);
    
    // Remplissage de la barre
    const pmPourcentage = pm.max > 0 ? (pm.value / pm.max) * 100 : 0;
    const fillHeight = (barHeight * pmPourcentage) / 100;
    const barFill = new PIXI.Graphics();
    
    // Gradient bleu
    barFill.beginFill(0x007bff, 1);
    barFill.drawRoundedRect(2, 20 + (barHeight - fillHeight), barWidth - 4, fillHeight, 2);
    barFill.endFill();
    
    // Glow bleu
    const glow = new PIXI.filters.GlowFilter({
      distance: 8,
      outerStrength: 2,
      color: 0x007bff
    });
    barFill.filters = [glow];
    
    barContainer.addChild(barFill);
    
    // Valeur texte
    const valueText = new PIXI.Text(pm.value.toString(), {
      fontSize: 11,
      fontWeight: "bold",
      fill: 0x4da3ff,
      stroke: 0x000000,
      strokeThickness: 3,
      dropShadow: true,
      dropShadowColor: 0x007bff,
      dropShadowBlur: 5,
      dropShadowDistance: 0
    });
    valueText.anchor.set(0.5, 0);
    valueText.position.set(12, 20 + barHeight + 5);
    barContainer.addChild(valueText);
    
    container.addChild(barContainer);
  }
}
