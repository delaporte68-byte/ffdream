/**
 * ============================================
 * LECTEUR YOUTUBE INTÉGRÉ — FFdreame
 * ============================================
 * Fenêtre flottante avec :
 * - Coller une URL YouTube (vidéo OU playlist)
 * - Player intégré avec contrôles natifs YouTube
 * - Liste des titres de la playlist (si playlist)
 * - Sauvegarde de l'URL entre sessions
 * - Accessible depuis le sidebar Playlists de Foundry
 * ============================================
 */

export class FFdreameYouTubePlayer extends Application {

  constructor(options = {}) {
    super(options);
    this._ytPlayer  = null;
    this._playlist  = [];
    this._currentIdx = 0;
    this._apiReady  = false;
  }

  /* ============================================
     OPTIONS FOUNDRY
     ============================================ */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id:           'ffdreame-youtube-player',
      title:        '🎵 Lecteur YouTube',
      template:     'systems/ffdreame/templates/ui/youtube-player.html',
      width:        420,
      height:       560,
      resizable:    true,
      minimizable:  true,
      classes:      ['ffdreame', 'youtube-player-app']
    });
  }

  /* ============================================
     DONNÉES POUR LE TEMPLATE
     ============================================ */
  getData() {
    const savedUrl  = game.settings.get('ffdreame', 'youtubeUrl')  || '';
    const savedList = game.settings.get('ffdreame', 'youtubePlaylistCache') || '[]';
    let playlist = [];
    try { playlist = JSON.parse(savedList); } catch(e) {}

    return {
      savedUrl,
      playlist,
      hasPlaylist: playlist.length > 0
    };
  }

  /* ============================================
     LISTENERS
     ============================================ */
  activateListeners(html) {
    super.activateListeners(html);

    // Charger URL
    html.find('#yt-load-btn').on('click', () => this._loadUrl(html));
    html.find('#yt-url-input').on('keydown', e => {
      if (e.key === 'Enter') this._loadUrl(html);
    });

    // Contrôles
    html.find('#yt-prev').on('click',   () => this._prev());
    html.find('#yt-play').on('click',   () => this._playPause());
    html.find('#yt-next').on('click',   () => this._next());
    html.find('#yt-vol-slider').on('input', e => this._setVolume(parseInt(e.target.value)));

    // Clic sur un titre dans la liste
    html.find('.yt-track').on('click', e => {
      const idx = parseInt(e.currentTarget.dataset.idx);
      this._playIndex(idx);
    });

    // Effacer
    html.find('#yt-clear-btn').on('click', () => this._clearPlayer(html));

    // Charger l'API YouTube si pas encore fait
    this._ensureYTApi();

    // Si une URL était sauvegardée → la charger automatiquement
    const saved = game.settings.get('ffdreame', 'youtubeUrl');
    if (saved) {
      setTimeout(() => this._buildPlayer(saved), 800);
    }
  }

  /* ============================================
     CHARGER UNE URL
     ============================================ */
  async _loadUrl(html) {
    const input = html.find('#yt-url-input').val()?.trim();
    if (!input) { ui.notifications.warn('⚠️ Colle une URL YouTube !'); return; }

    await game.settings.set('ffdreame', 'youtubeUrl', input);
    await this._buildPlayer(input);
  }

  /* ============================================
     CONSTRUIRE LE PLAYER
     ============================================ */
  async _buildPlayer(url) {
    const parsed = FFdreameYouTubePlayer._parseYouTubeUrl(url);
    if (!parsed) {
      ui.notifications.error('❌ URL YouTube invalide (vidéo ou playlist)');
      return;
    }

    const container = document.querySelector('#ffdreame-yt-iframe-container');
    if (!container) return;

    // Construire l'URL d'embed
    let embedUrl;
    if (parsed.type === 'playlist') {
      embedUrl = `https://www.youtube-nocookie.com/embed/videoseries?list=${parsed.listId}&enablejsapi=1&origin=${window.location.origin}`;
    } else {
      // Vidéo simple, avec playlist si listId présent
      embedUrl = `https://www.youtube-nocookie.com/embed/${parsed.videoId}?enablejsapi=1&origin=${window.location.origin}`;
      if (parsed.listId) embedUrl += `&list=${parsed.listId}`;
    }

    container.innerHTML = `
      <iframe
        id="ffdreame-yt-iframe"
        src="${embedUrl}"
        width="100%" height="240"
        frameborder="0"
        allow="autoplay; encrypted-media; picture-in-picture"
        allowfullscreen
        style="border-radius:8px; display:block;">
      </iframe>
    `;

    // Afficher les infos
    const infoEl = document.querySelector('#yt-info');
    if (infoEl) {
      infoEl.textContent = parsed.type === 'playlist'
        ? `🎵 Playlist chargée`
        : `🎵 Vidéo chargée`;
    }

    // Si c'est une playlist → récupérer les titres via l'API publique
    if (parsed.listId) {
      await this._fetchPlaylistItems(parsed.listId);
    }
  }

  /* ============================================
     RÉCUPÉRER LES TITRES DE LA PLAYLIST
     (via l'API YouTube oEmbed / noembed - sans clé API)
     ============================================ */
  async _fetchPlaylistItems(listId) {
    const listEl = document.querySelector('#yt-tracklist');
    if (!listEl) return;

    listEl.innerHTML = `<li style="color:#888; padding:8px;">⏳ Chargement de la playlist...</li>`;

    try {
      // Utiliser l'API YouTube Data v3 publique sans clé (limite 50 items)
      // Alternative sans clé : scraper l'embed ou utiliser noembed
      // On utilise une approche hybride : lire depuis l'iframe via postMessage
      // Pour l'instant, afficher un message d'info
      listEl.innerHTML = `
        <li style="color:#aaa; padding:8px; font-size:11px; font-style:italic;">
          ℹ️ La liste des titres s'affiche dans le player intégré ci-dessus.<br>
          Navigue avec les boutons ⏮️ ⏯️ ⏭️ du player YouTube.
        </li>
      `;

      // Essayer de lire via l'API YouTube IFrame (si disponible)
      this._tryGetPlaylistFromIframe(listId);

    } catch(e) {
      console.warn('FFdreame | YouTube fetch playlist:', e);
    }
  }

  /* ============================================
     TENTER DE LIRE LA PLAYLIST VIA IFRAME API
     ============================================ */
  _tryGetPlaylistFromIframe(listId) {
    const checkReady = () => {
      const iframe = document.querySelector('#ffdreame-yt-iframe');
      if (!iframe || !window.YT?.Player) {
        setTimeout(checkReady, 1000);
        return;
      }

      try {
        if (this._ytPlayer) {
          this._ytPlayer.destroy();
          this._ytPlayer = null;
        }

        this._ytPlayer = new YT.Player('ffdreame-yt-iframe', {
          events: {
            onReady: (event) => {
              this._apiReady = true;
              const playlist = event.target.getPlaylist?.();
              if (playlist && playlist.length > 0) {
                this._renderTrackList(playlist, event.target);
              }
            },
            onStateChange: (event) => {
              this._onPlayerStateChange(event);
            }
          }
        });
      } catch(e) {
        console.warn('FFdreame | YT.Player init:', e);
      }
    };
    setTimeout(checkReady, 1500);
  }

  /* ============================================
     AFFICHER LA LISTE DES TITRES
     ============================================ */
  _renderTrackList(videoIds, player) {
    const listEl = document.querySelector('#yt-tracklist');
    if (!listEl) return;

    listEl.innerHTML = '';
    videoIds.forEach((vid, idx) => {
      const li = document.createElement('li');
      li.className = 'yt-track';
      li.dataset.idx = idx;
      li.innerHTML = `<span class="yt-track-num">${idx + 1}</span> <span class="yt-track-title">Titre ${idx + 1}</span>`;
      li.addEventListener('click', () => this._playIndex(idx));
      listEl.appendChild(li);
    });

    // Essayer de récupérer les vrais titres
    this._enrichTrackTitles(videoIds, player);
  }

  _enrichTrackTitles(videoIds, player) {
    // Récupérer le titre de la vidéo en cours
    if (player && typeof player.getVideoData === 'function') {
      try {
        const data = player.getVideoData();
        if (data?.title) {
          const items = document.querySelectorAll('.yt-track');
          const currentIdx = player.getPlaylistIndex?.() || 0;
          if (items[currentIdx]) {
            items[currentIdx].querySelector('.yt-track-title').textContent = data.title;
          }
        }
      } catch(e) {}
    }
  }

  /* ============================================
     CHANGER L'ÉTAT DU PLAYER
     ============================================ */
  _onPlayerStateChange(event) {
    const playBtn = document.querySelector('#yt-play');
    if (!playBtn) return;

    // YT.PlayerState: -1=unstarted, 0=ended, 1=playing, 2=paused, 3=buffering, 5=cued
    if (event.data === 1) { // playing
      playBtn.textContent = '⏸';
      playBtn.title = 'Pause';
      // Mettre à jour le titre affiché
      if (this._ytPlayer?.getVideoData) {
        try {
          const data = this._ytPlayer.getVideoData();
          const infoEl = document.querySelector('#yt-info');
          if (infoEl && data?.title) infoEl.textContent = `🎵 ${data.title}`;
          // Surligner le titre actif dans la liste
          const idx = this._ytPlayer.getPlaylistIndex?.();
          if (idx !== undefined) {
            document.querySelectorAll('.yt-track').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.yt-track')[idx]?.classList.add('active');
          }
        } catch(e) {}
      }
    } else if (event.data === 2) { // paused
      playBtn.textContent = '▶';
      playBtn.title = 'Play';
    }
  }

  /* ============================================
     CONTRÔLES
     ============================================ */
  _playPause() {
    if (!this._ytPlayer || !this._apiReady) return;
    try {
      const state = this._ytPlayer.getPlayerState?.();
      if (state === 1) this._ytPlayer.pauseVideo?.();
      else             this._ytPlayer.playVideo?.();
    } catch(e) {
      // Fallback : agir directement sur l'iframe via postMessage
      const iframe = document.querySelector('#ffdreame-yt-iframe');
      if (iframe) iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
    }
  }

  _prev() {
    if (!this._ytPlayer || !this._apiReady) return;
    try { this._ytPlayer.previousVideo?.(); } catch(e) {}
  }

  _next() {
    if (!this._ytPlayer || !this._apiReady) return;
    try { this._ytPlayer.nextVideo?.(); } catch(e) {}
  }

  _playIndex(idx) {
    if (!this._ytPlayer || !this._apiReady) return;
    try { this._ytPlayer.playVideoAt?.(idx); } catch(e) {}
  }

  _setVolume(vol) {
    if (!this._ytPlayer || !this._apiReady) return;
    try { this._ytPlayer.setVolume?.(vol); } catch(e) {}
  }

  _clearPlayer(html) {
    const container = document.querySelector('#ffdreame-yt-iframe-container');
    if (container) container.innerHTML = `<div id="yt-placeholder" style="display:flex;align-items:center;justify-content:center;height:240px;background:rgba(0,0,0,0.3);border-radius:8px;color:#555;font-size:14px;">Colle une URL YouTube ci-dessus</div>`;
    const listEl = document.querySelector('#yt-tracklist');
    if (listEl) listEl.innerHTML = '';
    const infoEl = document.querySelector('#yt-info');
    if (infoEl) infoEl.textContent = '';
    html.find('#yt-url-input').val('');
    game.settings.set('ffdreame', 'youtubeUrl', '');
    if (this._ytPlayer) { try { this._ytPlayer.destroy(); } catch(e) {} this._ytPlayer = null; }
    this._apiReady = false;
  }

  /* ============================================
     CHARGER L'API YOUTUBE IFRAME
     ============================================ */
  _ensureYTApi() {
    if (window.YT?.Player) return; // déjà chargée
    if (document.getElementById('yt-iframe-api-script')) return; // déjà en cours

    const tag = document.createElement('script');
    tag.id  = 'yt-iframe-api-script';
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);

    // Callback global requis par l'API YouTube
    if (!window.onYouTubeIframeAPIReady) {
      window.onYouTubeIframeAPIReady = () => {
        console.log('FFdreame | YouTube IFrame API prête ✅');
      };
    }
  }

  /* ============================================
     PARSER UNE URL YOUTUBE
     Supporte :
     - https://www.youtube.com/watch?v=VIDEO_ID
     - https://www.youtube.com/watch?v=VIDEO_ID&list=PLAYLIST_ID
     - https://www.youtube.com/playlist?list=PLAYLIST_ID
     - https://youtu.be/VIDEO_ID
     ============================================ */
  static _parseYouTubeUrl(url) {
    if (!url) return null;
    try {
      // youtu.be short links
      const shortMatch = url.match(/youtu\.be\/([^?&]+)/);
      if (shortMatch) return { type: 'video', videoId: shortMatch[1], listId: null };

      const urlObj = new URL(url);

      // Playlist pure
      if (urlObj.pathname === '/playlist') {
        const listId = urlObj.searchParams.get('list');
        if (listId) return { type: 'playlist', videoId: null, listId };
      }

      // Vidéo (avec ou sans playlist)
      if (urlObj.pathname === '/watch') {
        const videoId = urlObj.searchParams.get('v');
        const listId  = urlObj.searchParams.get('list');
        if (videoId) return { type: listId ? 'playlist' : 'video', videoId, listId };
      }

      // Embed direct
      const embedMatch = url.match(/\/embed\/([^?&/]+)/);
      if (embedMatch) return { type: 'video', videoId: embedMatch[1], listId: null };

      return null;
    } catch(e) {
      return null;
    }
  }

  /* ============================================
     INSTANCE SINGLETON
     ============================================ */
  static _instance = null;

  static openPlayer() {
    if (!FFdreameYouTubePlayer._instance || !FFdreameYouTubePlayer._instance.rendered) {
      FFdreameYouTubePlayer._instance = new FFdreameYouTubePlayer();
    }
    FFdreameYouTubePlayer._instance.render(true);
    return FFdreameYouTubePlayer._instance;
  }

  /* ============================================
     INITIALISATION
     Enregistre les settings et le bouton dans le sidebar
     ============================================ */
  static init() {
    // Settings de sauvegarde
    game.settings.register('ffdreame', 'youtubeUrl', {
      name: 'Dernière URL YouTube',
      scope: 'client',
      config: false,
      type: String,
      default: ''
    });

    game.settings.register('ffdreame', 'youtubePlaylistCache', {
      name: 'Cache playlist YouTube',
      scope: 'client',
      config: false,
      type: String,
      default: '[]'
    });

    // Ajouter le bouton dans la sidebar Playlists
    Hooks.on('renderPlaylistDirectory', (app, html) => {
      if (html.find('#ffdreame-yt-btn').length) return; // déjà ajouté

      const btn = $(`
        <div id="ffdreame-yt-btn" style="
          margin: 8px 4px 4px;
          background: linear-gradient(135deg, #ff0000 0%, #cc0000 100%);
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 6px;
          padding: 8px 12px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          color: white;
          font-size: 13px;
          font-weight: bold;
          box-shadow: 0 2px 8px rgba(0,0,0,0.4);
          transition: all 0.2s;
          user-select: none;
        ">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
            <path d="M23.5 6.2c-.3-1-1.1-1.8-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6c-1 .3-1.8 1.1-2.1 2.1C0 8.1 0 12 0 12s0 3.9.5 5.8c.3 1 1.1 1.8 2.1 2.1C4.5 20.5 12 20.5 12 20.5s7.5 0 9.4-.6c1-.3 1.8-1.1 2.1-2.1C24 15.9 24 12 24 12s0-3.9-.5-5.8zM9.5 15.5V8.5l6.5 3.5-6.5 3.5z"/>
          </svg>
          YouTube Player
        </div>
      `);

      btn.on('mouseenter', () => btn.css('opacity', '0.85'));
      btn.on('mouseleave', () => btn.css('opacity', '1'));
      btn.on('click', () => FFdreameYouTubePlayer.openPlayer());

      // Insérer en haut de la sidebar playlists
      const header = html.find('.directory-header, .header-actions').first();
      if (header.length) {
        header.after(btn);
      } else {
        html.prepend(btn);
      }
    });
  }
}
