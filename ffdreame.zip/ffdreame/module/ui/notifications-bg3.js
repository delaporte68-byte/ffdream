/**
 * NOTIFICATIONS FFDREAME — STYLE BALDUR'S GATE 3
 *
 * Haut droite, deux zones :
 *  • Carré dés  : max 2, FIFO, NE disparaissent JAMAIS seuls
 *                 Seul le MJ peut fermer avec ✕
 *  • Bandeau texte : auto-disparition 4s, tout le monde voit
 */
export class FFdreameNotifications {

  static _zoneDes  = null;
  static _zoneTxt  = null;
  static _ready    = false;

  /* ── INIT ── */
  static init() {
    Hooks.once('ready', () => {
      FFdreameNotifications._build();
      FFdreameNotifications._intercept();
      FFdreameNotifications._hookDes();
      console.log('FFdreame | Notifications BG3 ✅');
    });
  }

  /* ── CONSTRUCTION ── */
  static _build() {
    document.getElementById('ffn-root')?.remove();
    const root = document.createElement('div');
    root.id = 'ffn-root';
    root.innerHTML = '<div id="ffn-des"></div><div id="ffn-txt"></div>';
    document.body.appendChild(root);
    FFdreameNotifications._zoneDes = root.querySelector('#ffn-des');
    FFdreameNotifications._zoneTxt = root.querySelector('#ffn-txt');
    FFdreameNotifications._css();
    FFdreameNotifications._ready = true;
  }

  /* ── HOOK CHAT → cartes dés ── */
  static _hookDes() {
    Hooks.on('createChatMessage', msg => {
      try {
        const html = msg.content || '';
        if (!html.includes('dice-total')) return;
        const valM = html.match(/dice-total[^>]*>\s*(\d+)/);
        const val  = valM ? valM[1] : '?';
        const who  = msg.speaker?.alias || '?';
        let type, label, ico;
        if      (html.includes('critical-success'))         { type='crit-ok'; label='CRITIQUE !'; ico='⭐'; }
        else if (html.includes('critical-failure'))         { type='crit-ko'; label='ÉCHEC CRIT'; ico='💀'; }
        else if (html.match(/dice-total\s+success/))        { type='ok';      label='Réussite';   ico='✓';  }
        else if (html.match(/dice-total\s+failure/))        { type='ko';      label='Échec';      ico='✗';  }
        else if (html.includes('"success"'))                { type='ok';      label='Réussite';   ico='✓';  }
        else if (html.includes('"failure"'))                { type='ko';      label='Échec';      ico='✗';  }
        else return;
        const flavM = (msg.flavor||'').match(/<h3[^>]*>([^<]{2,50})<\/h3>/);
        const tech  = flavM ? flavM[1].trim() : '';
        FFdreameNotifications._addDes({ val, who, type, label, ico, tech });
      } catch(e) {}
    });
  }

  /* ── CARTE DÉ ── */
  static _addDes({ val, who, type, label, ico, tech }) {
    if (!FFdreameNotifications._ready) return;
    const zone = FFdreameNotifications._zoneDes;
    // FIFO max 2
    const all = [...zone.querySelectorAll('.ffn-sq')];
    if (all.length >= 2) { all[0].remove(); }

    const isGM = game?.user?.isGM ?? false;
    const el = document.createElement('div');
    el.className = `ffn-sq ffn-${type}`;
    el.innerHTML = `
      <div class="ffn-stripe"></div>
      ${isGM ? '<button class="ffn-close" title="Fermer">✕</button>' : ''}
      <div class="ffn-ico">${ico}</div>
      <div class="ffn-num">${val}</div>
      <div class="ffn-lbl">${label}</div>
      <div class="ffn-who">${who}${tech ? `<em>${tech}</em>` : ''}</div>`;

    if (isGM) el.querySelector('.ffn-close').onclick = e => { e.stopPropagation(); FFdreameNotifications._out(el); };

    zone.appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('ffn-in')));
  }

  /* ── BANDEAU TEXTE ── */
  static push(msg, type = 'info') {
    if (!FFdreameNotifications._ready) return;
    const clean = FFdreameNotifications._strip(msg);
    if (!clean) return;
    const ico = { info:'ℹ', warn:'⚠', error:'✕', success:'✓' }[type] || 'ℹ';
    const el = document.createElement('div');
    el.className = `ffn-bar ffn-${type}`;
    el.innerHTML = `<div class="ffn-stripe"></div><span class="ffn-bar-ico">${ico}</span><span class="ffn-bar-msg">${clean}</span>`;
    FFdreameNotifications._zoneTxt.appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('ffn-in')));
    setTimeout(() => FFdreameNotifications._out(el), 4000);
  }

  static _out(el) {
    if (!el?.parentNode) return;
    el.classList.remove('ffn-in'); el.classList.add('ffn-out');
    setTimeout(() => el.remove(), 260);
  }

  /* ── INTERCEPTER ui.notifications FOUNDRY ── */
  static _intercept() {
    if (!ui?.notifications) { setTimeout(() => FFdreameNotifications._intercept(), 600); return; }
    const map = { notify:'info', info:'info', warn:'warn', error:'error', success:'success' };
    for (const [m, t] of Object.entries(map)) ui.notifications[m] = msg => FFdreameNotifications.push(msg, t);
    const hide = () => { const b = document.getElementById('notifications'); if (b) b.style.cssText = 'display:none!important'; };
    hide();
    new MutationObserver(hide).observe(document.body, { childList: true });
  }

  /* ── API ── */
  static async showCritical(type, name, val)  { FFdreameNotifications._addDes({ val, who: name, type: type==='success'?'crit-ok':'crit-ko', label:'CRITIQUE !', ico: type==='success'?'⭐':'💀', tech:'' }); }
  static async showTurnStart(name)            { FFdreameNotifications.push(`▶ Tour de <b>${name}</b>`, 'info'); }
  static async showTurnEnd(name)              { FFdreameNotifications.push(`🔒 Tour terminé — <b>${name}</b>`, 'warn'); }
  static async showNewRound(n)               { FFdreameNotifications.push(`⚔ <b>Round ${n}</b> — 1 Grand PA récupéré`, 'info'); }
  static async showAOERWarning(a, t)         { FFdreameNotifications.push(`⚠ Zone danger — <b>${t}</b>`, 'error'); }
  static async showTeleportation(name)       { FFdreameNotifications.push(`✦ Téléportation — <b>${name}</b>`, 'info'); }
  static async showKnockout(name)            { FFdreameNotifications.push(`💀 <b>K.O.</b> — ${name}`, 'error'); }
  static async showMassiveDamage(name, dmg)  { FFdreameNotifications.push(`💥 <b>${name}</b> — ${dmg} dégâts`, 'error'); }
  static async showNotification(opts)        { FFdreameNotifications.push([opts.title, opts.subtitle].filter(Boolean).join(' — '), opts.shake ? 'error' : 'info'); }

  static _strip(s) {
    return String(s).replace(/<br\s*\/?>/gi,' ').replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim().slice(0,100);
  }

  /* ── CSS BG3 ── */
  static _css() {
    document.getElementById('ffn-css')?.remove();
    const s = document.createElement('style');
    s.id = 'ffn-css';
    s.textContent = `
#notifications { display:none !important; }

#ffn-root {
  position: fixed;
  top: 12px; right: 12px;
  z-index: 99999;
  display: flex;
  flex-direction: column;
  gap: 10px;
  align-items: flex-end;
  pointer-events: none;
}
#ffn-des, #ffn-txt {
  display: flex;
  flex-direction: column;
  gap: 7px;
  align-items: flex-end;
}

/* ── Base commune fond bois BG3 ── */
.ffn-sq, .ffn-bar {
  position: relative;
  pointer-events: auto;
  font-family: 'Palatino Linotype', Georgia, serif;
  background: linear-gradient(155deg, rgba(28,18,10,.97) 0%, rgba(14,9,4,.99) 60%, rgba(20,13,6,.98) 100%);
  border: 1px solid rgba(160,100,35,.55);
  border-top-color: rgba(210,155,55,.4);
  border-bottom-color: rgba(100,60,15,.7);
  border-radius: 7px;
  box-shadow: 0 8px 32px rgba(0,0,0,.9), 0 2px 6px rgba(0,0,0,.7), inset 0 0 24px rgba(0,0,0,.35);
  overflow: hidden;
  opacity: 0;
  transform: translateX(20px) scale(.93);
  transition: opacity .22s cubic-bezier(.16,1,.3,1), transform .22s cubic-bezier(.16,1,.3,1);
}
.ffn-sq.ffn-in, .ffn-bar.ffn-in  { opacity:1; transform:translateX(0) scale(1); }
.ffn-sq.ffn-out, .ffn-bar.ffn-out { opacity:0; transform:translateX(14px) scale(.95); transition:opacity .22s ease, transform .22s ease; }

.ffn-stripe {
  position: absolute; top:0; left:0; right:0; height:2px; border-radius:7px 7px 0 0;
}

/* ── Bouton fermer MJ ── */
.ffn-close {
  position: absolute; top:4px; right:5px;
  background:none; border:none;
  color:rgba(180,130,50,.35); font-size:9px; cursor:pointer;
  padding:2px 4px; border-radius:3px; line-height:1; font-family:sans-serif;
  transition: color .15s, background .15s; z-index:5;
}
.ffn-close:hover { color:#fff; background:rgba(255,255,255,.1); }

/* ── Carré dé 120×120 ── */
.ffn-sq {
  width:120px; height:120px;
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  padding:14px 8px 8px; text-align:center;
}
.ffn-ico { font-size:15px; line-height:1; margin-bottom:1px; }
.ffn-num {
  font-size:54px; font-weight:700; line-height:.85;
  font-family:'Georgia',serif; letter-spacing:-2px;
}
.ffn-lbl { font-size:7.5px; letter-spacing:1.8px; text-transform:uppercase; font-weight:bold; margin-top:5px; }
.ffn-who {
  font-size:7px; color:rgba(200,165,90,.5); font-style:italic; margin-top:5px;
  max-width:104px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
}
.ffn-who em { display:block; font-size:6.5px; color:rgba(170,130,60,.38); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.ffn-sq::after {
  content:''; position:absolute; bottom:6px; left:50%; transform:translateX(-50%);
  width:48px; height:1px; background:linear-gradient(90deg,transparent,rgba(200,150,55,.22),transparent);
}

/* Couleurs dés */
.ffn-crit-ok .ffn-stripe { background:#ffd700; box-shadow:0 0 10px rgba(255,215,0,.7); }
.ffn-crit-ok .ffn-num    { color:#ffd700; text-shadow:0 0 16px rgba(255,215,0,.8),0 0 40px rgba(255,215,0,.3),2px 3px 6px #000; }
.ffn-crit-ok .ffn-lbl    { color:#ffd700; text-shadow:0 0 8px rgba(255,215,0,.6); }
.ffn-crit-ok .ffn-ico    { filter:drop-shadow(0 0 5px rgba(255,215,0,.8)); }

.ffn-crit-ko .ffn-stripe { background:#e02020; box-shadow:0 0 10px rgba(220,32,32,.7); }
.ffn-crit-ko .ffn-num    { color:#ff4040; text-shadow:0 0 16px rgba(220,32,32,.8),0 0 40px rgba(220,32,32,.3),2px 3px 6px #000; }
.ffn-crit-ko .ffn-lbl    { color:#ff4040; text-shadow:0 0 8px rgba(220,32,32,.6); }
.ffn-crit-ko .ffn-ico    { filter:drop-shadow(0 0 5px rgba(220,32,32,.8)); }

.ffn-ok .ffn-stripe { background:#38e87a; box-shadow:0 0 8px rgba(56,232,122,.5); }
.ffn-ok .ffn-num    { color:#44ff88; text-shadow:0 0 14px rgba(56,232,122,.7),2px 3px 6px #000; }
.ffn-ok .ffn-lbl    { color:#44ff88; text-shadow:0 0 6px rgba(56,232,122,.5); }
.ffn-ok .ffn-ico    { filter:drop-shadow(0 0 4px rgba(56,232,122,.6)); }

.ffn-ko .ffn-stripe { background:#e05530; box-shadow:0 0 8px rgba(224,85,48,.5); }
.ffn-ko .ffn-num    { color:#ff7755; text-shadow:0 0 14px rgba(224,85,48,.7),2px 3px 6px #000; }
.ffn-ko .ffn-lbl    { color:#ff8866; text-shadow:0 0 6px rgba(224,85,48,.5); }
.ffn-ko .ffn-ico    { filter:drop-shadow(0 0 4px rgba(224,85,48,.6)); }

/* ── Bandeau texte ── */
.ffn-bar {
  width:210px; display:flex; align-items:flex-start; gap:7px;
  padding:9px 14px 9px 12px; border-left:2px solid;
}
.ffn-info    { border-left-color:#00d9ff; }
.ffn-info    .ffn-stripe { background:#00d9ff; box-shadow:0 0 8px rgba(0,217,255,.5); }
.ffn-warn    { border-left-color:#ffd700; }
.ffn-warn    .ffn-stripe { background:#ffd700; box-shadow:0 0 8px rgba(255,215,0,.5); }
.ffn-error   { border-left-color:#ff4444; }
.ffn-error   .ffn-stripe { background:#ff4444; box-shadow:0 0 8px rgba(255,68,68,.5); }
.ffn-success { border-left-color:#44ff88; }
.ffn-success .ffn-stripe { background:#44ff88; box-shadow:0 0 8px rgba(68,255,136,.5); }

.ffn-bar-ico { font-size:11px; flex-shrink:0; margin-top:1px; font-family:sans-serif; }
.ffn-info    .ffn-bar-ico { color:#00d9ff; }
.ffn-warn    .ffn-bar-ico { color:#ffd700; }
.ffn-error   .ffn-bar-ico { color:#ff5555; }
.ffn-success .ffn-bar-ico { color:#44ff88; }

.ffn-bar-msg {
  flex:1; font-size:10.5px; color:rgba(225,195,140,.92);
  line-height:1.45; font-family:'Palatino Linotype',serif; word-break:break-word;
}
.ffn-bar-msg b, .ffn-bar-msg strong { color:#e8d8b0; font-weight:bold; }
`;
    document.head.appendChild(s);
  }
}
