/**
 * BARRE DE COMBAT FFDREAME — CORRIGÉE v6.1
 * ✅ GRISE LES BOUTONS QUAND CE N'EST PAS LE TOUR
 * ✅ Esquive/Défense/Marche TOUJOURS disponibles
 * ✅ Seul le joueur dont c'est le tour peut agir
 */
export class FFdreameCombatBar {

  static currentActor = null;
  static targetMode   = false;

  /* ─── INIT ─── */
  static init() {
    Hooks.once('ready', () => {
      setTimeout(() => FFdreameCombatBar._createBar(), 1200);
    });

    Hooks.on('controlToken', (token, controlled) => {
      if (FFdreameCombatBar.targetMode) return;
      if (controlled && token?.actor) FFdreameCombatBar._switchToActor(token.actor);
    });

    Hooks.on('updateItem', (item) => {
      if (item.parent?.id === FFdreameCombatBar.currentActor?.id)
        FFdreameCombatBar._updateTechniques();
    });

    Hooks.on('updateActor', (actor) => {
      if (actor.id === FFdreameCombatBar.currentActor?.id) {
        console.log('🔄 updateActor détecté, rafraîchir barre');
        FFdreameCombatBar._refreshBar();
      }
    });

    // Chaque changement de tour → rafraîchir la barre pour tout le monde
    Hooks.on('updateCombat', (combat, changed) => {
      if ('turn' in changed || 'round' in changed) {
        console.log('🔄 updateCombat détecté (tour/round change), rafraîchir barre');
        setTimeout(() => FFdreameCombatBar._refreshBar(), 120);
      }
    });

    Hooks.on('combatStart', () => setTimeout(() => FFdreameCombatBar._refreshBar(), 300));
    Hooks.on('deleteCombat', () => setTimeout(() => FFdreameCombatBar._refreshBar(), 300));

    // Bloquer l'ouverture de la fiche si pas le tour (sauf MJ)
    Hooks.on('renderActorSheet', (sheet) => {
      if (game.user.isGM) return;
      if (!game.combat?.started) return;
      if (!FFdreameCombatBar._peutAgir(sheet.actor)) {
        sheet.close();
        FFdreameNotifications?.push('🔒 Ce n\'est pas votre tour !', 'warn');
      }
    });
  }

  /* ─── VÉRIFICATION CENTRALE ─── */
  // Retourne true si l'acteur peut agir (son tour dans l'initiative)
  static _peutAgir(actor) {
    if (!actor) return false;
    if (game.user.isGM) return true;
    if (!game.combat?.started) return true; // hors combat : tout permis

    const combatant = game.combat.combatant;
    if (!combatant) return false;

    // C'est le tour de cet acteur ?
    return combatant.actorId === actor.id;
  }

  // Retourne true si la barre doit être verrouillée (hors tour OU actionBlocked posé)
  static _estBloque(actor) {
    if (!actor) return true;
    if (game.user.isGM) return false;
    if (!game.combat?.started) return false;

    // Pas mon tour → bloqué
    if (!FFdreameCombatBar._peutAgir(actor)) return true;

    // Mon tour mais j'ai cliqué "Fin Tour"
    try { return !!actor.getFlag('ffdreame', 'actionBlocked'); } catch(e) { return false; }
  }

  /* ─── CRÉATION DE LA BARRE ─── */
  static _createBar() {
    document.getElementById('ffdreame-combat-bar')?.remove();
    document.body.classList.add('has-combat-bar');

    const bar = document.createElement('div');
    bar.id = 'ffdreame-combat-bar';
    bar.innerHTML = `
      <div class="combat-bar-content">
        <div class="combat-bar-portrait" title="Ouvrir la fiche">
          <img src="icons/svg/mystery-man.svg" class="portrait-img" alt="Portrait"/>
          <div class="portrait-name">Aucun</div>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-actions">
          <button class="action-btn target-btn" title="Cibler un token">
            <i class="fas fa-crosshairs"></i><span>Cibler</span>
          </button>
          <button class="action-btn end-turn-btn" title="Fin de tour">
            <i class="fas fa-forward"></i><span>Fin Tour</span>
          </button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-tableaux">
          <button class="tableau-btn" data-tableau="1"><span class="tableau-name">Tableau 1</span></button>
          <button class="tableau-btn" data-tableau="2"><span class="tableau-name">Tableau 2</span></button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-reactions">
          <button class="reaction-btn" data-reaction="esquive" title="Esquive — toujours disponible">
            <i class="fas fa-running"></i>
          </button>
          <button class="reaction-btn" data-reaction="defense" title="Défense — toujours disponible">
            <i class="fas fa-shield-alt"></i>
          </button>
          <button class="reaction-btn" data-reaction="marche" title="Marche — toujours disponible">
            <i class="fas fa-walking"></i>
          </button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-techniques">
          <div class="techniques-container">
            <div class="techniques-empty-hint">Sélectionnez un token</div>
          </div>
        </div>
      </div>`;

    document.body.appendChild(bar);
    FFdreameCombatBar._bindEvents(bar);

    try {
      const t = canvas?.tokens?.controlled?.[0];
      if (t?.actor) FFdreameCombatBar._switchToActor(t.actor);
    } catch(e) {}
  }

  /* ─── EVENTS ─── */
  static _bindEvents(bar) {
    bar.querySelector('.combat-bar-portrait').addEventListener('click', () => {
      if (FFdreameCombatBar._estBloque(FFdreameCombatBar.currentActor)) return;
      FFdreameCombatBar.currentActor?.sheet.render(true);
    });

    bar.querySelector('.target-btn').addEventListener('click', () => {
      if (FFdreameCombatBar._estBloque(FFdreameCombatBar.currentActor)) {
        window.FFdreameNotifications?.push('🔒 Ce n\'est pas votre tour !', 'warn');
        return;
      }
      FFdreameCombatBar._toggleTargetMode();
    });

    bar.querySelector('.end-turn-btn').addEventListener('click', () => {
      FFdreameCombatBar._endTurn();
    });

    bar.querySelectorAll('.tableau-btn').forEach(btn =>
      btn.addEventListener('click', e => FFdreameCombatBar._toggleTableau(e.currentTarget.dataset.tableau))
    );

    bar.querySelectorAll('.reaction-btn').forEach(btn =>
      btn.addEventListener('click', e => FFdreameCombatBar._toggleReaction(e.currentTarget.dataset.reaction))
    );
  }

  /* ─── SWITCH ACTEUR ─── */
  static _switchToActor(actor) {
    FFdreameCombatBar.currentActor = actor;
    FFdreameCombatBar._refreshBar();
  }

  /* ─── REFRESH COMPLET ─── */
  static _refreshBar() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar) { FFdreameCombatBar._createBar(); return; }
    if (!FFdreameCombatBar.currentActor) return;

    const bloque = FFdreameCombatBar._estBloque(FFdreameCombatBar.currentActor);

    FFdreameCombatBar._updatePortrait(bar, bloque);
    FFdreameCombatBar._updateTableaux(bar, bloque);
    FFdreameCombatBar._updateReactions(bar); // ← Les réactions ne sont JAMAIS bloquées
    FFdreameCombatBar._updateTechniques(bloque);
    FFdreameCombatBar._updateButtons(bar, bloque);
  }

  static _updatePortrait(bar, bloque) {
    const actor = FFdreameCombatBar.currentActor;
    bar.querySelector('.portrait-img').src = actor.img || 'icons/svg/mystery-man.svg';
    const nameEl = bar.querySelector('.portrait-name');
    nameEl.textContent = actor.name || '???';
    nameEl.style.color = bloque ? '#ff6b6b' : '';
    bar.querySelector('.combat-bar-portrait').classList.toggle('turn-ended', bloque);
    bar.classList.toggle('turn-blocked', bloque);
  }

  static _updateButtons(bar, bloque) {
    // Fin Tour : disponible seulement si c'est MON tour et pas encore actionBlocked
    const monTour = FFdreameCombatBar._peutAgir(FFdreameCombatBar.currentActor);
    const dejaBloqueFlag = (() => { try { return !!FFdreameCombatBar.currentActor.getFlag('ffdreame', 'actionBlocked'); } catch(e) { return false; } })();
    const combatActif = !!game.combat?.started;

    const finTourDispo = combatActif && monTour && !dejaBloqueFlag;
    const endBtn = bar.querySelector('.end-turn-btn');
    endBtn.disabled = !finTourDispo;
    endBtn.classList.toggle('disabled', !finTourDispo);

    // Cibler + Tableaux : bloqués si pas mon tour
    bar.querySelectorAll('.target-btn, .tableau-btn').forEach(btn => {
      btn.disabled = bloque;
      btn.classList.toggle('disabled', bloque);
    });

    // Portrait
    bar.querySelector('.combat-bar-portrait').style.cursor = bloque ? 'not-allowed' : '';

    // ✅ CLÉS: Réactions JAMAIS bloquées - toujours actives
    bar.querySelectorAll('.reaction-btn').forEach(btn => {
      btn.disabled = false;
      btn.classList.remove('disabled');
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    });
  }

  static _updateTableaux(bar, bloque) {
    const combat = FFdreameCombatBar.currentActor?.system?.combat;
    if (!combat) return;
    const t1 = bar.querySelector('.tableau-btn[data-tableau="1"]');
    const t2 = bar.querySelector('.tableau-btn[data-tableau="2"]');
    if (t1 && combat.tableau1) {
      t1.querySelector('.tableau-name').textContent = combat.tableau1.nom || 'Tableau 1';
      t1.classList.toggle('active', !!combat.tableau1.actif);
    }
    if (t2 && combat.tableau2) {
      t2.querySelector('.tableau-name').textContent = combat.tableau2.nom || 'Tableau 2';
      t2.classList.toggle('active', !!combat.tableau2.actif);
    }
  }

  static _updateReactions(bar) {
    const reactions = FFdreameCombatBar.currentActor?.system?.combat?.reactions;
    bar.querySelectorAll('.reaction-btn').forEach(btn => {
      btn.classList.toggle('active', reactions?.[btn.dataset.reaction] === true);
      btn.disabled = false;
      btn.classList.remove('disabled');
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    });
  }

  static _updateTechniques(bloque) {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar || !FFdreameCombatBar.currentActor) return;
    const container = bar.querySelector('.techniques-container');
    container.innerHTML = '';

    if (bloque === undefined) bloque = FFdreameCombatBar._estBloque(FFdreameCombatBar.currentActor);

    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) { container.innerHTML = '<div class="techniques-empty-hint">Aucune donnée combat</div>'; return; }

    const t1Actif = !!combat.tableau1?.actif;
    const t2Actif = !!combat.tableau2?.actif;
    let hasContent = false;

    const addSlots = (tableau, actif) => {
      for (let i = 1; i <= 8; i++) {
        const itemId = tableau.slots?.[`slot${i}`];
        const item = itemId ? FFdreameCombatBar.currentActor.items.get(itemId) : null;
        if (item || i <= 4) {
          // ✅ CLÉS: Passer le flag "bloque" au createSlot
          container.appendChild(FFdreameCombatBar._createSlot(item, !actif || bloque, bloque));
          hasContent = true;
        }
      }
    };

    if (combat.tableau1) addSlots(combat.tableau1, t1Actif);
    if (combat.tableau1 && combat.tableau2) {
      const sep = document.createElement('div'); sep.className = 'techniques-separator'; container.appendChild(sep);
    }
    if (combat.tableau2) addSlots(combat.tableau2, t2Actif);

    if (!hasContent) container.innerHTML = '<div class="techniques-empty-hint">Aucune technique assignée</div>';

    // ✅ AFFICHER LE BANDEAU "🔒 Tour terminé" SI BLOQUÉ
    if (bloque) {
      const notice = document.createElement('div');
      notice.className = 'techniques-blocked-notice';
      notice.textContent = '🔒 Tour terminé - Esquive/Défense/Marche disponibles';
      container.prepend(notice);
    }
  }

  static _createSlot(item, disabled, bloque) {
    const slot = document.createElement('div');
    slot.classList.add('technique-slot');
    
    // ✅ APPLIQUER LES CLASSES CORRECTEMENT
    if (disabled) slot.classList.add('disabled');
    if (bloque && item) slot.classList.add('turn-ended');
    
    if (!item) { 
      slot.classList.add('empty'); 
      slot.innerHTML = '<div class="slot-empty-icon">·</div>'; 
      return slot; 
    }

    const pm = item.system?.coutPM || 0;
    slot.innerHTML = `
      <img src="${item.img||'icons/svg/mystery-man.svg'}" class="technique-img" onerror="this.src='icons/svg/mystery-man.svg'"/>
      <div class="technique-name">${item.name}</div>
      ${pm > 0 ? `<div class="technique-pm">${pm}PM</div>` : ''}`;
    slot.title = item.name + (bloque ? ' (Tour terminé)' : '');

    // ✅ CLÉS: Ajouter event listener SEULEMENT si pas disabled
    if (!disabled) {
      slot.addEventListener('click', () => FFdreameCombatBar._useTechnique(item));
    } else {
      slot.style.cursor = 'not-allowed';
      slot.style.pointerEvents = 'none';
    }
    
    slot.addEventListener('mouseenter', e => FFdreameCombatBar._showTooltip(item, e.currentTarget));
    slot.addEventListener('mouseleave', () => FFdreameCombatBar._hideTooltip());
    return slot;
  }

  static _showTooltip(item, el) {
    FFdreameCombatBar._hideTooltip();
    const pm = item.system?.coutPM||0, pa = item.system?.coutPA||'', portee = item.system?.portee||0;
    const desc = (item.system?.description||'').replace(/<[^>]+>/g,'');
    const short = desc.length > 100 ? desc.slice(0,97)+'...' : desc;
    const tt = document.createElement('div');
    tt.id = 'technique-tooltip'; tt.className = 'technique-tooltip';
    tt.innerHTML = `<div class="tt-h"><b>${item.name}</b></div>
      <div class="tt-c">${pm?`<span class="tt-pm">✨${pm}PM</span>`:''} ${pa?`<span class="tt-pa">⚡${pa}</span>`:''} ${portee?`<span class="tt-r">📍${portee}m</span>`:''}</div>
      ${short?`<div class="tt-t">${short}</div>`:''}`;
    document.body.appendChild(tt);
    const r = el.getBoundingClientRect(), tr = tt.getBoundingClientRect();
    let top = r.top - tr.height - 8, left = r.left + r.width/2 - tr.width/2;
    if (top < 5) top = r.bottom + 8;
    left = Math.max(5, Math.min(left, window.innerWidth - tr.width - 5));
    tt.style.cssText = `top:${top}px;left:${left}px`;
    requestAnimationFrame(() => tt.classList.add('show'));
  }

  static _hideTooltip() { document.getElementById('technique-tooltip')?.remove(); }

  static async _useTechnique(item) {
    const actor = FFdreameCombatBar.currentActor;
    
    // ✅ VÉRIFICATION: Ne laisser exécuter la technique QUE si c'est le tour du joueur
    if (!FFdreameCombatBar._peutAgir(actor)) {
      window.FFdreameNotifications?.push('🔒 Ce n\'est pas votre tour !', 'warn');
      console.warn('Tentative d\'action bloquée - Ce n\'est pas le tour du joueur');
      return;
    }

    // ✅ VÉRIFICATION: Pas de technique si actionBlocked est posé
    try {
      if (actor.getFlag('ffdreame', 'actionBlocked')) {
        window.FFdreameNotifications?.push('🔒 Tour terminé!', 'warn');
        return;
      }
    } catch(e) {}

    const sheet = FFdreameCombatBar.currentActor?.sheet;
    if (sheet?._useTableTechnique) await sheet._useTableTechnique(item);
    else if (sheet?._useTechnique) await sheet._useTechnique(item);
    else if (item.roll) await item.roll();
  }

  /* ─── CIBLAGE ─── */
  static _toggleTargetMode() {
    FFdreameCombatBar.targetMode = !FFdreameCombatBar.targetMode;
    document.querySelector('.target-btn')?.classList.toggle('active', FFdreameCombatBar.targetMode);
    if (!FFdreameCombatBar.targetMode) { FFdreameCombatBar._cancelTarget(); return; }
    document.body.style.cursor = 'crosshair';
    FFdreameCombatBar._targetHandler = e => { e.stopPropagation(); e.preventDefault(); FFdreameCombatBar._doTarget(); };
    const board = document.getElementById('board') || document;
    board.addEventListener('pointerup', FFdreameCombatBar._targetHandler, { capture:true, once:true });
    FFdreameCombatBar._targetEl = board;
  }

  static _cancelTarget() {
    FFdreameCombatBar.targetMode = false;
    document.body.style.cursor = '';
    document.querySelector('.target-btn')?.classList.remove('active');
    if (FFdreameCombatBar._targetHandler && FFdreameCombatBar._targetEl) {
      FFdreameCombatBar._targetEl.removeEventListener('pointerup', FFdreameCombatBar._targetHandler, { capture:true });
    }
  }

  static _doTarget() {
    FFdreameCombatBar.targetMode = false;
    document.body.style.cursor = '';
    document.querySelector('.target-btn')?.classList.remove('active');
    const token = canvas.tokens?.hover;
    if (!token) { window.FFdreameNotifications?.push('⚠️ Survolez un token avant de cliquer !', 'warn'); return; }
    token.setTarget(true, { user: game.user, releaseOthers: true });
    window.FFdreameNotifications?.push(`🎯 Cible : ${token.name}`, 'info');
  }

  /* ─── FIN DE TOUR ─── */
  static async _endTurn() {
    if (!FFdreameCombatBar.currentActor) return;
    if (!game.combat?.started) { window.FFdreameNotifications?.push('⚠️ Aucun combat en cours !', 'warn'); return; }

    if (!FFdreameCombatBar._peutAgir(FFdreameCombatBar.currentActor)) {
      window.FFdreameNotifications?.push("⚠️ Ce n'est pas votre tour !", 'warn'); return;
    }

    let dejaFini = false;
    try { dejaFini = !!FFdreameCombatBar.currentActor.getFlag('ffdreame', 'actionBlocked'); } catch(e) {}
    if (dejaFini && !game.user.isGM) { window.FFdreameNotifications?.push('🔒 Tour déjà terminé !', 'warn'); return; }

    // ✅ POSITIONNER LE FLAG ACTIONBLOCKED AVANT D'APPELER nextTurn
    await FFdreameCombatBar.currentActor.setFlag('ffdreame', 'actionBlocked', true);
    console.log(`✅ Flag actionBlocked posé pour ${FFdreameCombatBar.currentActor.name}`);
    
    FFdreameCombatBar._refreshBar();
    
    // ✅ PUIS appeler nextTurn qui va déclencher le hook updateCombat
    await game.combat.nextTurn();
  }

  /* ─── TABLEAUX ─── */
  static async _toggleTableau(num) {
    if (!FFdreameCombatBar.currentActor) return;
    if (FFdreameCombatBar._estBloque(FFdreameCombatBar.currentActor)) {
      window.FFdreameNotifications?.push('🔒 Ce n\'est pas votre tour !', 'warn'); return;
    }
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) return;
    if (num === '1' && combat.tableau1?.actif) { window.FFdreameNotifications?.push('⚠️ Tableau 1 déjà actif !', 'warn'); return; }
    if (num === '2' && combat.tableau2?.actif) { window.FFdreameNotifications?.push('⚠️ Tableau 2 déjà actif !', 'warn'); return; }

    if (game.combat?.started) {
      const ap = combat.actionPoints;
      let petit = null;
      for (let g=1;g<=3;g++) for (let p=1;p<=2;p++) { if (ap?.[`grand${g}`]?.[`petit${p}`]) { petit={g,p}; break; } if(petit) break; }
      if (!petit) { window.FFdreameNotifications?.push('⚠️ Pas de Petit PA !', 'warn'); return; }
      await FFdreameCombatBar.currentActor.update({
        [`system.combat.actionPoints.grand${petit.g}.petit${petit.p}`]: false,
        'system.combat.tableau1.actif': num==='1',
        'system.combat.tableau2.actif': num==='2'
      });
    } else {
      await FFdreameCombatBar.currentActor.update({
        'system.combat.tableau1.actif': num==='1',
        'system.combat.tableau2.actif': num==='2'
      });
    }
    FFdreameCombatBar._refreshBar();
  }

  /* ─── RÉACTIONS (TOUJOURS DISPONIBLES) ─── */
  static async _toggleReaction(reaction) {
    if (!FFdreameCombatBar.currentActor) return;
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) return;
    const current = combat.reactions?.[reaction] ?? false;
    if (current) {
      // Désactiver la réaction
      await FFdreameCombatBar.currentActor.update({ [`system.combat.reactions.${reaction}`]: false });
      window.FFdreameNotifications?.push(`❌ ${reaction.charAt(0).toUpperCase() + reaction.slice(1)} désactivée`, 'info');
    } else {
      // Activer la réaction (même si pas son tour!)
      const ap = combat.actionPoints;
      let petit = null;
      for (let g=1;g<=3;g++) for (let p=1;p<=2;p++) { if (ap?.[`grand${g}`]?.[`petit${p}`]) { petit={g,p}; break; } if(petit) break; }
      if (!petit) { window.FFdreameNotifications?.push('⚠️ Pas de Petit PA !', 'warn'); return; }
      await FFdreameCombatBar.currentActor.update({
        [`system.combat.actionPoints.grand${petit.g}.petit${petit.p}`]: false,
        [`system.combat.reactions.${reaction}`]: true
      });
      const labels = {esquive:'Esquive',defense:'Défense',marche:'Marche'};
      const icons  = {esquive:'🤸',defense:'🛡️',marche:'🚶'};
      window.FFdreameNotifications?.push(`✅ ${icons[reaction]} ${labels[reaction]} activée !`, 'info');
    }
    const bar = document.getElementById('ffdreame-combat-bar');
    if (bar) FFdreameCombatBar._updateReactions(bar);
  }

  static forceShow() { FFdreameCombatBar._createBar(); }
}

window.FFdreameCombatBar = FFdreameCombatBar;
