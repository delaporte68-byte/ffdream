# Modifications apportées au système FFdreame

## Date: 1 Février 2026

### 1. ✅ Puissance Magique - Nouvelle formule

**Avant:** Liée à Culture + Magie + Psychologie  
**Maintenant:** Liée à **Perception + Agilité + Magie**

**Fichier modifié:** `module/documents/actor.js`

---

### 2. ✅ Inversion du système de jets de dés

**Système inversé:**
- Les jets **BAS** sont des réussites
- Les jets **HAUTS** sont des échecs
- **1 = Réussite Critique** ✓✓
- **100 = Échec Critique** ✗✗
- **Bonus** se **SOUSTRAIENT** du résultat
- **Malus** s'**AJOUTENT** au résultat

**Exemple:**  
Rang S, seuil ≤ 60. Le joueur fait 63 → Échec  
Bonus 1d6 = 4 → Résultat final: 63 - 4 = 59 → Réussite !

**Fichiers modifiés:** `module/documents/actor.js`

---

### 3. ✅ Multiplicateurs de rang appliqués aux PV et PM

**Avant:** PV et PM n'étaient pas multipliés par le modificateur de rang  
**Maintenant:** PV et PM sont multipliés par le modificateur de rang (×1 à ×2 selon le rang)

**Fichier modifié:** `module/documents/actor.js`

---

### 4. ✅ Bases d'aptitudes éditables (GM uniquement)

**Nouveau:** Le GM peut cliquer sur la base d'une aptitude pour la modifier  
**Visuel:** La base apparaît en surbrillance au survol pour le GM

**Fichiers modifiés:**
- `templates/actor/character-sheet.html`
- `module/sheets/actor-sheet.js`
- `css/ffdreame.css`

---

### 5. ✅ Nouveau système de bonus de dés

**Avant:**
- 5 points = +1d6
- 10 points = +2d6

**Maintenant:**
- **5 points = 1d6** (bonus soustrait du jet)
- **10 points = 1d12** (remplace le 1d6, bonus soustrait du jet)

**Fichier modifié:** `module/documents/actor.js`

---

### 6. ⚠️ Techniques et Postures (À IMPLÉMENTER)

**Fonctionnalité demandée:**
- Drag & drop des techniques vers les postures
- Onglet "Attaque" dans chaque posture avec dégâts liés à Attaque ou Puissance Magique

**Status:** Nécessite plus de travail sur le système de drag & drop

---

### 7. ⚠️ Système de points d'action (À CORRIGER)

**Problème actuel:** Les petits points d'action ne fonctionnent pas en hiérarchie correcte

**Comportement souhaité:**
- Utiliser un **Grand** point → consomme ses 2 **Petits**
- Utiliser un **Petit** point → le 2ème Petit reste disponible
- **Attaque** → consomme 1 Petit
- **Technique** → consomme PM + 1 Grand

**Status:** Nécessite refonte de la logique des points d'action

---

### 8. ✅ Techniques de type BUFF

**Nouveau style ajouté:** 🛡️ BUFF - Technique de Soutien

**Types de Buff:**
- 🛡️ Réduction de dégâts (X%)
- 💚 Soins (X% des PV max)
- ⬆️ Bonus de jet (réduit le résultat de X points)

**Valeur:** Définie en % par le GM uniquement

**Fichiers modifiés:**
- `templates/item/technique-sheet.html`
- `template.json`
- `module/sheets/item-sheet.js`

---

### 9. ✅ Malus de fatigue et blessures

#### Fatigue (9 cases - icône fatigue)

| Case | Effet |
|------|-------|
| f1 | Rien |
| f2 | Échec critique +5% (passe de 95% à 90%) |
| f3 | Réussite critique -5% (impossible si coché) |
| f4 | **-15% PV max** |
| f5 | **+5% au jet** (malus) |
| f6 | **-25% Attaque et Puissance Magique** |
| f7 | **-20% PM max** |
| f8 | Perte de 1 Grand point d'action |
| f9 | Inconscience (RP) |

#### Blessures (9 cases - icône cœur)

| Case | Effet |
|------|-------|
| b1 | **+5% au jet** (malus) |
| b2 | Échec critique +5% (cumule avec fatigue) |
| b3 | **+5% au jet** (cumule avec b1) |
| b4 | **-15% Attaque et Puissance Magique** |
| b5 | **+5% au jet** |
| b6 | **-30% Attaque et Puissance Magique** |
| b7 | Perte de 10% PV par tour |
| b8 | Perte de 20% PV par tour + **-20% Attaque et PM** |
| b9 | Mort (RP) |

**Fichiers modifiés:** `module/documents/actor.js`

**Note:** Les effets de réussite/échec critique (f2, f3, b2) et pertes de PV par tour (b7, b8) devront être implémentés dans la logique de jet et de combat.

---

## Fichiers modifiés

- ✅ `module/documents/actor.js`
- ✅ `module/sheets/actor-sheet.js`
- ✅ `module/sheets/item-sheet.js`
- ✅ `templates/actor/character-sheet.html`
- ✅ `templates/item/technique-sheet.html`
- ✅ `template.json`
- ✅ `css/ffdreame.css`

---

## Fonctionnalités à implémenter ultérieurement

1. ⚠️ Drag & drop des techniques vers les postures
2. ⚠️ Onglet "Attaque" dans les postures
3. ⚠️ Refonte complète du système de points d'action
4. ⚠️ Gestion automatique de la perte de PV par tour (b7, b8)
5. ⚠️ Modification des seuils de réussite/échec critique (f2, f3, b2)
6. ⚠️ Blocage du 8ème grand point d'action quand f8 est activé

---

## Notes importantes

- Le système de jets inversés est **pleinement fonctionnel**
- Les malus de fatigue et blessures sont **calculés automatiquement**
- Les bases d'aptitudes sont **éditables par le GM** via un dialogue
- Le style BUFF est **disponible** pour les techniques de soutien
