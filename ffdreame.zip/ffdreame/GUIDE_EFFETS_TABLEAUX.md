# 🎯 SYSTÈME D'EFFETS DES TABLEAUX - FFdreame

## 📖 Vue d'ensemble

Chaque tableau de combat peut avoir un **effet passif** qui se déclenche selon certaines conditions.

### Types d'effets disponibles

#### 1. Effets basés sur les réussites

Ces effets se déclenchent après un certain nombre de techniques réussies.

**a) Bonus de dégâts après X réussites**
```javascript
Type : "bonus_degats_apres_reussites"
Seuil : 5 (techniques réussies)
Bonus : 50 (dégâts supplémentaires)
Description : "Après 5 techniques réussies, +50 dégâts à la prochaine attaque"
```

**b) Récupération PM après X réussites**
```javascript
Type : "bonus_pm_apres_reussites"
Seuil : 3
Bonus : 30
Description : "Après 3 techniques réussies, récupère 30 PM"
```

**c) Parade après X réussites**
```javascript
Type : "parade_apres_reussites"
Seuil : 4
Bonus : 0 (non utilisé)
Description : "Après 4 techniques réussies, jet de parade contre la prochaine attaque ennemie"
```

#### 2. Effets permanents (tableau actif)

Ces effets sont actifs tant que le tableau est sélectionné.

**a) Initiative automatique**
```javascript
Type : "initiative_automatique"
Seuil : 0 (non utilisé)
Bonus : 0 (non utilisé)
Description : "Prend automatiquement l'initiative en début de combat"
```

**b) Bonus de dégâts permanent**
```javascript
Type : "bonus_degats_permanent"
Bonus : 20
Description : "+20 dégâts à toutes les attaques"
```

**c) Bonus PM permanent**
```javascript
Type : "bonus_pm_permanent"
Bonus : 50
Description : "+50 PM max"
```

**d) Bonus Burste par technique**
```javascript
Type : "bonus_burste_technique"
Bonus : 15
Description : "+15 Burste par technique réussie (au lieu de +10)"
```

---

## ⚙️ Configuration

### Via la console F12

Pour configurer un effet sur un tableau :

```javascript
// Récupérer l'acteur
const actor = game.actors.getName("Nom du personnage");

// Configurer le Tableau 1
await actor.update({
  'system.combat.tableau1.effet': {
    type: "bonus_degats_apres_reussites",
    seuil: 5,
    compteur: 0,
    bonus: 50,
    description: "Après 5 techniques réussies, +50 dégâts"
  }
});

// Configurer le Tableau 2
await actor.update({
  'system.combat.tableau2.effet': {
    type: "initiative_automatique",
    seuil: 0,
    compteur: 0,
    bonus: 0,
    description: "Prend l'initiative en début de combat"
  }
});
```

### Macro pour configuration rapide

```javascript
// MACRO : Configurer effet de tableau
const actor = game.user.character;

const types = {
  "1": { type: "bonus_degats_apres_reussites", seuil: 5, bonus: 50 },
  "2": { type: "bonus_pm_apres_reussites", seuil: 3, bonus: 30 },
  "3": { type: "parade_apres_reussites", seuil: 4, bonus: 0 },
  "4": { type: "initiative_automatique", seuil: 0, bonus: 0 },
  "5": { type: "bonus_degats_permanent", seuil: 0, bonus: 20 },
  "6": { type: "bonus_pm_permanent", seuil: 0, bonus: 50 },
  "7": { type: "bonus_burste_technique", seuil: 0, bonus: 15 }
};

let content = `
  <form>
    <div class="form-group">
      <label>Tableau</label>
      <select name="tableau">
        <option value="1">Tableau 1</option>
        <option value="2">Tableau 2</option>
      </select>
    </div>
    <div class="form-group">
      <label>Type d'effet</label>
      <select name="type">
        <option value="1">Bonus dégâts après réussites</option>
        <option value="2">Récupération PM après réussites</option>
        <option value="3">Parade après réussites</option>
        <option value="4">Initiative automatique</option>
        <option value="5">Bonus dégâts permanent</option>
        <option value="6">Bonus PM permanent</option>
        <option value="7">Bonus Burste par technique</option>
      </select>
    </div>
    <div class="form-group">
      <label>Seuil (réussites nécessaires)</label>
      <input type="number" name="seuil" value="5"/>
    </div>
    <div class="form-group">
      <label>Bonus</label>
      <input type="number" name="bonus" value="50"/>
    </div>
  </form>
`;

new Dialog({
  title: "Configurer effet de tableau",
  content: content,
  buttons: {
    ok: {
      label: "Appliquer",
      callback: async (html) => {
        const tableau = html.find('[name="tableau"]').val();
        const typeKey = html.find('[name="type"]').val();
        const seuil = parseInt(html.find('[name="seuil"]').val()) || 0;
        const bonus = parseInt(html.find('[name="bonus"]').val()) || 0;
        
        const config = types[typeKey];
        
        await actor.update({
          [`system.combat.tableau${tableau}.effet`]: {
            type: config.type,
            seuil: seuil,
            compteur: 0,
            bonus: bonus,
            description: ""
          }
        });
        
        ui.notifications.info(`✅ Effet configuré sur le tableau ${tableau}`);
      }
    },
    cancel: {
      label: "Annuler"
    }
  },
  default: "ok"
}).render(true);
```

---

## 🎮 Exemples de configuration

### Build Agressif - Tableau 1

**Nom** : "Assaut"  
**Effet** : Bonus de dégâts après 5 réussites  
**Bonus** : +50 dégâts

```javascript
await actor.update({
  'system.combat.tableau1.nom': "Assaut",
  'system.combat.tableau1.effet': {
    type: "bonus_degats_apres_reussites",
    seuil: 5,
    compteur: 0,
    bonus: 50,
    description: "5 attaques réussies = +50 dégâts"
  }
});
```

**Gameplay** :
1. Utilise 5 techniques du tableau
2. Chaque réussite incrémente le compteur (1/5, 2/5, etc.)
3. À 5/5 → Bonus activé : +50 dégâts à la prochaine
4. Compteur reset à 0

---

### Build Défensif - Tableau 2

**Nom** : "Parade"  
**Effet** : Parade après 4 réussites

```javascript
await actor.update({
  'system.combat.tableau2.nom': "Parade",
  'system.combat.tableau2.effet': {
    type: "parade_apres_reussites",
    seuil: 4,
    compteur: 0,
    bonus: 0,
    description: "4 techniques réussies = parade active"
  }
});
```

**Gameplay** :
1. Utilise 4 techniques du tableau
2. À 4/4 → Parade activée
3. Prochaine attaque ennemie → Jet de parade automatique
4. Si parade réussie → Attaque bloquée !

---

### Build Leader - Tableau 1

**Nom** : "Initiative"  
**Effet** : Initiative automatique (permanent)

```javascript
await actor.update({
  'system.combat.tableau1.nom': "Initiative",
  'system.combat.tableau1.effet': {
    type: "initiative_automatique",
    seuil: 0,
    compteur: 0,
    bonus: 0,
    description: "Débute toujours en premier"
  }
});
```

**Gameplay** :
- En début de combat, ce personnage agit en premier
- Pas de jet d'initiative nécessaire
- Actif tant que le tableau 1 est sélectionné

---

### Build Soutien - Tableau 2

**Nom** : "Régénération"  
**Effet** : Récupération PM après 3 réussites

```javascript
await actor.update({
  'system.combat.tableau2.nom': "Régénération",
  'system.combat.tableau2.effet': {
    type: "bonus_pm_apres_reussites",
    seuil: 3,
    compteur: 0,
    bonus: 30,
    description: "3 soins = +30 PM"
  }
});
```

**Gameplay** :
1. Utilise 3 techniques de soin
2. À 3/3 → Récupère 30 PM immédiatement
3. Compteur reset, peut recommencer

---

## 🔧 Intégration dans le code

### Incrémenter le compteur

Le compteur s'incrémente automatiquement après chaque technique réussie depuis le tableau.

Code dans `actor-sheet.js` :
```javascript
if (success) {
  await FFdreameTableauEffets.incrementerCompteur(this.actor, numeroTableau);
}
```

### Vérifier les bonus permanents

Pour appliquer les bonus permanents dans les calculs de dégâts :

```javascript
const bonusDegats = FFdreameTableauEffets.getBonusPermanent(this.actor, "degats");
const degatsFinaux = degatsBase + bonusDegats;
```

### Initiative automatique

En début de combat :

```javascript
const aInitiative = await FFdreameTableauEffets.verifierInitiativeAutomatique(this.actor);
if (aInitiative) {
  // Ce personnage commence
}
```

---

## 📊 Liste complète des types

| Type | Déclenchement | Application | Seuil | Bonus |
|------|---------------|-------------|-------|-------|
| `bonus_degats_apres_reussites` | Après X réussites | Prochaine attaque | Nb réussites | Dégâts |
| `bonus_pm_apres_reussites` | Après X réussites | Immédiat | Nb réussites | PM |
| `parade_apres_reussites` | Après X réussites | Prochaine attaque ennemie | Nb réussites | - |
| `initiative_automatique` | Début combat | Permanent | - | - |
| `bonus_degats_permanent` | Permanent | Toutes attaques | - | Dégâts |
| `bonus_pm_permanent` | Permanent | PM max | - | PM |
| `bonus_burste_technique` | Permanent | Par technique | - | Burste |

---

## 🎯 Cas d'usage avancés

### Double tableau avec effets

```javascript
// Tableau 1 : Assaut (+50 dégâts après 5 réussites)
await actor.update({
  'system.combat.tableau1.effet': {
    type: "bonus_degats_apres_reussites",
    seuil: 5,
    bonus: 50
  }
});

// Tableau 2 : Soutien (+30 PM après 3 réussites)
await actor.update({
  'system.combat.tableau2.effet': {
    type: "bonus_pm_apres_reussites",
    seuil: 3,
    bonus: 30
  }
});
```

**Stratégie** :
- Phase 1 : Tableau 1 actif → Accumule 5 réussites
- Phase 2 : Switch tableau 2 → Récupère PM
- Phase 3 : Retour tableau 1 avec bonus dégâts prêt
- Phase 4 : Utilise ultimate

---

## ⚠️ Limitations actuelles

1. **Interface utilisateur** : Pas encore de UI dans la fiche personnage (utiliser console F12 ou macro)
2. **Un seul effet par tableau** : Chaque tableau ne peut avoir qu'un effet à la fois
3. **Compteur partagé** : Le compteur ne distingue pas les types de techniques (toutes comptent)
4. **Parade unique** : La parade se consomme sur la prochaine attaque (réussie ou ratée)

---

## 🔮 Évolutions futures

- [ ] Interface graphique dans la fiche personnage
- [ ] Effets multiples par tableau
- [ ] Conditions d'activation plus complexes (type de technique, cible, etc.)
- [ ] Effets de synchro entre tableaux
- [ ] Historique des activations
- [ ] Effets visuels lors du déclenchement

---

**Version** : 1.0  
**Date** : Février 2026  
**Compatibilité** : FFdreame v8.0+
