# ✅ STYLE CHM - UPGRADE COMPLET

## 🎯 MODIFICATIONS APPLIQUÉES :

### 1. **Template.json**
✅ Ajout `animation.duree` dans chaque slot CHM (slot1 à slot5)

### 2. **HTML technique-sheet-v2.html**
✅ Onglet CHM complètement refait avec pour CHAQUE slot :

**Champs disponibles :**
- ⚔️ **Style** : CAC, MAG, PUI, MULTI, CUR
- 💥 **Dégâts de base**
- 📏 **Portée** (mètres)
- 🎬 **Animation JB2A** (input texte)
- ⏱️ **Durée animation** (1s, 2s, 3s, 5s, 8s)
- ✨ **Effet 1** (Type, Valeur, Durée)
- ✨ **Effet 2** (même chose)
- 📝 **Description**

---

## 🆕 NOUVEAUX EFFETS DISPONIBLES :

| Effet | Code | Description |
|-------|------|-------------|
| **Absorbe PM** | `absorbe_pm` | Vole X PM à la cible |
| **Malus Jet** | `malus_jet` | -X% au prochain jet de la cible |
| **DoT** | `dot` | X dégâts par tour pendant Y tours |
| **Ralentissement** | `ralentissement` | Réduit les PA de la cible |

### Effets déjà existants :
- `soins` : Restaure PV
- `ponction` : Vole PV

---

## ⚠️ CODE JS NON IMPLÉMENTÉ

Les **NOUVEAUX EFFETS** ne sont PAS encore codés dans actor-sheet.js !

Il faut ajouter dans `_appliquerEffet()` :

```javascript
case "absorbe_pm":
  // Absorber PM de la cible
  
case "malus_jet":
  // Stocker malus dans flag
  
case "dot":
  // Appliquer dégâts sur X tours
  
case "ralentissement":
  // Réduire PA
```

---

## 🧪 TEST :

### Créer une technique CHM :
```
1. Style principal : CHM
2. Onglet CHM
3. Slot 1 :
   - Nom : "Frappe de Feu"
   - Style : CAC
   - Dégâts : 30
   - Animation : jb2a.fire_bolt.orange
   - Durée : 3s
   - Effet 1 : DoT, Valeur 10, Durée 3 tours
4. Slot 2 :
   - Nom : "Drain"
   - Style : MAG
   - Dégâts : 20
   - Effet 1 : Absorbe PM, Valeur 15
```

---

## 📊 RÉCAPITULATIF :

| Feature | Status |
|---------|--------|
| Template.json | ✅ FAIT |
| HTML Onglet CHM | ✅ FAIT |
| Code JS nouveaux effets | ❌ PAS FAIT |
| Animation par slot | ✅ PRÊT (si code existe) |
| Style MULTI dans CHM | ✅ DISPONIBLE |

---

**Les champs sont là, mais il faut coder les nouveaux effets !**

Voulez-vous que je code les effets manquants ? 🔧
