# 🔧 CORRECTION DU STYLE MULTI - Techniques de Zone

## 📋 Problème identifié

Le style **MULTI** demandait au joueur de **cliquer sur la carte** pour placer la zone d'effet, ce qui différait du comportement des autres styles de techniques.

## ✅ Solution appliquée

Le système a été modifié pour fonctionner comme **tous les autres styles** :

### Workflow corrigé

1. **Cibler un token** (bouton droit → Cibler ou clic sur le token)
2. **Cliquer sur la technique** dans le tableau
3. **Vérification automatique** de la distance
4. **Jet de dés** pour la réussite
5. **Application des dégâts** si réussite

---

## 🎯 TYPE CERCLE - Attaque en zone circulaire

### Comportement
- **Cible** : Un token précis
- **Zone d'effet** : Tous les tokens dans un rayon autour de la cible
- **Distance max** : Définie dans l'onglet "Impact" de la technique
- **Rayon** : Défini par "Largeur" ÷ 2 dans l'onglet "Impact"

### Exemple
```
Configuration technique :
- Type : cercle
- Distance max : 5m
- Largeur : 2m → Rayon effectif = 1m

Utilisation :
1. Je cible un ennemi à 4m
2. Je lance ma technique
3. Distance OK (4m ≤ 5m)
4. Jet de dés → Réussite
5. L'ennemi ciblé + tous les ennemis dans 1m autour de lui prennent les dégâts
6. Burste +10 par cible touchée
7. Consommation des PA (selon config)
```

---

## ⚡ TYPE LIGNE - Attaque en rayon (lance-flammes)

### Comportement
- **Cible** : Un token précis
- **Zone d'effet** : Tous les tokens entre le lanceur et la cible, dans la largeur définie
- **Distance max** : Définie dans l'onglet "Impact"
- **Largeur** : Définie dans l'onglet "Impact"

### Exemple
```
Configuration technique :
- Type : ligne
- Distance max : 3m
- Largeur : 1m

Utilisation :
1. Je cible un ennemi à 2.5m
2. Je lance ma technique
3. Distance OK (2.5m ≤ 3m)
4. Jet de dés → Réussite
5. Tous les tokens sur le chemin entre moi et la cible, dans 1m de largeur, prennent les dégâts
6. Burste +10 par cible touchée
7. Consommation des PA (selon config)
```

---

## 🔄 Différences entre les deux types

| Aspect | Type CERCLE | Type LIGNE |
|--------|-------------|------------|
| **Cible visée** | Reçoit les dégâts | Reçoit les dégâts |
| **Zone touchée** | Autour de la cible | Entre le lanceur et la cible |
| **Forme** | Cercle centré sur la cible | Rayon/cône depuis le lanceur |
| **Utilité** | Explosion, onde de choc | Lance-flammes, rayon laser |

---

## 📊 Système de dégâts multiples

Les dégâts sont **dégressifs** selon l'ordre des cibles touchées :

- **1ère cible** : 100% des dégâts
- **2ème cible** : 80% des dégâts (-20%)
- **3ème cible** : 60% des dégâts (-40%)
- **4ème cible** : 40% des dégâts (-60%)
- etc.

---

## ⚡ Gain de Burste

- **+10 Burste par cible touchée**
- Si vous touchez 3 ennemis → +30 Burste
- Maximum : 100 Burste (débloque l'Ultimate)

---

## 🎬 Animations et effets visuels

- **Template visuel** apparaît temporairement sur la carte
- **Animation JB2A** si le module est activé et configuré
- **Messages dans le chat** avec détail des dégâts par cible

---

## 📝 Configuration des techniques MULTI

Dans la fiche de technique, onglet **Impact** :

```
Type : [cercle] ou [ligne]
Distance max : X mètres (portée maximale)
Largeur : Y mètres
  - Pour cercle : diamètre → rayon = Y/2
  - Pour ligne : largeur du rayon
```

---

## ⚙️ Fichiers modifiés

- **`module/combat/multi-zone.js`** :
  - Méthode `_placeZoneRonde()` : Utilise les tokens ciblés au lieu d'un clic
  - Méthode `_placeLigneDroite()` : Suppression du message "Cliquez sur une cible"
  - Messages du chat améliorés avec nom de la cible et détails de la zone

---

## 🚀 Utilisation en jeu

1. **Créer la technique** avec le style "multi"
2. **Configurer** l'onglet Impact (type, distance, largeur)
3. **Ajouter** la technique dans un tableau de combat
4. **En combat** :
   - Cibler un ennemi (clic droit → Cibler)
   - Cliquer sur la technique dans le tableau
   - Le système fait le reste automatiquement !

---

## ✨ Avantages de la correction

- ✅ **Cohérence** : Même workflow que les autres styles
- ✅ **Simplicité** : Plus besoin de cliquer deux fois
- ✅ **Rapidité** : Utilisation plus fluide en combat
- ✅ **Clarté** : Messages détaillés dans le chat

---

**Date de correction** : Février 2026  
**Version** : FFdreame v8.0+
