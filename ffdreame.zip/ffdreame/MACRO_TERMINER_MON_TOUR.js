// ========================================
// MACRO JOUEUR : TERMINER MON TOUR
// ========================================
// Cette macro bloque les tableaux de techniques
// jusqu'au prochain tour du joueur

// Vérifier qu'un token est sélectionné
if (!canvas.tokens.controlled.length) {
  ui.notifications.warn("⚠️ Sélectionnez votre token !");
  return;
}

const token = canvas.tokens.controlled[0];
const actor = token.actor;

if (!actor) {
  ui.notifications.error("❌ Token invalide !");
  return;
}

// Vérifier que c'est un personnage joueur
if (actor.type !== "character" && actor.type !== "cyberpunk") {
  ui.notifications.warn("⚠️ Cette macro est réservée aux personnages joueurs !");
  return;
}

// Demander confirmation
const confirmation = await Dialog.confirm({
  title: "Terminer mon Tour",
  content: `
    <div style="text-align: center; padding: 20px;">
      <h2>${actor.name}</h2>
      <p>Voulez-vous terminer votre tour ?</p>
      <p style="color: #ff9900; font-size: 12px;">
        ⚠️ Vous ne pourrez plus utiliser vos tableaux de techniques<br/>
        jusqu'à votre prochain tour.
      </p>
      <p style="color: #00d9ff; font-size: 12px;">
        ✅ Vous pourrez toujours utiliser Esquive, Défense et Marche.
      </p>
    </div>
  `,
  yes: () => true,
  no: () => false,
  defaultYes: false
});

if (!confirmation) {
  ui.notifications.info("❌ Annulé");
  return;
}

// Bloquer les actions
await actor.setFlag('ffdreame', 'actionBlocked', true);

// Message dans le chat
ChatMessage.create({
  speaker: ChatMessage.getSpeaker({ actor }),
  content: `
    <div style="
      background: rgba(255, 153, 0, 0.2);
      padding: 15px;
      border-left: 4px solid #ff9900;
      border-radius: 4px;
      text-align: center;
    ">
      <h3 style="margin-top: 0;">🔒 Tour Terminé</h3>
      <p><strong>${actor.name}</strong> a terminé son tour.</p>
      <p style="font-size: 12px; color: #999;">
        Les tableaux de techniques sont bloqués jusqu'au prochain tour.
      </p>
    </div>
  `
});

ui.notifications.info(`🔒 ${actor.name} a terminé son tour !`);

// Si on est en combat, passer au combattant suivant
const combat = game.combat;
if (combat && combat.combatant && combat.combatant.actor.id === actor.id) {
  // C'est bien le tour du joueur actuel, on passe au suivant
  await combat.nextTurn();
}
