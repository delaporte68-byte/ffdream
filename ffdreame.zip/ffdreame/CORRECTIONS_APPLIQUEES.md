# ✅ CORRECTIONS APPLIQUÉES

## 3 CORRECTIONS PRINCIPALES :

### 1. ✅ Combat Tracker - Tokens 60px max
Fichier: module/combat/combat-system.js (CSS injecté)

### 2. ✅ Scroll technique - 700px max
Fichier: css/ffdreame.css (fin du fichier)

### 3. ✅ Durée animation utilisée
Fichier: module/sheets/actor-sheet.js (fonction _jouerAnimationItem)

## TESTS :
- Combat : Tokens compacts + boutons visibles
- Technique : Scrollbar si > 700px
- Animation : Respecte durée configurée
- Téléportation : Code OK (si ne marche pas = config)
