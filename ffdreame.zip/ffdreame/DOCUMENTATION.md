# Système d'Objets/Techniques pour Foundry VTT - Documentation Complète

## 🎯 Vue d'Ensemble

Ce système permet de créer des objets/techniques avancés pour Foundry VTT avec :
- **4 styles de calcul** différents (CAC, MAG, PUI, AOE)
- **Effets conditionnels** basés sur les jets de dés
- **2 effets par objet** avec 7 types différents
- **Animations intégrées** (Sequencer et JB2A)
- **Gestion automatique** des ressources (magie, actions)
- **Affichage dans le chat** avec style personnalisé

---

## 📦 Contenu du Package

### Fichiers Principaux

1. **item-objet-sheet.html** (Template)
   - Interface utilisateur à 4 onglets
   - Formulaires pour tous les paramètres
   - Helpers Handlebars intégrés

2. **objet-item-sheet.js** (Logique)
   - Classe ItemSheet personnalisée
   - Calculs automatiques des dégâts
   - Gestion des effets conditionnels
   - Intégration animations
   - Messages dans le chat

3. **objet-item-data.js** (Données)
   - Modèle de données DataModel
   - Validation des champs
   - Valeurs par défaut

4. **objet-item-sheet.css** (Styles)
   - Design moderne et responsive
   - Style pour messages de chat
   - Couleurs et animations

5. **init-objet-system.js** (Initialisation)
   - Enregistrement du système
   - Configuration globale
   - Helpers Handlebars
   - Macro globale

6. **template.json** (Structure)
   - Définition du type "objet"
   - Tous les champs de données

7. **README.md** (Guide)
   - Guide d'installation complet
   - Documentation des fonctionnalités
   - Exemples détaillés
   - Dépannage

8. **exemples-objets.json** (Exemples)
   - 7 objets prêts à l'emploi
   - Couvrant tous les cas d'usage
   - À importer directement

---

## ⚡ Fonctionnalités Principales

### 1. Système de Calcul des Dégâts

#### **CAC - Corps à Corps**
```
Dégâts = Base + Attaque + Aptitude + (Puissance Magique ÷ 2)
```
Idéal pour : Épées, haches, armes de mêlée

#### **MAG - Magique**
```
Dégâts = Base + Attaque + Puissance Magique + (Attaque ÷ 2)
```
Idéal pour : Sorts, magie offensive

#### **PUI - Puissance**
```
Dégâts = Base + Attaque + Attaque + Puissance Magique
```
Idéal pour : Coups puissants, techniques spéciales

#### **AOE - Zone d'Effet**
```
Dégâts = Base + (Attaque ÷ 2) + (Puissance Magique ÷ 2)
Réduction progressive : 100%, 80%, 70%, 60%...
```
Idéal pour : Explosions, sorts de zone

---

### 2. Effets Conditionnels

Chaque objet peut avoir **2 effets** qui s'activent selon le **résultat du jet de dés (1d100)**.

#### Types d'Effets Disponibles :

| Code | Nom | Description |
|------|-----|-------------|
| **soins** | Soins | Restaure X% des PV perdus |
| **bufa** | Buff Attaque | Augmente l'aptitude d'attaque de X% |
| **bufj** | Buff Jet | Réduit le prochain jet de l'ennemi de X% |
| **bufd** | Buff Défense | Réduit les dégâts reçus de X% |
| **soinsg** | Soins de Groupe | Augmente les PV de tous les alliés de X% |
| **ponction** | Ponction Vie | Absorbe X% des PV de la cible |
| **ponctionm** | Ponction Magie | Absorbe X% des PM de la cible |

#### Système de Conditions

```
Si Jet ≤ Condition → Effet activé
Si Jet > Condition → Effet ignoré
```

**Exemple :**
- Effet 1 : Soins 30% si jet ≤ 100 (toujours)
- Effet 2 : Soins Groupe 15% si jet ≤ 20 (rare)

---

### 3. Gestion des Ressources

#### Points de Magie
- Consommation automatique lors de l'utilisation
- Vérification avant activation
- Message d'erreur si insuffisant

#### Points d'Action
- **Grand Point d'Action** : Coûte 1 grande action
- **Petit Point d'Action** : Coûte 1 petite action
- Système à implémenter selon vos règles

---

### 4. Animations Intégrées

#### **Sequencer**
- Chemin personnalisé vers vos animations
- Déclenchement automatique

#### **JB2A Free**
Animations prédéfinies :
- Boule de Feu
- Projectile Magique
- Soin
- Bouclier
- Coup d'Épée
- Et plus...

---

## 🎨 Interface Utilisateur

### Onglets de la Fiche

#### 1️⃣ Description
- Éditeur de texte riche
- Description narrative de l'objet
- Visible dans la fiche

#### 2️⃣ Propriétés
- **Coût en Magie** (nombre)
- **Points d'Action** (cases à cocher)
- **Dégâts de Base** (nombre)
- **Style de Calcul** (menu déroulant)
- **Explication du style** (dynamique)

#### 3️⃣ Effets
Pour Effet 1 et Effet 2 :
- **Type** (menu déroulant - 7 choix)
- **Valeur** (% ou nombre)
- **Condition** (seuil d'activation 0-100)

#### 4️⃣ Animation
- **Sequencer** (chemin texte)
- **JB2A** (menu déroulant)

---

## 🔧 Installation Rapide

### Étapes d'Installation

1. **Copier les fichiers** dans votre système Foundry
2. **Modifier les chemins** dans les fichiers JS
3. **Importer le CSS** dans system.json
4. **Ajouter l'import** dans votre main.js
5. **Redémarrer** Foundry

### Structure Minimale Requise

```
votre-systeme/
├── templates/item/item-objet-sheet.html
├── sheets/objet-item-sheet.js
├── data/objet-item-data.js
├── styles/objet-item-sheet.css
├── scripts/init-objet-system.js
└── template.json (modifié)
```

---

## 💡 Utilisation Pratique

### Créer un Objet

1. Items → Créer → Type "Objet"
2. Remplir les 4 onglets
3. Sauvegarder

### Utiliser un Objet

#### Depuis la Fiche
Clic sur le bouton ✨ dans l'inventaire

#### Via Macro
```javascript
utiliserObjet("Nom de l'Objet");
```

### Résultat dans le Chat

Le système affiche automatiquement :
- Nom de l'objet
- Utilisateur
- Style utilisé
- Dégâts calculés
- Résultat du jet
- Effets activés

Avec un style visuel attrayant (dégradé violet).

---

## 📊 Exemples Concrets

### 🗡️ Épée Flamboyante (CAC)
- 10 dégâts base
- +20% attaque si jet ≤ 70
- Animation d'épée
- Coût : 5 PM

### 🔥 Boule de Feu (MAG)
- 25 dégâts base
- -15% jet ennemi si ≤ 50
- Drain 10% PV si ≤ 30
- Coût : 15 PM

### 💊 Potion de Soin (Support)
- 0 dégâts
- Soins 30% (toujours)
- Soins groupe 10% si ≤ 20
- Coût : 0 PM

### 💥 Explosion Arcanique (AOE)
- 20 dégâts base (réduits par cible)
- -10% jet ennemi si ≤ 70
- Drain 15% PM si ≤ 40
- Coût : 20 PM

---

## 🎯 Cas d'Usage

### Combat Physique
Style **CAC** + Effet **BufA** + Animation mêlée

### Magie Offensive
Style **MAG** + Effets **BufJ** + **Ponction** + Animation magique

### Soutien de Groupe
Style **MAG** + Effets **Soins** + **SoinsG** + Animation lumineuse

### Contrôle de Zone
Style **AOE** + Effets **BufJ** + **BufD** + Animation d'explosion

### Drain Vampirique
Style **MAG** + Effets **Ponction** + **PonctionM** + Animation sombre

---

## ⚙️ Personnalisation

### Ajouter un Nouvel Effet

1. **template.json** : Ajouter dans les choices
2. **objet-item-data.js** : Ajouter dans StringField.choices
3. **item-objet-sheet.html** : Ajouter dans <select>
4. **objet-item-sheet.js** : Implémenter la logique

### Modifier les Calculs

Dans `_calculerDegats()` de **objet-item-sheet.js**, adaptez les formules selon vos besoins.

### Changer les Animations

Ajoutez vos chemins Sequencer ou sélectionnez d'autres animations JB2A.

---

## 🐛 Dépannage Fréquent

### "Template not found"
→ Vérifiez le chemin dans `defaultOptions()` de objet-item-sheet.js

### "Cannot read property 'valeur'"
→ Vérifiez que votre acteur a les attributs requis (attaque, magie, etc.)

### Animations non visibles
→ Vérifiez que Sequencer et JB2A sont installés et activés

### Effets non activés
→ Vérifiez les conditions (seuil) et le résultat du jet dans le chat

---

## 📈 Évolutions Futures

- [ ] Multi-cibles pour AOE
- [ ] Durée des buffs
- [ ] Effets visuels sur tokens
- [ ] Sons personnalisés
- [ ] Templates de zone
- [ ] Résistances élémentaires
- [ ] Combo d'objets
- [ ] Cooldowns

---

## 🙏 Crédits

- **Sequencer** : Pour le système d'animation
- **JB2A** : Pour les animations gratuites
- **Foundry VTT** : Pour la plateforme

---

## 📞 Support

Consultez le **README.md** pour :
- Guide détaillé
- Exemples étendus
- Solutions aux problèmes courants
- Instructions d'installation complètes

---

**Système créé pour Foundry VTT v11+**
**Version 1.0 - Février 2026**

🎲 **Bon jeu !** ✨
