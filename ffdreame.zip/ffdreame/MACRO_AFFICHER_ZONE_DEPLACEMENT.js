/**
 * ============================================
 * MACRO : AFFICHER ZONE DE DÉPLACEMENT
 * ============================================
 * Affiche un cercle autour du token sélectionné
 * montrant sa portée de déplacement maximale
 */

// Vérifier que le système est chargé
if (!window.FFdreameMovementBlocker) {
  ui.notifications.error("❌ Le système FFdreame n'est pas chargé !");
  return;
}

// Récupérer le token sélectionné
const token = canvas.tokens.controlled[0];

if (!token) {
  ui.notifications.warn("⚠️ Veuillez sélectionner un token d'abord !");
  return;
}

const actor = token.actor;
if (!actor) {
  ui.notifications.error("❌ Ce token n'a pas d'acteur associé !");
  return;
}

// Vérifier que c'est un PJ
if (actor.type !== "character" && actor.type !== "cyberpunk") {
  ui.notifications.info("ℹ️ Ce type de personnage n'a pas de limite de déplacement.");
  return;
}

// Calculer le déplacement
const athletisme = actor.system.physique?.athletisme?.value || 0;
const deplacementMetres = 2 + athletisme;

// Afficher la zone
await FFdreameMovementBlocker.showMovementRange(token, 5000); // 5 secondes

// Message informatif
ui.notifications.info(
  `📍 Zone de déplacement affichée pour <strong>${actor.name}</strong><br>` +
  `Athlétisme: ${athletisme} → Déplacement max: ${deplacementMetres}m`
);

console.log(`📍 Zone affichée - ${actor.name}: ${deplacementMetres}m (Athlétisme: ${athletisme})`);
