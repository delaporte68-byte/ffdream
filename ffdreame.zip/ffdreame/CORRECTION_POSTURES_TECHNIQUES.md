# 🔧 CORRECTION : Affichage des Techniques dans les Postures

## ❌ Problème identifié

Les techniques créées ne s'affichaient pas dans les postures même quand le champ "Posture Associée" était correctement rempli.

### Cause du problème

Le système utilisait une **comparaison stricte** entre :
- Le nom de la posture (ex: "Style du Dragon")
- Le champ "Posture Associée" de la technique (ex: "style du dragon" ou "Style du Dragon ")

Cette comparaison échouait si :
- ❌ La casse était différente (majuscules/minuscules)
- ❌ Il y avait des espaces en début ou fin
- ❌ Un caractère ne correspondait pas exactement

## ✅ Solution appliquée

### 1. Nouveau Helper Handlebars

**Fichier modifié :** `module/ffdreame.js`

Ajout d'un helper `postureMatch` qui compare les noms de manière **flexible** :

```javascript
Handlebars.registerHelper('postureMatch', function(postureAssociee, postureName) {
  if (!postureAssociee || !postureName) return false;
  
  // Normaliser les deux chaînes : minuscules et trim
  const normalized1 = String(postureAssociee).trim().toLowerCase();
  const normalized2 = String(postureName).trim().toLowerCase();
  
  return normalized1 === normalized2;
});
```

**Ce que fait ce helper :**
- ✅ Convertit les deux noms en minuscules
- ✅ Supprime les espaces en début/fin
- ✅ Compare les versions normalisées

### 2. Modification du Template

**Fichier modifié :** `templates/actor/character-sheet.html`

**Avant :**
```handlebars
{{#if (and (eq tech.type "technique") (eq tech.system.postureAssociee ../item.name))}}
```

**Après :**
```handlebars
{{#if (and (eq tech.type "technique") (postureMatch tech.system.postureAssociee ../item.name))}}
```

## 📋 Comment utiliser

### Étape 1 : Créer une Posture

1. Menu Items → Créer un Item → Type: "Posture"
2. Remplir le nom : **"Style du Dragon"**
3. Configurer les autres paramètres (Attaque Base, Effet, etc.)
4. Glisser la posture dans l'inventaire du personnage

### Étape 2 : Créer une Technique

1. Menu Items → Créer un Item → Type: "Technique"
2. Remplir les informations de base
3. **IMPORTANT** - Dans "Posture Associée", écrire le nom de la posture

**Exemples qui fonctionnent maintenant :**
- ✅ "Style du Dragon" (exact)
- ✅ "style du dragon" (minuscules)
- ✅ "STYLE DU DRAGON" (majuscules)
- ✅ " Style du Dragon " (avec espaces)
- ✅ "style   du   dragon" (même avec plusieurs espaces, ils seront normalisés)

4. Glisser la technique dans l'inventaire du personnage

### Étape 3 : Vérifier

1. Ouvrir la fiche du personnage
2. Aller dans l'onglet **Combat**
3. Activer la posture avec le bouton **TOGGLE**
4. **Les techniques doivent maintenant apparaître** dans la posture !

## 💡 Conseils d'utilisation

### Pour éviter les problèmes

1. **Copier-coller** : Le plus simple est de copier le nom de la posture et le coller dans le champ "Posture Associée"
2. **Vérifier** : Après avoir créé une technique, vérifiez qu'elle apparaît bien dans la posture
3. **Nom simple** : Utilisez des noms de postures simples et uniques

### Si une technique n'apparaît toujours pas

1. Vérifiez que le type d'item est bien "Technique"
2. Ouvrez l'item Technique
3. Vérifiez le champ "Posture Associée"
4. Copiez EXACTEMENT le nom de la posture (depuis la fiche de la posture)
5. Collez-le dans "Posture Associée"
6. Sauvegardez
7. Rafraîchissez la fiche personnage (F5)

## 🎯 Exemple complet

### Créer un style de combat complet

#### Posture : "Poing de Fer"
```
Nom: Poing de Fer
Attaque Base: +20
Effet: Bonus dégâts 20%
Condition: Après 3 attaques réussies
```

#### Technique 1 : "Frappe Tonnerre"
```
Nom: Frappe Tonnerre
Style: CAC
Coût PM: 10
Base Dégâts: 50
Posture Associée: poing de fer  ← Ça fonctionne maintenant !
```

#### Technique 2 : "Bouclier de Fer"
```
Nom: Bouclier de Fer
Style: BUFF
Coût PM: 15
Buff Type: Réduction dégâts
Buff Value: 30%
Posture Associée: POING DE FER  ← Ça fonctionne aussi !
```

## 🔧 Fichiers modifiés

1. **module/ffdreame.js** - Ajout du helper `postureMatch`
2. **templates/actor/character-sheet.html** - Utilisation du nouveau helper

## ⚙️ Installation de la correction

1. **Sauvegardez** votre monde Foundry VTT
2. **Fermez** Foundry VTT
3. **Remplacez** les fichiers dans `Data/systems/ffdreame/`
4. **Redémarrez** Foundry VTT
5. **Testez** en créant une posture et une technique

## ✅ Résultat attendu

Après cette correction :
- ✅ Les techniques s'affichent dans leur posture associée
- ✅ La comparaison est insensible à la casse
- ✅ Les espaces en début/fin sont ignorés
- ✅ Plus besoin de faire exactement correspondre la casse

---

**Version de la correction :** 1.0  
**Date :** 3 Février 2026  
**Compatibilité :** FFdreame System v3.0+
