# FFDreame v4.4 - Nouveau Système de Combat

## 🎯 Changements Majeurs

### ❌ ANCIEN SYSTÈME (Supprimé)
- **Postures** : 2 postures avec techniques intégrées
- Les techniques étaient liées aux postures

### ✅ NOUVEAU SYSTÈME

#### 1. 📦 **Cadres d'Objets** (Remplace les postures)
- **2 cadres indépendants** avec chacun **8 slots**
- Chaque cadre peut être **activé/désactivé** avec une checkbox
- Les objets ne sont utilisables que si leur cadre est actif

**Types d'objets acceptés :**
- ✨ **Techniques** (avec coût PM)
- 🎒 **Équipements** (objets divers)

**Comment utiliser :**
1. **Drag & Drop** : Glissez une technique ou un équipement depuis l'inventaire vers un slot vide
2. **Activation** : Cochez la case "Activer" pour rendre le cadre utilisable
3. **Utilisation** : Cliquez sur le bouton ▶️ pour utiliser l'objet
4. **Retrait** : Cliquez sur ❌ pour retirer l'objet du slot

#### 2. ⚔️ **Style d'Attaque** (Remplace l'attaque de base des postures)
- **4 types d'armes disponibles** :
  - ⚔️ Épée
  - 🥢 Bâton
  - 🔫 Flingue
  - 🏹 Arc

**Configuration :**
- Sélectionnez le type d'arme dans le menu déroulant
- Définissez les dégâts de base
- Les dégâts totaux = Dégâts de base + Aptitude Attaque

**Utilisation :**
- Cliquez sur "ATTAQUE DE BASE" pour lancer une attaque
- Consomme 1 point d'action
- Ajoute +10 Burste

#### 3. 🔥 **Style Ultime** (Remplace les ultimates des postures)
- **Ultime unique et personnalisable**

**Configuration :**
- **Nom** : Le nom de votre ultime
- **Description** : Effet narratif de l'ultime
- **Dégâts** : Dégâts infligés
- **Icône** : Choisissez parmi 4 icônes
  - 💥 Explosion
  - 🔥 Feu
  - ⚡ Éclair
  - ⭐ Étoile

**Conditions d'utilisation :**
- ✅ Burste ≥ 100
- ❌ Burste < 100 (verrouillé)

**Effet :**
- Réinitialise le Burste à 0
- Inflige les dégâts configurés
- Message spectaculaire dans le chat

---

## 🎮 Guide d'Utilisation

### Configuration Initiale

1. **Onglet Combat** de la fiche personnage
2. **Section "Style d'Attaque"** : Choisissez votre arme et définissez les dégâts
3. **Section "Cadres d'Objets"** : 
   - Glissez vos techniques et équipements préférés dans les slots
   - Activez le(s) cadre(s) que vous voulez utiliser
4. **Section "Style Ultime"** : Configurez votre ultime personnel

### En Combat

#### Tour de jeu classique :
1. **Attaque de Base** : Utilisez votre style d'attaque (⚔️🥢🔫🏹)
   - Coût : 1 point d'action
   - Effet : +10 Burste

2. **Techniques** : Utilisez les objets de vos cadres actifs
   - Coût : PM + 1 point d'action
   - Effet : +10 Burste

3. **Ultime** : Quand Burste = 100
   - Coût : 100 Burste (réinitialisé à 0)
   - Effet : Dégâts massifs

---

## 💡 Conseils Stratégiques

### Gestion des Cadres
- **Cadre 1** : Techniques offensives principales
- **Cadre 2** : Techniques défensives / utilitaires
- Changez de cadre actif selon la situation

### Build Équilibré
- **Style Attaque** : Dégâts de base modérés, fiable
- **Techniques** : Effets spéciaux et dégâts élevés
- **Ultime** : Capacité de retournement de situation

### Progression
- Investissez dans **Aptitude Attaque** pour améliorer votre style d'attaque
- Investissez dans **Puissance Magique** pour vos techniques
- Créez des techniques variées pour différentes situations

---

## 🔧 Informations Techniques

### Structure de Données (template.json)

```json
"combat": {
  "cadreObjets1": {
    "actif": false,
    "slots": [
      {"itemId": "", "itemName": "", "itemImg": ""},
      // ... 8 slots au total
    ]
  },
  "cadreObjets2": {
    "actif": false,
    "slots": [...]
  },
  "styleAttaque": {
    "type": "epee",
    "degatsBase": 0,
    "icone": "fa-sword"
  },
  "styleUltime": {
    "nom": "",
    "description": "",
    "degats": 0,
    "icone": "fa-burst"
  }
}
```

### Nouvelles Méthodes JavaScript

- `_onToggleCadre()` : Active/Désactive un cadre
- `_onUseObjet()` : Utilise un objet du cadre
- `_onRemoveFromSlot()` : Retire un objet d'un slot
- `_onDropObjetInSlot()` : Gère le drag & drop
- `_onAttaqueStyle()` : Lance l'attaque de base
- `_onUseUltimeStyle()` : Déclenche l'ultime
- `_executeTechniqueCadre()` : Exécute une technique

---

## 📋 Migration depuis l'ancienne version

### Pour les personnages existants :

1. **Postures** : Les anciennes postures restent dans les items mais ne sont plus utilisées
2. **Techniques** : Déplacez vos techniques dans les nouveaux cadres d'objets
3. **Ultimates** : Reconfigurez votre ultime dans la section "Style Ultime"

### Données conservées :
- ✅ Toutes les compétences et aptitudes
- ✅ Les techniques (en tant qu'items)
- ✅ L'équipement
- ✅ Les talents et atouts

---

## 🎨 Personnalisation CSS

Les nouveaux éléments utilisent ces classes CSS principales :
- `.styles-attaque-section`
- `.cadres-objets-section`
- `.cadre-objets` / `.cadre-actif`
- `.objet-slot` / `.objet-content`
- `.style-ultime-section`
- `.ultimate-card` / `.unlocked` / `.locked`

Modifiez `ffdreame.css` pour personnaliser l'apparence.

---

## 🐛 Dépannage

### Les cadres ne s'affichent pas ?
- Vérifiez que le fichier `template.json` a été mis à jour
- Rechargez Foundry VTT

### Les objets ne se déposent pas dans les slots ?
- Vérifiez que c'est bien une technique ou un équipement
- Vérifiez que les événements JavaScript sont bien enregistrés

### L'ultime ne se déclenche pas ?
- Vérifiez que Burste ≥ 100
- Vérifiez que l'ultime est configuré (nom non vide)

---

## 📝 Changelog v4.4

### Ajouts
- ✨ Système de Cadres d'Objets (2 cadres x 8 slots)
- ⚔️ Style d'Attaque personnalisable
- 🔥 Style Ultime unique
- 🎨 Nouveau CSS pour les cadres et styles

### Suppressions
- ❌ Système de Postures (2 postures)
- ❌ Techniques intégrées aux postures
- ❌ Ultimates liés aux postures

### Améliorations
- 🎮 Interface plus intuitive et modulaire
- 🔄 Drag & Drop pour faciliter la gestion
- 💪 Plus de flexibilité dans les builds

---

## 👥 Crédits

Système FFDreame v4.4
Modifications majeures du système de combat
