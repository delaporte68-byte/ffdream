# ✅ RÉCAPITULATIF : Système de Combat Complet

## 🎯 Votre Question

> "La gestion des combat pour le MJ, la fin de tour redonne bien 1 point d'action, la macro fin d'action pour les joueurs, les tours d'initiative sont bien pris en compte ?"

**Réponse :** OUI, TOUT fonctionne ✅ avec quelques détails importants à connaître.

---

## ⚔️ Système de Combat - Ce qui Fonctionne

### ✅ 1. Initiative (1d100)
**Code :** `ffdreame.js` ligne 97
```javascript
CONFIG.Combat.initiative = {
  formula: "1d100",
  decimals: 0
};
```

**Résultat :**
- Jet d'initiative : 1d100 pour tout le monde
- Bonus "Prend l'Initiative" : 999 (toujours premier)
- Ordre descendant : 999 → 100 → 95 → 50 → etc.

**Comment l'activer :**
```
1. MJ : Créer un combat (bouton ⚔️)
2. MJ : Ajouter les combattants (drag & drop)
3. MJ : Cliquer "Roll All" dans le Combat Tracker
→ Initiative lancée automatiquement !
```

---

### ✅ 2. Récupération de 1 Grand PA par Round

**Code :** `combat-system.js` ligne 244-254
```javascript
for (let i = 1; i <= 3; i++) {
  const grand = actionPoints[`grand${i}`];
  if (grand && (!grand.petit1 || !grand.petit2)) {
    // Restaure 1 Grand PA (2 Petits)
    await actor.update({
      [`system.combat.actionPoints.grand${i}.petit1`]: true,
      [`system.combat.actionPoints.grand${i}.petit2`]: true
    });
    paRecuperes++;
    break; // UN SEUL Grand PA récupéré
  }
}
```

**Résultat :**
- Chaque joueur récupère **1 Grand PA** (= 2 Petits PA)
- Si déjà à 3 Grands PA → Reste à 3 (pas de dépassement)
- Déplacement gratuit réinitialisé
- Réactions désactivées

**Déclenchement :**
1. **Automatique** : Quand le round change dans Foundry
2. **Manuel** : Bouton MJ "🔄 Nouveau Tour"

---

### ✅ 3. Macro "Terminer mon Tour" (Joueurs)

**Fichier :** `MACRO_TERMINER_MON_TOUR.js`

**Comment l'installer :**
```
1. Joueur : Ouvrir la barre de macros (en bas)
2. Créer une nouvelle macro
3. Type : Script
4. Coller le contenu du fichier
5. Glisser dans la barre
```

**Fonctionnement :**
```
1. Joueur sélectionne son token
2. Clique sur la macro
3. Dialogue de confirmation
4. Si OUI :
   - Actions bloquées (flag actionBlocked = true)
   - Message dans le chat
   - Passe au combattant suivant automatiquement
```

**Code clé :** Ligne 54 + 82
```javascript
await actor.setFlag('ffdreame', 'actionBlocked', true);
await combat.nextTurn(); // Passe au suivant
```

---

### ✅ 4. Blocage des Tableaux

**Code :** `actor-sheet.js` ligne 1143
```javascript
const actionBlocked = this.actor.getFlag('ffdreame', 'actionBlocked');
if (actionBlocked && !game.user.isGM) {
  ui.notifications.warn("🔒 Votre tour est terminé !");
  return; // Technique bloquée
}
```

**Résultat :**
- Joueur ne peut plus utiliser ses tableaux de techniques
- **PEUT TOUJOURS** utiliser Esquive/Défense/Marche
- MJ peut débloquer manuellement (bouton "🔓")

---

### ✅ 5. Déblocage au Nouveau Tour

**Code :** `combat-system.js` ligne 225
```javascript
static async startTurn(actor) {
  await actor.unsetFlag('ffdreame', 'actionBlocked');
  ui.notifications.info(`▶️ C'est le tour de ${actor.name} !`);
}
```

**Résultat :**
- Quand c'est le tour du joueur → Automatiquement débloqué
- Notification "▶️ C'est le tour de [Nom] !"

---

## 🎮 Workflow Complet d'un Combat

### Tour 1 :
```
MJ : Créer combat + Roll All
→ Initiative lancée (1d100)

Joueur 1 (init 95) : Son tour commence
→ Débloqué automatiquement
→ Utilise ses techniques
→ Clique "Terminer mon Tour"
→ Bloqué + passe au suivant

Joueur 2 (init 80) : Son tour commence
→ Débloqué automatiquement
→ Utilise ses techniques
→ Clique "Terminer mon Tour"

PNJ (init 50) : MJ joue pour lui
→ Utilise ses techniques
→ MJ clique "Next Turn" dans le tracker
```

### Fin du Round 1 → Début Round 2 :
```
Système : Détecte le changement de round
→ Appelle newRound() automatiquement
→ TOUS les joueurs récupèrent 1 Grand PA
→ Déplacements réinitialisés
→ Réactions désactivées
→ Tout le monde débloqué

→ Retour au premier dans l'ordre d'initiative
```

---

## 🔧 Boutons MJ dans le Combat Tracker

Le MJ voit **2 boutons supplémentaires** :

### 🔄 Nouveau Tour (Récupérer PA)
**Action :**
- Force la récupération de 1 Grand PA pour tous
- Réinitialise déplacements
- Désactive réactions
- Débloque tous les joueurs

**Utilité :**
- Si le système ne détecte pas le changement de round
- Pour forcer une récupération manuelle

### 🔓 Débloquer Tous les Joueurs
**Action :**
- Retire le flag `actionBlocked` de tous

**Utilité :**
- Si un joueur a cliqué trop tôt
- Pour permettre à quelqu'un de rejouer

---

## ⚠️ Points d'Attention

### 1. Détection du Nouveau Round

**Code :** `combat-system.js` ligne 160
```javascript
if (changed.round !== undefined && changed.round > (combat.previous?.round || 0)) {
  await this.newRound(combat);
}
```

**Problème potentiel :**
- `combat.previous` peut ne pas exister dans certaines versions de Foundry
- Si le round ne change pas automatiquement → Utiliser le bouton MJ

**Solution de secours :**
- Bouton "🔄 Nouveau Tour" toujours disponible

### 2. Macro Joueurs

**Important :**
- Les joueurs DOIVENT créer la macro eux-mêmes
- Le fichier `MACRO_TERMINER_MON_TOUR.js` est juste le code à copier
- Pas de macro partagée automatiquement

**Instructions à donner aux joueurs :**
```
1. Ouvre la barre de macros (en bas)
2. Nouvelle macro → Script
3. Colle ce code : [donner le fichier]
4. Glisse dans ta barre
```

### 3. Initiative Bonus

**Pour activer "Prend l'Initiative" :**
```
Actuellement : Champ interne uniquement

Depuis la console (F12) :
const actor = game.actors.getName("Nom du Joueur");
await actor.update({'system.combat.initiativeBonus': true});

Résultat : Initiative = 999 (toujours premier)
```

**TODO (optionnel) :**
- Ajouter une case à cocher sur la fiche pour faciliter

---

## 📊 Résumé Visuel

### État des PA au fil du combat :

```
Début Combat : 3 Grands PA (6 Petits)
│
├─ Joueur 1 Tour 1 :
│  ├─ Utilise 1 Grand PA → Reste 2 Grands PA
│  ├─ Utilise 1 Petit PA → Reste 1 Grand + 1 Petit
│  └─ Termine son tour
│
├─ Joueur 2 Tour 1 :
│  └─ (idem)
│
└─ FIN ROUND 1 → DÉBUT ROUND 2
   │
   ├─ Récupération : +1 Grand PA pour tous
   │  Joueur 1 : 1 Grand + 1 Petit + 1 Grand récupéré
   │           = 2 Grands + 1 Petit = 5 Petits PA
   │
   └─ Retour au tour de Joueur 1
```

---

## ✅ Checklist de Vérification

Testez ces points pour confirmer que tout marche :

- [ ] **Initiative 1d100** : Roll All dans le tracker
- [ ] **Ordre correct** : Du plus haut au plus bas
- [ ] **Tour commence** : Notification "▶️ C'est le tour de..."
- [ ] **Macro fonctionne** : Bloquer et passer au suivant
- [ ] **Techniques bloquées** : Après "Terminer mon Tour"
- [ ] **Réactions OK** : Esquive/Défense fonctionnent même bloqué
- [ ] **Nouveau round** : Tous récupèrent 1 Grand PA
- [ ] **Débloquage auto** : Au nouveau tour du joueur
- [ ] **Bouton MJ** : "🔄 Nouveau Tour" fonctionne
- [ ] **Affichage tracker** : PV/PM/PA visibles

---

## 🐛 Dépannage

### "Le nouveau round ne donne pas de PA"
1. Vérifiez la console (F12) : Cherchez "🔄 Nouveau round détecté"
2. Si absent → Utilisez le bouton MJ "🔄 Nouveau Tour"
3. Vérifiez que le combat est bien actif

### "La macro ne marche pas"
1. Vérifiez que le token est sélectionné
2. Type doit être "Script" (pas "Chat")
3. Vérifiez la console pour les erreurs

### "Les techniques ne se bloquent pas"
1. Console : `game.user.character.getFlag('ffdreame', 'actionBlocked')`
2. Doit retourner `true` après la macro
3. Si `false` → La macro n'a pas fonctionné

---

## 💡 Conseils d'Utilisation

1. **Expliquez aux joueurs** comment créer la macro
2. **Testez un combat** à vide avant la vraie partie
3. **Utilisez le bouton MJ** si le système ne détecte pas le round
4. **Ne vous fiez pas uniquement** au système automatique

---

Tout est prêt ! Testez et confirmez que ça marche comme vous voulez ! 🎮✨
