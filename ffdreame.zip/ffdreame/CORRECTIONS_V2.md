# 🔥 CORRECTIONS FINALES - Techniques dans Postures

## ⚠️ PROBLÈME IDENTIFIÉ ET RÉSOLU

Les techniques ne s'affichaient pas dans les postures à cause de **2 erreurs** :

### Erreur 1 : Items non passés au template
Le contexte du template ne recevait pas la liste des items du personnage.

### Erreur 2 : Références incorrectes
Le template utilisait `actor.items` au lieu de `items`.

---

## ✅ CORRECTIONS APPLIQUÉES

### 1. JavaScript (`module/sheets/actor-sheet.js`)

**Lignes modifiées : 28-43**

```javascript
async getData() {
  const context = super.getData();
  
  const actorData = this.actor.toObject(false);
  context.system = actorData.system;
  context.flags = actorData.flags;

  // ✅ CORRECTION : Passer les items
  context.items = this.actor.items.contents;
  context.actor = this.actor;

  context.isGM = game.user.isGM;
  context.rangInfo = this._getRangInfo(context.system.rang);

  return context;
}
```

**Changements :**
- ✅ Ajout de `context.items = this.actor.items.contents;`
- ✅ Ajout de `context.actor = this.actor;`

### 2. Template HTML (`templates/actor/character-sheet.html`)

**Lignes modifiées : 490-596**

**AVANT (ne fonctionnait pas) :**
```handlebars
{{#each actor.items as |item index|}}
  {{#each @root.actor.items as |tech|}}
```

**APRÈS (corrigé) :**
```handlebars
{{#each items as |item index|}}
  {{#each @root.items as |tech|}}
```

**Changements supplémentaires :**
- `item.id` → `item._id` (utilisation de l'ID correct)
- `@root.actor.system` → `@root.system` (référence correcte)
- Ajout d'icônes 💎 et ⚔️ pour PM et dégâts
- Messages d'aide améliorés

---

## 🎯 RÉSULTAT ATTENDU

Maintenant, les techniques devraient s'afficher correctement :

```
╔═══════════════════════════════════════════════════════╗
║              POSTURES & TECHNIQUES                    ║
╠═══════════════════════════╦═══════════════════════════╣
║  🥊 POSTURE 1            ║  🥊 POSTURE 2            ║
║  [✓ ACTIVE] [CONFIG]     ║  [○ Inactive] [CONFIG]   ║
║                          ║                          ║
║  ⚔️ ATTAQUE DE BASE      ║  ⚔️ ATTAQUE DE BASE      ║
║  170 dégâts              ║  150 dégâts              ║
║                          ║                          ║
║  📜 TECHNIQUES:          ║  📜 TECHNIQUES:          ║
║  ┌────────────────────┐ ║  ┌────────────────────┐ ║
║  │ Technique A        │ ║  │ Technique C        │ ║
║  │ 💎 15 PM           │ ║  │ 💎 20 PM           │ ║
║  │ ⚔️ 30 dégâts       │ ║  │ ⚔️ 40 dégâts       │ ║
║  └────────────────────┘ ║  └────────────────────┘ ║
║  ┌────────────────────┐ ║  ┌────────────────────┐ ║
║  │ Technique B        │ ║  │ Technique D        │ ║
║  │ 💎 25 PM           │ ║  │ 💎 35 PM           │ ║
║  │ ⚔️ 50 dégâts       │ ║  │ ⚔️ 60 dégâts       │ ║
║  └────────────────────┘ ║  └────────────────────┘ ║
║                          ║                          ║
║  🔥 ULTIMATE             ║  🔥 ULTIMATE             ║
║  Dragon Céleste          ║  Bouclier Parfait        ║
║  🔓 DISPONIBLE           ║  🔒 Burste < 100         ║
║  [🔥 LANCER ULTIMATE]    ║  [🔥 LANCER ULTIMATE]    ║
╚═══════════════════════════╩═══════════════════════════╝
```

---

## 📦 FICHIERS MODIFIÉS

### Version 2 (Corrections techniques)

1. **`module/sheets/actor-sheet.js`**
   - Méthode `getData()` corrigée
   - Items maintenant passés au contexte

2. **`templates/actor/character-sheet.html`**
   - Références aux items corrigées
   - Utilisation de `items` au lieu de `actor.items`
   - ID corrigés (`_id` au lieu de `id`)

3. **`css/ffdreame.css`**
   - Styles token central (version 1)
   - Section Burst masquée (version 1)
   - **Aucune modification supplémentaire dans v2**

---

## 🚀 INSTALLATION v2

### Option 1 : Nouvelle Installation
1. Extraire `ffdreame-modified-v2.zip`
2. Remplacer tout le dossier `systems/ffdreame/`
3. Redémarrer Foundry VTT
4. Rafraîchir (F5)

### Option 2 : Mise à jour depuis v1
Si vous avez déjà installé la version 1, remplacez seulement :
- `module/sheets/actor-sheet.js`
- `templates/actor/character-sheet.html`

---

## 🧪 TEST RAPIDE

### 1. Créer une Posture
```
Nom: "Test Combat"
Attaque Base: 20
```

### 2. Créer une Technique
```
Nom: "Frappe Test"
Style: CAC
Coût PM: 10
Base Dégâts: 30
Posture Associée: "Test Combat"  ← COPIER-COLLER !
```

### 3. Vérifier
1. Ouvrir fiche personnage
2. Onglet Combat
3. Section Postures & Techniques
4. **La technique "Frappe Test" doit apparaître sous "Test Combat" ✅**

---

## 🐛 DÉBOGAGE

### Si les techniques ne s'affichent toujours pas :

#### Test 1 : Console F12
```javascript
let actor = game.actors.getName("NomPersonnage");
console.log("Items:", actor.items.contents);
console.log("Postures:", actor.items.filter(i => i.type === "posture"));
console.log("Techniques:", actor.items.filter(i => i.type === "technique"));
```

#### Test 2 : Vérifier la Correspondance
```javascript
let tech = actor.items.find(i => i.name === "Frappe Test");
console.log("Posture associée:", tech.system.postureAssociee);
// Doit afficher EXACTEMENT: "Test Combat"
```

#### Test 3 : Vérifier le Template
```javascript
let sheet = actor.sheet;
let context = await sheet.getData();
console.log("Context items:", context.items);
// Doit afficher un tableau d'items
```

---

## 📊 DIFFÉRENCES v1 vs v2

| Fonctionnalité | v1 | v2 |
|---|---|---|
| Token central | ✅ | ✅ |
| Burst supprimée | ✅ | ✅ |
| Postures affichées | ✅ | ✅ |
| Techniques affichées | ❌ | ✅ |
| Items dans contexte | ❌ | ✅ |
| Références correctes | ❌ | ✅ |

---

## ⚠️ IMPORTANT

### Règle d'Or : COPIER-COLLER le Nom

Pour éviter les erreurs, **toujours copier-coller** le nom de la posture :

1. Ouvrir la posture
2. Sélectionner et copier le nom (Ctrl+C)
3. Ouvrir la technique
4. Coller dans "Posture Associée" (Ctrl+V)

**NE JAMAIS taper manuellement !**

---

## 📁 CONTENU DE L'ARCHIVE v2

```
ffdreame-modified-v2.zip
│
├── README_MODIFICATIONS.md          (Guide complet)
├── MODIFICATIONS_NOUVELLES.md       (Documentation détaillée)
├── RESUME_RAPIDE.md                 (Résumé visuel)
├── GUIDE_TEST_TECHNIQUES.md         (Nouveau ! Guide de test)
├── PRESENTATION.html                (Page web interactive)
│
├── module/
│   ├── sheets/
│   │   ├── actor-sheet.js           (✅ CORRIGÉ v2)
│   │   ├── actor-sheet.js.backup    (Original)
│   │   └── ...
│   └── ...
│
├── templates/
│   ├── actor/
│   │   ├── character-sheet.html     (✅ CORRIGÉ v2)
│   │   ├── character-sheet.html.backup (Original)
│   │   └── ...
│   └── ...
│
├── css/
│   ├── ffdreame.css                 (✅ Modifié v1)
│   ├── ffdreame.css.backup          (Original)
│   └── ...
│
└── [autres fichiers système inchangés]
```

---

## ✅ CHECKLIST POST-INSTALLATION

- [ ] Archive v2 extraite
- [ ] Fichiers remplacés dans `systems/ffdreame/`
- [ ] Foundry VTT redémarré
- [ ] Page rafraîchie (F5)
- [ ] Fiche personnage ouverte
- [ ] Onglet Principal : Token central visible ✅
- [ ] Onglet Combat : Grande barre Burst disparue ✅
- [ ] Onglet Combat : 2 colonnes de postures visibles ✅
- [ ] Posture créée (ex: "Test Combat")
- [ ] Technique créée avec "Posture Associée" correcte
- [ ] Technique visible dans sa posture ✅
- [ ] Bouton technique cliquable quand posture active ✅
- [ ] Dégâts et PM affichés sur la technique ✅

---

## 🎉 SUCCÈS !

Si tous les tests passent, votre système FFdreame v4.0 est maintenant **100% fonctionnel** avec :

- ✅ Token central interactif
- ✅ Interface combat optimisée
- ✅ Système postures/techniques opérationnel
- ✅ Affichage de 2 postures côte à côte
- ✅ Techniques visibles et cliquables
- ✅ Calculs de dégâts automatiques
- ✅ Système Ultimate avec Burst

**Bon jeu ! 🎮🔥**

---

## 📞 SUPPORT

Documents disponibles :
- `GUIDE_TEST_TECHNIQUES.md` - Guide de test complet
- `MODIFICATIONS_NOUVELLES.md` - Documentation système
- `RESUME_RAPIDE.md` - Résumé visuel
- `README_MODIFICATIONS.md` - Vue d'ensemble

En cas de problème :
1. Consulter `GUIDE_TEST_TECHNIQUES.md`
2. Utiliser la console F12 pour déboguer
3. Vérifier les fichiers .backup pour restaurer
4. Tester avec un nouveau personnage

---

**FFdreame System v4.0 - Corrections v2**
*Février 2026*
