# 📏 GUIDE : Système de Portée des Techniques

## 🎯 Vue d'ensemble

Chaque technique a maintenant une **portée maximale** en mètres. Si la cible est trop loin, la technique ne peut pas être lancée.

---

## ⚙️ Configuration

### Dans la fiche de technique :

**Champ "Portée maximale"** (en mètres)
```
📏 Portée maximale (en mètres) : [1.5]
💡 Exemples : CAC = 1.5m | Arme de jet = 5m | Magie = 10m | Longue portée = 20m
```

### Portées Recommandées par Style :

| Style | Portée Typique | Exemple |
|-------|---------------|---------|
| **CAC** | 1.5m | Coup de poing, Épée |
| **ATTA** | 1.5m | Attaque au corps à corps |
| **MAG** | 10m | Boule de feu |
| **ATTM** | 10m | Éclair magique |
| **PUI** | 5m | Technique hybride |
| **ULTIM** | 15m | Ultimate puissant |
| **AOE** | 8m | Zone d'effet |
| **MULTI** | Voir config | Distance gérée par MULTI |
| **CUR** | 10m | Soins à distance |
| **EF** | Variable | Selon l'effet |

---

## 🎮 En Jeu

### Scénario 1 : Technique à portée ✅
```
Joueur : Utilise "Coup de Poing" (CAC, portée 1.5m)
Cible : À 1m de distance
→ ✅ La technique se lance normalement
```

### Scénario 2 : Cible trop loin ❌
```
Joueur : Utilise "Coup de Poing" (CAC, portée 1.5m)
Cible : À 5m de distance
→ ❌ Message : "Cible trop loin ! Distance: 5m | Portée de Coup de Poing: 1.5m"
→ La technique ne se lance pas
→ Les PA/PM ne sont pas consommés
```

### Scénario 3 : Magie longue portée ✅
```
Joueur : Utilise "Boule de Feu" (MAG, portée 10m)
Cible : À 8m de distance
→ ✅ La technique se lance normalement
```

---

## 📐 Calcul de la Distance

Le système utilise la **grille de la scène** pour calculer la distance :

```
Distance = √(ΔX² + ΔY²) × Distance_par_case

Exemple avec une grille de 1.5m/case :
- Cible à 3 cases = 4.5m
- Cible à 1 case = 1.5m
- Cible à 2 cases en diagonale = 2.8m
```

### Configuration de la grille :
- Foundry VTT : Scene → Configuration → Grid Distance
- Par défaut : 1.5m par case (D&D 5ft = 1.5m)

---

## 🛠️ Exemples de Configuration

### Technique de Corps à Corps :
```
Nom : Coup d'Épée
Style : CAC
Portée : 1.5m
→ Ne peut toucher que les ennemis adjacents
```

### Technique de Projectile :
```
Nom : Shuriken
Style : ATTA
Portée : 8m
→ Peut toucher à moyenne distance
```

### Sort de Magie :
```
Nom : Éclair
Style : MAG
Portée : 12m
→ Longue portée magique
```

### Ultimate :
```
Nom : Météore Destructeur
Style : ULTIM
Portée : 20m
→ Très longue portée (c'est un ultimate !)
```

### Soins :
```
Nom : Lumière de Guérison
Style : CUR
Portée : 10m
→ Peut soigner à distance
```

---

## 🎭 Styles Spéciaux

### Style MULTI :
Le style MULTI a **sa propre gestion de portée** (dans la config MULTI).
Le champ "Portée" général n'est **pas utilisé** pour MULTI.

### Style CHM (Choix Multiple) :
La portée s'applique à **tous les choix** du CHM.

### Style CUR (Soins) :
La portée s'applique normalement. Si pas de cible, soigne le lanceur (portée = 0).

---

## 💡 Conseils de Game Design

### Équilibrage :
- **CAC : 1.5m** (standard)
- **Arme de jet : 5-8m** (arc, shuriken)
- **Magie simple : 10m** (sorts de base)
- **Magie puissante : 15m** (sorts avancés)
- **Ultimate : 20m+** (techniques ultimes)

### Cohérence :
- Plus la technique est puissante, plus la portée peut être longue
- Les techniques coûteuses en PM peuvent avoir plus de portée
- Les Ultimates peuvent ignorer les limites de portée normales

### Tactique :
- Forcer les joueurs CAC à se rapprocher = plus de risque
- Permettre aux mages de rester à distance = sécurité mais fragilité
- Créer des zones de contrôle avec les portées

---

## ⚠️ Notes Importantes

1. **La portée de 0** : La technique ne peut cibler que le lanceur
2. **Pas de cible** : Certains styles (CUR sur soi) ne nécessitent pas de cible
3. **Les PNJ** : Même système de portée pour les NPC
4. **Distance en 3D** : Le système calcule en 2D (pas de hauteur)

---

## 🐛 Dépannage

### "Ma technique CAC ne se lance pas sur un ennemi adjacent"
- Vérifiez que la portée est bien configurée (minimum 1.5m)
- Vérifiez la configuration de la grille (Scene settings)

### "Toutes mes techniques sont bloquées"
- Vérifiez que vous avez bien ciblé un ennemi (clic droit → Cibler)
- Vérifiez que la portée n'est pas à 0

### "La distance affichée ne correspond pas"
- Vérifiez la valeur "Grid Distance" dans les paramètres de la scène
- Ouvrez la console (F12) pour voir le calcul exact

---

## 🔧 Migration des Techniques Existantes

Les techniques créées **avant cette mise à jour** auront une portée par défaut de **1.5m**.

Pour les mettre à jour :
1. Ouvrez chaque technique
2. Ajustez le champ "Portée maximale"
3. Sauvegardez

**Astuce :** Créez des templates de techniques avec des portées pré-configurées !

---

Bon combat stratégique ! ⚔️📏
