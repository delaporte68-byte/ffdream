# 🎮 Guide d'Installation Rapide - Corrections FFdreame

## 📋 Résumé des corrections

### ✅ Problème 1 : Tableaux simultanés
**Statut :** DÉJÀ CORRIGÉ dans votre code
- Le système empêche déjà l'activation simultanée des deux tableaux
- Si vous rencontrez toujours ce problème, essayez de vider le cache de votre navigateur

### ✅ Problème 2 : Techniques de soins ne fonctionnent pas
**Corrigé !**
- Les techniques de style "CUR" fonctionnent maintenant automatiquement (sans jet de dés)
- Les soins sont appliqués immédiatement à la cible ou à soi-même

### ✅ Problème 3 : Techniques de téléportation ne fonctionnent pas
**Corrigé !**
- Nouveau style "TP" pour les techniques de téléportation pure
- La téléportation fonctionne maintenant automatiquement (sans jet de dés)

---

## 🚀 Installation

### Option 1 : Remplacement complet (RECOMMANDÉ)

1. **Sauvegardez votre système actuel** (important !)
   - Faites une copie de votre dossier `Data/systems/ffdreame`

2. **Remplacez les fichiers modifiés :**
   ```
   📁 templates/item/technique-sheet-v2.html  ← Modifié (ajout style TP)
   📁 module/sheets/actor-sheet.js            ← Modifié (nouvelles fonctions)
   ```

3. **Rechargez Foundry VTT**
   - F5 dans le navigateur
   - Ou redémarrez complètement Foundry

---

### Option 2 : Modification manuelle (pour les experts)

Si vous préférez modifier manuellement, consultez le fichier `LISEZMOI_CORRECTIONS.md` pour les instructions détaillées.

---

## 📝 Utilisation des nouvelles fonctionnalités

### Techniques de soins (style CUR)

1. Créer ou modifier une technique
2. Choisir le style **❤️ CUR - Soins**
3. Définir les "Dégâts de base" = montant des soins (ex: 20)
4. Configurer PM et PA comme d'habitude
5. **Important :** Pas besoin de jet de dés, les soins sont automatiques !

**Utilisation en jeu :**
- Cibler un allié (ou vous-même)
- Cliquer sur la technique
- Les soins sont appliqués immédiatement
- Les PV sont restaurés jusqu'au maximum

---

### Techniques de téléportation (style TP)

1. Créer ou modifier une technique
2. Choisir le style **🚀 TP - Téléportation**
3. Configurer la téléportation dans l'onglet "🚀 Téléportation"
4. Définir PM et PA
5. **Important :** Pas besoin de jet de dés, la téléportation est automatique !

**Utilisation en jeu :**
- Cibler une case ou un allié (selon la config)
- Cliquer sur la technique
- La téléportation s'effectue immédiatement
- Si annulée, les PA sont restitués

---

## 🐛 Dépannage

### Les soins ne fonctionnent toujours pas
1. Vérifiez que le style est bien "CUR" (pas "MAG" ou autre)
2. Vérifiez que vous avez assez de PM et PA
3. Essayez de cibler quelqu'un (ou vous-même)
4. Rechargez la page (F5)

### La téléportation ne fonctionne pas
1. Vérifiez que le style est bien "TP"
2. Vérifiez que la téléportation est configurée dans l'onglet dédié
3. Vérifiez que le module de téléportation est activé (`window.FFdreameTeleportation`)
4. Rechargez la page (F5)

### Les tableaux s'activent en même temps
1. Ce problème devrait déjà être corrigé dans votre code
2. Essayez de vider le cache du navigateur
3. Vérifiez les données de l'acteur (peut-être corrompues)

---

## ⚠️ Notes importantes

- **Sauvegardez toujours** avant d'appliquer des modifications
- Les anciennes techniques de style "CUR" qui avaient un autre style devront être **re-configurées**
- Pour les techniques de téléportation avec dégâts, gardez l'ancien système (le style TP est pour la téléportation pure)
- La Burste augmente de +10 pour chaque technique de soins ou téléportation réussie

---

## 📞 Support

Si vous rencontrez des problèmes :
1. Consultez le fichier `LISEZMOI_CORRECTIONS.md` pour plus de détails
2. Vérifiez les logs de la console (F12 dans le navigateur)
3. Vérifiez que tous les fichiers ont bien été remplacés

Bon jeu ! 🎲
