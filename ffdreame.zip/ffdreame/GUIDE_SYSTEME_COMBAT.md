# 🎮 GUIDE : Système de Combat FFdreame

## ⚔️ Vue d'ensemble

Le système utilise le **Combat Tracker** natif de Foundry (petit onglet à droite) pour gérer les combats.

---

## 📋 Fonctionnalités

### **Pour les Joueurs :**
- ✅ Voir leurs PV, PM, Points d'Action dans le tracker
- ✅ Utiliser leurs techniques pendant leur tour
- ✅ Cliquer sur "Terminer mon Tour" pour passer au suivant
- ✅ Toujours utiliser Esquive/Défense/Marche (même hors de leur tour)

### **Pour le MJ :**
- ✅ Lancer l'initiative automatiquement
- ✅ Bouton "Nouveau Tour" pour récupérer 1 Grand PA pour tous
- ✅ Bouton "Débloquer Tous" pour réautoriser les joueurs
- ✅ Voir Fatigue/Blessure de chaque joueur

---

## 🚀 Démarrer un Combat

### Étape 1 : Ajouter les combattants
1. Cliquez sur le bouton **"⚔️ Combat"** en haut à gauche
2. Faites glisser les tokens sur la scène dans le Combat Tracker

### Étape 2 : Lancer l'initiative
1. Cliquez sur **"🎲 Roll All"** dans le tracker
2. Les joueurs avec le bonus "Prend l'Initiative" seront automatiquement en premier (999)
3. Les autres auront un jet de 1d100

### Étape 3 : Commencer le combat
1. Cliquez sur **"▶️ Begin Combat"**
2. Le premier combattant est activé

---

## 🎯 Pendant le Combat

### **Tour du Joueur :**

1. **C'est son tour** → Notification "▶️ C'est le tour de [Nom] !"
2. **Il utilise ses techniques** depuis ses tableaux
3. **Il clique sur la macro "Terminer mon Tour"**
4. **Ses tableaux se bloquent** 🔒
5. **Le tour passe au suivant** automatiquement

### **Hors de son tour :**

- ❌ **Ne peut PAS** utiliser les tableaux de techniques
- ✅ **Peut TOUJOURS** utiliser :
  - 🤸 Esquive
  - 🛡️ Défense
  - 🚶 Marche

---

## 🔄 Fin de Tour (Tous ont joué)

### Méthode 1 : Automatique
Quand le dernier combattant termine son tour, le système détecte automatiquement le nouveau round.

### Méthode 2 : Bouton MJ
Le MJ peut cliquer sur **"🔄 Nouveau Tour (Récupérer PA)"**

### Ce qui se passe :
1. ✅ Chaque joueur récupère **1 Grand PA** (s'il n'est pas au max de 3)
2. ✅ Le déplacement gratuit est **réinitialisé**
3. ✅ Les réactions (Esquive/Défense/Marche) sont **désactivées**
4. ✅ Tous les joueurs sont **débloqués**

---

## 🎭 Affichage dans le Combat Tracker

Pour chaque combattant, vous verrez :

```
[Image du Token] Nom du Personnage
❤️ 150/200   ✨ 80/100   ⚡ 2/3 PA
😴 2   🩹 1   🔒 (si tour terminé)
```

**Légende :**
- ❤️ = Points de Vie (rouge si critique, orange si blessé, vert si ok)
- ✨ = Points de Magie
- ⚡ = Points d'Action (Grands PA disponibles)
- 😴 = Nombre de cases de Fatigue actives
- 🩹 = Nombre de cases de Blessure actives
- 🔒 = Tour terminé (actions bloquées)

---

## 🔧 Macro "Terminer mon Tour"

### Installation :
1. Ouvrez la **Barre de Macros** (en bas de l'écran)
2. Créez une **Nouvelle Macro**
3. Type : **Script**
4. Collez le contenu du fichier `MACRO_TERMINER_MON_TOUR.js`
5. Sauvegardez et glissez-la dans votre barre

### Utilisation :
1. **Sélectionnez votre token**
2. **Cliquez sur la macro**
3. **Confirmez**
4. Vos tableaux se bloquent et le tour passe au suivant

---

## 🎖️ Bonus "Prend l'Initiative"

### Activation :
Pour l'instant, c'est un champ interne. Pour l'activer :

**Depuis la console (F12) :**
```javascript
// Remplacez TOKEN_ID par l'ID de votre token
const token = canvas.tokens.get("TOKEN_ID");
await token.actor.update({
  'system.combat.initiativeBonus': true
});
```

**Effet :**
- Initiative = **999** (toujours en premier)
- Même si plusieurs joueurs ont ce bonus, ils seront tous à 999 (ordre aléatoire entre eux)

### Note :
Je peux ajouter une case à cocher sur la fiche si vous voulez que ce soit plus accessible.

---

## 🛠️ Boutons MJ dans le Combat Tracker

### 🔄 Nouveau Tour (Récupérer PA)
- Récupère 1 Grand PA pour TOUS
- Réinitialise déplacements
- Désactive réactions
- Débloque tous les joueurs

### 🔓 Débloquer Tous les Joueurs
- Réautorise tous les joueurs à utiliser leurs techniques
- Utile si vous voulez laisser quelqu'un rejouer

---

## ⚠️ Important

### Le MJ peut TOUJOURS débloquer un joueur :
Si un joueur a terminé son tour par erreur, le MJ peut :
1. Cliquer sur **"🔓 Débloquer Tous"**
2. OU utiliser la console :
```javascript
const actor = game.actors.getName("Nom du Joueur");
await actor.unsetFlag('ffdreame', 'actionBlocked');
```

### Les réactions fonctionnent TOUJOURS :
Même si le tour est terminé, les joueurs peuvent :
- Activer Esquive/Défense avant une attaque
- Utiliser Marche pour se déplacer

---

## 🐛 Dépannage

### "Mes tableaux ne se bloquent pas"
- Vérifiez que le système de combat est bien initialisé (message dans la console)
- Rechargez la page (F5)

### "Le tour ne passe pas automatiquement"
- Assurez-vous d'être en combat actif (bouton ▶️ Begin Combat)
- Le tour passe quand le joueur clique sur "Terminer mon Tour" ET que c'est bien son tour

### "Les PA ne se récupèrent pas"
- Cliquez manuellement sur "🔄 Nouveau Tour"
- Ou passez au round suivant dans le tracker

---

## 💡 Conseils

1. **Créez la macro "Terminer mon Tour"** et partagez-la avec vos joueurs
2. **Utilisez le round** du Combat Tracker pour suivre les tours
3. **N'hésitez pas à débloquer** un joueur s'il a cliqué trop tôt
4. **Le GM Tracker** peut rester pour les paramètres globaux (mode dés, etc.)

---

## 🎯 Workflow Type d'un Combat

```
1. MJ : Créer le combat + Ajouter les tokens
2. MJ : Roll All (initiative)
3. MJ : Begin Combat
4. Joueur 1 : Joue → Clique "Terminer mon Tour"
5. Joueur 2 : Joue → Clique "Terminer mon Tour"
6. Joueur 3 : Joue → Clique "Terminer mon Tour"
7. PNJ : Le MJ joue pour lui → Next Turn
8. → Nouveau Round détecté
9. → Tous récupèrent 1 Grand PA
10. → Retour à l'étape 4
```

Bon combat ! ⚔️
