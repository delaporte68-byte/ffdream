# 🔍 DEBUG EFFETS - GUIDE COMPLET

## ❌ PROBLÈME RAPPORTÉ :

1. **Effet "Soins"** ne soigne pas
2. **Effet "Bonus Dégâts"** ne fonctionne pas

---

## 🧪 TEST 1 : Soins (Effet sur technique)

### Configuration :
```
1. Créer technique style CUR
2. Onglet Effets
3. Effet 1 : Type = soins
4. Valeur = 50
5. Unité = pourcent ou fixe
6. Condition = 100 (toujours)
```

### Test :
```
1. F12 → Console
2. Lancer la technique
3. Vérifier Console :
   - "✨ Effet 1 : Soins +X PV"
   - Message dans le chat avec soins
```

### Si ça ne marche PAS :
```
Envoyez-moi la Console complète quand vous lancez la technique
```

---

## 🧪 TEST 2 : Bonus Dégâts (Effet de tableau)

### Configuration :
```
1. Ouvrir fiche perso
2. Tableau 1 → Bouton ⚙️ Config Effet
3. Type : Bonus Dégâts
4. Condition : 3 réussites
5. Seuil : 3
6. Valeur : 20 (= +20%)
```

### Test :
```
1. F12 → Console
2. Utiliser 3 techniques du Tableau 1 (réussites)
3. Après la 3ème :
   Console : "🎉 Effet activé !"
   Interface : Voyant vert sur tableau
4. Utiliser 4ème technique :
   Console : "💥 Bonus Dégâts +X appliqué"
   Chat : Dégâts augmentés
```

### Si ça ne marche PAS :
```
Envoyez-moi les messages Console ligne par ligne
```

---

## 🔧 CODE VÉRIFIÉ :

### Soins (ligne 2249) :
```javascript
async _appliquerSoins(valeur, unite) {
  const pvActuel = this.actor.system.aptitudes.pv.value;
  const pvMax = this.actor.system.aptitudes.pv.max;
  
  let soins = 0;
  if (unite === "pourcent") {
    soins = Math.floor((pvMax * valeur) / 100);
  } else {
    soins = valeur;
  }
  
  const nouveauPV = Math.min(pvMax, pvActuel + soins);
  
  await this.actor.update({
    'system.aptitudes.pv.value': nouveauPV
  });
  
  return `Soins +${soins} PV`;
}
```
✅ Code OK

### Bonus Dégâts (ligne 3153) :
```javascript
case 'bonus_degats':
  if (effet.unite === 'pourcent') {
    bonusApplique = Math.floor(degatsBase * (effet.valeur / 100));
  } else {
    bonusApplique = effet.valeur;
  }
  degatsFinaux = degatsBase + bonusApplique;
  effetApplique = `Bonus Dégâts +${bonusApplique}`;
```
✅ Code OK

---

## ⚠️ CAUSES POSSIBLES :

### Soins ne marche pas :
1. Effet pas configuré (Type = "aucun" ?)
2. Condition pas remplie (jet > condition ?)
3. Unité incorrecte

### Bonus Dégâts ne marche pas :
1. Effet tableau pas activé
2. Compteur pas au seuil
3. Condition = "permanent" ou "debut_combat" au lieu de "reussites"

---

## 📞 POUR DÉBUGGER :

### Console Messages à chercher :
```
Soins :
- "✨ Effet 1 : Soins +X PV"
- Chat message avec PV avant → après

Bonus Dégâts :
- "🎯 _incrementerCompteurEffet appelée"
- "➕ Incrémentation: X → Y"
- "🎉 Effet activé !"
- "💥 Bonus Dégâts +X appliqué"
```

**Faites le test et envoyez-moi TOUS les messages Console ! 🔍**
