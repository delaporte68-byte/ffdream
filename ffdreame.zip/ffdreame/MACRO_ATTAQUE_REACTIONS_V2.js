/**
 * ============================================
 * MACRO MJ : ATTAQUE AVEC RÉACTIONS AUTO
 * ============================================
 * Système automatique d'esquive et défense
 * 
 * UTILISATION :
 * 1. Sélectionner le token attaquant
 * 2. Cibler le défenseur (clic droit)
 * 3. Lancer la macro
 * 4. Entrer dégâts et % d'attaque
 * 
 * RÈGLES :
 * - Esquive : Seuil = Attaque% + Agilité
 * - Défense : Seuil = Attaque% + Endurance
 * 
 * RÉDUCTIONS :
 * - Jet > Attaque% : 100% dégâts (échec)
 * - Jet entre Attaque% et -15% : 60% dégâts
 * - Jet entre -15% et -25% : 50% dégâts
 * - Jet ≤ -25% ou critique : 0% dégâts
 */

// ==========================================
// VÉRIFICATIONS INITIALES
// ==========================================

// Vérifier que le système est chargé
if (!game.ffdreame?.ReactionSystem) {
  ui.notifications.error("❌ Le système de réactions FFdreame n'est pas chargé !");
  console.error("Assurez-vous que reaction-system.js est bien importé dans ffdreame.js");
  return;
}

// Vérifier qu'un token attaquant est sélectionné
if (!canvas.tokens.controlled.length) {
  ui.notifications.warn("⚠️ Sélectionnez l'attaquant (votre token) !");
  return;
}

const attaquantToken = canvas.tokens.controlled[0];

// Vérifier qu'une cible est ciblée
const targets = Array.from(game.user.targets);
if (targets.length === 0) {
  ui.notifications.warn("⚠️ Ciblez un défenseur (clic droit sur son token) !");
  return;
}

const cibleToken = targets[0];

// Vérifier que les acteurs existent
if (!attaquantToken.actor || !cibleToken.actor) {
  ui.notifications.error("❌ Un des tokens n'a pas d'acteur associé !");
  return;
}

console.log(`⚔️ ATTAQUE : ${attaquantToken.name} → ${cibleToken.name}`);

// ==========================================
// DIALOG : PARAMÈTRES D'ATTAQUE
// ==========================================

const resultat = await new Promise((resolve) => {
  new Dialog({
    title: "⚔️ Paramètres d'Attaque",
    content: `
      <form style="padding: 10px;">
        <div style="margin-bottom: 15px;">
          <p style="text-align: center; margin-bottom: 10px;">
            <strong>${attaquantToken.name}</strong> attaque <strong>${cibleToken.name}</strong>
          </p>
        </div>
        
        <div class="form-group" style="margin-bottom: 15px;">
          <label style="display: block; margin-bottom: 5px;">
            <strong>Dégâts de base :</strong>
          </label>
          <input 
            type="number" 
            name="degats" 
            value="50" 
            min="0" 
            style="width: 100%; padding: 5px;"
            placeholder="Ex: 50, 100, 150..."
          />
          <small style="color: #999; display: block; margin-top: 3px;">
            Les dégâts avant application de l'esquive/défense
          </small>
        </div>
        
        <div class="form-group" style="margin-bottom: 15px;">
          <label style="display: block; margin-bottom: 5px;">
            <strong>Jet d'attaque (%) :</strong>
          </label>
          <div style="display: flex; gap: 10px; align-items: center;">
            <input 
              type="number" 
              name="pourcentage" 
              value="" 
              min="1" 
              max="100"
              style="flex: 1; padding: 5px;"
              placeholder="Laisser vide pour jet auto"
            />
            <button 
              type="button" 
              id="roll-auto" 
              style="padding: 5px 15px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;"
            >
              🎲 Lancer
            </button>
          </div>
          <small style="color: #999; display: block; margin-top: 3px;">
            Laisser vide pour lancer automatiquement 1d100
          </small>
        </div>
      </form>
      
      <script>
        document.getElementById('roll-auto').addEventListener('click', () => {
          const roll = Math.floor(Math.random() * 100) + 1;
          document.querySelector('[name="pourcentage"]').value = roll;
        });
      </script>
    `,
    buttons: {
      attack: {
        icon: '<i class="fas fa-sword"></i>',
        label: "⚔️ Attaquer",
        callback: (html) => {
          const degats = parseInt(html.find('[name="degats"]').val()) || 50;
          const pourcentage = parseInt(html.find('[name="pourcentage"]').val()) || null;
          resolve({ degats, pourcentage });
        }
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Annuler",
        callback: () => resolve(null)
      }
    },
    default: "attack",
    close: () => resolve(null)
  }, {
    width: 400
  }).render(true);
});

if (!resultat) {
  console.log("Attaque annulée par l'utilisateur");
  return;
}

// ==========================================
// EXÉCUTION DE L'ATTAQUE
// ==========================================

console.log(`📊 Paramètres: Dégâts=${resultat.degats}, Jet=${resultat.pourcentage || 'auto'}`);

try {
  const result = await game.ffdreame.ReactionSystem.processAttaque(
    attaquantToken,
    cibleToken,
    resultat.degats,
    resultat.pourcentage
  );
  
  if (result) {
    console.log("✅ Attaque réussie:", result);
    
    // Message récapitulatif en console
    console.log(`
      ═══════════════════════════════════════
      📊 RÉSUMÉ DE L'ATTAQUE
      ═══════════════════════════════════════
      Attaquant: ${attaquantToken.name}
      Défenseur: ${cibleToken.name}
      
      Dégâts Base: ${result.degatsBase}
      Dégâts Finaux: ${result.degatsFinaux}
      Réduction: ${result.reduction ? Math.round(result.reduction * 100) : 0}%
      
      Réaction: ${result.reactionUtilisee || 'Aucune'}
      ${result.reactionUtilisee ? `Jet: ${result.jetReaction}% / ${result.seuilReussite}%` : ''}
      ${result.reactionUtilisee ? `Marge: ${result.marge}%` : ''}
      
      PV: ${result.pvActuel} → ${result.nouveauPV}
      ═══════════════════════════════════════
    `);
  }
  
} catch (error) {
  console.error("❌ Erreur lors de l'attaque:", error);
  ui.notifications.error(`❌ Erreur: ${error.message}`);
}
