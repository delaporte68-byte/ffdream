# ⚡ FFdreame v3.7 - Corrections Complètes - Calculs & Token

## 📅 Date : 3 Février 2026

---

## 🎯 NOUVELLES CORRECTIONS MAJEURES

### ✅ 1. CALCULS AUTOMATIQUES SUR FICHE CYBERPUNK

**PROBLÈME :** La fiche cyberpunk n'appliquait AUCUN calcul automatique. Les compétences n'influençaient pas les aptitudes, le rang et le niveau n'avaient aucun effet.

**SOLUTION :**
Modification du fichier `/module/documents/actor.js` (ligne 17-23) :

```javascript
prepareDerivedData() {
  super.prepareDerivedData();
  
  // AVANT : if (this.type === "character")
  // MAINTENANT : Les deux types bénéficient des calculs
  if (this.type === "character" || this.type === "cyberpunk") {
    this._prepareCharacterData();
  }
}
```

**RÉSULTAT :** 
La fiche cyberpunk applique maintenant **TOUS** les calculs automatiques :
- ✅ Compétences → Aptitudes
- ✅ Modificateurs de rang (×1.0 à ×2.0)
- ✅ Points d'aptitudes selon niveau (LV × 5)
- ✅ Points de compétences selon rang (15 + bonus de rang)
- ✅ Réductions de fatigue et blessures
- ✅ Formules PV/PM avec multiplicateurs (Endurance × 100, Magie × 100, etc.)

---

### ✅ 2. CONTRÔLE DU TOKEN SUR FICHE CYBERPUNK

**PROBLÈME :** L'image du token au centre de la fiche cyberpunk n'était pas interactive.

**SOLUTION :**
1. **Template modifié** (`/templates/actor/cyberpunk-character-sheet.html`) :
   - Ajout de `data-action="show-image"` sur le container
   - Ajout de `data-edit="img"` sur l'image
   - Ajout d'un hint visuel au survol

2. **CSS modifié** (`/css/cyberpunk.css`) :
   - Container maintenant `cursor: pointer`
   - Effet hover avec `scale(1.05)` et glow magenta
   - Hint qui apparaît au survol avec instructions

3. **JavaScript ajouté** (`/module/sheets/actor-sheet.js`) :
   - **Clic gauche** : Ouvre le FilePicker pour changer l'image de l'acteur
   - **Clic droit** : Ouvre la configuration du Prototype Token

**RÉSULTAT :**
```
┌─────────────────────────────────┐
│   [IMAGE DU TOKEN CYBERPUNK]    │
│                                  │
│  Au survol :                     │
│  ────────────────────────────    │
│  📝 Clic : Image                 │
│     Clic droit : Token           │
└─────────────────────────────────┘
```

---

## 📊 SYSTÈME DE CALCULS EXPLIQUÉ

### 🔗 **Liens Compétences → Aptitudes**

#### **ATTAQUE**
```
ATTAQUE = (Base + Investissement + Force + Agilité + Perception) × Mult Rang × (1 - réductions)
```

**Exemple concret :**
- Base : 0
- Investissement : 10 points
- Force : 5
- Agilité : 3
- Perception : 4
- **TOTAL BRUT** : 0 + 10 + 5 + 3 + 4 = 22

**Avec Rang S (×2.0)** : 22 × 2.0 = **44 ATQ**
**Avec fatigue f6 (-25%)** : 44 × 0.75 = **33 ATQ**

---

#### **PUISSANCE MAGIQUE**
```
PM = (Base + Investissement + Perception + Agilité + Magie) × Mult Rang × (1 - réductions)
```

**Exemple concret :**
- Base : 0
- Investissement : 15 points
- Perception : 4
- Agilité : 3
- Magie : 8
- **TOTAL BRUT** : 0 + 15 + 4 + 3 + 8 = 30

**Avec Rang A (×1.7)** : 30 × 1.7 = **51 PM**

---

#### **POINTS DE VIE**
```
PV MAX = ((Base + Investissement) + (Volonté × 10) + (Endurance × 100)) × Mult Rang × (1 - réductions)
```

**Exemple concret :**
- Base : 50
- Investissement : 20 points
- Volonté : 6
- Endurance : 5
- **CALCUL** : (50 + 20) + (6 × 10) + (5 × 100) = 70 + 60 + 500 = 630

**Avec Rang B (×1.5)** : 630 × 1.5 = **945 PV**
**Avec fatigue f4 (-15%)** : 945 × 0.85 = **803 PV**

⚠️ **IMPORTANT** : L'Endurance a un impact MASSIF (× 100) !

---

#### **POINTS DE MANA**
```
PM MAX = ((Base + Investissement) + (Magie × 100) + (Volonté × 10)) × Mult Rang × (1 - réductions)
```

**Exemple concret :**
- Base : 10
- Investissement : 25 points
- Magie : 8
- Volonté : 6
- **CALCUL** : (10 + 25) + (8 × 100) + (6 × 10) = 35 + 800 + 60 = 895

**Avec Rang S (×2.0)** : 895 × 2.0 = **1790 PM**
**Avec fatigue f7 (-20%)** : 1790 × 0.8 = **1432 PM**

⚠️ **IMPORTANT** : La Magie a un impact MASSIF (× 100) !

---

### 🎖️ **Modificateurs de Rang**

| Rang | Seuil Jet (d100) | Multiplicateur | Points Compétences | Couleur |
|------|------------------|----------------|-------------------|---------|
| **F** | ≤ 40 | ×1.0 | 15 (+0) | Gris |
| **D** | ≤ 45 | ×1.0 | 20 (+5) | Marron |
| **C** | ≤ 50 | ×1.2 | 25 (+5) | Bronze |
| **B** | ≤ 55 | ×1.5 | 35 (+10) | Argent |
| **A** | ≤ 60 | ×1.7 | 40 (+5) | Or |
| **S** | ≤ 60 | ×2.0 | 50 (+10) | Cyan |
| **SS** | ≤ 65 | ×2.0 | 55 (+5) | Magenta |

**Impact du rang sur un personnage :**
- Rang F : 100 PV de base
- Rang C : 100 × 1.2 = 120 PV (+20%)
- Rang B : 100 × 1.5 = 150 PV (+50%)
- Rang S : 100 × 2.0 = 200 PV (+100%) 🔥

---

### 📈 **Progression par Niveau**

```
Points d'Aptitudes = Niveau × 5
```

| Niveau | Points d'Aptitudes | Exemple répartition |
|--------|-------------------|---------------------|
| 1 | 5 | 3 ATQ, 2 PM |
| 5 | 25 | 10 ATQ, 5 PM, 5 PV, 5 Mana |
| 10 | 50 | 15 ATQ, 10 PM, 15 PV, 10 Mana |
| 20 | 100 | 30 ATQ, 25 PM, 25 PV, 20 Mana |

Ces points sont **cumulatifs** et **permanents**.

---

### 💔 **Réductions de Combat**

#### **Fatigue :**
| Case | Effet | Impact |
|------|-------|--------|
| f4 | -15% PV MAX | 1000 PV → 850 PV |
| f6 | -25% ATQ et PM | 50 ATQ → 37 ATQ |
| f7 | -20% Mana MAX | 500 PM → 400 PM |

**Cumul possible** : f4 + f6 + f7 = -15% PV, -25% ATQ/PM, -20% Mana

#### **Blessures :**
| Case | Effet | Impact |
|------|-------|--------|
| b4 | -15% ATQ et PM | 60 ATQ → 51 ATQ |
| b6 | -30% ATQ et PM | 60 ATQ → 42 ATQ |
| b8 | -20% ATQ et PM | 60 ATQ → 48 ATQ |

**DANGER EXTRÊME** : Si b4 + b6 + b8 sont cochées :
- Réduction totale : -65% ATQ et PM ! 💀
- 60 ATQ → 21 ATQ (divisé par ~3)

---

## 🎮 UTILISATION DU TOKEN CYBERPUNK

### Comment modifier l'image du personnage :

1. **Clic gauche** sur l'image du token :
   ```
   → Ouvre le sélecteur de fichiers
   → Choisissez une nouvelle image
   → L'image du personnage change automatiquement
   ```

2. **Clic droit** sur l'image du token :
   ```
   → Ouvre la configuration du Prototype Token
   → Permet de régler :
      • Image du token (différente de l'acteur)
      • Taille du token (1×1, 2×2, etc.)
      • Vision (distance, angle)
      • Lumières émises
      • Barres de ressources (PV, PM)
      • Et bien plus...
   ```

### Différence Image Acteur vs Token :

```
┌─────────────────────────────────────────┐
│ IMAGE ACTEUR (clic gauche)              │
│ → Apparaît dans la fiche du personnage  │
│ → Apparaît dans le chat                 │
│                                          │
│ IMAGE TOKEN (clic droit → config)       │
│ → Apparaît sur la carte/scene           │
│ → Peut être différente (ex: portrait    │
│    dans la fiche, sprite sur la carte)  │
└─────────────────────────────────────────┘
```

---

## 📁 FICHIERS MODIFIÉS

### 1. `/module/documents/actor.js`
- ✅ Ligne 17-23 : Ajout du type "cyberpunk" dans les calculs automatiques

### 2. `/templates/actor/cyberpunk-character-sheet.html`
- ✅ Lignes 131-157 : Rendre le token cliquable
- ✅ Ajout du hint visuel au survol

### 3. `/css/cyberpunk.css`
- ✅ Lignes 413-453 : Styles pour token interactif
- ✅ Effet hover avec scale et glow
- ✅ Hint qui apparaît au survol

### 4. `/module/sheets/actor-sheet.js`
- ✅ Lignes 164-170 : Ajout des event listeners
- ✅ Nouvelles méthodes `_onTokenImageClick()` et `_onTokenConfigClick()`

---

## 🧪 TESTS À EFFECTUER

### Test 1 : Calculs Automatiques Cyberpunk
1. Créer un nouveau personnage type "Cyberpunk"
2. Définir Rang = C, Niveau = 5
3. Ajouter des points dans les compétences (ex: Force = 5)
4. **Vérifier** : L'ATQ augmente automatiquement
5. Changer le Rang à S
6. **Vérifier** : Toutes les aptitudes sont multipliées par 2

### Test 2 : Token Interactif
1. Ouvrir une fiche Cyberpunk
2. Survoler l'image du token
3. **Vérifier** : Effet de zoom + glow magenta + hint apparaît
4. Clic gauche → **Vérifier** : FilePicker s'ouvre
5. Clic droit → **Vérifier** : Config Prototype Token s'ouvre

### Test 3 : Réductions de Combat
1. Cocher f6 (fatigue)
2. **Vérifier** : ATQ et PM réduits de 25%
3. Cocher b4 et b6 (blessures)
4. **Vérifier** : ATQ et PM réduits de 45% supplémentaires (total ~60%)

### Test 4 : Progression par Niveau
1. Personnage niveau 1 → 5 points d'aptitudes
2. Monter au niveau 10 → **Vérifier** : 50 points d'aptitudes
3. Dépenser des points → **Vérifier** : Calculs se mettent à jour

### Test 5 : Modificateurs de Compétences
1. Mettre Endurance = 10
2. **Vérifier** : PV augmente de 1000 (10 × 100)
3. Mettre Magie = 8
4. **Vérifier** : Mana augmente de 800 (8 × 100)

---

## 📊 EXEMPLES DE BUILDS

### Build Guerrier (Corps à Corps)
```
Rang: B (×1.5)
Niveau: 10 (50 points aptitudes)

Compétences:
├─ Force: 10
├─ Endurance: 8
├─ Agilité: 5
└─ Perception: 3

Investissements aptitudes:
├─ Attaque: 20 points
├─ PV: 15 points
└─ PM: 15 points

RÉSULTAT:
• ATQ = (20 + 10 + 5 + 3) × 1.5 = 57
• PV = (15 + 60 + 800) × 1.5 = 1312
• Mana = 15 × 1.5 = 22
```

### Build Mage (Puissance Magique)
```
Rang: A (×1.7)
Niveau: 10 (50 points aptitudes)

Compétences:
├─ Magie: 10
├─ Volonté: 8
├─ Perception: 6
└─ Agilité: 4

Investissements aptitudes:
├─ Puissance Magique: 25 points
├─ Mana: 20 points
└─ PV: 5 points

RÉSULTAT:
• PM = (25 + 6 + 4 + 10) × 1.7 = 76
• Mana MAX = (20 + 1000 + 80) × 1.7 = 1870
• PV = (5 + 80 + 0) × 1.7 = 144
```

### Build Hybride (Équilibré)
```
Rang: S (×2.0)
Niveau: 15 (75 points aptitudes)

Compétences:
├─ Force: 6
├─ Endurance: 5
├─ Magie: 7
├─ Agilité: 6
├─ Perception: 5
└─ Volonté: 6

Investissements aptitudes:
├─ Attaque: 18 points
├─ Puissance Magique: 18 points
├─ PV: 20 points
└─ Mana: 19 points

RÉSULTAT:
• ATQ = (18 + 6 + 6 + 5) × 2.0 = 70
• PM = (18 + 5 + 6 + 7) × 2.0 = 72
• PV MAX = (20 + 60 + 500) × 2.0 = 1160
• Mana MAX = (19 + 700 + 60) × 2.0 = 1558
```

---

## ⚠️ POINTS IMPORTANTS

### 1. **Recalcul Automatique**
Les aptitudes se recalculent **automatiquement** quand vous :
- Changez une valeur de compétence
- Montez de niveau
- Changez de rang
- Investissez des points d'aptitudes
- Cochez/décochez fatigue ou blessures

### 2. **Points Non Perdus**
Les points de compétences et d'aptitudes sont **cumulatifs** :
- Passer de Rang C à Rang B ajoute 10 points de compétences (ne retire rien)
- Monter de niveau ajoute 5 points d'aptitudes (ne retire rien)

### 3. **Réductions Cumulatives**
Fatigue ET blessures se **cumulent** :
- f6 + b6 = -25% -30% = **-55%** sur ATQ et PM
- Peut rendre un personnage inutile en combat !

### 4. **Différence Character vs Cyberpunk**
Les deux fiches utilisent maintenant **exactement les mêmes calculs**.
La seule différence est **visuelle** (thème fantasy vs cyberpunk).

---

## 🚀 INSTALLATION

### Nouvelle Installation :
1. Extraire `ffdreame-system-v3.7-COMPLETE.zip` dans `Data/systems/`
2. Nommer le dossier `ffdreame`
3. Redémarrer Foundry VTT
4. Créer un monde avec le système "FFdreame"

### Mise à Jour :
1. **Sauvegarder votre dossier actuel**
2. Remplacer les fichiers suivants :
   - `module/documents/actor.js`
   - `module/sheets/actor-sheet.js`
   - `templates/actor/cyberpunk-character-sheet.html`
   - `css/cyberpunk.css`
3. Rafraîchir Foundry (F5)
4. Aucune migration de données nécessaire

---

## 🎉 BON JEU !

Toutes les fonctionnalités sont maintenant synchronisées entre les fiches Character et Cyberpunk.
Profitez du système de progression complet avec calculs automatiques !

**Version : 3.7**
**Date : 3 Février 2026**
