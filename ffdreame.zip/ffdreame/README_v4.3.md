# 🔥 FFdreame v4.3 - CORRECTIONS FINALES

## ✅ PROBLÈMES CORRIGÉS

### 1. ❌ Bouton "Ajouter une Technique" ne fonctionnait pas
**✅ CORRIGÉ** : Le bouton s'affiche maintenant correctement et vous pouvez ajouter jusqu'à 10 techniques !

### 2. ❌ Token pas dans un cercle + Aptitudes mal positionnées  
**✅ CORRIGÉ** : 
- Token maintenant dans un **CERCLE** comme les aptitudes
- Les 4 aptitudes sont **AUTOUR** du token (Haut, Bas, Gauche, Droite)
- Clic sur token = changer image
- Clic droit = Prototype Token

---

## 🎯 RÉSULTAT VISUEL

### Onglet Principal

```
        ┌─────────────┐
        │  [ATTAQUE]  │
        │     150     │
        └─────────────┘
              ↑
              │
┌──────┐      │      ┌──────────────┐
│ [PM] │      │      │ [PUISSANCE]  │
│ 60/60│ ←  [🖼️]  → │     120      │
└──────┘    TOKEN    └──────────────┘
              │
              ↓
        ┌─────────────┐
        │    [PV]     │
        │   100/100   │
        └─────────────┘
```

**Le token est un CERCLE au centre, les aptitudes sont AUTOUR !**

### Onglet Techniques (dans Posture)

```
╔══════════════════════════════════════╗
║  Techniques créées : 0 / 10          ║
╠══════════════════════════════════════╣
║  Aucune technique créée              ║
║  Cliquez sur "➕ Ajouter"           ║
║                                      ║
║  [➕ Ajouter une Technique (1/10)]   ║
╚══════════════════════════════════════╝
```

**Le bouton fonctionne ! Cliquez et créez vos techniques !**

---

## 🚀 INSTALLATION

### 1. Extraire l'archive
```
ffdreame-v4.3-FINAL.zip → Extraire
```

### 2. Remplacer les fichiers
```
Copier le contenu dans :
systems/ffdreame/
```

### 3. Redémarrer Foundry VTT
```
Arrêter → Relancer → Rafraîchir (F5)
```

---

## 🧪 TEST RAPIDE

### Test Token (30 secondes)

1. Ouvrir une fiche personnage
2. Onglet **Principal**
3. ✅ Token visible au centre dans un cercle
4. ✅ Aptitude ATTAQUE en HAUT
5. ✅ Aptitude PM à GAUCHE
6. ✅ Aptitude PUISSANCE à DROITE
7. ✅ Aptitude PV en BAS
8. Cliquer sur le token → Choisir nouvelle image ✅
9. Clic droit sur token → Config Prototype ✅

### Test Techniques (1 minute)

1. **Créer Item** → Type "Posture"
2. Nom : "Test"
3. **Onglet ⚡ Techniques**
4. ✅ Message "Aucune technique créée"
5. ✅ Bouton "➕ Ajouter une Technique (1/10)"
6. Cliquer sur "➕" → **Technique #1 apparaît** ✅
7. Remplir : Nom "Griffe", PM 15, Dégâts 30
8. Cliquer à nouveau "➕" → **Technique #2 apparaît** ✅
9. Cliquer encore "➕" → **Technique #3 apparaît** ✅
10. Compteur affiche "3 / 10" ✅
11. **SUCCÈS ! Vous pouvez créer plusieurs techniques !** 🎉

---

## 📋 FICHIERS MODIFIÉS

### v4.3 - Corrections Finales

1. **templates/actor/character-sheet.html**
   - Token en cercle au centre
   - Aptitudes autour (Haut/Bas/Gauche/Droite)

2. **templates/item/posture-sheet.html**
   - Bouton "Ajouter" toujours visible
   - Pas de limite artificielle

3. **module/sheets/actor-sheet.js**
   - Méthodes `_onTokenImageClick()` ajoutée
   - Méthode `_onTokenConfigClick()` ajoutée

4. **module/sheets/item-sheet.js**
   - Limite de 10 techniques vérifiée
   - Messages de notification

5. **css/ffdreame.css**
   - Styles token en cercle
   - Positionnement aptitudes en croix
   - Hover overlay sur token

---

## ✅ FONCTIONNALITÉS COMPLÈTES

### Token Central
- ✅ Dans un cercle comme les aptitudes
- ✅ Cliquable pour changer l'image
- ✅ Clic droit pour Prototype Token
- ✅ Hover avec icône caméra
- ✅ Nom du personnage en bas

### Aptitudes en Cercle
- ✅ ATTAQUE en HAUT
- ✅ PM à GAUCHE  
- ✅ PUISSANCE à DROITE
- ✅ PV en BAS
- ✅ Détails positionnés correctement
- ✅ Boutons + accessibles

### Techniques Multiple
- ✅ Jusqu'à 10 techniques par posture
- ✅ Bouton "Ajouter" toujours fonctionnel
- ✅ Compteur de techniques
- ✅ Confirmation de suppression
- ✅ Messages de notification
- ✅ Numérotation automatique

---

## 🎨 STYLES

### Token
- Cercle de 150px
- Bordure dorée (comme les aptitudes)
- Image ronde
- Effet hover avec overlay noir
- Icône caméra au survol

### Aptitudes
- Même style qu'avant
- Repositionnées en croix autour du token
- Distance de ~200px du centre
- Labels et valeurs visibles
- Boutons + accessibles

---

## 📊 CAPACITÉS TOTALES

### Par Personnage
- **1 Token central** personnalisable
- **4 Aptitudes** en cercle autour
- **2 Postures** maximum
- **10 Techniques** par posture
- = **20 TECHNIQUES AU TOTAL** ! 🎉

### Par Posture
- 1 Nom
- 1 Description
- 1 Attaque Base
- 1 Effet de posture
- 1 Ultimate
- **10 Techniques** configurables

---

## 🐛 SI ÇA NE MARCHE PAS

### Le bouton "Ajouter" n'apparaît pas
**Solution :**
- Vous devez être **MJ** (Game Master)
- Les joueurs ne peuvent pas ajouter de techniques
- Se connecter en tant que MJ

### Le token n'est pas un cercle
**Solution :**
- Vider le cache : **Ctrl+Shift+R**
- Vérifier que le fichier CSS est bien remplacé
- Redémarrer Foundry VTT

### Les aptitudes sont mal placées
**Solution :**
- Rafraîchir la page (F5)
- Vérifier les fichiers :
  - `templates/actor/character-sheet.html`
  - `css/ffdreame.css`

### Le bouton "Ajouter" ne fait rien
**Solution :**
- Console F12 pour voir les erreurs
- Vérifier que `module/sheets/item-sheet.js` est bien remplacé
- Redémarrer Foundry VTT

---

## 💡 CONSEILS

### Créer des Postures Équilibrées

**Techniques Légères** (1-3) :
- Petit PA, 10-15 PM
- 20-30 dégâts
- Actions rapides

**Techniques Moyennes** (4-6) :
- Grand PA, 15-25 PM
- 30-50 dégâts
- Actions principales

**Techniques Puissantes** (7-9) :
- Grand PA, 25-40 PM
- 50-80 dégâts
- Finishers

**Technique Utilitaire** (10) :
- BUFF ou support
- Soin, bouclier, bonus

---

## 🎊 C'EST PRÊT !

Votre système FFdreame v4.3 est maintenant **COMPLET** et **FONCTIONNEL** :

✅ Token central en cercle
✅ Aptitudes autour (croix)
✅ Techniques multiples (10 max)
✅ Interface professionnelle
✅ Messages de confirmation
✅ Badges colorés
✅ Formules automatiques

**Profitez de votre système ! ⚔️🔥**

---

**FFdreame System v4.3 - "Corrections Finales"**
*Février 2026*
