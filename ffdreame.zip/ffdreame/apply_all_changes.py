#!/usr/bin/env python3
import re

print("🔧 Application de TOUTES les modifications...")

# ===== 1. CHARACTER-SHEET.HTML - Ajouter interface GM effets =====
print("1️⃣  Ajout interface GM effets tableaux...")

with open('templates/actor/character-sheet.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Chercher où insérer (après les slots du tableau 1)
marker1 = '</div>\n            </div>\n\n            <!-- TABLEAU 2'

if marker1 in html:
    # Interface GM pour tableau 1
    interface_gm_t1 = '''</div>
            </div>

            <!-- INTERFACE EFFETS GM - TABLEAU 1 -->
            {{#if @root.isGM}}
            <div class="tableau-effet-gm">
              <button type="button" class="effet-gm-btn" data-table="1">⭐ Effet</button>
              <div class="effet-gm-panel" data-table="1" style="display:none;">
                <select name="system.combat.tableau1.effet.typebonus" class="effet-gm-select">
                  <option value="">Aucun</option>
                  <option value="initiative" {{#if (eq system.combat.tableau1.effet.typebonus "initiative")}}selected{{/if}}>Initiative</option>
                  <option value="degats" {{#if (eq system.combat.tableau1.effet.typebonus "degats")}}selected{{/if}}>Bonus dégâts</option>
                  <option value="parade" {{#if (eq system.combat.tableau1.effet.typebonus "parade")}}selected{{/if}}>Parade auto</option>
                  <option value="regen_pa" {{#if (eq system.combat.tableau1.effet.typebonus "regen_pa")}}selected{{/if}}>Régén PA</option>
                  <option value="bonus_jet" {{#if (eq system.combat.tableau1.effet.typebonus "bonus_jet")}}selected{{/if}}>Bonus jet</option>
                </select>
                <input type="number" name="system.combat.tableau1.effet.valeur" value="{{system.combat.tableau1.effet.valeur}}" class="effet-gm-input" placeholder="Valeur"/>
                <select name="system.combat.tableau1.effet.condition" class="effet-gm-select">
                  <option value="">Aucune</option>
                  <option value="x_reussites" {{#if (eq system.combat.tableau1.effet.condition "x_reussites")}}selected{{/if}}>X réussites</option>
                </select>
                <input type="number" name="system.combat.tableau1.effet.seuil" value="{{system.combat.tableau1.effet.seuil}}" class="effet-gm-input-sm" placeholder="Seuil"/>
                <select name="system.combat.tableau1.effet.tableauApplication" class="effet-gm-select">
                  <option value="meme" {{#if (eq system.combat.tableau1.effet.tableauApplication "meme")}}selected{{/if}}>Même</option>
                  <option value="autre" {{#if (eq system.combat.tableau1.effet.tableauApplication "autre")}}selected{{/if}}>Autre</option>
                  <option value="les_deux" {{#if (eq system.combat.tableau1.effet.tableauApplication "les_deux")}}selected{{/if}}>Les deux</option>
                </select>
                <span class="effet-gm-compteur">{{system.combat.tableau1.effet.compteur}}/{{system.combat.tableau1.effet.seuil}}</span>
                <button type="button" class="reset-effet-gm" data-table="1">🔄</button>
              </div>
            </div>
            {{/if}}

            <!-- TABLEAU 2'''
    
    html = html.replace(marker1, interface_gm_t1)
    print("   ✅ Interface tableau 1 ajoutée")
else:
    print("   ❌ Marker tableau 1 non trouvé")

# Interface pour tableau 2
marker2 = '</div>\n          </div>\n\n        <!-- ======= ATOUTS'

if marker2 in html:
    interface_gm_t2 = '''</div>
          </div>

          <!-- INTERFACE EFFETS GM - TABLEAU 2 -->
          {{#if @root.isGM}}
          <div class="tableau-effet-gm">
            <button type="button" class="effet-gm-btn" data-table="2">⭐ Effet</button>
            <div class="effet-gm-panel" data-table="2" style="display:none;">
              <select name="system.combat.tableau2.effet.typebonus" class="effet-gm-select">
                <option value="">Aucun</option>
                <option value="initiative" {{#if (eq system.combat.tableau2.effet.typebonus "initiative")}}selected{{/if}}>Initiative</option>
                <option value="degats" {{#if (eq system.combat.tableau2.effet.typebonus "degats")}}selected{{/if}}>Bonus dégâts</option>
                <option value="parade" {{#if (eq system.combat.tableau2.effet.typebonus "parade")}}selected{{/if}}>Parade auto</option>
                <option value="regen_pa" {{#if (eq system.combat.tableau2.effet.typebonus "regen_pa")}}selected{{/if}}>Régén PA</option>
                <option value="bonus_jet" {{#if (eq system.combat.tableau2.effet.typebonus "bonus_jet")}}selected{{/if}}>Bonus jet</option>
              </select>
              <input type="number" name="system.combat.tableau2.effet.valeur" value="{{system.combat.tableau2.effet.valeur}}" class="effet-gm-input" placeholder="Valeur"/>
              <select name="system.combat.tableau2.effet.condition" class="effet-gm-select">
                <option value="">Aucune</option>
                <option value="x_reussites" {{#if (eq system.combat.tableau2.effet.condition "x_reussites")}}selected{{/if}}>X réussites</option>
              </select>
              <input type="number" name="system.combat.tableau2.effet.seuil" value="{{system.combat.tableau2.effet.seuil}}" class="effet-gm-input-sm" placeholder="Seuil"/>
              <select name="system.combat.tableau2.effet.tableauApplication" class="effet-gm-select">
                <option value="meme" {{#if (eq system.combat.tableau2.effet.tableauApplication "meme")}}selected{{/if}}>Même</option>
                <option value="autre" {{#if (eq system.combat.tableau2.effet.tableauApplication "autre")}}selected{{/if}}>Autre</option>
                <option value="les_deux" {{#if (eq system.combat.tableau2.effet.tableauApplication "les_deux")}}selected{{/if}}>Les deux</option>
              </select>
              <span class="effet-gm-compteur">{{system.combat.tableau2.effet.compteur}}/{{system.combat.tableau2.effet.seuil}}</span>
              <button type="button" class="reset-effet-gm" data-table="2">🔄</button>
            </div>
          </div>
          {{/if}}

        <!-- ======= ATOUTS'''
    
    html = html.replace(marker2, interface_gm_t2)
    print("   ✅ Interface tableau 2 ajoutée")
else:
    print("   ❌ Marker tableau 2 non trouvé")

with open('templates/actor/character-sheet.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("✅ character-sheet.html modifié")


# ===== 2. TECHNIQUE-SHEET.HTML - Ajouter onglet Animation =====
print("2️⃣  Ajout onglet Animation...")

with open('templates/item/technique-sheet.html', 'r', encoding='utf-8') as f:
    technique_html = f.read()

# Ajouter l'onglet dans la navigation
if 'data-tab="animation"' not in technique_html:
    nav_marker = '<a class="item" data-tab="degats">💥 Dégâts</a>'
    if nav_marker in technique_html:
        technique_html = technique_html.replace(
            nav_marker,
            nav_marker + '\n    <a class="item" data-tab="animation">🎬 Animation</a>'
        )
        print("   ✅ Onglet ajouté à la navigation")

# Ajouter le contenu de l'onglet (version SIMPLE pour l'instant, on peut l'enrichir après)
if 'tab animation' not in technique_html:
    content_marker = '  </div><!-- end item-sheet-body -->'
    if content_marker in technique_html:
        animation_tab = '''
    <!-- ===== ONGLET ANIMATION ===== -->
    <div class="tab animation" data-group="item-primary" data-tab="animation">
      <div class="technique-tab-content">
        <label><input type="checkbox" name="system.animation.enabled" {{#if system.animation.enabled}}checked{{/if}}/> Activer l'animation</label>
        
        <div style="margin-top:15px;">
          <label>Animation:</label>
          <input type="text" name="system.animation.path" value="{{system.animation.path}}" placeholder="jb2a.fire_bolt.orange" style="width:100%;"/>
        </div>
        
        <div style="margin-top:15px;">
          <label>Type:</label>
          <select name="system.animation.type" style="width:100%;">
            <option value="projectile" {{#if (eq system.animation.type "projectile")}}selected{{/if}}>Projectile</option>
            <option value="explosion" {{#if (eq system.animation.type "explosion")}}selected{{/if}}>Explosion</option>
            <option value="melee" {{#if (eq system.animation.type "melee")}}selected{{/if}}>Corps à corps</option>
          </select>
        </div>
        
        <div style="margin-top:15px;">
          <label>Taille:</label>
          <input type="number" name="system.animation.options.scale" value="{{system.animation.options.scale}}" step="0.1" min="0.1" max="5" style="width:100%;"/>
        </div>
        
        <div style="margin-top:15px;">
          <label><input type="checkbox" name="system.animation.targeting.stretchTo" {{#if system.animation.targeting.stretchTo}}checked{{/if}}/> Étirer vers la cible</label>
        </div>
      </div>
    </div>

  </div><!-- end item-sheet-body -->'''
        
        technique_html = technique_html.replace(content_marker, animation_tab)
        print("   ✅ Contenu onglet Animation ajouté")

with open('templates/item/technique-sheet.html', 'w', encoding='utf-8') as f:
    f.write(technique_html)

print("✅ technique-sheet.html modifié")


# ===== 3. CSS - Ajouter styles =====
print("3️⃣  Ajout CSS...")

css_effets_gm = '''
/* Interface GM Effets Tableaux */
.tableau-effet-gm {
  margin-top: 8px;
  padding: 5px;
  background: rgba(255, 215, 0, 0.1);
  border-radius: 4px;
}

.effet-gm-btn {
  width: 100%;
  padding: 5px;
  background: linear-gradient(135deg, #ffd700, #ffa500);
  border: none;
  border-radius: 3px;
  color: #333;
  font-weight: bold;
  font-size: 11px;
  cursor: pointer;
}

.effet-gm-btn:hover {
  background: linear-gradient(135deg, #ffed4e, #ffb347);
}

.effet-gm-panel {
  display: grid;
  grid-template-columns: 2fr 1fr 1.5fr 0.8fr 1.5fr 0.8fr 0.5fr;
  gap: 5px;
  margin-top: 8px;
  padding: 8px;
  background: white;
  border-radius: 3px;
}

.effet-gm-select,
.effet-gm-input,
.effet-gm-input-sm {
  padding: 4px;
  border: 1px solid #ccc;
  border-radius: 2px;
  font-size: 11px;
}

.effet-gm-compteur {
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f0f0;
  border-radius: 2px;
  font-size: 10px;
  font-weight: bold;
  color: #ffa500;
}

.reset-effet-gm {
  padding: 4px;
  background: #ff6b6b;
  color: white;
  border: none;
  border-radius: 2px;
  cursor: pointer;
  font-size: 10px;
}

.reset-effet-gm:hover {
  background: #ff5252;
}
'''

with open('css/ffdreame.css', 'a', encoding='utf-8') as f:
    f.write('\n\n' + css_effets_gm)

print("✅ CSS ajouté")

print("\n🎉 TOUTES LES MODIFICATIONS APPLIQUÉES !")
print("✅ Effets GM tableaux")
print("✅ Onglet Animation")
print("✅ CSS")
