# 🎯 FFdreame - Version FINALE avec Interface d'Effets

## ✨ NOUVELLE FONCTIONNALITÉ : Interface graphique pour les effets !

Configurez les effets de vos tableaux **directement dans la fiche de personnage** !

Plus besoin de console F12 ou de macros compliquées. Tout est **visuel** et **intuitif** ! 🎨

---

## 🎮 Comment ça marche ?

### En 3 clics

```
1. Ouvrez votre fiche → Onglet Combat
2. Cliquez sur "⚡ Effet passif" sous un tableau
3. Configurez : Type + Seuil + Bonus
```

**C'est tout !** ✅

---

## 🎯 7 types d'effets disponibles

### Effets à compteur (après X réussites)

1. **Bonus de dégâts** → +50 dégâts après 5 réussites
2. **Récupération PM** → +30 PM après 3 réussites
3. **Parade** → Jet de parade après 4 réussites

### Effets permanents (tableau actif)

4. **Initiative automatique** → Commence toujours en premier
5. **Bonus dégâts permanent** → +20 dégâts à toutes les attaques
6. **Bonus PM permanent** → +50 PM max
7. **Bonus Burste** → +15 Burste au lieu de +10

---

## 🎨 Interface visuelle

### Bouton "⚡ Effet passif"

Sous chaque tableau, un beau bouton bleu avec animation.

### Formulaire déroulant

- Menu déroulant pour choisir le type
- Champs pour Seuil et Bonus
- Description personnalisable
- **Sauvegarde automatique** ✅

### Barre de progression

```
Progression : 3 / 5  [🔄]
```

Voir en temps réel votre progression vers l'activation !

---

## 💡 Exemple d'utilisation

### Configuration

```
Tableau 1 : "Assaut"
└─ ⚡ Effet passif (cliquer)
   ├─ Type : Bonus dégâts après X réussites
   ├─ Seuil : 5
   ├─ Bonus : 50
   └─ Description : "Frappe dévastatrice"
```

### En combat

```
Attaque 1 → Réussite → Progression : 1/5
Attaque 2 → Réussite → Progression : 2/5
Attaque 3 → Réussite → Progression : 3/5
Attaque 4 → Réussite → Progression : 4/5
Attaque 5 → Réussite → Progression : 5/5

🔥 BONUS ACTIVÉ ! +50 dégâts

Prochaine attaque → +50 dégâts supplémentaires !
Progression : 0/5 (reset automatique)
```

---

## 📦 Installation

### Installation complète

```bash
1. Désactiver FFdreame
2. Supprimer Data/systems/ffdreame/
3. Extraire ffdreame-interface-effets.zip
4. Réactiver FFdreame
5. Ctrl+F5 pour recharger
```

### Mise à jour depuis version précédente

Remplacer ces fichiers :
```
template.json
templates/actor/character-sheet.html
css/ffdreame.css
module/sheets/actor-sheet.js
module/combat/tableau-effets.js
```

---

## ✅ Tout inclus dans cette version

### Corrections précédentes

✅ **Pas de templates** - Les carrés jaunes ne s'affichent plus  
✅ **Ordre dégâts Multi** - Cible principale = 100% garantis  
✅ **PA immédiatement** - Consommés dès le jet  
✅ **Burste +10 fixe** - Peu importe le nombre de cibles  

### Nouvelles fonctionnalités

✅ **Système d'effets** - 7 types d'effets pour les tableaux  
✅ **Interface graphique** - Configuration visuelle dans la fiche  
✅ **Compteur en temps réel** - Voir la progression  
✅ **Sauvegarde auto** - Pas de bouton "Sauvegarder" nécessaire  

---

## 🎯 Avantages de l'interface

| Avant | Maintenant |
|-------|------------|
| Console F12 complexe | Clic sur un bouton |
| Code JavaScript à écrire | Formulaire simple |
| Pas de retour visuel | Compteur en temps réel |
| Macros à créer | Tout intégré |

---

## 📚 Documentation

- **GUIDE_INTERFACE_EFFETS.md** - Guide complet de l'interface
- **CORRECTION_FINALE.md** - Détails des corrections Multi
- **README_FINAL.md** - Vue d'ensemble système Multi

---

## 🎮 Pour commencer

### 1. Testez l'interface

```
1. Ouvrez n'importe quel personnage
2. Onglet Combat
3. Cliquez "⚡ Effet passif" sous Tableau 1
4. Regardez l'interface se déployer !
```

### 2. Configurez votre premier effet

```
Type : Bonus dégâts après X réussites
Seuil : 5
Bonus : 30
Description : Mon premier effet !
```

### 3. Testez en combat

```
1. Ajoutez 5 techniques au Tableau 1
2. En combat, utilisez-les
3. Regardez le compteur : 1/5, 2/5, 3/5...
4. À 5/5 → BOOM ! +30 dégâts activé
```

---

## 🐛 Dépannage

### L'interface ne s'affiche pas

**Solution** :
1. Ctrl+F5 pour vider le cache
2. Vérifiez que le tableau est activé (toggle ON)
3. Réouvrez la fiche

### Les changements ne se sauvegardent pas

**Solution** :
1. Êtes-vous propriétaire du personnage ?
2. Fermez et rouvrez la fiche
3. Vérifiez la console F12 pour les erreurs

### Le compteur ne bouge pas

**Solution** :
1. Vérifiez que l'effet est bien configuré
2. La technique doit RÉUSSIR pour compter
3. La technique doit venir de CE tableau

---

## 🎨 Captures d'écran

### Bouton fermé

```
┌───────────────────────────┐
│  [Tableau 1: Assaut    ]  │
│  ┌─────────────────────┐  │
│  │  [Slot 1] [Slot 2] │  │
│  └─────────────────────┘  │
│  ┌─────────────────────┐  │
│  │ ⚡ Effet passif     │  │ ← Cliquer ici
│  └─────────────────────┘  │
└───────────────────────────┘
```

### Bouton ouvert

```
┌───────────────────────────┐
│  [Tableau 1: Assaut    ]  │
│  ┌─────────────────────┐  │
│  │  [Slot 1] [Slot 2] │  │
│  └─────────────────────┘  │
│  ┌─────────────────────┐  │
│  │ ⚡ Effet passif     │  │
│  └─────────────────────┘  │
│  ┌─────────────────────┐  │
│  │ Type: [Bonus dégâts]│  │
│  │ Seuil: [5]  Bonus:  │  │
│  │        [50]         │  │
│  │ Description: ...    │  │
│  │                     │  │
│  │ Progression: 3/5 🔄 │  │
│  └─────────────────────┘  │
└───────────────────────────┘
```

---

## 🏆 Builds recommandés

### Build Berserker

**Tableau 1** : Bonus dégâts après 5 réussites (+50)  
**Tableau 2** : Récup PM après 3 réussites (+30)

**Stratégie** :
- Phase agressive avec Tableau 1
- Switch Tableau 2 pour récupérer
- Retour Tableau 1 avec bonus prêt

### Build Tank

**Tableau 1** : Parade après 4 réussites  
**Tableau 2** : Bonus PM permanent (+50)

**Stratégie** :
- Tableau 1 pour accumuler parade
- Tableau 2 pour plus de PM et techniques défensives

### Build Leader

**Tableau 1** : Initiative automatique  
**Tableau 2** : Bonus Burste (+15 au lieu de +10)

**Stratégie** :
- Joue toujours en premier
- Remplit la burste plus vite
- Ultimate plus rapidement

---

## ⚡ Performance

- **Sauvegarde instantanée** - Pas d'attente
- **Animation fluide** - Interface réactive
- **Mise à jour temps réel** - Compteur synchronisé
- **Léger** - Aucun impact sur les performances

---

**Profitez de vos tableaux personnalisés !** 🎉

Version : FINALE avec interface graphique  
Date : Février 2026  
Compatibilité : Foundry VTT v11/v12
