# FFdreame - Version Modifiée v4.0

## 🎉 Bienvenue !

Cette archive contient votre système FFdreame avec 3 modifications majeures :

1. ✅ **Token Central Interactif** dans l'onglet Principal
2. ✅ **Suppression de la Grande Barre Burst**
3. ✅ **Documentation complète du Système Postures/Techniques**

---

## 📚 DOCUMENTATION INCLUSE

### 1. **MODIFICATIONS_NOUVELLES.md** (Guide Complet)
   - Documentation détaillée de toutes les modifications
   - Instructions d'installation
   - Guide d'utilisation
   - Section dépannage
   - Plus de 400 lignes de documentation

### 2. **RESUME_RAPIDE.md** (Guide Visuel)
   - Résumé visuel des changements
   - Diagrammes avant/après
   - Checklist rapide
   - Problèmes fréquents

---

## 🚀 INSTALLATION RAPIDE

### Option 1 : Remplacement Complet
```
1. Sauvegarder votre dossier actuel systems/ffdreame/
2. Extraire cette archive
3. Copier tout le contenu dans systems/ffdreame/
4. Redémarrer Foundry VTT
5. Rafraîchir la page (F5)
```

### Option 2 : Remplacement Sélectif
```
Remplacer uniquement ces 3 fichiers :
- templates/actor/character-sheet.html
- css/ffdreame.css
- module/sheets/actor-sheet.js
```

---

## 🔍 FICHIERS MODIFIÉS

Les fichiers suivants ont été modifiés :

### 1. `templates/actor/character-sheet.html`
**Modifications :**
- Ajout du token central avec cercles d'aptitudes (lignes ~166-216)
- Suppression de la grande section Burst (lignes ~475-486)

**Sauvegardes :**
- Fichier original sauvegardé comme `character-sheet.html.backup`

### 2. `css/ffdreame.css`
**Modifications :**
- Ajout styles pour token central et disposition en cercle (après ligne 550)
- Masquage de `.burste-section` avec `display: none;` (ligne 2182)

**Sauvegardes :**
- Fichier original sauvegardé comme `ffdreame.css.backup`

### 3. `module/sheets/actor-sheet.js`
**Modifications :**
- Ajout event listeners pour le token central (lignes 173-174)

**Sauvegardes :**
- Fichier original sauvegardé comme `actor-sheet.js.backup`

---

## ⚡ TESTS RAPIDES

### Test 1 : Token Central
```
1. Ouvrir une fiche personnage
2. Aller dans l'onglet "Principal"
3. Observer le token au centre avec les 4 aptitudes autour
4. Cliquer sur le token → sélectionner une image
5. Clic droit → configurer Prototype Token
```

### Test 2 : Suppression Burst
```
1. Ouvrir une fiche personnage
2. Aller dans l'onglet "Combat"
3. Vérifier que la grande barre Burst a disparu
4. Vérifier que la petite barre en haut est toujours là
```

### Test 3 : Postures & Techniques
```
1. Créer une posture nommée "Test Combat"
2. Créer une technique avec :
   - Nom : "Attaque Rapide"
   - Style : CAC
   - Coût PM : 10
   - Base Dégâts : 30
   - Posture Associée : "Test Combat" (EXACTEMENT)
3. Ouvrir onglet Combat
4. Activer la posture "Test Combat"
5. Vérifier que "Attaque Rapide" apparaît
6. Cliquer sur la technique pour lancer un jet
```

---

## 🛡️ SÉCURITÉ & SAUVEGARDES

### Fichiers de Sauvegarde Inclus
```
- templates/actor/character-sheet.html.backup
- css/ffdreame.css.backup
- module/sheets/actor-sheet.js.backup
```

### Restaurer l'Original
Si vous voulez revenir en arrière :
```
1. Supprimer les fichiers modifiés
2. Renommer les fichiers .backup en enlevant .backup
3. Redémarrer Foundry VTT
```

---

## 📖 UTILISATION DES NOUVELLES FONCTIONNALITÉS

### Token Central
- **Fonction** : Affichage visuel du personnage au centre de la fiche
- **Clic gauche** : Change l'image du personnage
- **Clic droit** : Ouvre la configuration du Prototype Token
- **Visuel** : Bordure dorée avec effet lumineux
- **Animation** : Agrandissement au survol

### Disposition des Aptitudes
```
          [ATTAQUE]
              ↑
              |
   [PM] ← [TOKEN] → [PUISSANCE MAGIQUE]
              |
              ↓
            [PV]
```

### Système Postures/Techniques

#### Créer une Posture
1. Menu Items → Créer Item → Type "Posture"
2. Remplir : Nom, Description, Attaque Base, Effets
3. (Optionnel) Ultimate avec nom, description, dégâts

#### Créer une Technique
1. Menu Items → Créer Item → Type "Technique"
2. Remplir :
   - **Nom** : Nom de la technique
   - **Style** : CAC, MG, P, EHa, EHm, EF, ou BUFF
   - **Coût PM** : Points magiques requis
   - **Base Dégâts** : Dégâts de base
   - **Posture Associée** : ⚠️ Nom EXACT de la posture

#### ⚠️ IMPORTANT : Nom Exact
Le champ "Posture Associée" doit contenir le nom **EXACT** de la posture :
- ✅ Correct : `"Dragon Fury"` → `"Dragon Fury"`
- ❌ Incorrect : `"dragon fury"`, `"Dragon fury"`, `"DragonFury"`

**Astuce** : Copier-coller le nom de la posture dans la technique !

---

## 🎨 STYLES DE TECHNIQUE

| Style | Formule | Description |
|-------|---------|-------------|
| **CAC** | ATQ + (PM ÷ 2) + Base | Corps à corps avec magie |
| **MG** | (ATQ ÷ 2) + PM + Base | Magie pure guidée |
| **P** | ATQ + PM + Base | Parfait (équilibre total) |
| **EHa** | ATQ + Base | Éclat Haine (Attaque) - 3 jets |
| **EHm** | PM + Base | Éclat Haine (Magie) - 3 jets |
| **EF** | PM + Base + (ATQ ÷ 2) | Éclat Foudre avec effets |
| **BUFF** | Pas de dégâts | Soins, buffs, bonus |

---

## 🐛 DÉPANNAGE

### Le token ne s'affiche pas
**Solution :**
1. Vérifier que le fichier CSS a été correctement remplacé
2. Vider le cache du navigateur (Ctrl+Shift+R)
3. Vérifier dans F12 si les styles sont chargés

### La grande barre Burst est toujours visible
**Solution :**
1. Vérifier que `display: none;` est dans `.burste-section`
2. Vider le cache du navigateur
3. Redémarrer Foundry VTT

### Les techniques n'apparaissent pas dans la posture
**Solutions :**
1. Vérifier que le nom dans "Posture Associée" est **EXACTEMENT** le même
2. Vérifier que l'item est bien de type "technique"
3. Fermer et rouvrir la fiche personnage
4. Console F12 : `game.actors.getName("NomPerso").items.filter(i => i.type === "technique")`

### Le token ne répond pas au clic
**Solution :**
1. Vérifier que le fichier JS a été correctement remplacé
2. Vérifier la console F12 pour des erreurs
3. Redémarrer Foundry VTT

---

## 📊 COMPATIBILITÉ

- ✅ Compatible avec tous les personnages existants
- ✅ Compatible avec toutes les fonctionnalités existantes
- ✅ Pas de perte de données
- ✅ Réversible avec les fichiers .backup

---

## 🎯 FONCTIONNALITÉS CONSERVÉES

Toutes les fonctionnalités existantes sont conservées :

- ✅ Système de compétences (Physique, Dextérité, Intelligence, Charisme)
- ✅ Système d'aptitudes (Attaque, PM, PV, Puissance Magique)
- ✅ Points d'action (Petits et Grands PA)
- ✅ Fatigue et Blessures
- ✅ Petite barre Burst (en haut de l'onglet Combat)
- ✅ Calcul automatique du Burst (+10 attaque, +5 coup reçu)
- ✅ Système de Talents
- ✅ Atouts de combat
- ✅ Gestion du niveau et rang
- ✅ Toutes les formules de calcul existantes

---

## 📞 SUPPORT

### Ressources Incluses
1. **MODIFICATIONS_NOUVELLES.md** - Guide complet détaillé
2. **RESUME_RAPIDE.md** - Guide visuel rapide
3. **Fichiers .backup** - Sauvegardes originales
4. **Ce README** - Vue d'ensemble et installation

### En Cas de Problème
1. Consulter la section DÉPANNAGE ci-dessus
2. Vérifier les fichiers .backup pour restaurer
3. Consulter la console F12 du navigateur
4. Utiliser la commande : `game.actors.getName("NomPerso")` dans la console

---

## 🎮 PRÊT À JOUER !

Votre système FFdreame est maintenant amélioré avec :
- 🖼️ Token central interactif
- 🔥 Interface Combat optimisée
- ⚔️ Système Postures/Techniques documenté
- 📚 Documentation complète

**Amusez-vous bien ! 🎉**

---

## 📝 CHANGELOG

### Version 4.0 (Février 2026)
- ➕ Ajout du token central interactif dans l'onglet Principal
- ➕ Disposition en cercle des aptitudes autour du token
- ➖ Suppression de la grande section Burst de l'onglet Combat
- 📖 Documentation complète du système Postures/Techniques
- 💾 Fichiers de sauvegarde créés automatiquement
- 📚 Guides d'utilisation détaillés inclus

---

**FFdreame System - Cyberpunk Fantasy RPG**
*Version Modifiée v4.0 - Février 2026*
