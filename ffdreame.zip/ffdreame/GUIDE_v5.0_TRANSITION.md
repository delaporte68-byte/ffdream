# 🎮 FFdreame v5.0 - Système d'objets Attaque & Ultimate

## ⚠️ VERSION EN CONSTRUCTION

Cette version transforme complètement le système de combat avec des **objets indépendants**.

---

## ✅ CE QUI A ÉTÉ FAIT

### 1. **Nouveaux types d'Items créés**

#### 📍 Type "Attaque"
- **Nom** : personnalisable
- **Description** : texte libre
- **Dégâts** : définis par le MJ
- **Icône** : choix parmi :
  - ⚔️ Épée
  - 🔫 Flingue
  - 🏑 Bâton
  - 🏹 Arc
  - 🔨 Marteau
  - 🪓 Hache
  - 🗡️ Dague
  - 👊 Poing

#### 🔥 Type "Ultimate"
- **Nom** : personnalisable
- **Description** : texte libre
- **Dégâts** : définis par le MJ
- **Condition** : Burste = 100
- **Effets spéciaux** :
  - 💥 **DEG** : Dégâts supplémentaires
  - ❤️ **SOINS** : Restaure X% des PV max
  - ⚡ **BUF PA** : +1 Grand PA (4 au total) pendant X tours
  - 🎯 **CRIT** : +X% de chance de critique

### 2. **Postures modifiées**

**Supprimé :**
- ❌ Attaque de base (maintenant objet séparé)
- ❌ Ultimate (maintenant objet séparé)

**Ajouté :**
- ✅ Onglet "Cases (8)" avec 8 emplacements

**Conservé :**
- ✅ Description
- ✅ Effet de posture
- ✅ Techniques (créées directement)

---

## 🚧 EN COURS DE DÉVELOPPEMENT

### Ce qu'il reste à faire :

1. **Fiche personnage** :
   - Supprimer l'affichage attaque/ultimate des postures
   - Créer 2 tableaux avec 8 cases chacun
   - Nom éditable pour chaque tableau
   - Icône d'activation

2. **Drag & Drop** :
   - Glisser objets Attaque/Ultimate dans les cases
   - Stocker l'ID de l'objet dans la case

3. **Interactivité** :
   - Clic sur case → Lance l'objet (jet de dés)
   - Gestion des effets spéciaux Ultimate

---

## 🎯 Comment créer les nouveaux objets

### Créer une Attaque :

```
1. Menu Items → Créer Item
2. Type: Attaque
3. Nom: "Frappe épée"
4. Dégâts: 50 (MJ)
5. Icône: ⚔️ Épée
6. Sauvegarder
```

### Créer un Ultimate :

```
1. Menu Items → Créer Item
2. Type: Ultimate
3. Nom: "Dragon Céleste"
4. Dégâts: 200 (MJ)
5. Effet: SOINS
6. Valeur: 30 (= 30% PV)
7. Sauvegarder
```

### Créer une Posture :

```
1. Menu Items → Créer Item
2. Type: Posture
3. Onglet "Description": Texte
4. Onglet "Effet Posture": Choisir effet
5. Onglet "Techniques": Créer techniques
6. Onglet "Cases (8)": (en attente drag & drop)
7. Sauvegarder
```

---

## 📊 Architecture actuelle

```
AVANT (v4.x):
Posture {
  - Attaque base
  - Ultimate
  - Techniques
}

MAINTENANT (v5.0):
Posture {
  - Effet
  - Techniques
  - 8 Cases (vides pour l'instant)
}

Attaque (objet séparé) {
  - Dégâts
  - Icône
}

Ultimate (objet séparé) {
  - Dégâts
  - Effet spécial
}
```

---

## ⚠️ LIMITATIONS ACTUELLES

- ❌ Les cases de posture ne sont pas encore utilisables
- ❌ La fiche personnage affiche encore l'ancien système
- ❌ Pas de drag & drop fonctionnel
- ❌ Les objets Attaque/Ultimate ne sont pas encore jouables

---

## 🚀 PROCHAINE ÉTAPE

**v5.1** : Implémentation complète des tableaux sur la fiche personnage avec drag & drop et interactions.

---

**Version actuelle** : 5.0 (Transition)  
**État** : Objets créés, integration en cours  
**Prochaine version** : 5.1 (Tableaux fonctionnels)
