# 🚀 GUIDE COMPLET : Système de Téléportation

## 🎯 Vue d'ensemble

Le système de téléportation permet de **déplacer automatiquement** des tokens après l'utilisation d'une technique réussie.

### **2 Types de Téléportation :**

1. **🏃 Téléportation du Lanceur**
   - Vous vous téléportez autour de la cible
   - Positions : Derrière, Devant, Gauche, Droite
   - Parfait pour : Backstab, Rush, Charge

2. **🎯 Téléportation de la Cible**
   - Vous téléportez la cible où vous voulez
   - Clic sur la carte pour choisir la destination
   - Parfait pour : Repousse, Push, Control

---

## 📦 Fichiers Créés

1. **`module/combat/teleportation-system.js`** ✅ - Logique complète
2. **`TEMPLATE_ONGLET_TELEPORTATION.html`** ⚠️ - UI à intégrer
3. **`CODE_INTEGRATION_TELEPORTATION.js`** ⚠️ - Code à ajouter
4. **`template.json`** ✅ - Champs ajoutés

---

## ⚙️ Installation

### Étape 1 : Template.json (Déjà fait ✅)
Le champ `teleportation` a été ajouté à la structure des techniques.

### Étape 2 : Ajouter l'onglet dans technique-sheet-v2.html

**A. Dans les onglets (ligne ~15) :**
```html
<a class="item" data-tab="teleportation">🚀 Téléportation</a>
```

**B. Dans le contenu (après l'onglet animations) :**
Copiez tout le contenu de `TEMPLATE_ONGLET_TELEPORTATION.html`

### Étape 3 : Intégrer le code dans actor-sheet.js

**A. Import (début du fichier) :**
```javascript
import { FFdreameTeleportation } from "../combat/teleportation-system.js";
```

**B. Après la technique réussie (ligne ~1663) :**
```javascript
// Jouer l'animation si présente et si réussite
if (success) {
  await this._jouerAnimationItem(technique);
  
  // ===== GESTION DE LA TÉLÉPORTATION =====
  const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
  if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
    const targets = Array.from(game.user.targets);
    const targetToken = targets.length > 0 ? targets[0] : null;
    
    await FFdreameTeleportation.handleTeleportation(this.actor, targetToken, teleportConfig);
  }
  
  // ===== GESTION DES EFFETS DE TABLEAUX =====
  await this._incrementerCompteurEffet();
}
```

### Étape 4 : Pour les slots CHM

Dans `template.json`, pour chaque slot CHM (slot1 à slot5), ajouter après `"animation"` :
```json
"teleportation": {
  "actif": false,
  "type": "lanceur",
  "position": "derriere",
  "distanceMax": 5
}
```

---

## 🎮 Configuration dans l'Interface

### Onglet Téléportation :

```
╔════════════════════════════════════╗
║ 🚀 SYSTÈME DE TÉLÉPORTATION       ║
╠════════════════════════════════════╣
║ ☑️ Activer la téléportation        ║
║                                    ║
║ 🎯 Type :                          ║
║ [🏃 Téléporter le Lanceur (moi)]  ║
║                                    ║
║ 📏 Distance max : [5] mètres       ║
║                                    ║
║ 📍 Position :                      ║
║ [⬆️ Derrière la cible]            ║
║                                    ║
║     ⬆️                             ║
║  ⬅️ 🎯 ➡️     (Schéma)            ║
║     ⬇️                             ║
╚════════════════════════════════════╝
```

---

## 🎯 Exemples de Configuration

### Technique "Backstab" (Assassin)
```
Téléportation : ✅ Actif
Type : Lanceur
Position : Derrière
Distance max : 3m

→ Vous attaquez, puis vous téléportez derrière l'ennemi
```

### Technique "Repousse" (Tank)
```
Téléportation : ✅ Actif
Type : Cible
Distance max : 5m

→ Vous attaquez, puis cliquez pour repousser l'ennemi
```

### Technique "Charge" (Guerrier)
```
Téléportation : ✅ Actif
Type : Lanceur
Position : Devant
Distance max : 10m

→ Vous foncez sur l'ennemi (apparaît devant lui)
```

### Technique "Échange" (Mage)
```
Téléportation : ✅ Actif
Type : Cible
Distance max : 8m

→ Vous échangez de place avec la cible
💡 Astuce : Créez 2 techniques (une pour vous, une pour la cible)
```

---

## 🎬 Workflow en Jeu

### Type "Lanceur" :
1. **Ciblez** un ennemi
2. **Utilisez** la technique
3. **Jet de dés** → Réussite
4. **Dégâts** appliqués
5. ✨ **Téléportation automatique** derrière/à côté
6. **Animation** (Misty Step bleu)
7. **Notification** "✨ Vous vous téléportez derrière [Nom] !"

### Type "Cible" :
1. **Ciblez** un ennemi
2. **Utilisez** la technique
3. **Jet de dés** → Réussite
4. **Dégâts** appliqués
5. 🎯 **Cliquez sur la carte** pour choisir où téléporter
6. **Vérification distance** (depuis position actuelle de la cible)
7. ✨ **Téléportation**
8. **Animation** + Notification

---

## 📐 Calcul de Distance

### Pour Type "Lanceur" :
```
Distance = Du lanceur → Nouvelle position
Exemple : Vous êtes à 8m de l'ennemi
          Vous vous téléportez derrière lui (1 case)
          Distance parcourue = 9m
          Si distance max = 10m → ✅ OK
```

### Pour Type "Cible" :
```
Distance = De la cible → Destination cliquée
Exemple : La cible est à 5m de vous
          Vous cliquez à 3m de la cible
          Distance parcourue par la cible = 3m
          Si distance max = 5m → ✅ OK
```

---

## 🎨 Schéma Visuel des Positions

```
        ⬆️ DERRIÈRE
         |
         |
⬅️ GAUCHE - 🎯 CIBLE - DROITE ➡️
         |
         |
        ⬇️ DEVANT
```

**Légende :**
- 🎯 = Position de la cible
- ⬆️⬇️⬅️➡️ = Où vous apparaissez

---

## 💡 Idées de Techniques

### Combat Rapproché :
- **Backstab** : Téléportation lanceur derrière (CAC)
- **Encerclement** : Téléportation lanceur sur le côté (CAC)
- **Charge Brutale** : Téléportation lanceur devant (PUI)

### Contrôle :
- **Repousse** : Téléportation cible loin (MAG)
- **Attraction** : Téléportation cible près (MAG)
- **Projection** : Téléportation cible (AOE sur plusieurs)

### Tactique :
- **Échange de Position** : 2 techniques (lanceur + cible)
- **Coup et Fuite** : Attaque + téléportation lanceur loin
- **Piège** : Téléportation cible dans une zone dangereuse

### Hybride :
- **Assassinat** : CAC + téléportation derrière + critique
- **Combo Rush** : ATTA + téléportation devant + ATTA à nouveau

---

## ⚠️ Limitations et Règles

### Distance :
- ❌ **Ne peut pas dépasser** la distance max configurée
- ✅ Vérification avant la téléportation
- ⚠️ Message d'erreur si trop loin

### Collision :
- ⚠️ Le système ne vérifie PAS les murs/obstacles
- 💡 À vous de cliquer sur une zone accessible

### Cible Requise :
- Pour type "Lanceur" : **Cible obligatoire**
- Pour type "Cible" : **Cible obligatoire**
- Sans cible : ⚠️ Warning (pas de crash)

### Limites de Scène :
- ❌ Ne peut pas téléporter hors de la carte
- ✅ Vérification automatique

---

## 🎬 Animation (Sequencer)

### Animation Utilisée :
```
Départ : jb2a.misty_step.01.blue (nuage bleu)
Arrivée : jb2a.misty_step.02.blue (apparition)
```

### Si Sequencer non installé :
- Téléportation **instantanée** (pas d'animation)
- Fonctionne quand même normalement

---

## 🐛 Dépannage

### "Aucune téléportation ne se produit"
1. Vérifiez que la case "Activer" est ☑️
2. Vérifiez qu'une cible est ciblée (clic droit → Cibler)
3. Vérifiez que la technique a réussi
4. Ouvrez la console (F12) pour voir les logs

### "Distance trop grande"
1. Vérifiez la distance max configurée
2. La cible est peut-être trop loin
3. Pour type "Lanceur", la distance inclut le déplacement jusqu'à la cible

### "Téléportation hors carte"
1. Cliquez dans les limites de la scène
2. Le système bloque automatiquement les positions hors limite

### "Pas de notification"
1. Vérifiez que le module est bien importé
2. Rechargez Foundry (F5)

---

## 🔧 Personnalisation

### Changer l'Animation :
Dans `teleportation-system.js`, ligne ~155 :
```javascript
.file("jb2a.misty_step.01.blue")
```
Remplacez par votre animation préférée !

### Ajouter Plus de Positions :
Éditez le template HTML pour ajouter :
- Diagonales (haut-gauche, haut-droite, etc.)
- Distance variable (proche, loin)

### Animation Personnalisée par Technique :
Ajoutez un champ `teleportAnimation` dans le template.json

---

## 📊 Statistiques Utiles

**Distance Moyenne par Grille :**
- 1 case = 1.5m (standard D&D)
- Diagonale = ~2.1m
- 2 cases = 3m

**Distances Recommandées :**
- Backstab : 3-5m
- Charge : 8-12m
- Repousse : 3-8m
- Échange : 5-10m

---

Bon jeu stratégique avec la téléportation ! 🚀✨
