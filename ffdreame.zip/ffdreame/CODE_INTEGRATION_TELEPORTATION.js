// ============================================
// CODE À AJOUTER DANS actor-sheet.js
// ============================================

// 1. IMPORTER LE MODULE (au début du fichier, avec les autres imports)
import { FFdreameTeleportation } from "../combat/teleportation-system.js";

// 2. AJOUTER APRÈS LA TECHNIQUE RÉUSSIE (ligne ~1663, après _jouerAnimationItem)
// Remplacer cette section :
/*
    // Jouer l'animation si présente et si réussite
    if (success) {
      await this._jouerAnimationItem(technique);
      
      // ===== GESTION DES EFFETS DE TABLEAUX =====
      await this._incrementerCompteurEffet();
    }
*/

// PAR :
    // Jouer l'animation si présente et si réussite
    if (success) {
      await this._jouerAnimationItem(technique);
      
      // ===== GESTION DE LA TÉLÉPORTATION =====
      const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
      if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
        const targets = Array.from(game.user.targets);
        const targetToken = targets.length > 0 ? targets[0] : null;
        
        await FFdreameTeleportation.handleTeleportation(this.actor, targetToken, teleportConfig);
      }
      
      // ===== GESTION DES EFFETS DE TABLEAUX =====
      await this._incrementerCompteurEffet();
    }


// ============================================
// MÊME CHOSE POUR AOE (ligne ~1850)
// ============================================
// Après les dégâts appliqués dans AOE, ajouter :

      // ===== GESTION DE LA TÉLÉPORTATION =====
      const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
      if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
        const targets = Array.from(game.user.targets);
        const targetToken = targets.length > 0 ? targets[0] : null;
        
        await FFdreameTeleportation.handleTeleportation(this.actor, targetToken, teleportConfig);
      }


// ============================================
// MÊME CHOSE POUR MULTI (dans multi-zone.js)
// ============================================
// Dans multi-zone.js, après l'application des dégâts (ligne ~170 et ~330)

      // ===== GESTION DE LA TÉLÉPORTATION =====
      const { FFdreameTeleportation } = await import('./teleportation-system.js');
      const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
      if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
        // Pour MULTI, téléporter vers la première cible touchée
        const firstTarget = tokensInZone.length > 0 ? tokensInZone[0] : null;
        
        await FFdreameTeleportation.handleTeleportation(actor, firstTarget, teleportConfig);
      }


// ============================================
// NOTES IMPORTANTES
// ============================================

/**
 * PLACEMENT DANS LE CODE :
 * 
 * 1. La téléportation doit se faire APRÈS :
 *    - Le jet de dés réussi
 *    - Les dégâts appliqués
 *    - L'animation jouée
 * 
 * 2. La téléportation doit se faire AVANT :
 *    - L'incrémentation du compteur d'effets
 * 
 * 3. Pour chaque style, vérifier qu'il y a bien :
 *    - Une cible (pour "lanceur" type)
 *    - La réussite de la technique
 * 
 * GESTION DES ERREURS :
 * - Si pas de cible : warning mais pas de crash
 * - Si distance trop grande : warning
 * - Si position hors limites : warning
 * 
 * ANIMATION :
 * - Utilise jb2a.misty_step si Sequencer disponible
 * - Sinon téléportation instantanée
 */
