# 🐲 GUIDE : Fiche NPC/Monstre Simplifiée

## 🎯 Vue d'ensemble

La fiche NPC est une version **compacte** de la fiche joueur, tout sur **une seule page**, mais avec **toutes les fonctionnalités essentielles** :
- ⚡ Points d'Action (comme les joueurs)
- 🤸 Réactions (Esquive/Défense/Marche)
- ⚔️ Tableau de techniques (8 slots)
- 🎖️ Atouts activables par le MJ
- 📊 Compétences simplifiées

---

## 🆕 Créer un NPC

### Méthode 1 : Depuis les Acteurs
1. Cliquez sur **"Acteurs"** dans la barre latérale
2. Cliquez sur **"Créer un Acteur"**
3. Choisissez le type **"NPC/Monstre"**
4. Nommez votre NPC

### Méthode 2 : Glisser-Déposer
1. Créez un token sur la scène
2. Double-cliquez dessus
3. Cliquez sur "Créer Acteur"
4. Choisissez type "NPC/Monstre"

---

## 📋 Organisation de la Fiche

### **Colonne Gauche :**
- ❤️ **Aptitudes de Combat** (PV, PM, Burste, Attaque, PM, Défense)
- 📊 **Compétences** (Force, Endurance, Agilité, etc.)
- ⚡ **Points d'Action** (3 Grands PA = 6 Petits PA)
- 🎯 **Réactions** (Esquive, Défense, Marche)

### **Colonne Droite :**
- ⚡ **Tableau de Techniques** (8 slots)
- 🎖️ **Atouts / Bonus** (4 slots activables)
- 📝 **Description / Notes**

---

## ⚔️ Configurer les Stats

### Stats de Base :
```
Goblin Guerrier:
- Niveau: 5
- Rang: D
- PV: 80/80
- PM: 30/30
- Attaque: 15
- Puissance Magique: 5
- Défense: 10
```

### Compétences :
```
Physique:
- Force: 3
- Endurance: 5
- Athlétisme: 2

Dextérité:
- Agilité: 4
- Perception: 3

Mental:
- Volonté: 2
- Magie: 1
```

---

## 🎖️ Système d'Atouts (Bonus MJ)

Les atouts permettent au MJ d'activer/désactiver des bonus pour le NPC.

### Exemples d'Atouts :

**Atout 1 : Rage du Guerrier**
- Nom: `Rage du Guerrier`
- Valeur: `+15% jets d'attaque, +10 dégâts`
- ☑️ Actif

**Atout 2 : Peau Épaisse**
- Nom: `Peau Épaisse`
- Valeur: `-30% dégâts reçus`
- ☐ Inactif

**Atout 3 : Vision Nocturne**
- Nom: `Vision Nocturne`
- Valeur: `+20% Perception dans le noir`
- ☑️ Actif

**Atout 4 : Berserker**
- Nom: `Berserker`
- Valeur: `Double dégâts si PV < 30%`
- ☐ Inactif

### Comment ça fonctionne :

1. **Le MJ coche la case** pour activer l'atout
2. **La ligne s'illumine en bleu** (feedback visuel)
3. **Le MJ applique manuellement** les bonus pendant le jeu
4. **C'est un aide-mémoire visuel** pour le MJ

> ⚠️ **Note :** Les atouts ne s'appliquent PAS automatiquement aux jets. C'est au MJ de les prendre en compte. Par exemple, si "Rage du Guerrier" est actif, le MJ ajoute +15% au jet et +10 aux dégâts.

---

## ⚡ Tableau de Techniques

### Ajouter une Technique :
1. Créez une **Technique** (Item)
2. **Glissez-déposez** l'item sur un slot vide du tableau
3. La technique apparaît dans le slot

### Utiliser une Technique :
1. **Cliquez** sur le slot
2. La technique se lance comme pour un joueur
3. Jet de dés automatique
4. Dégâts calculés
5. Réactions de la cible gérées automatiquement

### Exemple de Techniques pour un Goblin :

**Slot 1 : Coup de Dague**
- Style: CAC
- Dégâts de base: 10
- Coût: 5 PM

**Slot 2 : Cri de Guerre**
- Style: EF (Effet)
- Effet: +10% attaque alliés
- Coût: 10 PM

**Slot 3 : Fuite Rapide**
- Style: ATTA
- Dégâts: 5
- Permet de se déplacer après

---

## 🎯 Réactions (Esquive / Défense / Marche)

### Fonctionnent EXACTEMENT comme les joueurs :

**Esquive 🤸**
- Coûte: 1 Petit PA
- Seuil: Jet attaque + Agilité
- Réduit les dégâts

**Défense 🛡️**
- Coûte: 1 Petit PA
- Seuil: Jet attaque + Endurance
- Réduit les dégâts

**Marche 🚶**
- Coûte: 1 Petit PA
- Permet de se déplacer à nouveau

---

## ⚡ Points d'Action

Les NPC ont **exactement le même système** que les joueurs :

- **3 Grands PA** au début du combat
- Chaque Grand PA = **2 Petits PA**
- **Récupèrent 1 Grand PA** par tour
- **Ne dépassent jamais 3 Grands PA**

### Utilisation :
- ☑️ Case cochée = PA disponible
- ☐ Case décochée = PA utilisé

---

## 🎮 En Combat

### Tour du NPC :
1. **C'est son tour** dans le Combat Tracker
2. **Le MJ utilise ses techniques** depuis le tableau
3. **Ou lance des attaques manuelles**
4. **Clic "Next Turn"** pour passer au suivant

### Si le NPC se fait attaquer :
1. Le MJ peut **activer Esquive/Défense** AVANT l'attaque
2. Le jet de réaction se fait **automatiquement**
3. Les dégâts sont **réduits si réussi**

---

## 💡 Conseils d'Utilisation

### Pour des Monstres Faibles (Gobelins, Bandits) :
- Pas besoin de techniques compliquées
- 2-3 techniques suffisent
- Stats basses (3-5 en compétences)
- 1-2 atouts max

### Pour des Boss :
- 6-8 techniques variées
- Stats élevées (8-12 en compétences)
- 3-4 atouts puissants
- Burste à 100 pour l'Ultimate

### Pour des PNJ Alliés :
- Techniques de soutien (soins, buffs)
- Stats moyennes
- Atouts utilitaires

---

## 📊 Exemple Complet : Dragon Rouge Jeune

```
═══════════════════════════════════════════════
NOM : Dragon Rouge Jeune
TYPE : Boss
NIVEAU : 15
RANG : A
═══════════════════════════════════════════════

APTITUDES :
❤️ PV : 500/500
✨ PM : 200/200
⚡ Burste : 0/100
⚔️ Attaque : 45
🔮 Puissance Magique : 60
🛡️ Défense : 30

COMPÉTENCES :
💪 Force : 12
💪 Endurance : 10
💪 Athlétisme : 6
🤸 Agilité : 4
🤸 Perception : 8
🧠 Volonté : 9
🧠 Magie : 11

TECHNIQUES :
1. Morsure Enflammée (CAC, 30 dégâts, 10 PM)
2. Souffle de Feu (MULTI-Cône, 50 dégâts, 30 PM)
3. Coup de Queue (AOE, 3 jets, 20 dégâts/jet, 20 PM)
4. Vol Rapide (ATTA, 15 dégâts + déplacement, 5 PM)
5. Rugissement (EF, -15% jets ennemis, 15 PM)
6. Écailles Renforcées (CUR, +100 PV, 25 PM)
7. Météore de Flammes (ULTIM, 150 dégâts, Burste 100)
8. [Vide]

ATOUTS :
☑️ Peau Écailleuse : -40% dégâts physiques
☑️ Maître du Feu : +20% dégâts feu
☐ Rage du Dragon : x2 dégâts si PV < 30%
☐ Ailes Puissantes : Peut voler au-dessus du combat

DESCRIPTION :
Un dragon rouge encore jeune mais déjà redoutable.
Ses écailles brillent d'un rouge incandescent et sa
gueule crache des flammes dévastatrices. Il protège
farouchement son trésor dans une grotte volcanique.
═══════════════════════════════════════════════
```

---

## 🔧 Astuces MJ

1. **Préparez des Templates** : Créez des NPC de base (Goblin, Bandit, Garde) et dupliquez-les

2. **Utilisez les Atouts** : C'est plus rapide que de recalculer les stats à chaque fois

3. **Techniques Simples** : Pour les mobs, 2-3 techniques suffisent

4. **Description** : Notez les points faibles, résistances, comportement

5. **Combat Tracker** : Ajoutez les NPC au combat, l'initiative se lance auto

---

## ⚙️ Différences avec la Fiche Joueur

| Fonctionnalité | Joueur | NPC |
|----------------|--------|-----|
| **Pages** | Multiple onglets | 1 seule page |
| **Compétences** | 10+ compétences | 7 compétences |
| **Tableaux** | 2 tableaux x 8 slots | 1 tableau x 8 slots |
| **Atouts** | Passifs permanents | Activables par MJ |
| **Postures** | Oui | Non |
| **Fatigue/Blessure** | Oui (cases) | Non (simplifié) |
| **PA/Réactions** | Oui | Oui (identique) |
| **Techniques** | Oui | Oui (identique) |

---

## 🐛 Dépannage

### "Les techniques ne se lancent pas"
- Vérifiez que la technique est bien dans les items de l'acteur
- Rechargez la fiche (fermez et rouvrez)

### "Les réactions ne fonctionnent pas"
- Assurez-vous qu'il reste des Petits PA
- Vérifiez que l'acteur n'est pas bloqué (🔒)

### "Les atouts ne s'appliquent pas"
- C'est normal ! Les atouts sont manuels, le MJ doit appliquer les bonus lui-même

---

Bonne chasse ! 🐲⚔️
