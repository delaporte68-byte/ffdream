# 🎮 FFDreame v4.4 - Guide Rapide

## 📦 CE QUI A CHANGÉ

### ❌ AVANT (v4.3)
```
┌─────────────────────────────┐
│   POSTURE 1    POSTURE 2    │
│   - Tech 1     - Tech 1     │
│   - Tech 2     - Tech 2     │
│   - Tech 3     - Tech 3     │
│   [Ultimate 1] [Ultimate 2] │
└─────────────────────────────┘
```

### ✅ MAINTENANT (v4.4)
```
┌─────────────────────────────────────────┐
│  ⚔️ STYLE D'ATTAQUE                     │
│  Épée/Bâton/Flingue/Arc + Dégâts        │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  📦 CADRE 1 [☑ Actif]                   │
│  [Slot1][Slot2][Slot3][Slot4]           │
│  [Slot5][Slot6][Slot7][Slot8]           │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  📦 CADRE 2 [☐ Inactif]                 │
│  [Slot1][Slot2][Slot3][Slot4]           │
│  [Slot5][Slot6][Slot7][Slot8]           │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  🔥 STYLE ULTIME                        │
│  Nom + Description + Dégâts + Icône     │
│  [LANCER ULTIMATE] (si Burste ≥ 100)   │
└─────────────────────────────────────────┘
```

---

## 🚀 DÉMARRAGE RAPIDE

### 1️⃣ Configuration du Style d'Attaque
```
1. Allez dans l'onglet "Combat"
2. Section "Style d'Attaque"
3. Choisissez : ⚔️ Épée / 🥢 Bâton / 🔫 Flingue / 🏹 Arc
4. Définissez les dégâts de base (ex: 10)
```

### 2️⃣ Remplir les Cadres d'Objets
```
1. Créez des techniques dans vos Items
2. Drag & Drop vers un slot vide du cadre
3. Cochez "Activer" pour rendre le cadre utilisable
4. Répétez pour le 2ème cadre
```

### 3️⃣ Configurer l'Ultime
```
1. Section "Style Ultime"
2. Nom : "Tempête de Flammes"
3. Description : "Invoque une tempête de feu"
4. Dégâts : 150
5. Icône : 🔥 Feu
```

---

## 💪 EN COMBAT

### Option 1 : Attaque Basique
```
[⚔️ ATTAQUE DE BASE]
→ Dégâts : Base + Aptitude Attaque
→ Coût : 1 PA
→ Effet : +10 Burste
```

### Option 2 : Technique du Cadre
```
[Cadre Actif] → Clic sur [▶️]
→ Dégâts : Variable selon technique
→ Coût : PM + 1 PA
→ Effet : +10 Burste
```

### Option 3 : Ultimate
```
[🔥 LANCER ULTIMATE]
→ Conditions : Burste = 100
→ Dégâts : Selon configuration
→ Effet : Burste → 0
```

---

## 🎯 EXEMPLES DE BUILD

### 🗡️ Guerrier Épée
```
Style Attaque : ⚔️ Épée (Dégâts: 15)

Cadre 1 (Offensif) - ACTIF :
├─ Entaille rapide (10 PM)
├─ Coup puissant (20 PM)
├─ Tourbillon (30 PM)
└─ Contre-attaque (15 PM)

Cadre 2 (Défensif) :
├─ Blocage (10 PM)
├─ Esquive (5 PM)
└─ Régénération (25 PM)

Ultime : ⚡ "Lame Céleste" (200 dmg)
```

### 🏹 Archer
```
Style Attaque : 🏹 Arc (Dégâts: 12)

Cadre 1 (Tir) - ACTIF :
├─ Flèche percante (15 PM)
├─ Tir multiple (25 PM)
├─ Flèche explosive (30 PM)
└─ Tir de précision (20 PM)

Cadre 2 (Support) :
├─ Piège (15 PM)
├─ Camouflage (10 PM)
└─ Soin (20 PM)

Ultime : 🌟 "Pluie de Flèches" (180 dmg)
```

### 🔫 Tireur
```
Style Attaque : 🔫 Flingue (Dégâts: 18)

Cadre 1 (Flingue) - ACTIF :
├─ Tir rapide (10 PM)
├─ Sniper (25 PM)
├─ Rafale (35 PM)
└─ Rechargement tactique (5 PM)

Cadre 2 (Tech) :
├─ Grenade (30 PM)
├─ Tourelle (40 PM)
└─ Bouclier (20 PM)

Ultime : 💥 "Barrage Orbital" (250 dmg)
```

---

## 🔄 STRATÉGIES

### Rotation Standard
```
1. Attaque de base (⚔️) × 2-3
   → Génère du Burste

2. Techniques du cadre actif
   → Dégâts + effets spéciaux

3. À 100 Burste → ULTIME 🔥
   → Finisher puissant

4. Nouveau cycle
```

### Gestion des Cadres
```
DÉBUT DU COMBAT :
├─ Cadre 1 : ACTIF (offensif)
└─ Cadre 2 : INACTIF (défensif)

SI EN DANGER :
├─ Désactiver Cadre 1
└─ Activer Cadre 2 (défenses/soins)

FIN DU COMBAT :
└─ Réactiver Cadre 1
```

---

## 📊 COMPARAISON

| Aspect | v4.3 Postures | v4.4 Cadres |
|--------|---------------|-------------|
| Slots | 2 postures | 16 slots (2×8) |
| Flexibilité | Technique → Posture | Drag & Drop libre |
| Activation | 1 posture active | Cadres indépendants |
| Ultimate | 2 ultimates | 1 ultime global |
| Attaque | Liée à posture | Style indépendant |

---

## ⚡ RACCOURCIS

- **Activer cadre** : Checkbox en haut à droite du cadre
- **Utiliser objet** : Bouton ▶️ sur le slot
- **Retirer objet** : Bouton ❌ sur le slot
- **Ajouter objet** : Drag & Drop depuis inventaire
- **Changer arme** : Menu déroulant Style d'Attaque

---

## 🐛 PROBLÈMES COURANTS

### "Le cadre ne s'active pas"
→ Vérifiez que la checkbox est cochée ☑

### "Je ne peux pas déposer d'objets"
→ Seules les Techniques et Équipements sont acceptés

### "L'ultime est grisé"
→ Il faut Burste ≥ 100 pour l'utiliser

### "Mes anciennes postures ont disparu"
→ Normal, elles sont remplacées par les cadres
→ Recréez vos techniques dans les nouveaux cadres

---

## 💡 ASTUCES PRO

1. **Gardez un cadre en réserve** pour changer de stratégie
2. **Équilibrez PM/dégâts** dans vos techniques
3. **L'ultime doit être votre coup d'éclat** (150-300 dmg)
4. **Variez les styles d'arme** selon les situations
5. **Organisez vos cadres thématiquement** (offensif/défensif)

---

Bon jeu ! 🎮
