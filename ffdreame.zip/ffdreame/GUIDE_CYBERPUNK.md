# 🌃 FFdreame v3.3 - STYLE CYBERPUNK

## 🎨 NOUVEAU : Fiche Personnage Cyberpunk !

Vous pouvez maintenant choisir entre **2 styles de fiches** :
- 📜 **Fantasy** (style original médiéval)
- 🌃 **Cyberpunk** (nouveau style futuriste néon)

---

## 🚀 Comment choisir le style ?

### Méthode 1 : À la création
1. Créer un nouveau personnage
2. Ouvrir sa fiche
3. En haut à droite (GM uniquement) : **Sélecteur "Style"**
4. Choisir "🌃 Cyberpunk"
5. Fermer et réouvrir la fiche → **STYLE CHANGÉ !**

### Méthode 2 : Sur personnage existant
1. Ouvrir la fiche du personnage
2. **Sélecteur "Style"** (GM uniquement)
3. Changer de "Fantasy" à "Cyberpunk"
4. Fermer et réouvrir → **TRANSFORMATION !**

---

## 🎯 Onglet PROFIL (Cyberpunk)

### Layout Futuriste

```
┌─────────────────────────────────────────────────────┐
│ [IDENTIFICATION]      LV: 5    RANG: A   [Style▼] │
├──────────┬──────────────────────────────┬───────────┤
│ COMPÉT.  │                              │ APTITUDES │
│          │       ╔═══════╗              │           │
│ Force: 5 │       ║ TOKEN ║              │   ⬢ ATQ  │
│ Athléti  │       ║ IMAGE ║              │   ⬢ PM   │
│ Enduran  │       ║ 300px ║              │   ⬢ PV   │
│          │       ╚═══════╝              │   ⬢ MANA │
│ Furtivi  │                              │           │
│ Agilité  │   Stats autour du token     │ Hexagones │
│ Percept  │                              │ avec +    │
│          │                              │           │
│ Culture  │                              │           │
│ Magie    │                              │           │
│ Volonté  │                              │           │
│          │                              │           │
│ Intimid  │                              │           │
│ Psycho   │                              │           │
│ Persuas  │                              │           │
├──────────┴──────────────────────────────┴───────────┤
│         ▓▓▓ TALENTS AUGMENTÉS ▓▓▓                   │
│  [Talent 1]  [Talent 2]  [Talent 3]  [Talent 4]    │
├─────────────────────────────────────────────────────┤
│ POINTS COMPÉTENCES: 12/50  |  POINTS APTITUDES: 8/20│
└─────────────────────────────────────────────────────┘
```

### Caractéristiques visuelles

**Compétences (gauche) :**
- Fond noir/bleu foncé
- Bordures cyan néon
- Groupes colorés (Physique, Dextérité, etc.)
- Boutons "+" lumineux
- Animation de scan vertical

**Token (centre) :**
- Image circulaire 300×300px
- Bordure néon qui change de couleur
- Effet de scan lines animé
- Overlay holographique
- Stats aux 4 points cardinaux

**Aptitudes (droite) :**
- Hexagones lumineux
- Bordures magenta
- Icônes : ⚔ ✦ ♥ ◆
- Boutons "+" hexagonaux
- Effet glow au survol

**Talents :**
- 4 cartes avec bordures animées
- Effet de gradient rotatif au survol
- Background noir transparent
- Checkbox cyan

---

## 🎨 Style Visuel Cyberpunk

### Palette de couleurs

| Couleur | Code | Utilisation |
|---------|------|-------------|
| 🔵 Cyan | #00FFFF | Principal, bordures, texte |
| 🔴 Magenta | #FF00FF | Accents, aptitudes |
| 🟡 Jaune | #FFFF00 | Labels, valeurs importantes |
| 🔵 Bleu | #0080FF | Boutons, dégradés |
| 🟣 Violet | #8000FF | Effets secondaires |
| ⚫ Noir | #0A0A0A | Fond principal |

### Effets spéciaux

**Glow (Lueur néon) :**
- Tous les éléments ont un effet de lueur
- Animation pulse sur les éléments actifs
- Intensité variable selon l'importance

**Scan lines :**
- Lignes horizontales animées sur tout le fond
- Effet de scan vertical sur les panels
- Animation continue

**Glitch :**
- Effet glitch au focus des inputs
- Décalage rapide gauche/droite
- Donne un effet "cybernétique"

**Dégradés animés :**
- Bordures qui changent de couleur
- Rotation de gradient sur les talents
- Effet holographique

---

## ⚔️ Onglet COMBAT (En construction)

**Prévu :**
- Barres PV/PM/Burste néon
- Fatigue/Blessures en grille hexagonale
- Points d'action lumineux
- Postures avec effets glitch
- Ultimate avec explosion visuelle

---

## 🎒 Onglet ÉQUIPEMENT (En construction)

**Prévu :**
- Inventaire style terminal
- Items avec icônes néon
- Catégories avec tabs lumineux
- Poids en graphique circulaire

---

## 🔧 Système technique

### Même mécanique, nouveau look !

**IMPORTANT :** Le style Cyberpunk utilise **exactement le même système** que Fantasy :
- ✅ Mêmes compétences
- ✅ Mêmes aptitudes
- ✅ Mêmes calculs
- ✅ Mêmes formules
- ✅ Mêmes talents
- ✅ Burste, postures, techniques...

**Seul change :** L'apparence visuelle !

### Comment ça marche ?

Le champ `styleSheet` dans le personnage détermine quel template utiliser :
- `"fantasy"` → `character-sheet.html` (original)
- `"cyberpunk"` → `cyberpunk-character-sheet.html` (nouveau)

Le CSS Cyberpunk (`cyberpunk.css`) s'ajoute au CSS Fantasy sans le remplacer.

---

## 🎯 Utilisation recommandée

### Pour une campagne Fantasy
→ Tous les personnages en mode **Fantasy** 📜

### Pour une campagne Cyberpunk/SF
→ Tous les personnages en mode **Cyberpunk** 🌃

### Pour une campagne mixte
→ Certains en Fantasy, d'autres en Cyberpunk selon leur origine !

---

## ⚠️ Notes importantes

### État actuel (v3.3)

**✅ TERMINÉ :**
- Onglet PROFIL complet
- Design cyberpunk complet
- Système de sélection de style
- Compétences fonctionnelles
- Aptitudes fonctionnelles
- Talents fonctionnels
- Points fonctionnels

**🚧 EN CONSTRUCTION :**
- Onglet COMBAT (sera fait ensuite)
- Onglet ÉQUIPEMENT (sera fait ensuite)

### Limitations actuelles

- Les onglets Combat et Équipement affichent "EN CONSTRUCTION"
- Pour l'instant, utilisez l'onglet PROFIL
- Les fonctionnalités complètes arrivent dans la prochaine version

---

## 🎨 Personnalisation

### Si vous voulez modifier les couleurs

Éditez `css/cyberpunk.css` et changez les variables :

```css
:root {
  --cyber-cyan: #00ffff;      /* Cyan principal */
  --cyber-magenta: #ff00ff;   /* Magenta accents */
  --cyber-yellow: #ffff00;    /* Jaune labels */
  --cyber-bg-dark: #0a0a0a;   /* Fond noir */
}
```

### Si vous voulez désactiver les animations

Recherchez `@keyframes` dans `cyberpunk.css` et commentez-les.

---

## 🐛 Dépannage

**Le style ne change pas ?**
1. Fermez complètement la fiche
2. Rouvrez-la
3. Vérifiez que le sélecteur indique "Cyberpunk"
4. Rechargez Foundry si nécessaire (F5)

**Les boutons "+" ne fonctionnent pas ?**
→ Normal ! Ils utilisent les mêmes listeners que Fantasy (déjà implémentés)

**L'image du token ne s'affiche pas ?**
→ Assurez-vous d'avoir défini une image pour votre acteur

**Tout est en cyan, c'est normal ?**
→ Oui ! C'est le thème Cyberpunk 🌃

---

## 🚀 Prochaines étapes

**v3.4 (à venir) :**
- Onglet COMBAT Cyberpunk complet
- Barres PV/PM/Burste avec néons
- Postures avec effets lumineux
- Ultimate avec animation explosive

**v3.5 (à venir) :**
- Onglet ÉQUIPEMENT Cyberpunk
- Inventaire style terminal
- Effets visuels sur les items

---

**Version actuelle :** 3.3  
**Style :** Cyberpunk (Onglet PROFIL)  
**État :** FONCTIONNEL ✅  

Profitez du style futuriste ! 🌃✨💫
