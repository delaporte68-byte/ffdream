# ✅ CORRECTIONS APPLIQUÉES - VERSION FINALE

## 🔧 CORRECTIONS FAITES :

### 1. ✅ Tableaux mutuellement exclusifs
**Fichier** : `template.json` ligne 187
**Correction** : `tableau2.actif = false` par défaut
**Test** : Seul T1 est actif au démarrage

### 2. ✅ Sélecteur durée animation
**Fichier** : `templates/item/technique-sheet-v2.html`
**Correction** : Select avec options 1s, 2s, 3s, 5s, 8s, permanent
**Test** : Onglet Animation → Sélecteur visible

### 3. ⚠️ Animation CHM
**Status** : PAS ENCORE FAIT
**À FAIRE** : Ajouter champs animation dans chaque slot CHM
**Complexité** : Moyenne (template.json + HTML)

### 4. ⚠️ Téléportation ne marche pas
**Status** : CODE OK - DEBUG NÉCESSAIRE
**À TESTER** :
1. Console (F12) lors de l'utilisation
2. Vérifier que `actif: true` dans la technique
3. Vérifier qu'une cible est sélectionnée
4. Regarder les erreurs

### 5. ⚠️ Jets de réussite
**Status** : À CLARIFIER
**Question** : Quel jet manque exactement ?
- Le jet principal ?
- Un message dans le chat ?
- Une notification ?

### 6. ✅ Récupération PA
**Fichier** : `module/combat/combat-system.js`
**Correction** : Logs debug ajoutés
**Test** : Console (F12) → Vérifier message "🔄 Nouveau round"

### 7. ✅ Tokens petits
**Fichier** : `module/combat/combat-system.js`
**Correction** : CSS pour Combat + Encounters + Popout
**Test** : Tokens doivent faire 36px × 36px max

### 8. ⚠️ Image actor ≠ Token
**Status** : PAS ENCORE FAIT
**Solution** : Foundry gère nativement (Actor img ≠ prototypeToken.texture.src)
**À VÉRIFIER** : Si ça ne marche pas, ajouter champ custom

---

## 🧪 TESTS À FAIRE :

### Test 1 : Tableaux
```
1. Ouvrez fiche perso
2. Vérifiez : T1 actif, T2 grisé
3. Cliquez T2 → T1 se désactive
4. Cliquez T1 → T2 se désactive
```

### Test 2 : Durée animation
```
1. Ouvrez technique
2. Onglet Animation
3. Vérifiez : Select avec 6 options
4. Sélectionnez 8 secondes
5. Lancez technique → Animation dure 8s
```

### Test 3 : PA Recovery
```
1. Lancez combat
2. F12 → Console
3. Cliquez "Next Round"
4. Console doit montrer : "🔄 Nouveau round"
5. Vérifiez PA des persos (+1 Grand PA)
```

### Test 4 : Téléportation
```
1. Technique avec téléportation actif
2. Sélectionnez cible
3. F12 → Console
4. Lancez technique
5. Console doit montrer logs
6. Envoyez-moi les logs si erreur
```

---

## ⚠️ PROBLÈMES NON RÉSOLUS :

### Animation CHM
Nécessite modification de `template.json` + HTML
→ Complexe, à faire si vraiment nécessaire

### Téléportation
Code OK mais ne bouge pas les tokens
→ DEBUG nécessaire avec Console logs

### Jets de réussite
Pas clair quel est le problème
→ Précisez ce qui ne s'affiche pas

### Image actor
Foundry le gère nativement
→ Vérifier si ça marche déjà

---

## 📞 POUR DÉBUGGER :

### Récupération PA ne marche pas :
```
1. F12 → Console
2. Lancez combat
3. Faites "Next Round"
4. Envoyez-moi : Message "🔍 updateCombat hook"
```

### Téléportation ne marche pas :
```
1. F12 → Console
2. Lancez technique avec téléportation
3. Regardez : "FFdreame | Téléportation..."
4. Envoyez-moi les messages
```

---

**Installez ce ZIP et testez ! Envoyez-moi les logs Console pour les problèmes restants ! 🔍**
