# 🎬 GUIDE COMPLET DES ANIMATIONS - FFdreame

## 🎯 Problème résolu

**Avant** : Les animations ne marchaient pas ou donnaient des erreurs "could not find file"

**Maintenant** : 
- ✅ Chemins corrects pour JB2A Free
- ✅ Support de Eski Effect Free
- ✅ Gestion intelligente selon le type de technique
- ✅ Options de personnalisation complètes

---

## 📦 Modules requis

### Obligatoire
- **Sequencer** - Gestionnaire d'animations
  - https://foundryvtt.com/packages/sequencer

### Bibliothèques d'animations (au moins une)
- **JB2A Free** - Animations 2D gratuites
  - https://foundryvtt.com/packages/JB2A_DnD5e
  
- **Eski Effect Free** - Animations 3D gratuites
  - https://foundryvtt.com/packages/eskieffects-free

---

## 🎨 Animations JB2A Free - Chemins corrects

### Pour ATTM (Attaque magique)

**Projectiles magiques** :
```
jb2a.fire_bolt.orange          ← Trait de feu
jb2a.ray_of_frost.blue         ← Rayon de givre  
jb2a.lightning_bolt.narrow.blue ← Éclair
jb2a.magic_missile.blue        ← Missile magique
jb2a.scorching_ray.01.orange   ← Rayon scorchant
jb2a.acid_splash.01.green      ← Projectile d'acide
```

### Pour MULTI (Multi-cibles)

**Explosions** :
```
jb2a.fireball.beam.orange      ← Boule de feu (RECOMMANDÉ)
jb2a.explosion.orange          ← Explosion simple
jb2a.explosion.blue            ← Explosion glace
jb2a.thunderwave.center.blue   ← Onde de choc
jb2a.impact.ground_crack.blue  ← Impact au sol
```

**Zones d'effet** :
```
jb2a.ice_spikes.radial.white   ← Pics de glace radiaux
jb2a.wall_of_fire.100ft.orange ← Mur de feu
jb2a.sleet_storm.blue          ← Tempête de grêle
```

### Pour ATTA (Attaque physique)

**Corps à corps** :
```
jb2a.melee_generic.slash.01    ← Slash
jb2a.melee_generic.bludgeoning.01 ← Coup
jb2a.melee_generic.piercing.01 ← Piqûre
```

**Projectiles physiques** :
```
jb2a.arrow.physical.white      ← Flèche
```

### Pour CUR (Soins)

**Effets de soin** :
```
jb2a.healing_generic.burst.greenorange ← Soin (RECOMMANDÉ)
jb2a.bless.400px.intro.blue    ← Bénédiction
```

### Pour DEF (Défense)

**Boucliers** :
```
jb2a.shield.01.intro.blue      ← Bouclier
jb2a.shield_themed.above.molten_earth.01.orange ← Bouclier de terre
```

---

## 🌟 Animations Eski Effect Free

### Projectiles 3D

```
modules/eskieffects-free/effects/magic/energy_orb_01_regular_blue_30ft_1000x400.webm
modules/eskieffects-free/effects/magic/light_ray_01_regular_white_30ft_1600x400.webm
modules/eskieffects-free/effects/magic/fire_bolt_01_regular_orange_30ft_1600x400.webm
```

### Explosions 3D

```
modules/eskieffects-free/effects/magic/explosion_01_regular_blue_400x400.webm
modules/eskieffects-free/effects/magic/fire_explosion_01_regular_orange_400x400.webm
```

### Buffs / Auras

```
modules/eskieffects-free/effects/magic/shield_01_regular_blue_400x400.webm
modules/eskieffects-free/effects/magic/healing_01_regular_green_400x400.webm
```

---

## ⚙️ Configuration dans la console (en attendant l'interface)

### Configurer une animation

Ouvrez la console (F12) et utilisez :

```javascript
// Récupérer votre technique
const technique = game.items.getName("Boule de Feu");

// Configuration complète
await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",  // ou "eski_free"
    type: "explosion",      // projectile, explosion, melee, buff, healing, zone
    path: "jb2a.fireball.beam.orange",
    options: {
      scale: 1.0,           // Taille (0.5 = 50%, 2.0 = 200%)
      duration: 1000,       // Durée en ms
      delay: 0,             // Délai avant l'animation en ms
      repeats: 1,           // Nombre de répétitions
      opacity: 1.0,         // Transparence (0.0 à 1.0)
      tint: "",             // Couleur (ex: "#FF0000" pour rouge)
      anchor: "center",     // Point d'ancrage
      waitUntilFinished: -500  // Attendre avant de continuer
    },
    targeting: {
      source: "caster",     // Qui lance (caster, target, position)
      target: "target",     // Vers qui (target, caster, position, none)
      stretchTo: false,     // Étirer vers la cible (projectiles)
      attachTo: false,      // Attacher à la cible (buffs)
      moveTowards: false,   // Se déplacer vers la cible
      teleport: false       // Téléporter à la fin
    },
    sound: {
      enabled: false,
      file: "",
      volume: 0.8,
      delay: 0
    }
  }
});
```

---

## 🎯 Exemples par style

### ATTM - Trait de feu

```javascript
const technique = game.items.getName("Trait de feu");

await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",
    type: "projectile",
    path: "jb2a.fire_bolt.orange",
    options: {
      scale: 0.8,
      duration: 1000,
      waitUntilFinished: -200
    },
    targeting: {
      source: "caster",
      target: "target",
      stretchTo: true,  // Important pour projectiles !
      attachTo: false,
      moveTowards: false,
      teleport: false
    }
  }
});
```

### MULTI - Boule de feu

```javascript
const technique = game.items.getName("Boule de feu");

await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",
    type: "explosion",
    path: "jb2a.fireball.beam.orange",
    options: {
      scale: 1.2,  // Plus grosse pour multi-cibles
      duration: 1500,
      waitUntilFinished: -500
    },
    targeting: {
      source: "caster",
      target: "target",  // Explosion sur la cible
      stretchTo: false,  // Pas de stretch pour explosions
      attachTo: false,
      moveTowards: false,
      teleport: false
    }
  }
});
```

### CUR - Soin

```javascript
const technique = game.items.getName("Soin");

await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",
    type: "healing",
    path: "jb2a.healing_generic.burst.greenorange",
    options: {
      scale: 1.0,
      duration: 2000,
      waitUntilFinished: -1000
    },
    targeting: {
      source: "caster",
      target: "target",  // ou "caster" pour auto-soin
      stretchTo: false,
      attachTo: true,    // Attacher l'effet de soin
      moveTowards: false,
      teleport: false
    }
  }
});
```

### ATTA - Slash corps à corps

```javascript
const technique = game.items.getName("Slash");

await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",
    type: "melee",
    path: "jb2a.melee_generic.slash.01",
    options: {
      scale: 1.0,
      duration: 800,
      waitUntilFinished: -300
    },
    targeting: {
      source: "caster",
      target: "target",
      stretchTo: false,
      attachTo: false,
      moveTowards: false,
      teleport: false
    }
  }
});
```

---

## 🔧 Paramètres importants

### Type d'animation

| Type | Usage | stretchTo | attachTo |
|------|-------|-----------|----------|
| **projectile** | Flèches, sorts qui volent | ✅ true | ❌ false |
| **explosion** | Boules de feu, impacts | ❌ false | ❌ false |
| **melee** | Coups, slashs | ❌ false | ❌ false |
| **buff** | Boucliers, auras | ❌ false | ✅ true |
| **healing** | Soins | ❌ false | ✅ true |
| **zone** | Murs, tempêtes | ❌ false | ❌ false |

### Scale (taille)

- `0.5` = 50% (petit)
- `1.0` = 100% (normal)
- `1.5` = 150% (grand)
- `2.0` = 200% (très grand)

**Recommandations** :
- Projectiles simples : `0.7-0.9`
- Explosions : `1.0-1.5`
- Multi-cibles : `1.2-2.0`
- Ultimates : `2.0-3.0`

### Duration (durée)

- `500` = 0.5 seconde (rapide)
- `1000` = 1 seconde (normal)
- `2000` = 2 secondes (lent)
- `3000` = 3 secondes (très lent)

**Recommandations** :
- Attaques rapides : `500-800`
- Sorts normaux : `1000-1500`
- Explosions : `1500-2000`
- Buffs/soins : `2000-3000`

### waitUntilFinished

Temps à attendre AVANT que l'action continue :

- `-500` = Continue 500ms avant la fin de l'animation
- `-200` = Continue 200ms avant la fin (rapide)
- `0` = Attend la fin complète
- `1000` = Attend la fin + 1 seconde

**Recommandations** :
- Projectiles rapides : `-200`
- Normal : `-500`
- Explosions longues : `-1000`

---

## 🐛 Dépannage

### "could not find file"

**Causes** :
1. Chemin incorrect
2. Module JB2A/Eski non installé
3. Faute de frappe dans le chemin

**Solutions** :
1. Vérifiez que le module est activé dans "Add-on Modules"
2. Copiez-collez exactement les chemins de ce guide
3. Testez avec une animation simple d'abord : `jb2a.explosion.orange`

### Animation ne se joue pas

**Vérifications** :
1. `enabled: true` ✅
2. Module Sequencer activé ✅
3. Module JB2A ou Eski activé ✅
4. Chemin correct ✅
5. La technique a réussi (jet de dés) ✅

### Animation trop petite/grande

Ajustez le paramètre `scale` :
```javascript
options: {
  scale: 1.5  // Augmentez pour agrandir
}
```

### Animation trop rapide/lente

Ajustez `duration` :
```javascript
options: {
  duration: 2000  // Augmentez pour ralentir
}
```

---

## 📋 Macro rapide pour tester

Créez une macro pour tester rapidement :

```javascript
// MACRO : Tester animation
const technique = game.user.character.items.find(i => i.name === "VOTRE TECHNIQUE");

if (!technique) {
  ui.notifications.warn("Technique non trouvée !");
  return;
}

// Configuration de test
await technique.update({
  'system.animation': {
    enabled: true,
    library: "jb2a_free",
    type: "explosion",
    path: "jb2a.explosion.orange",
    options: {
      scale: 1.0,
      duration: 1000,
      waitUntilFinished: -500
    },
    targeting: {
      source: "caster",
      target: "target",
      stretchTo: false,
      attachTo: false,
      moveTowards: false,
      teleport: false
    }
  }
});

ui.notifications.info("✅ Animation configurée ! Testez la technique.");
```

---

## 🎬 Bibliothèque complète (référence rapide)

### JB2A Free - Top 20

```
PROJECTILES:
jb2a.fire_bolt.orange
jb2a.ray_of_frost.blue
jb2a.lightning_bolt.narrow.blue
jb2a.magic_missile.blue
jb2a.arrow.physical.white

EXPLOSIONS:
jb2a.fireball.beam.orange
jb2a.explosion.orange
jb2a.explosion.blue
jb2a.thunderwave.center.blue
jb2a.impact.ground_crack.blue

MELEE:
jb2a.melee_generic.slash.01
jb2a.melee_generic.bludgeoning.01
jb2a.melee_generic.piercing.01

BUFFS/SOINS:
jb2a.healing_generic.burst.greenorange
jb2a.shield.01.intro.blue
jb2a.bless.400px.intro.blue

ZONES:
jb2a.ice_spikes.radial.white
jb2a.wall_of_fire.100ft.orange
jb2a.sleet_storm.blue
```

---

**Version** : Animations complètes  
**Date** : Février 2026  
**Modules requis** : Sequencer + (JB2A ou Eski)
