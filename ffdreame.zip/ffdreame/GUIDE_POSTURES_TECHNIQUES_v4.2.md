# 🎯 GUIDE COMPLET - Créer Postures avec Techniques Intégrées

## ✅ PROBLÈME RÉSOLU

Vous aviez raison ! La méthode avec un onglet "Techniques" directement dans la posture est BEAUCOUP plus simple.

J'ai corrigé le système pour que vous puissiez créer **jusqu'à 10 techniques par posture** facilement.

---

## 🚀 COMMENT CRÉER UNE POSTURE AVEC SES TECHNIQUES

### Étape 1 : Créer la Posture

1. **Menu Items** → **Créer un Item**
2. **Type** : Sélectionner **"Posture"**
3. **Nom** : Donnez un nom à votre posture (ex: "Style Dragon")

### Étape 2 : Configurer la Posture

#### Onglet 📖 Description
- **Description** : Décrivez le style de combat

#### Onglet ⚔️ Attaque Base
- **Base Attaque** : Bonus de dégâts pour l'attaque de base (ex: 20)

#### Onglet ✨ Effet Posture
- **Type d'effet** : Bonus dégâts %, Régénération PA, Contre, Esquive, Initiative
- **Valeur** : Montant du bonus
- **Condition** : Quand l'effet se déclenche

#### Onglet 🔥 Ultimate
- **Nom Ultimate** : Nom de la technique ultime (ex: "Dragon Céleste")
- **Description** : Effet spectaculaire
- **Dégâts** : Dégâts de l'ultimate (ex: 300)

### Étape 3 : Ajouter les Techniques

#### Onglet ⚡ Techniques (NOUVEAU!)

**C'est ici que vous créez toutes vos techniques !**

1. Cliquez sur **"➕ Ajouter une Technique"**
2. Une nouvelle technique apparaît avec tous les champs :

```
┌─────────────────────────────────────────┐
│ #1 [Nom de la technique]           [✕]  │
├─────────────────────────────────────────┤
│ 📝 Description:                         │
│ [Description de la technique...]        │
│                                         │
│ ✨ Effets spéciaux:                     │
│ [Ex: Étourdit 1 tour, +1 action...]    │
│                                         │
│ ⚔️ Style: [CAC ▼]  💎 PM: [15]         │
│ ⚔️ Dégâts: [30]    🎯 PA: [Grand ▼]    │
│                                         │
│ 📊 Formule: ATQ + (PM÷2) + 30          │
└─────────────────────────────────────────┘
```

3. Remplissez les champs :
   - **Nom** : Ex: "Griffe du Dragon"
   - **Description** : Ce que fait la technique
   - **Effets spéciaux** : Effets additionnels
   - **Style** : CAC, MG, P, EHa, EHm, EF, BUFF
   - **Coût PM** : Points magiques requis (ex: 15)
   - **Dégâts base** : Dégâts de base (ex: 30)
   - **Points d'action** : Petit PA (◆) ou Grand PA (⬛)

4. Cliquez à nouveau sur **"➕ Ajouter une Technique"** pour en créer une autre

5. **Répétez jusqu'à avoir 6-10 techniques !**

---

## 📊 EXEMPLE COMPLET

### Posture : "Style Dragon"

**Onglet Description:**
- Description : Un style de combat brutal basé sur la force brute

**Onglet Attaque Base:**
- Base Attaque : 20

**Onglet Ultimate:**
- Nom : Dragon Céleste
- Dégâts : 300

**Onglet Techniques:**

#### Technique #1 : Griffe du Dragon
- Style : CAC
- PM : 15
- Dégâts : 30
- PA : Grand PA
- Effets : Saignement 5 dégâts/tour

#### Technique #2 : Souffle Enflammé
- Style : MG
- PM : 25
- Dégâts : 50
- PA : Grand PA
- Effets : Brûlure 3 tours

#### Technique #3 : Écailles Protectrices
- Style : BUFF
- PM : 20
- Dégâts : 30% (réduction)
- PA : Grand PA
- Effets : Bouclier temporaire

#### Technique #4 : Frappe Rapide
- Style : CAC
- PM : 10
- Dégâts : 20
- PA : Petit PA
- Effets : +1 action bonus

#### Technique #5 : Rugissement
- Style : BUFF
- PM : 15
- Dégâts : 20% (bonus ATQ)
- PA : Petit PA
- Effets : +20% ATQ pendant 2 tours

#### Technique #6 : Queue Fouettante
- Style : P
- PM : 30
- Dégâts : 60
- PA : Grand PA
- Effets : Repousse l'ennemi

---

## 🎮 AFFICHAGE SUR LA FICHE PERSONNAGE

Une fois votre posture avec ses techniques créée, dans la fiche du personnage :

### Onglet Combat → Section Postures

```
╔═══════════════════════════════════════════════╗
║  🥊 STYLE DRAGON                             ║
║  [○ Inactive] [⚙️ CONFIG]                    ║
╠═══════════════════════════════════════════════╣
║  ⚔️ ATTAQUE DE BASE                          ║
║  170 dégâts                                   ║
║                                               ║
║  📜 TECHNIQUES:                               ║
║  ┌─────────────────────────────────────────┐ ║
║  │ 1. Griffe du Dragon                     │ ║
║  │    💎 15 PM  ⚔️ 30 dégâts  ⬛ Grand PA   │ ║
║  │    Saignement 5 dégâts/tour             │ ║
║  └─────────────────────────────────────────┘ ║
║  ┌─────────────────────────────────────────┐ ║
║  │ 2. Souffle Enflammé                     │ ║
║  │    💎 25 PM  ⚔️ 50 dégâts  ⬛ Grand PA   │ ║
║  │    Brûlure 3 tours                      │ ║
║  └─────────────────────────────────────────┘ ║
║  ┌─────────────────────────────────────────┐ ║
║  │ 3. Écailles Protectrices                │ ║
║  │    💎 20 PM  🛡️ 30% réduction  ⬛ Grand │ ║
║  │    Bouclier temporaire                  │ ║
║  └─────────────────────────────────────────┘ ║
║  ... (3 autres techniques)                   ║
║                                               ║
║  🔥 ULTIMATE : Dragon Céleste                ║
║  🔓 DISPONIBLE (Burst = 100)                 ║
║  [🔥 LANCER ULTIMATE]                        ║
╚═══════════════════════════════════════════════╝
```

---

## ⚙️ FONCTIONNALITÉS

### Limite de Techniques
- **Maximum : 10 techniques par posture**
- Le bouton "Ajouter" affiche le compteur : "➕ Ajouter une Technique (3/10)"
- Quand la limite est atteinte, un message s'affiche

### Suppression de Technique
- Cliquez sur le **[✕]** à côté du nom
- Une confirmation s'affiche : "Êtes-vous sûr de vouloir supprimer ?"
- La technique est supprimée définitivement

### Compteur
En haut de l'onglet Techniques :
```
┌─────────────────────────────────┐
│ Techniques créées : 6 / 10      │
└─────────────────────────────────┘
```

### Formules de Calcul
Chaque technique affiche automatiquement sa formule selon le style :

| Style | Formule | Badge |
|-------|---------|-------|
| **⚔️ CAC** | ATQ + (PM÷2) + Base | Orange |
| **✨ MG** | (ATQ÷2) + PM + Base | Violet |
| **💥 P** | ATQ + PM + Base | Or |
| **🌪️ EHa** | ATQ + Base (3 jets) | Rouge |
| **🌊 EHm** | PM + Base (3 jets) | Bleu |
| **⚡ EF** | PM + Base + (ATQ÷2) | Jaune |
| **🛡️ BUFF** | Buff/Soin: Base% | Vert |

---

## 🎨 STYLES DE TECHNIQUE

### ⚔️ CAC (Corps à Corps)
- **Formule** : ATQ + (PM ÷ 2) + Base
- **Usage** : Attaque physique avec légère amplification magique
- **Exemple** : 150 ATQ + (60 PM ÷ 2) + 30 Base = **210 dégâts**

### ✨ MG (Magie Guidée)
- **Formule** : (ATQ ÷ 2) + PM + Base
- **Usage** : Magie pure avec appui physique mineur
- **Exemple** : (150 ATQ ÷ 2) + 60 PM + 50 Base = **185 dégâts**

### 💥 P (Parfait)
- **Formule** : ATQ + PM + Base
- **Usage** : Fusion totale physique + magique
- **Exemple** : 150 ATQ + 60 PM + 40 Base = **250 dégâts**

### 🌪️ EHa (Éclat Haine - Attaque)
- **Formule** : ATQ + Base
- **Spécial** : 3 jets consécutifs avec seuils décroissants
  - Jet 1 : Seuil -60
  - Jet 2 : Seuil -50 (si jet 1 réussi)
  - Jet 3 : Seuil -40 (si jet 2 réussi)
- **Usage** : Combo physique dévastateur

### 🌊 EHm (Éclat Haine - Magie)
- **Formule** : PM + Base
- **Spécial** : 3 jets consécutifs avec seuils décroissants
- **Usage** : Combo magique dévastateur

### ⚡ EF (Éclat Foudre)
- **Formule** : PM + Base + (ATQ ÷ 2)
- **Usage** : Puissance magique avec effets spéciaux

### 🛡️ BUFF (Soutien)
- **Formule** : Pas de dégâts
- **Types** :
  - Réduction de dégâts (ex: 30%)
  - Soins (ex: 40% PV max)
  - Bonus d'attaque (ex: +25% ATQ)

---

## 🔧 CONSEILS D'UTILISATION

### Organiser vos Techniques

**Petits PA** (action rapide) :
- Attaques légères (10-20 PM, 20-30 dégâts)
- Buffs rapides
- Déplacements

**Grands PA** (action principale) :
- Attaques puissantes (20-40 PM, 40-80 dégâts)
- Buffs majeurs
- Combos

### Équilibrage

Pour une posture équilibrée, créez :
- **2-3 techniques légères** (Petit PA, faible PM)
- **2-3 techniques moyennes** (Grand PA, PM modéré)
- **1-2 techniques puissantes** (Grand PA, PM élevé)
- **1 technique de soutien** (BUFF ou utilité)

### Exemples d'Effets Spéciaux

- **Stun** : Étourdit 1 tour
- **Paralysie** : Immobilise 2 tours
- **Saignement** : 5 dégâts/tour pendant 3 tours
- **Brûlure** : 3 dégâts/tour pendant 5 tours
- **+1 Action** : Donne une action bonus
- **Repousse** : Éloigne l'ennemi
- **Soin** : Restaure X PV
- **Bouclier** : Absorbe X dégâts

---

## 📝 CHECKLIST DE CRÉATION

Pour chaque posture, vérifiez :

- [ ] Nom de la posture défini
- [ ] Description écrite
- [ ] Attaque Base configurée
- [ ] Effet de posture choisi (optionnel)
- [ ] Ultimate défini (optionnel)
- [ ] Au moins 3-4 techniques créées
- [ ] Chaque technique a un nom
- [ ] Style défini pour chaque technique
- [ ] Coûts PM configurés
- [ ] Dégâts base configurés
- [ ] Points d'action (PA) définis
- [ ] Effets spéciaux notés (optionnel)
- [ ] Formules vérifiées

---

## 🐛 RÉSOLUTION DE PROBLÈMES

### Le bouton "Ajouter une Technique" ne fait rien
**Solution :**
1. Vérifier que vous êtes connecté en tant que **MJ**
2. Les joueurs ne peuvent pas ajouter de techniques
3. Redémarrer Foundry VTT

### Les techniques ne s'affichent pas
**Solution :**
1. Vérifier que vous avez bien **sauvegardé** la posture (icône disquette)
2. Fermer et rouvrir la fiche de la posture
3. Rafraîchir la page (F5)

### Je ne peux ajouter qu'une seule technique
**Solution :**
- Cette version corrige ce problème !
- Vous pouvez maintenant en créer **jusqu'à 10**
- Cliquez plusieurs fois sur "Ajouter une Technique"

### La limite de 10 techniques est atteinte
**Solution :**
- Si vous avez besoin de plus de techniques, créez une **2ème posture**
- Chaque personnage peut avoir **2 postures**
- Donc 2 × 10 = **20 techniques au total** !

---

## 🎯 RÉSUMÉ RAPIDE

### Créer une Posture avec Techniques

1. **Créer Item** → Type "Posture"
2. Remplir nom, description, attaque base
3. **Onglet Techniques** → Cliquer "➕ Ajouter une Technique"
4. Remplir tous les champs de la technique
5. Cliquer à nouveau sur "➕ Ajouter" pour la suivante
6. Répéter jusqu'à avoir 6-10 techniques
7. **Sauvegarder** (icône disquette)
8. La posture avec ses techniques apparaît automatiquement sur la fiche du personnage !

---

## 📦 FICHIERS MODIFIÉS

Cette version v4.2 modifie :

1. **`templates/item/posture-sheet.html`**
   - Onglet Techniques amélioré
   - Compteur de techniques
   - Interface utilisateur enrichie
   - Champ Points d'action ajouté

2. **`module/sheets/item-sheet.js`**
   - Limite à 10 techniques
   - Messages de confirmation
   - Dialogue de suppression
   - Valeurs par défaut améliorées

3. **`css/ffdreame.css`**
   - Styles pour l'onglet techniques
   - Badges colorés par style
   - Animations et transitions

---

## ✅ AVANTAGES DE CETTE MÉTHODE

✅ **Simple** : Tout dans la même fiche posture
✅ **Rapide** : Pas besoin de créer des items séparés
✅ **Organisé** : Toutes les techniques d'une posture au même endroit
✅ **Flexible** : Jusqu'à 10 techniques par posture
✅ **Visuel** : Compteur et formules automatiques
✅ **Sécurisé** : Confirmation avant suppression

---

**Bon création de postures ! 🎮⚔️**
