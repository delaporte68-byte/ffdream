// ========================================
// MACRO DE MIGRATION - V10.1
// Ajoute les champs manquants aux acteurs existants
// ========================================

console.log("🔄 Début de la migration V10.1...");

// Récupérer tous les personnages
const characters = game.actors.filter(a => a.type === "character" || a.type === "cyberpunk");

console.log(`📋 ${characters.length} acteur(s) à migrer`);

let migrated = 0;
let errors = 0;

for (const actor of characters) {
  try {
    console.log(`  → Migration de ${actor.name}...`);
    
    // Préparer les données manquantes
    const updateData = {};
    let needsUpdate = false;
    
    // 1. Vérifier deplacementGratuitUtilise
    if (actor.system.combat?.deplacementGratuitUtilise === undefined) {
      updateData['system.combat.deplacementGratuitUtilise'] = false;
      needsUpdate = true;
      console.log(`    ✓ Ajout de deplacementGratuitUtilise`);
    }
    
    // 2. Vérifier reactions
    if (!actor.system.combat?.reactions) {
      updateData['system.combat.reactions'] = {
        esquive: false,
        defense: false,
        marche: false
      };
      needsUpdate = true;
      console.log(`    ✓ Ajout de reactions`);
    } else {
      // Vérifier chaque réaction
      if (actor.system.combat.reactions.esquive === undefined) {
        updateData['system.combat.reactions.esquive'] = false;
        needsUpdate = true;
      }
      if (actor.system.combat.reactions.defense === undefined) {
        updateData['system.combat.reactions.defense'] = false;
        needsUpdate = true;
      }
      if (actor.system.combat.reactions.marche === undefined) {
        updateData['system.combat.reactions.marche'] = false;
        needsUpdate = true;
      }
    }
    
    // 3. Vérifier actionPoints.grandX.disponible
    const actionPoints = actor.system.combat?.actionPoints;
    if (actionPoints) {
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand && grand.disponible === undefined) {
          updateData[`system.combat.actionPoints.grand${i}.disponible`] = true;
          needsUpdate = true;
          console.log(`    ✓ Ajout de actionPoints.grand${i}.disponible`);
        }
      }
    }
    
    // Mettre à jour si nécessaire
    if (needsUpdate) {
      await actor.update(updateData);
      migrated++;
      console.log(`  ✅ ${actor.name} migré avec succès`);
    } else {
      console.log(`  ⏭️ ${actor.name} déjà à jour`);
    }
    
  } catch (error) {
    console.error(`  ❌ Erreur pour ${actor.name}:`, error);
    errors++;
  }
}

console.log(`
╔════════════════════════════════════
║  MIGRATION TERMINÉE
╠════════════════════════════════════
║  Total: ${characters.length} acteur(s)
║  Migrés: ${migrated}
║  À jour: ${characters.length - migrated - errors}
║  Erreurs: ${errors}
╚════════════════════════════════════
`);

if (migrated > 0) {
  ui.notifications.info(`✅ Migration réussie ! ${migrated} acteur(s) mis à jour.`);
} else {
  ui.notifications.info(`✅ Tous les acteurs sont déjà à jour !`);
}

if (errors > 0) {
  ui.notifications.error(`❌ ${errors} erreur(s) détectée(s). Voir console (F12).`);
}
