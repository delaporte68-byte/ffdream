# 🎯 GUIDE - Interface d'effets de tableaux

## ✨ Interface graphique intégrée !

Vous pouvez maintenant configurer les effets **directement dans la fiche de personnage**, sans console ni macro !

---

## 📍 Où trouver l'interface ?

### Dans l'onglet Combat

1. Ouvrez votre fiche de personnage
2. Allez dans l'onglet **"Combat"**
3. Sous chaque tableau, vous verrez un bouton **"⚡ Effet passif"**

---

## 🎮 Utilisation

### Étape 1 : Ouvrir l'interface

Cliquez sur le bouton **"⚡ Effet passif"** sous le tableau que vous voulez configurer.

L'interface se déploie avec tous les champs de configuration.

### Étape 2 : Choisir le type d'effet

Dans le menu déroulant **"Type d'effet"**, sélectionnez :

- **Aucun** - Désactive l'effet
- **Bonus dégâts après X réussites** - +X dégâts après Y techniques réussies
- **Récup PM après X réussites** - Récupère X PM après Y réussites
- **Parade après X réussites** - Jet de parade après Y réussites
- **Initiative automatique** - Prend l'initiative en début de combat
- **Bonus dégâts permanent** - +X dégâts à toutes les attaques
- **Bonus PM permanent** - +X PM max
- **Bonus Burste par technique** - +X Burste au lieu de +10

### Étape 3 : Configurer les valeurs

#### Seuil (réussites)
Nombre de techniques réussies nécessaires pour activer l'effet.

**Exemples** :
- `5` → L'effet s'active après 5 techniques réussies
- `3` → L'effet s'active après 3 techniques réussies

**Note** : Pour les effets permanents (Initiative, Bonus permanent...), le seuil n'est pas utilisé.

#### Bonus
Montant du bonus appliqué.

**Exemples** :
- `50` → +50 dégâts ou +50 PM
- `20` → +20 Burste par technique
- `30` → Récupère 30 PM

### Étape 4 : Description (optionnelle)

Vous pouvez ajouter une description personnalisée de l'effet.

**Exemple** : "Après 5 attaques, frappe dévastatrice !"

### Étape 5 : Voir la progression

Une fois l'effet configuré, une barre de progression s'affiche :

```
Progression : 3 / 5  [🔄]
```

- **3** = Nombre actuel de réussites
- **5** = Seuil à atteindre
- **🔄** = Bouton pour réinitialiser le compteur

---

## 💡 Exemples de configuration

### Build Agressif

**Tableau 1 : "Assaut"**

```
Type d'effet : Bonus dégâts après X réussites
Seuil : 5
Bonus : 50
Description : Frappe dévastatrice !
```

**En jeu** :
- Attaque 1 → 1/5
- Attaque 2 → 2/5
- ...
- Attaque 5 → 5/5 → 🔥 +50 dégâts activé !

---

### Build Défensif

**Tableau 1 : "Garde"**

```
Type d'effet : Parade après X réussites
Seuil : 4
Bonus : 0
Description : Parade activée
```

**En jeu** :
- 4 techniques défensives → Parade prête
- Prochaine attaque ennemie → Jet de parade

---

### Build Leader

**Tableau 1 : "Initiative"**

```
Type d'effet : Initiative automatique
Seuil : 0
Bonus : 0
Description : Premier à frapper
```

**En jeu** :
- Début de combat → Vous jouez en premier automatiquement

---

### Build Soutien

**Tableau 2 : "Régénération"**

```
Type d'effet : Récup PM après X réussites
Seuil : 3
Bonus : 30
Description : Récupération magique
```

**En jeu** :
- 3 sorts de soin → +30 PM immédiatement

---

## 🔄 Modifier un effet existant

1. Cliquez sur **"⚡ Effet passif"**
2. L'interface s'ouvre avec les valeurs actuelles
3. Modifiez les champs que vous voulez
4. Cliquez ailleurs ou changez d'onglet → **Sauvegarde automatique** ✅

---

## 🔁 Réinitialiser le compteur

Si vous voulez recommencer à zéro :

1. Cliquez sur le bouton **🔄** à côté de la progression
2. Confirmez
3. Le compteur revient à 0/X

---

## ❌ Désactiver un effet

Pour enlever l'effet d'un tableau :

1. Ouvrez l'interface (**"⚡ Effet passif"**)
2. Dans **"Type d'effet"**, sélectionnez **"Aucun"**
3. L'effet est désactivé ✅

---

## 🎨 Interface visuelle

### Bouton "Effet passif"

- **Bleu** → Cliquez pour ouvrir
- **Dégradé** → Effet actif et moderne
- **Icône ⚡** → Facile à repérer

### Formulaire déroulant

- **Animation fluide** → Se déploie en douceur
- **Champs organisés** → Type, Seuil, Bonus, Description
- **Progression visible** → Compteur en temps réel

### Compteur

- **Fond bleu clair** → Met en évidence la progression
- **Bordure bleue** → Effet activé
- **Bouton reset rouge** → Réinitialiser facilement

---

## 🔧 Compatibilité

### Sauvegarde automatique

Tous les changements sont sauvegardés **automatiquement** quand vous :
- Changez de champ
- Cliquez ailleurs
- Changez d'onglet

**Pas besoin de bouton "Sauvegarder" !**

### Multi-tableaux

- Tableau 1 et Tableau 2 ont chacun leur propre effet
- Les effets sont **indépendants**
- Vous pouvez en configurer un seul ou les deux

### Compatibilité avec anciennes versions

Si vous migrez depuis une version sans effets :
- Les champs seront vides par défaut
- Configurez vos effets comme vous voulez
- Aucun effet n'est actif par défaut

---

## 📊 Tableau récapitulatif

| Type d'effet | Seuil nécessaire ? | Bonus nécessaire ? | Permanent ? |
|--------------|-------------------|-------------------|-------------|
| Bonus dégâts après réussites | ✅ Oui | ✅ Oui | ❌ Non |
| Récup PM après réussites | ✅ Oui | ✅ Oui | ❌ Non |
| Parade après réussites | ✅ Oui | ❌ Non | ❌ Non |
| Initiative automatique | ❌ Non | ❌ Non | ✅ Oui |
| Bonus dégâts permanent | ❌ Non | ✅ Oui | ✅ Oui |
| Bonus PM permanent | ❌ Non | ✅ Oui | ✅ Oui |
| Bonus Burste par technique | ❌ Non | ✅ Oui | ✅ Oui |

---

## 🐛 Dépannage

### L'interface ne s'ouvre pas

**Vérifications** :
1. Avez-vous cliqué sur le bon bouton ? (⚡ Effet passif)
2. Le tableau est-il activé ? (Toggle ON)
3. Console F12 → Erreurs ?

**Solution** : Ctrl+F5 pour vider le cache

### Les changements ne se sauvegardent pas

**Vérifications** :
1. Êtes-vous propriétaire du personnage ?
2. La fiche est-elle en mode édition ?
3. Console F12 → Erreurs ?

**Solution** : Fermez et rouvrez la fiche

### Le compteur ne s'incrémente pas en combat

**Vérifications** :
1. L'effet est-il bien configuré ?
2. La technique a-t-elle réussi ?
3. La technique vient-elle bien de CE tableau ?

**Solution** : Vérifiez le type d'effet et le seuil

---

## ✨ Avantages de l'interface graphique

| Aspect | Avant (Console/Macro) | Maintenant (Interface) |
|--------|----------------------|------------------------|
| **Facilité** | Console F12 complexe | Clic sur un bouton |
| **Visibilité** | Code caché | Tout visible dans la fiche |
| **Modification** | Code à écrire | Champs à remplir |
| **Progression** | Invisible | Compteur en temps réel |
| **Erreurs** | Faciles | Validées automatiquement |

---

## 🎯 Conseils d'utilisation

### Commencez simple

Pour votre premier effet :
1. Choisissez "Bonus dégâts après X réussites"
2. Seuil : 5
3. Bonus : 30
4. Testez en combat !

### Expérimentez

- Essayez différents seuils (3, 5, 7...)
- Testez différents bonus (20, 50, 100...)
- Combinez avec différents tableaux

### Adaptez à votre style

- **Agressif** → Bonus dégâts
- **Défensif** → Parade
- **Soutien** → Récup PM
- **Leader** → Initiative

---

**Amusez-vous avec vos nouveaux effets !** 🎉

Version : 1.0 avec interface graphique  
Date : Février 2026
