# 🎮 FFdreame v3.2 - CORRECTIONS ET NOUVEAUTÉS

## 📦 Installation

**Remplacez** votre système actuel par cette version v3.2  
**SAUVEGARDEZ** vos personnages avant !

---

## ✅ CORRECTIONS APPORTÉES

### 1. 🎲 Bonus de compétences appliqués automatiquement
**CORRIGÉ :**  Les bonus de dés sont maintenant appliqués automatiquement aux jets !
- **5 points** → **-1d6** (soustrait du résultat)
- **10 points** → **-1d12** (remplace le 1d6, soustrait du résultat)
- Affichage dans le message de jet : "📊 Bonus compétence: 1d6 (5 points)"

### 2. ✅ Techniques s'affichent dans les postures
**CORRIGÉ :** Les techniques s'affichent maintenant correctement quand leur champ "Posture Associée" correspond au nom exact de la posture.

**Comment ça marche :**
1. Créez une posture : "Style du Dragon"
2. Créez une technique et dans **"Posture Associée"** mettez exactement : **"Style du Dragon"**
3. La technique apparaît automatiquement dans la posture sur la fiche !

### 3. 🎯 Affichage 2 postures côte à côte
**MODIFIÉ :** Maximum 2 postures par personnage, affichées en 2 colonnes
- Posture 1 → Colonne gauche
- Posture 2 → Colonne droite
- Layout responsive (1 colonne sur mobile)

### 4. 🔄 Nouveau tour restaure 1 seul grand PA
**CORRIGÉ :** Le bouton "Nouveau Tour" ne restaure plus TOUS les PA !
- Trouve le **premier grand PA complètement utilisé** (2 petits à false)
- Le restaure (remet les 2 petits à true)
- Les autres restent dans leur état actuel
- Message : "Grand PA X restauré (2 petits)"

### 5. ⚡ SYSTÈME BURSTE + ULTIMATE

#### Jauge Burste
- **Barre visuelle** affichée en haut de l'onglet Combat
- **0 à 100**
- **+10** par attaque ou technique **réussie**
- **+5** par coup reçu (à implémenter manuellement pour l'instant)
- Notification à 100 : "⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !"

#### Ultimate par posture
- **1 Ultimate par posture**
- Défini dans la feuille posture (onglet 🔥 Ultimate)
- **Nom, Description, Dégâts** (MJ uniquement)
- **Débloqué** seulement si Burste = 100
- **Consomme** :
  - Toute la Burste (→ 0)
  - 1 Grand PA
- **Bouton "🔥 LANCER ULTIMATE"** sur la fiche
- Message de chat spectaculaire avec dégâts

---

## 🎮 UTILISATION

### Créer un style de combat complet

**1. Créer la Posture**
```
Menu Items → Posture
Nom: "Poing de Fer"
Attaque Base: +20
Effet: Bonus dégâts 15%
Condition: Après 2 attaques
Ultimate Nom: "Météore de Fer"
Ultimate Desc: "Frappe dévastatrice qui fend le ciel"
Ultimate Dégâts: 500
```

**2. Créer les Techniques**
```
Menu Items → Technique
Nom: "Frappe Tonnerre"
Style: CAC
PM: 10
Base Dégâts: 50
Posture Associée: "Poing de Fer"  ← IMPORTANT: nom exact
```

**3. Glisser dans l'inventaire du joueur**
- Les techniques apparaissent automatiquement dans la posture

### Combat typique

1. **Activer posture** → Toggle ON
2. **Attaquer** → +10 Burste (si réussite)
3. **Technique** → +10 Burste (si réussite)
4. **Répéter** jusqu'à Burste = 100
5. **ULTIMATE** → 🔥 Dégâts massifs → Burste à 0
6. **Nouveau Tour** → Restaure 1 grand PA

---

## 📊 SYSTÈME BURSTE DÉTAILLÉ

### Gains de Burste

| Action | Résultat | Burste |
|--------|----------|--------|
| Attaque de base | Réussite | +10 |
| Technique | Réussite | +10 |
| Coup reçu | - | +5 (manuel) |
| Ultimate | Utilisé | → 0 |

### Utilisation de l'Ultimate

**Conditions :**
- ✅ Burste = 100
- ✅ Posture active
- ✅ 1 Grand PA disponible
- ✅ Ultimate défini dans la posture

**Effet :**
- Lance le jet de réussite
- Si réussite → Dégâts de l'Ultimate
- Consomme le Grand PA
- **Réinitialise Burste à 0**

---

## 🎨 AFFICHAGE

### Jauge Burste
```
⚡ BURSTE
━━━━━━━━━━━━━━━━░░░░  75 / 100
+10 par attaque/technique réussie | +5 par coup reçu
```

### Posture avec Ultimate
```
╔═══════════════════════════════╗
║ Style du Dragon      🔘 ACTIVE║
╠═══════════════════════════════╣
║ ⚔️ ATTAQUE DE BASE    170 dégâts ║
║ ✨ +15% après 2 attaques         ║
║                                ║
║ ⚡ Frappe Tonnerre   10 PM  50 dégâts ║
║ ⚡ Souffle Dragon    15 PM  70 dégâts ║
║                                ║
║ 🔥 MÉTÉORE DE FER              ║
║ 🔓 DISPONIBLE                  ║
║ Frappe dévastatrice...         ║
║ 💥 500 dégâts                  ║
║ [🔥 LANCER ULTIMATE]           ║
╚═══════════════════════════════╝
```

---

## ⚠️ NOTES IMPORTANTES

### Limite de postures
- **Maximum 2 postures** par personnage
- Si vous en créez plus, seules les 2 premières s'afficheront

### Association techniques
- Le nom dans "Posture Associée" doit être **EXACTEMENT** le même que le nom de la posture
- Sensible à la casse : "Dragon" ≠ "dragon"
- Espaces comptent : "Style Dragon" ≠ "Style  Dragon"

### Nouveau tour
- Ne restaure qu'**1 grand PA** (le premier complètement utilisé)
- Applique toujours les pertes de PV (blessures 7-8)
- Respecte la fatigue f8 (pas de grand 3)

### Burste manuelle
- Le +5 par coup reçu doit être géré manuellement pour l'instant
- Le MJ peut modifier la jauge directement sur la fiche

---

## 🐛 SI PROBLÈMES

**Les techniques ne s'affichent pas ?**
→ Vérifiez que le nom dans "Posture Associée" est EXACT

**Le Burste ne monte pas ?**
→ Vérifiez que l'attaque/technique a réussi (≤ seuil)

**L'Ultimate ne se lance pas ?**
→ Vérifiez Burste = 100, posture active, Grand PA dispo

**Le nouveau tour restaure tout ?**
→ Normal si tous les PA étaient à false, il restaure le premier trouvé

---

## 📚 RÉSUMÉ DES CHANGEMENTS

✅ Bonus compétences automatiques  
✅ Techniques s'affichent dans postures  
✅ 2 postures max, côte à côte  
✅ Nouveau tour = 1 grand PA  
✅ Jauge Burste fonctionnelle  
✅ Ultimate par posture  
✅ +10 Burste par réussite  
✅ Burste → 0 après Ultimate  

---

**Version:** 3.2 COMPLETE  
**Date:** 2 Février 2026  
**Statut:** TOUS LES POINTS CORRIGÉS ✅  

Bon jeu ! 🎲✨🔥
