# 📋 CHANGELOG - Correction Postures & Techniques

## Version 3.1 - 3 Février 2026

### 🔧 Correction majeure

**Problème résolu :** Les techniques créées ne s'affichaient pas dans les postures lorsqu'elles étaient glissées dans l'inventaire.

### 📝 Modifications apportées

#### 1. `module/ffdreame.js`
- ✅ Ajout du helper Handlebars `postureMatch`
- ✅ Comparaison flexible des noms de postures (insensible à la casse, ignore les espaces)

#### 2. `templates/actor/character-sheet.html`
- ✅ Restauration du fichier (était vide)
- ✅ Utilisation du nouveau helper `postureMatch` au lieu de `eq`
- ✅ Les techniques s'affichent maintenant correctement dans leurs postures

### 📚 Documentation ajoutée

- ✅ `CORRECTION_POSTURES_TECHNIQUES.md` - Explication détaillée de la correction
- ✅ `GUIDE_RAPIDE_POSTURES.md` - Guide rapide d'utilisation
- ✅ Ce fichier CHANGELOG

### 🎯 Impact

**Avant :**
```handlebars
{{#if (eq tech.system.postureAssociee item.name)}}
```
- Comparaison stricte (sensible à la casse)
- "Dragon Style" ≠ "dragon style"

**Après :**
```handlebars
{{#if (postureMatch tech.system.postureAssociee item.name)}}
```
- Comparaison flexible (insensible à la casse)
- "Dragon Style" = "dragon style" = "DRAGON STYLE" = " Dragon Style "

### ✅ Tests effectués

- ✅ Création d'une posture avec nom en majuscules
- ✅ Création d'une technique avec nom en minuscules
- ✅ Vérification de l'affichage dans la fiche personnage
- ✅ Test avec espaces en début/fin
- ✅ Test avec différentes combinaisons de casse

### 🔄 Compatibilité

- ✅ Compatible avec FFdreame System v3.0
- ✅ Compatible avec Foundry VTT v11+
- ✅ Rétrocompatible avec les postures/techniques existantes
- ✅ Ne nécessite pas de migration de données

### 📦 Installation

1. Sauvegarder votre monde
2. Fermer Foundry VTT
3. Remplacer les fichiers dans `Data/systems/ffdreame/`
4. Redémarrer Foundry VTT

### 🎮 Utilisation

Plus besoin de faire exactement correspondre la casse !

**Posture :** "Poing de Fer"

**Techniques fonctionnent avec :**
- ✅ "Poing de Fer"
- ✅ "poing de fer"
- ✅ "POING DE FER"
- ✅ " Poing de Fer "

### 🐛 Bugs corrigés

- [x] Les techniques ne s'affichent pas dans les postures
- [x] Comparaison stricte des noms empêche l'affichage
- [x] Espaces en début/fin causent des problèmes
- [x] Différence de casse empêche l'association

### 🚀 Améliorations futures

Suggestions pour les prochaines versions :

- [ ] Sélection de posture via dropdown dans l'item Technique
- [ ] Auto-complétion des noms de postures
- [ ] Validation en temps réel de l'association
- [ ] Message d'erreur si la posture n'existe pas

---

**Développé avec ❤️ pour la communauté FFdreame**
