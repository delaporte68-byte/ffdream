# 🎮 FFdreame v5.1 - Modifications Apportées

## ✅ MODIFICATIONS RÉALISÉES

### 1. **Suppression de la grande jauge Burste**
- ✅ La jauge Burste a été complètement retirée de la fiche personnage (onglet Combat)
- ⚠️ La valeur Burste est toujours stockée dans les données (`system.combat.burste`) mais n'est plus affichée visuellement

### 2. **Token éditable au centre avec aptitudes autour**
- ✅ Token du personnage placé au centre de la section aptitudes
- ✅ Aptitudes repositionnées autour du token :
  - **Haut** : Attaque
  - **Droite** : Puissance Magique
  - **Bas** : Points de Vie
  - **Gauche** : Points Magiques
- ✅ **Suppression des effets de survol** : Les aptitudes ne bougent plus quand on passe la souris dessus
- ✅ Token cliquable pour changer l'image

### 3. **Suppression du champ "Style" dans les items Posture**
- ✅ Le sélecteur "Style" a été retiré de l'onglet Techniques dans la fiche Posture
- ✅ Le champ "Style" n'est plus affiché sur la fiche personnage dans les techniques
- ✅ Les informations de calcul de dégâts liées au style ont été supprimées
- ⚠️ La donnée `style` existe toujours dans le template.json mais n'est plus visible/éditable

### 4. **Création de deux tableaux interactifs éditables**
- ✅ Deux tableaux ajoutés à la place de la jauge Burste
- ✅ Chaque tableau possède :
  - Un **nom éditable** (par défaut : "Attaques" et "Ultimates")
  - **8 cases** disposées en : 1 / 2 / 2 / 2 / 1
  - Cases interactives avec effet de survol
  - Icône "+" pour les cases vides
  - Icône "📦" pour les cases remplies

### 5. **Suppression des sections Attaque et Ultimate dans les Postures**
- ✅ La section "Attaque de base" a été retirée de l'affichage des postures
- ✅ La section "Ultimate" a été retirée de l'affichage des postures
- ⚠️ Les techniques intégrées aux postures restent affichées normalement

---

## 📦 STRUCTURE DES DONNÉES

### Nouveaux champs ajoutés dans `template.json` :

```json
"combat": {
  "burste": 0,
  
  "tableau1": {
    "nom": "Attaques",
    "slots": {
      "slot1": null,
      "slot2": null,
      "slot3": null,
      "slot4": null,
      "slot5": null,
      "slot6": null,
      "slot7": null,
      "slot8": null
    }
  },
  
  "tableau2": {
    "nom": "Ultimates",
    "slots": {
      "slot1": null,
      "slot2": null,
      "slot3": null,
      "slot4": null,
      "slot5": null,
      "slot6": null,
      "slot7": null,
      "slot8": null
    }
  }
}
```

---

## 🎨 CSS AJOUTÉ

- **`.interactive-tables-wrapper`** : Conteneur des deux tableaux
- **`.interactive-table`** : Style de chaque tableau
- **`.table-name-edit`** : Champ de nom éditable du tableau
- **`.table-slot`** : Style des cases individuelles (80x80px)
- **`.slot-empty`** / **`.slot-filled`** : États des cases
- **`.aptitudes-grid-wrapper`** : Conteneur pour le token central + aptitudes
- **`.token-central`** : Style du token central (120x120px)
- **`.apt-top`**, **`.apt-right`**, **`.apt-bottom`**, **`.apt-left`** : Positionnement des aptitudes

---

## 🚧 PROCHAINES ÉTAPES (À DÉVELOPPER)

### Fonctionnalités restantes à implémenter :

1. **Drag & Drop** :
   - Glisser des objets Attaque/Ultimate dans les cases des tableaux
   - Stocker l'ID de l'objet dans `system.combat.tableau1.slots.slotX`

2. **Interactivité des cases** :
   - Clic sur une case → Lance l'objet (jet de dés)
   - Affichage de l'icône de l'objet au lieu de 📦
   - Affichage du nom de l'objet au survol

3. **Gestion des effets spéciaux** :
   - Effets Ultimate (DEG, SOINS, BUF PA, CRIT)
   - Intégration avec le système de combat

4. **JavaScript à ajouter** :
   - Gestionnaire de drag & drop
   - Clic sur cases pour lancer les objets
   - Mise à jour des données actor

---

## 📋 FICHIERS MODIFIÉS

### Templates :
- ✅ `templates/actor/character-sheet.html`
- ✅ `templates/item/posture-sheet.html`

### CSS :
- ✅ `css/ffdreame.css` (ajout de ~250 lignes)

### Données :
- ✅ `template.json` (ajout des tableaux dans combat)

---

## ⚙️ INSTALLATION

1. Extraire le fichier ZIP dans le dossier de votre système Foundry
2. Remplacer les fichiers existants
3. Recharger Foundry VTT
4. Les modifications seront automatiquement appliquées

---

## 🎯 RÉSUMÉ VISUEL

**AVANT (v5.0)** :
```
┌─────────────────────────┐
│  Grande Jauge Burste    │
│  ████████████░░░░  75%  │
└─────────────────────────┘

Aptitudes (verticales) :
- Attaque
- Puissance Magique  
- PV
- PM

Postures avec :
- ⚔️ Attaque de base
- 🔥 Ultimate
- Techniques
```

**MAINTENANT (v5.1)** :
```
Tableaux Interactifs :
┌─── Attaques ───┐  ┌─── Ultimates ───┐
│     [+]        │  │      [+]         │
│   [+]  [+]     │  │    [+]  [+]      │
│   [+]  [+]     │  │    [+]  [+]      │
│   [+]  [+]     │  │    [+]  [+]      │
│     [+]        │  │      [+]         │
└────────────────┘  └──────────────────┘

Token Central + Aptitudes :
        [Attaque]
             ↑
    [PM] ← [🪙] → [Puissance Magique]
             ↓
          [PV]

Postures avec :
- Effet de posture
- Techniques (sans style affiché)
```

---

**Version** : 5.1 (Corrections appliquées)  
**Date** : 03/02/2026  
**État** : Templates et CSS corrigés - JavaScript à développer pour l'interactivité complète
