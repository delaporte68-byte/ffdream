# 🎬 GUIDE : Configurer les Animations pour les Techniques MULTI

## ⚠️ Prérequis OBLIGATOIRES

### 1. **Module Sequencer** (REQUIS)
- **Nom exact :** `sequencer`
- **Lien :** https://foundryvtt.com/packages/sequencer
- **Installation :** Aller dans "Add-on Modules" → Rechercher "Sequencer" → Installer
- **⚡ IMPORTANT :** Activer le module dans votre monde !

### 2. **Module JB2A** (au choix)
- **JB2A Free** : `JB2A_DnD5e` (gratuit, limité)
- **JB2A Patreon** : `jb2a_patreon` (complet, payant)
- **⚡ IMPORTANT :** Activer le module dans votre monde !

---

## 🔧 Configuration d'une Technique MULTI

### Étape 1 : Ouvrir la fiche de technique
1. Cliquez sur la technique
2. Allez dans l'onglet **🎬 Animations**

### Étape 2 : Choisir une animation
Dans le menu déroulant, vous verrez des animations prédéfinies :

#### **🔥 Feu**
```
jb2a.fire_bolt.orange
jb2a.fireball.beam.orange
jb2a.fire_jet.orange
jb2a.explosion.orange
```

#### **⚡ Électricité**
```
jb2a.lightning_bolt.narrow.blue
jb2a.chain_lightning.primary.blue
jb2a.static_electricity.01.blue
```

#### **❄️ Glace**
```
jb2a.ice_spikes.radial.white
jb2a.snowflake.01.blue
```

#### **🌟 Lumière/Énergie**
```
jb2a.eldritch_blast.purple
jb2a.magic_missile.blue
jb2a.healing_generic.400px.blue
```

### Étape 3 : Utiliser un lien direct JB2A
Si vous voulez une animation spécifique non listée :

1. Allez sur : https://jb2a.com/home/free-database/
2. Trouvez votre animation
3. Copiez le chemin (exemple : `jb2a.chain_lightning.primary.blue`)
4. **OU** collez l'URL complète si c'est un fichier .webm

---

## 🐛 Dépannage

### ❌ "Module 'Sequencer' requis pour les animations"
**Solution :** Installez et activez le module Sequencer
1. Aller dans "Configuration des modules"
2. Cocher ✅ Sequencer
3. Sauvegarder et recharger

### ❌ "Module JB2A requis pour les animations"
**Solution :** Installez et activez JB2A (gratuit OU patreon)
1. Aller dans "Add-on Modules"
2. Chercher "JB2A"
3. Installer puis activer dans "Configuration des modules"

### ❌ L'animation ne se lance pas (aucun message d'erreur)
**Vérification 1 :** Ouvrez la console (F12) et regardez les logs
- Vous devriez voir `🎬 Tentative d'animation...`
- Suivez les messages pour comprendre où ça bloque

**Vérification 2 :** Le chemin de l'animation est-il correct ?
```javascript
// CORRECT ✅
jb2a.fire_bolt.orange

// INCORRECT ❌
jb2a.firebolt.orange  (pas de underscore)
fire_bolt.orange      (manque le préfixe jb2a)
```

**Vérification 3 :** Testez avec une animation simple
1. Choisissez `jb2a.fire_bolt.orange` (très basique)
2. Si ça marche, le problème vient du chemin de l'autre animation

### ❌ "Erreur d'animation: File not found"
**Solution :** Le chemin est incorrect ou l'animation n'existe pas dans votre version de JB2A
- Vérifiez que vous avez la bonne version (Free vs Patreon)
- Certaines animations sont exclusives à la version Patreon

---

## 🧪 Tester vos Animations

### Test rapide dans la console (F12) :
```javascript
// Remplacez YOUR_TECHNIQUE_ID par l'ID de votre technique
const technique = game.items.get("YOUR_TECHNIQUE_ID");
console.log("Animation configurée:", technique.system.animation?.jb2a);

// Test de module
console.log("Sequencer:", typeof Sequence !== 'undefined' ? "OK" : "MANQUANT");
console.log("JB2A Patreon:", game.modules.get("jb2a_patreon")?.active);
console.log("JB2A Free:", game.modules.get("JB2A_DnD5e")?.active);
```

---

## 📋 Exemple de Configuration Complète

### Boule de Feu (Zone Cercle)
- **Type MULTI :** Zone (cercle)
- **Distance max :** 10m
- **Largeur :** 3m
- **Animation :** `jb2a.fireball.beam.orange`

### Éclair en Ligne (Ligne Droite)
- **Type MULTI :** Ligne
- **Distance max :** 8m
- **Largeur :** 1.5m
- **Animation :** `jb2a.lightning_bolt.narrow.blue`

---

## 🎯 Animations Recommandées par Type

| Type de Zone | Animations Recommandées |
|--------------|------------------------|
| **Cercle (Explosion)** | `jb2a.explosion.orange`<br>`jb2a.fireball.explosion.orange`<br>`jb2a.thunderwave.center.blue` |
| **Ligne (Rayon)** | `jb2a.fire_bolt.orange`<br>`jb2a.lightning_bolt.narrow.blue`<br>`jb2a.scorching_ray.01.orange` |
| **Cône** | `jb2a.burning_hands.cone.orange`<br>`jb2a.breath_weapons.fire.cone.orange` |

---

## 💡 Astuces

1. **Les animations "beam" et "bolt" fonctionnent bien pour les lignes**
2. **Les animations "explosion" et "nova" fonctionnent bien pour les cercles**
3. **Commencez avec des animations simples** avant d'essayer des complexes
4. **Vérifiez TOUJOURS que Sequencer est actif** (c'est le module le plus oublié !)

---

## 🆘 Support

Si après tout ça les animations ne marchent toujours pas :
1. Ouvrez la console (F12)
2. Lancez la technique MULTI
3. Copiez tous les messages qui commencent par `🎬` ou `❌`
4. Partagez-les pour diagnostic
