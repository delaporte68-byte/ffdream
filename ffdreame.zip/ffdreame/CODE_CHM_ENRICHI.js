/* ================================
   EXÉCUTER UNE VARIANTE CHM (VERSION ENRICHIE)
   ================================ */
async _executeTechniqueCHMVariante(technique, variante, seuilReussite) {
  console.log(`🎯 Exécution variante CHM: ${variante.nom} (${variante.style})`);
  
  // Créer une technique temporaire avec TOUS les paramètres de la variante
  const techniqueTmp = foundry.utils.duplicate(technique);
  techniqueTmp.name = `${technique.name} - ${variante.nom}`;
  techniqueTmp.system.style = variante.style;
  techniqueTmp.system.baseDegats = variante.baseDegats;
  techniqueTmp.system.portee = variante.portee || 1.5;
  
  // Copier les effets
  if (variante.effet1) {
    techniqueTmp.system.effet1 = variante.effet1;
  }
  if (variante.effet2) {
    techniqueTmp.system.effet2 = variante.effet2;
  }
  
  // Copier l'animation
  if (variante.animation) {
    techniqueTmp.system.animation = variante.animation;
  }
  
  // Copier la config MULTI si le style est multi
  if (variante.style === 'multi' && variante.multi) {
    techniqueTmp.system.multi = variante.multi;
  }
  
  // Si le style est MULTI, utiliser le système MULTI
  if (variante.style === 'multi') {
    console.log('🌀 Variante CHM de type MULTI détectée');
    
    // Vérifier PM
    const pmActuel = this.actor.system.aptitudes.pm.value;
    const coutPM = technique.system.coutPM || 0;
    
    if (pmActuel < coutPM) {
      ui.notifications.warn(`⚠️ PM insuffisants ! (${pmActuel}/${coutPM})`);
      return;
    }
    
    // Importer le système MULTI
    const { FFdreameMultiZone } = await import('../combat/multi-zone.js');
    
    const result = await FFdreameMultiZone.useTechniqueMulti(this.actor, techniqueTmp);
    
    // Gérer le résultat
    if (result && result.outOfRange) {
      console.log("❌ Distance non respectée pour la variante CHM-MULTI");
      return;
    }
    
    if (!result || (!result.success && !result.consumed)) {
      console.log("⏹️ Variante CHM-MULTI annulée");
      return;
    }
    
    // Consommer les PM
    console.log("✅ Distance OK pour CHM-MULTI, consommation PM");
    await this.actor.update({
      'system.aptitudes.pm.value': pmActuel - coutPM
    });
    
    // Incrémenter compteur d'effets si réussite
    if (result.success) {
      await this._incrementerCompteurEffet();
    }
    
    return;
  }
  
  // Pour les autres styles, utiliser la méthode normale
  const pmActuel = this.actor.system.aptitudes.pm.value;
  const coutPM = technique.system.coutPM || 0;
  
  // Vérifier PM
  if (pmActuel < coutPM) {
    ui.notifications.warn(`⚠️ PM insuffisants ! (${pmActuel}/${coutPM})`);
    return;
  }
  
  // Gestion des PA selon le style de la variante
  const actionPoints = this.actor.system.combat.actionPoints;
  const style = variante.style;
  
  let paConsomme = false;
  
  if (style === 'atta' || style === 'attm') {
    // 1 Petit PA
    for (let g = 1; g <= 3; g++) {
      for (let p = 1; p <= 2; p++) {
        if (actionPoints[`grand${g}`]?.[`petit${p}`]) {
          await this.actor.update({
            [`system.combat.actionPoints.grand${g}.petit${p}`]: false
          });
          paConsomme = true;
          break;
        }
      }
      if (paConsomme) break;
    }
    
    if (!paConsomme) {
      ui.notifications.warn("⚠️ Pas de Petit PA disponible !");
      return;
    }
  } else {
    // 1 Grand PA (2 Petits)
    for (let g = 1; g <= 3; g++) {
      if (actionPoints[`grand${g}`]?.petit1 && actionPoints[`grand${g}`]?.petit2) {
        await this.actor.update({
          [`system.combat.actionPoints.grand${g}.petit1`]: false,
          [`system.combat.actionPoints.grand${g}.petit2`]: false
        });
        paConsomme = true;
        break;
      }
    }
    
    if (!paConsomme) {
      ui.notifications.warn("⚠️ Pas de Grand PA disponible !");
      return;
    }
  }
  
  // Consommer PM
  await this.actor.update({
    'system.aptitudes.pm.value': pmActuel - coutPM
  });
  
  // Exécuter comme une technique normale
  await this._useTableTechniqueNormal(techniqueTmp, seuilReussite, pmActuel, coutPM);
}
