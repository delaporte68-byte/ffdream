# 🎯 FFdreame - Style MULTI - Version FINALE

## ✅ Corrections finales

1. **✅ Plus de templates** - Les carrés jaunes ne s'affichent plus du tout
2. **✅ Cible principale = 100%** - La cible ciblée reçoit toujours 100% des dégâts en premier
3. **✅ PA consommés immédiatement** - Dès le jet, même si échec
4. **✅ Burste +10 fixe** - Peu importe le nombre de cibles

---

## 🎮 Fonctionnement

### Utilisation simple

```
1. Cibler un ennemi (clic droit → Cibler)
2. Cliquer sur la technique MULTI
3. Grand PA consommé immédiatement
4. Jet de dés

Si RÉUSSITE :
→ Cible ciblée : 100% dégâts
→ Ennemis dans la zone : 80%, 60%, 40%...
→ PM consommés
→ Burste +10
→ Animation JB2A (pas de template ✅)

Si ÉCHEC :
→ PA perdus
→ PM conservés
→ Aucun dégât
```

---

## 📊 Système de dégâts

### Réduction progressive

- **1ère cible** (celle que vous ciblez) : **100%** des dégâts
- **2ème cible** (dans la zone) : **80%** des dégâts
- **3ème cible** (dans la zone) : **60%** des dégâts
- **4ème cible** (dans la zone) : **40%** des dégâts
- **5ème cible** (dans la zone) : **20%** des dégâts
- **6ème+** : **0%** des dégâts

### Exemple

```
Boule de Feu (100 dégâts de base)

1. Goblin Chef [CIBLE] : 100 dégâts (100%)
2. Goblin 1 : 80 dégâts (80%)
3. Goblin 2 : 60 dégâts (60%)
4. Goblin 3 : 40 dégâts (40%)
```

La cible avec **[CIBLE]** dans le message est celle que vous avez ciblée.

---

## 🎬 Plus de templates !

### Avant
- Carrés jaunes/bleus qui restaient sur la carte 🟨🟦
- Problèmes de suppression
- Carte encombrée

### Maintenant
- **Aucun template créé** ✅
- Animation JB2A uniquement
- Carte propre

---

## 🚀 Installation

```bash
1. Désactiver FFdreame
2. Supprimer Data/systems/ffdreame/
3. Extraire ffdreame-multi-final.zip dans Data/systems/
4. Réactiver FFdreame
5. Ctrl+F5 pour recharger
```

Ou remplacer uniquement :
- `module/combat/multi-zone.js`

---

## 📝 Types de techniques

### Type CERCLE
- Zone autour de la cible
- Tous les ennemis dans le rayon sont touchés
- Exemple : Boule de feu, Explosion, Onde de choc

### Type LIGNE
- Rayon entre vous et la cible
- Tous les ennemis sur le chemin sont touchés
- Exemple : Lance-flammes, Éclair, Rayon laser

---

## 🎯 Test rapide

### Créer une technique de test

```
Style : multi
Type : cercle
Distance max : 6m
Largeur : 4m
Dégâts : 100
PA : Grand
PM : 30
```

### Tester

1. Placer 3-4 ennemis proches
2. Cibler celui au centre
3. Utiliser la technique
4. Vérifier dans le chat :
   - ✅ `[CIBLE]` sur le bon ennemi
   - ✅ 100% pour lui, 80% 60% 40% pour les autres
   - ✅ Pas de carrés jaunes sur la carte

---

## 📚 Documentation

- **CORRECTION_FINALE.md** - Détails complets
- **GUIDE_ANIMATIONS_JB2A.md** - Configurer les animations
- **GUIDE_VISUEL_MULTI.md** - Exemples et tactiques

---

## 🐛 Problème ?

### Templates apparaissent encore
→ Videz le cache (Ctrl+F5)  
→ Vérifiez la version installée

### Cible ne reçoit pas 100%
→ Cherchez `[CIBLE]` dans le message  
→ Devrait être sur la première ligne

### Animation ne marche pas
→ Voir `GUIDE_ANIMATIONS_JB2A.md`

---

**Version** : FINALE  
**Date** : Février 2026  
**Compatibilité** : Foundry VTT v11/v12

**C'est tout bon !** 🎉
