# 🎯 FFdreame - Version avec EFFETS DE TABLEAUX

## ✨ Nouveautés de cette version

### Système d'effets passifs pour les tableaux

Chaque tableau peut maintenant avoir un **effet passif** qui se déclenche selon certaines conditions !

---

## 🎮 Types d'effets disponibles

### 📊 Effets basés sur les réussites

Ces effets comptent vos techniques réussies et se déclenchent au seuil.

1. **Bonus de dégâts après X réussites**
   - Après 5 techniques réussies → +50 dégâts à la prochaine attaque
   
2. **Récupération PM après X réussites**
   - Après 3 techniques réussies → Récupère 30 PM
   
3. **Parade après X réussites**
   - Après 4 techniques réussies → Jet de parade contre la prochaine attaque ennemie

### ⚡ Effets permanents

Ces effets sont actifs tant que le tableau est sélectionné.

4. **Initiative automatique**
   - Prend automatiquement l'initiative en début de combat

5. **Bonus de dégâts permanent**
   - +20 dégâts à toutes les attaques

6. **Bonus PM permanent**
   - +50 PM max

7. **Bonus Burste par technique**
   - +15 Burste par technique au lieu de +10

---

## ⚙️ Configuration FACILE avec la Macro

### Installation de la macro

1. Créez une nouvelle macro dans Foundry
2. Copiez-collez le contenu de `macro-configurer-effets-tableaux.js`
3. Cliquez sur la macro pour ouvrir l'interface

### Utilisation

```
1. Sélectionnez votre personnage
2. Lancez la macro
3. Choisissez le tableau (1 ou 2)
4. Choisissez le type d'effet
5. Configurez seuil et bonus (si nécessaire)
6. Cliquez sur "Appliquer"
```

**C'est tout !** 🎉

---

## 💡 Exemples de builds

### Build Agressif - "Fury Fighter"

**Tableau 1** : "Assaut"
- Effet : Bonus dégâts après 5 réussites
- Bonus : +50 dégâts

**Stratégie** :
```
1. Enchaîne 5 attaques rapides
2. Au 5ème coup → Compteur à 5/5
3. Prochaine attaque → +50 dégâts !
4. Compteur reset → Recommence
```

---

### Build Défensif - "Tank Guardian"

**Tableau 1** : "Défense"
- Effet : Parade après 4 réussites

**Stratégie** :
```
1. Utilise 4 techniques défensives
2. Parade activée → 🛡️
3. Prochaine attaque ennemie → Jet de parade
4. Si réussi → Attaque bloquée !
```

---

### Build Leader - "First Strike"

**Tableau 1** : "Initiative"
- Effet : Initiative automatique (permanent)

**Stratégie** :
```
- En début de combat → Agit toujours en premier
- Pas de jet d'initiative
- Parfait pour débuter avec un buff d'équipe
```

---

### Build Soutien - "Healer Mage"

**Tableau 2** : "Régénération"
- Effet : Récupération PM après 3 réussites
- Bonus : +30 PM

**Stratégie** :
```
1. Lance 3 sorts de soin
2. Au 3ème → Récupère 30 PM
3. Peut enchaîner avec d'autres soins
4. PM quasiment infinis !
```

---

### Build Hybride - "Berserker Mage"

**Tableau 1** : "Assaut" (Bonus dégâts +50 après 5 réussites)  
**Tableau 2** : "Mana" (Récup 30 PM après 3 réussites)

**Stratégie** :
```
Phase 1 : Tableau 1 actif
- Accumule 5 réussites
- Attaque finale avec +50 dégâts

Phase 2 : Switch Tableau 2
- Lance 3 sorts
- Récupère 30 PM

Phase 3 : Retour Tableau 1
- Compteur toujours à 5/5
- Encore +50 dégâts dispo !
```

---

## 🎯 Comment ça marche en jeu

### Pendant le combat

```
Vous : *Utilise une technique du Tableau 1*
Système : *Jet de dés... Réussite !*
Système : "⚡ Effet Assaut: 3/5"

Vous : *Encore une technique*
Système : "⚡ Effet Assaut: 4/5"

Vous : *Encore !*
Système : "🔥 BONUS DE DÉGÂTS ACTIVÉ ! +50 à la prochaine attaque"

Vous : *Utilise ultimate*
→ Dégâts de base + 50 bonus = DESTRUCTION

Système : "⚡ Effet Assaut: 0/5" (reset)
```

---

## 📊 Tableau récapitulatif

| Effet | Type | Seuil | Bonus | Permanent |
|-------|------|-------|-------|-----------|
| Bonus dégâts après réussites | Compteur | 5 | 50 | ❌ |
| Récup PM après réussites | Compteur | 3 | 30 | ❌ |
| Parade après réussites | Compteur | 4 | - | ❌ |
| Initiative automatique | - | - | - | ✅ |
| Bonus dégâts permanent | - | - | 20 | ✅ |
| Bonus PM permanent | - | - | 50 | ✅ |
| Bonus Burste | - | - | 15 | ✅ |

---

## 🔧 Installation

### Installation complète

```bash
1. Désactiver FFdreame
2. Supprimer Data/systems/ffdreame/
3. Extraire ffdreame-avec-effets-tableaux.zip dans Data/systems/
4. Réactiver FFdreame
5. Relancer Foundry (Ctrl+F5)
```

### Mise à jour depuis version précédente

Remplacer ces fichiers :
```
template.json
module/combat/tableau-effets.js (nouveau)
module/sheets/actor-sheet.js
```

---

## 📝 Configuration manuelle (console F12)

Si vous préférez utiliser la console au lieu de la macro :

```javascript
// Récupérer votre personnage
const actor = game.user.character;

// Configurer Tableau 1 : Bonus dégâts après 5 réussites
await actor.update({
  'system.combat.tableau1.effet': {
    type: "bonus_degats_apres_reussites",
    seuil: 5,
    compteur: 0,
    bonus: 50,
    description: "Après 5 techniques réussies, +50 dégâts"
  }
});

// Configurer Tableau 2 : Initiative automatique
await actor.update({
  'system.combat.tableau2.effet': {
    type: "initiative_automatique",
    seuil: 0,
    compteur: 0,
    bonus: 0,
    description: "Prend l'initiative en début de combat"
  }
});
```

---

## 🐛 Dépannage

### Le compteur ne s'incrémente pas

Vérifications :
1. Le tableau est bien actif ?
2. La technique est bien dans ce tableau ?
3. La technique a réussi (jet de dés) ?
4. Console F12 → Chercher "📊 Compteur tableau"

### L'effet ne se déclenche pas

Vérifications :
1. Le seuil est atteint ? (ex: 5/5)
2. Console F12 → Chercher "🎯 Effet activé"
3. Le type d'effet est bien configuré ?

### La macro ne fonctionne pas

1. Vérifiez que vous avez un personnage sélectionné
2. Ouvrez la console F12 pour voir les erreurs
3. Vérifiez que le fichier `tableau-effets.js` est bien installé

---

## 📚 Documentation

- **GUIDE_EFFETS_TABLEAUX.md** - Documentation complète du système
- **macro-configurer-effets-tableaux.js** - Macro prête à l'emploi

---

## ✨ Compatibilité

Cette version inclut **TOUTES** les corrections précédentes :

✅ Templates supprimés (pas de carrés jaunes)  
✅ Ordre des dégâts Multi corrigé  
✅ PA consommés immédiatement  
✅ Burste +10 fixe  
✅ **NOUVEAU** : Système d'effets de tableaux

---

## 🎮 Démarrage rapide

### Test en 3 étapes

1. **Installez la macro**
   - Copiez `macro-configurer-effets-tableaux.js`
   - Créez une nouvelle macro dans Foundry

2. **Configurez un effet**
   - Sélectionnez votre personnage
   - Lancez la macro
   - Tableau 1 → "Bonus dégâts après 5 réussites"
   - Seuil : 5, Bonus : 50

3. **Testez en combat**
   - Utilisez 5 techniques du tableau 1
   - Regardez le compteur (3/5, 4/5, 5/5)
   - Au 5ème → Bonus activé !
   - Prochaine attaque → +50 dégâts

**Amusez-vous bien !** 🎉

---

**Version** : 1.0 avec effets de tableaux  
**Date** : Février 2026  
**Compatibilité** : Foundry VTT v11/v12
