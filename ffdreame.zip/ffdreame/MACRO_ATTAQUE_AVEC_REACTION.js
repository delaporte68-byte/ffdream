// ========================================
// MACRO MJ : ATTAQUE AVEC RÉACTION
// Gère automatiquement Esquive et Défense
// ========================================

// Vérifier qu'un token est sélectionné (attaquant)
if (!canvas.tokens.controlled.length) {
  ui.notifications.warn("Sélectionnez l'attaquant (votre token) !");
  return;
}

const attaquant = canvas.tokens.controlled[0];

// Vérifier qu'une cible est ciblée
const targets = Array.from(game.user.targets);
if (targets.length === 0) {
  ui.notifications.warn("Ciblez un joueur (clic droit sur son token) !");
  return;
}

const cible = targets[0];
const defenseur = cible.actor;

if (!defenseur) {
  ui.notifications.error("La cible n'a pas d'acteur associé !");
  return;
}

// Demander le résultat du jet d'attaque et les dégâts
const resultatDialog = await new Promise((resolve) => {
  new Dialog({
    title: "Attaque",
    content: `
      <form>
        <div class="form-group">
          <label>Résultat du jet d'attaque (1d100) :</label>
          <input type="number" name="jetAttaque" value="50" min="1" max="100" />
        </div>
        <div class="form-group">
          <label>Dégâts de base :</label>
          <input type="number" name="degats" value="50" min="0" />
        </div>
      </form>
    `,
    buttons: {
      attack: {
        label: "Valider",
        callback: (html) => {
          const jetAttaque = parseInt(html.find('[name="jetAttaque"]').val()) || 50;
          const degats = parseInt(html.find('[name="degats"]').val()) || 50;
          resolve({ jetAttaque, degats });
        }
      },
      cancel: {
        label: "Annuler",
        callback: () => resolve(null)
      }
    },
    default: "attack"
  }).render(true);
});

if (resultatDialog === null) return;

const resultatAttaque = resultatDialog.jetAttaque;
const degatsBase = resultatDialog.degats;

// Afficher l'attaque
ChatMessage.create({
  speaker: ChatMessage.getSpeaker({ token: attaquant }),
  content: `<h3>⚔️ Attaque de ${attaquant.name}</h3>
           <p>Cible : ${defenseur.name}</p>
           <p>Jet d'attaque : ${resultatAttaque}</p>
           <p>Dégâts potentiels : ${degatsBase}</p>`
});

// ===== VÉRIFIER LES RÉACTIONS =====
const reactions = defenseur.system.combat.reactions;
const esquiveActive = reactions.esquive;
const defenseActive = reactions.defense;

let reactionType = null;
let competenceValeur = 0;

if (esquiveActive && defenseActive) {
  // Les deux actives → Demander laquelle utiliser
  reactionType = await new Promise((resolve) => {
    new Dialog({
      title: "Réaction",
      content: `<p>${defenseur.name} a <strong>Esquive</strong> ET <strong>Défense</strong> actives !</p>
                <p>Laquelle utiliser ?</p>`,
      buttons: {
        esquive: {
          label: "🤸 Esquive",
          callback: () => resolve('esquive')
        },
        defense: {
          label: "🛡️ Défense",
          callback: () => resolve('defense')
        }
      }
    }).render(true);
  });
} else if (esquiveActive) {
  reactionType = 'esquive';
} else if (defenseActive) {
  reactionType = 'defense';
}

// ===== CALCUL DES DÉGÂTS =====
let degatsFinaux = degatsBase;
let messageReaction = "";

if (reactionType) {
  // Récupérer la compétence appropriée
  if (reactionType === 'esquive') {
    // Esquive = Agilité
    competenceValeur = defenseur.system.dexterite.agilite.value || 0;
  } else {
    // Défense = Endurance
    competenceValeur = defenseur.system.physique.endurance.value || 0;
  }
  
  // SEUIL = Résultat de l'attaque + Compétence
  // Exemple : Attaque fait 50, Agilité = 5 → le joueur doit faire ≤ 55 pour réussir
  const seuilReaction = resultatAttaque + competenceValeur;
  
  // Jet de réaction du défenseur (1d100)
  const jetReaction = new Roll("1d100");
  await jetReaction.evaluate();
  const resultatReaction = jetReaction.total;
  
  // Le défenseur réussit si son jet ≤ seuil
  const reussite = resultatReaction <= seuilReaction;
  
  // La marge détermine la qualité de la défense
  const marge = resultatReaction - seuilReaction;
  
  // Afficher le jet
  const reactionLabel = reactionType === 'esquive' ? '🤸 ESQUIVE' : '🛡️ DÉFENSE';
  const reactionIcon = reactionType === 'esquive' ? '🤸' : '🛡️';
  const competenceLabel = reactionType === 'esquive' ? 'Agilité' : 'Endurance';
  
  await jetReaction.toMessage({
    speaker: ChatMessage.getSpeaker({ actor: defenseur }),
    flavor: `<h3>${reactionLabel}</h3>
             <p>Jet de défense : <strong>${resultatReaction}</strong></p>
             <p>Seuil requis : <strong>≤ ${seuilReaction}</strong> (Attaque ${resultatAttaque} + ${competenceLabel} ${competenceValeur})</p>
             <p>${reussite ? '✅ <strong>RÉUSSI !</strong>' : '❌ <strong>RATÉ !</strong>'}</p>`
  });
  
  // Calcul de la réduction
  if (reussite) {
    let reduction = 0;
    
    if (marge <= -20 || resultatReaction <= 5) {
      // Annulation complète
      reduction = 1.0;
      messageReaction = `${reactionIcon} <strong>RÉACTION PARFAITE !</strong> Dégâts annulés (Marge: ${marge})`;
    } else if (marge <= -15) {
      // 50% de réduction
      reduction = 0.5;
      messageReaction = `${reactionIcon} <strong>Réaction réussie !</strong> Dégâts réduits de 50% (Marge: ${marge})`;
    } else {
      // 20% de réduction
      reduction = 0.2;
      messageReaction = `${reactionIcon} <strong>Réaction partielle</strong> Dégâts réduits de 20% (Marge: ${marge})`;
    }
    
    degatsFinaux = Math.floor(degatsBase * (1 - reduction));
  } else {
    messageReaction = `❌ ${reactionLabel} ratée ! Dégâts complets.`;
  }
  
  // Désactiver la réaction
  await defenseur.update({
    [`system.combat.reactions.${reactionType}`]: false
  });
  
} else {
  messageReaction = "Aucune réaction active. Dégâts complets.";
}

// ===== APPLIQUER LES DÉGÂTS =====
const pvActuel = defenseur.system.aptitudes.pv.value;
const nouveauPV = Math.max(0, pvActuel - degatsFinaux);

await defenseur.update({
  'system.aptitudes.pv.value': nouveauPV
});

// ===== MESSAGE FINAL =====
let messageFinal = `
  <div style="background: rgba(255, 0, 0, 0.2); padding: 15px; border-left: 4px solid #ff0000; border-radius: 4px;">
    <h2 style="margin-top: 0;">⚔️ ATTAQUE : ${attaquant.name} → ${defenseur.name}</h2>
    <hr/>
    <p><strong>Jet d'attaque :</strong> ${resultatAttaque}%</p>
    <p>${messageReaction}</p>
    <hr/>
    <p><strong>Dégâts de base :</strong> ${degatsBase}</p>
    <p><strong>Dégâts infligés :</strong> <span style="font-size: 24px; color: #ff0000;">${degatsFinaux}</span></p>
    <hr/>
    <p><strong>PV :</strong> ${pvActuel} → <span style="color: ${nouveauPV === 0 ? '#ff0000' : '#00ff00'};">${nouveauPV}</span></p>
`;

if (nouveauPV === 0) {
  messageFinal += `<p style="color: #ff0000; font-size: 20px; font-weight: bold;">💀 K.O. !</p>`;
}

messageFinal += `</div>`;

ChatMessage.create({
  content: messageFinal
});

ui.notifications.info(`⚔️ Attaque : ${degatsFinaux} dégâts infligés à ${defenseur.name}`);
