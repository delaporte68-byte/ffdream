# 🎯 GUIDE RAPIDE : Créer Postures et Techniques

## 📝 Checklist de création

### 🥋 POSTURE
```
□ Menu Items → Créer Item
□ Type : Posture
□ Nom : "Mon Style"  ← Noter ce nom !
□ Attaque Base : 15
□ Effet : Au choix
□ Glisser sur le personnage
```

### ⚡ TECHNIQUE
```
□ Menu Items → Créer Item
□ Type : Technique
□ Nom : "Ma Technique"
□ Style : CAC/MG/P/etc.
□ Coût PM : 10
□ Base Dégâts : 30
□ Posture Associée : "Mon Style"  ← Utiliser le même nom !
□ Glisser sur le personnage
```

### ✅ VÉRIFICATION
```
□ Ouvrir fiche personnage
□ Onglet Combat
□ Cliquer TOGGLE sur la posture
□ La technique doit apparaître !
```

## 💡 ASTUCE : Copier-Coller

### Méthode infaillible

1. **Créer la posture** → Noter son nom exact
2. **Créer la technique** → Copier-coller le nom de la posture dans "Posture Associée"
3. **Résultat garanti !**

### Exemple

**Posture créée :** "Danse de l'Ombre"

**Dans la technique :**
1. Ouvrir l'item Posture
2. Sélectionner le nom "Danse de l'Ombre"
3. Copier (Ctrl+C)
4. Ouvrir l'item Technique
5. Coller dans "Posture Associée" (Ctrl+V)
6. Sauvegarder

## ⚠️ Erreurs fréquentes (CORRIGÉES !)

### Avant la correction
❌ Posture : "Dragon Style"
❌ Technique : "dragon style" → Ne fonctionnait PAS

### Après la correction
✅ Posture : "Dragon Style"
✅ Technique : "dragon style" → Fonctionne !
✅ Technique : "DRAGON STYLE" → Fonctionne !
✅ Technique : " Dragon Style " → Fonctionne !

## 🎮 Utilisation en jeu

```
1. Début du tour → "🔄 NOUVEAU TOUR"
2. Activer la posture → Bouton TOGGLE
3. Utiliser une technique → Clic sur la technique
4. Le système consomme PM + Grand PA automatiquement
```

## 🔧 En cas de problème

Si une technique n'apparaît pas :

1. ✅ Vérifier que la posture est bien de type "Posture"
2. ✅ Vérifier que la technique est bien de type "Technique"
3. ✅ Ouvrir la technique et vérifier "Posture Associée"
4. ✅ Rafraîchir la page (F5)
5. ✅ Activer/désactiver la posture avec TOGGLE

Si ça ne fonctionne toujours pas :

1. Supprimer la technique
2. Recréer la technique en copiant-collant le nom de la posture
3. Glisser à nouveau sur le personnage

---

**Bon jeu ! 🎲✨**
