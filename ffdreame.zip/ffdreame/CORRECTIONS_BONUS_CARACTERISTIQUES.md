# 🎯 Corrections des Bonus de Caractéristiques

## Problème identifié

Lorsque tu cliquais sur une caractéristique pour faire un jet, **les bonus de dés n'étaient pas pris en compte** dans le jet.

### Causes du bug :

1. **Dans `actor-sheet.js`** : La fonction `_onCompetenceRoll()` cherchait la valeur de la compétence dans un `<input type="number">` qui **n'existe pas** dans ton template HTML
2. **Dans `character-sheet.html`** : L'affichage des bonus était incorrect (affichait "+1d6+2d6" = "+3d6" à 10 points au lieu de "+1d12")

---

## ✅ Corrections appliquées

### 1. Fichier : `module/sheets/actor-sheet.js`

**Ligne 221-237** - Fonction `_onCompetenceRoll()` modifiée :

```javascript
async _onCompetenceRoll(event) {
  event.preventDefault();
  const element = event.currentTarget;
  
  // Empêcher le clic sur le bouton + de déclencher le jet
  if (event.target.classList.contains('btn-plus-competence')) {
    return;
  }
  
  // Récupérer le label et la valeur de la compétence
  const label = element.querySelector('label')?.textContent || 'Compétence';
  
  // ✨ CORRECTION : Récupérer la valeur depuis le span (pas d'input dans le template)
  const valueSpan = element.querySelector('.competence-value');
  const value = parseInt(valueSpan?.textContent) || 0;

  // Lancer le jet
  if (this.actor) {
    await this.actor.rollCompetence(label, value);
  }
}
```

**Ce qui a changé :**
- ❌ Avant : cherchait `input[type="number"]` qui n'existait pas
- ✅ Maintenant : récupère la valeur depuis `<span class="competence-value">`
- ➕ Bonus : empêche le bouton "+" de déclencher un jet

---

### 2. Fichier : `templates/actor/character-sheet.html`

**Toutes les lignes `bonus-indicator`** - Affichage corrigé :

**Avant (incorrect) :**
```html
<span class="bonus-indicator">
  {{#if (gte system.physique.force.value 5)}}+1d6{{/if}}
  {{#if (gte system.physique.force.value 10)}}+2d6{{/if}}
</span>
```
☝️ Problème : à 10 points, ça affichait "+1d6+2d6" = "+3d6"

**Après (correct) :**
```html
<span class="bonus-indicator">
  {{#if (gte system.physique.force.value 10)}}+1d12
  {{else}}{{#if (gte system.physique.force.value 5)}}+1d6{{/if}}{{/if}}
</span>
```
✅ Maintenant : 5-9 points = "+1d6", 10+ points = "+1d12"

---

## 📊 Système de bonus (rappel)

| Points | Bonus de dé | Réduction seuil | Exemple |
|--------|-------------|-----------------|---------|
| 0-4    | Aucun       | 0               | Seuil 65 → 65 |
| 5-9    | **+1d6**    | -5              | Seuil 65 → 60 |
| 10+    | **+1d12**   | -10             | Seuil 65 → 55 |

---

## 🧪 Test des corrections

Pour tester :
1. Ouvre ta fiche de personnage
2. Mets une caractéristique à **5 points** → clic dessus → le jet doit afficher **1d100+1d6**
3. Mets une caractéristique à **10 points** → clic dessus → le jet doit afficher **1d100+1d12**
4. Le message dans le chat doit afficher : "📊 Bonus compétence: 1d6" ou "1d12"

---

## 📦 Installation

1. Sauvegarde ton module actuel
2. Remplace les fichiers suivants par les versions corrigées :
   - `module/sheets/actor-sheet.js`
   - `templates/actor/character-sheet.html`
3. Rafraîchis Foundry VTT (F5)
4. Teste avec une fiche de personnage !

---

## 🎉 Résultat

Maintenant, quand tu cliques sur une caractéristique, **les bonus sont correctement appliqués** au jet de dés ! 🎲
