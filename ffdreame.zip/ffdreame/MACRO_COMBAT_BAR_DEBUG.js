/**
 * MACRO DE DIAGNOSTIC - Barre de Combat FFdreame
 * Coller dans une macro Foundry de type "Script"
 * Permet de vérifier et forcer l'affichage de la barre
 */

console.log("=== DIAGNOSTIC BARRE DE COMBAT ===");

// 1. Vérifier si la barre existe dans le DOM
const bar = document.getElementById('ffdreame-combat-bar');
if (bar) {
  const style = window.getComputedStyle(bar);
  console.log("✅ Barre trouvée dans le DOM");
  console.log("  - display:", style.display);
  console.log("  - visibility:", style.visibility);
  console.log("  - opacity:", style.opacity);
  console.log("  - bottom:", style.bottom);
  console.log("  - z-index:", style.zIndex);
  console.log("  - position:", style.position);
  ui.notifications.info("✅ La barre existe dans le DOM - check F12 pour les détails");
} else {
  console.warn("❌ Barre NON trouvée dans le DOM");
  ui.notifications.warn("❌ Barre non trouvée - tentative de création...");
}

// 2. Vérifier si la classe has-combat-bar est sur le body
const hasClass = document.body.classList.contains('has-combat-bar');
console.log(hasClass ? "✅ Classe has-combat-bar présente" : "❌ Classe has-combat-bar ABSENTE");

// 3. Vérifier si FFdreameCombatBar est accessible
if (window.FFdreameCombatBar) {
  console.log("✅ FFdreameCombatBar accessible globalement");
  console.log("  - currentActor:", FFdreameCombatBar.currentActor?.name || 'Aucun');
  console.log("  - _initialized:", FFdreameCombatBar._initialized);
  
  // 4. Forcer la création
  console.log("🔄 Forçage de l'affichage...");
  FFdreameCombatBar.forceShow();
  
  setTimeout(() => {
    const newBar = document.getElementById('ffdreame-combat-bar');
    if (newBar) {
      ui.notifications.info("✅ Barre de combat créée avec succès !");
    } else {
      ui.notifications.error("❌ ÉCHEC création de la barre - voir F12 console");
    }
  }, 500);
  
} else {
  console.error("❌ FFdreameCombatBar NON accessible - problème d'import du module !");
  ui.notifications.error("❌ Module combat-bar.js non chargé ! Rechargez Foundry (F5)");
}
