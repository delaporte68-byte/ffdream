# 🎮 FFdreame v5.2 - Modifications FINALES

## ✅ MODIFICATIONS RÉALISÉES (v5.2)

### 1. **Suppression de la section Postures & Techniques dans l'onglet Combat**
- ✅ La section complète a été retirée pour gagner de la place
- ✅ Les postures et techniques restent accessibles via l'inventaire des items

### 2. **Réorganisation de la section Combat - Disposition ergonomique**
- ✅ **Colonne Gauche** : Bulles PV et PM
- ✅ **Colonne Centre** : Jauge Burste réduite et compacte
- ✅ **Colonne Droite** : Grilles Fatigue et Blessures (compactes)
- ✅ Tout tient sur une seule ligne horizontale
- ✅ Design optimisé pour un maximum de visibilité avec un minimum d'espace

### 3. **Jauge Burste compacte**
- ✅ Taille réduite (min-width: 200px)
- ✅ Positionnée entre PV/PM et Fatigue/Blessures
- ✅ Garde toutes ses fonctionnalités (input, affichage du pourcentage, message "PRÊT")
- ✅ Info-bulle sur le gain de Burste

### 4. **Cases Fatigue et Blessures compactes**
- ✅ Grille de 9 cases en ligne (3px d'espacement)
- ✅ Taille réduite (30x30px par case)
- ✅ Design ergonomique avec numéros visibles
- ✅ Effets visuels au survol et activation conservés

### 5. **Jets de caractéristiques avec bonus intégrés** ⭐ NOUVEAU
- ✅ **5 points dans une caractéristique** :
  - Ajoute **+1d6** au jet
  - Réduit le seuil de **-5** (ex: d65 devient d60)
- ✅ **10 points dans une caractéristique** :
  - Ajoute **+1d12** au jet
  - Réduit le seuil de **-10** (ex: d65 devient d55)
- ✅ Affichage clair dans le message de chat :
  - Montre le seuil original et le seuil réduit
  - Affiche le type de dé bonus
  - Exemple : "📊 Bonus compétence: 1d12 + Seuil réduit de 10 (65 → 55)"

---

## 🎯 STRUCTURE VISUELLE DE LA SECTION COMBAT

```
┌─────────────────────────────────────────────────────────────────┐
│                      ONGLET COMBAT                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌───────┐  ┌───────┐     ┌─────────────┐     ┌──────────────┐│
│  │  PV   │  │  PM   │     │   BURSTE    │     │   FATIGUE    ││
│  │  ❤️   │  │  ⚡   │     │ ████░░░ 75% │     │ [1][2][3]... ││
│  │ 150/  │  │ 50/   │     │   75 / 100  │     │              ││
│  │  200  │  │  100  │     │             │     │  BLESSURES   ││
│  └───────┘  └───────┘     └─────────────┘     │ [1][2][3]... ││
│                                                └──────────────┘│
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                    POINTS D'ACTION                              │
│                  [⬛] [⬛] [⬛]                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│     ┌─── Attaques ───┐     ┌─── Ultimates ───┐               │
│     │      [+]       │     │       [+]        │               │
│     │    [+]  [+]    │     │     [+]  [+]     │               │
│     │    [+]  [+]    │     │     [+]  [+]     │               │
│     │    [+]  [+]    │     │     [+]  [+]     │               │
│     │      [+]       │     │       [+]        │               │
│     └────────────────┘     └──────────────────┘               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 💡 SYSTÈME DE JETS AVEC BONUS

### Exemple 1 : Force = 5 points

**Rang A (seuil de base : 60)**

```
Sans bonus (Force 0) :
- Jet : 1d100
- Seuil : ≤ 60

Avec bonus (Force 5) :
- Jet : 1d100 + 1d6
- Seuil : ≤ 55
- Affichage : "📊 Bonus compétence: 1d6 + Seuil réduit de 5 (60 → 55)"
```

### Exemple 2 : Agilité = 10 points

**Rang S (seuil de base : 60)**

```
Sans bonus (Agilité 0) :
- Jet : 1d100
- Seuil : ≤ 60

Avec bonus (Agilité 10) :
- Jet : 1d100 + 1d12
- Seuil : ≤ 50
- Affichage : "📊 Bonus compétence: 1d12 + Seuil réduit de 10 (60 → 50)"
```

---

## 📊 TABLEAU DES BONUS PAR NIVEAU DE COMPÉTENCE

| Points | Bonus au jet | Réduction seuil | Exemple (Rang A, base 60) |
|--------|--------------|-----------------|---------------------------|
| 0-4    | Aucun        | 0               | 1d100 ≤ 60                |
| 5-9    | +1d6         | -5              | 1d100+1d6 ≤ 55            |
| 10+    | +1d12        | -10             | 1d100+1d12 ≤ 50           |

---

## 🎨 CSS AJOUTÉ (v5.2)

### Nouvelle disposition compacte :
- `.combat-stats-row` : Grille 3 colonnes (auto + 1fr + auto)
- `.combat-orbs-group` : Conteneur PV/PM
- `.burste-compact` : Jauge Burste réduite
- `.burste-compact-track` : Barre de progression (20px de haut)
- `.status-grids-compact` : Conteneur Fatigue/Blessures
- `.status-case-compact` : Cases 30x30px
- `.status-grid-compact` : Grille 9 colonnes

---

## 📝 FICHIERS MODIFIÉS (v5.2)

### Templates :
- ✅ `templates/actor/character-sheet.html`
  - Suppression section Postures & Techniques
  - Nouvelle disposition combat compacte
  - Nouvelle section Burste réduite
  - Cases Fatigue/Blessures compactes

### CSS :
- ✅ `css/ffdreame.css`
  - Ajout ~200 lignes pour disposition compacte
  - Styles pour jauge Burste compacte
  - Styles pour cases Fatigue/Blessures compactes

### JavaScript :
- ✅ `module/documents/actor.js`
  - Modification fonction `rollCompetence`
  - Ajout calcul réduction seuil
  - Ajout affichage bonus dans message de chat

---

## 🚀 INSTALLATION

1. Extraire le fichier `ffdreame-system-v5.2-FINAL.zip`
2. Remplacer les fichiers dans votre dossier système Foundry
3. Recharger Foundry VTT
4. Les modifications seront automatiquement appliquées

---

## 📋 RÉCAPITULATIF DES VERSIONS

### v5.0 (Initial)
- Création des objets Attaque et Ultimate
- Modification des Postures (8 cases)

### v5.1 (Corrections)
- Suppression grande jauge Burste
- Token central + aptitudes autour
- Suppression champ "Style" des techniques
- Deux tableaux interactifs (Attaques/Ultimates)

### v5.2 (Final) ⭐ ACTUEL
- Suppression section Postures & Techniques (onglet Combat)
- Jauge Burste compacte entre PV/PM et Fatigue/Blessures
- Cases Fatigue/Blessures ergonomiques et compactes
- **Jets de caractéristiques avec bonus intégrés**
  - 5 points = +1d6 et -5 au seuil
  - 10 points = +1d12 et -10 au seuil

---

## ⚙️ CONFIGURATION RECOMMANDÉE

Pour une expérience optimale :

1. **Onglet Principal** : Gestion du personnage, compétences, aptitudes, talents
2. **Onglet Combat** : Interface compacte avec tout accessible rapidement
3. **Onglet Équipement** : Inventaire (à développer)

---

## 🎯 PROCHAINES ÉTAPES (Optionnel)

1. **Drag & Drop** pour les tableaux interactifs
2. **Interactivité** des cases (clic pour lancer objets)
3. **Affichage des icônes** des objets dans les cases
4. **Gestion automatique** des effets Ultimate

---

**Version** : 5.2 (FINAL)  
**Date** : 03/02/2026  
**État** : Système complet et fonctionnel - Prêt pour le jeu !

🎉 **Toutes les fonctionnalités demandées sont maintenant implémentées !**
