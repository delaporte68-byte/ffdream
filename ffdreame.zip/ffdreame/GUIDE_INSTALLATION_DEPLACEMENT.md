# 🏃 GUIDE D'INSTALLATION - SYSTÈME DE DÉPLACEMENT ROBUSTE

## 📋 Table des Matières
1. [Présentation du Système](#présentation)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Utilisation](#utilisation)
5. [Dépannage](#dépannage)

---

## 🎯 Présentation du Système

### Fonctionnement
Le système limite physiquement le déplacement des tokens en fonction de la compétence **Athlétisme** :

```
Déplacement Max = 2 mètres + Athlétisme
```

**Exemples :**
- Athlétisme 0 → 2m max
- Athlétisme 3 → 5m max
- Athlétisme 8 → 10m max

### Caractéristiques
✅ **Blocage physique** - Impossible de contourner  
✅ **Indicateur visuel** (avec Drag Ruler)  
✅ **Gestion déplacement gratuit** - 1 par tour  
✅ **Réaction Marche** - Dépense 1 Petit PA pour se déplacer à nouveau  
✅ **Blocage mort** - Les morts ne bougent pas  

---

## 🔧 Installation

### Étape 1 : Copier les Fichiers

Les fichiers suivants ont été créés/modifiés :

```
ffdreame/
├── module/
│   ├── ffdreame.js                               ✏️ MODIFIÉ
│   └── helpers/
│       ├── drag-ruler-integration.js             ✨ NOUVEAU
│       └── movement-blocker.js                   ✨ NOUVEAU
└── lang/
    └── fr.json                                    ✏️ MODIFIÉ
```

#### Fichiers à copier dans votre système :

1. **`module/helpers/drag-ruler-integration.js`** (nouveau)
2. **`module/helpers/movement-blocker.js`** (nouveau)
3. **`module/ffdreame.js`** (modifié)
4. **`lang/fr.json`** (modifié)

### Étape 2 : Installer Drag Ruler (RECOMMANDÉ)

Pour avoir l'indicateur visuel de la zone de déplacement :

1. Ouvrir Foundry VTT
2. Aller dans **Configuration → Modules complémentaires**
3. Cliquer sur **Installer un module**
4. Chercher : `Drag Ruler`
5. Installer et activer le module

**Module Drag Ruler :**
- URL : https://foundryvtt.com/packages/drag-ruler
- Auteur : MangoFVTT
- Gratuit

> ⚠️ **Note :** Le système fonctionne SANS Drag Ruler, mais l'expérience est bien meilleure avec.

### Étape 3 : Vérifier l'Installation

1. Redémarrer Foundry VTT
2. Ouvrir la console (F12)
3. Vérifier les messages :

```
FFdreame | Initialisation du système
FFdreame | Initialisation du bloqueur de déplacement...
FFdreame | Bloqueur de déplacement activé ✅
FFdreame | Système prêt
FFdreame | Configuration de Drag Ruler... (si installé)
FFdreame | Drag Ruler configuré avec succès ✅ (si installé)
```

---

## ⚙️ Configuration

### Configuration de la Grille

Le système utilise la distance de grille configurée dans la scène :

1. **Clic droit sur la scène** → Configurer
2. **Grille** → Distance de la grille
3. Définir (exemple : `1.5` pour 1.5m par case)

### Configuration Drag Ruler (si installé)

1. **Configuration → Paramètres du module**
2. Chercher **Drag Ruler**
3. **Speed Provider** → Sélectionner `FFdreame`

Les couleurs par défaut :
- 🟢 **Vert** : Déplacement normal (90% du max)
- 🟠 **Orange** : Proche de la limite (90-100%)
- 🔴 **Rouge** : Déplacement bloqué (>100%)

---

## 🎮 Utilisation

### Pour les Joueurs

#### 1. Déplacement Normal

1. **Sélectionner votre token**
2. **Glisser vers la destination**
   - Avec Drag Ruler : Un cercle coloré indique la zone
   - 🟢 Vert = OK
   - 🔴 Rouge = Impossible
3. **Relâcher le token**

**Résultat :**
- ✅ Si dans la limite → Token se déplace
- ❌ Si hors limite → Message d'erreur + token ne bouge pas

#### 2. Déplacement Gratuit Utilisé

Si vous avez déjà utilisé votre déplacement gratuit :

1. **Activer 🚶 MARCHE** (bouton sur la fiche)
   - Coût : 1 Petit PA
2. **Se déplacer normalement**
3. Le bouton Marche se désactive automatiquement

#### 3. Personnage Mort

Si vos PV tombent à 0 :
- 💀 Icône tête de mort apparaît
- ⛔ Déplacement totalement bloqué
- Le token ne peut plus bouger (même avec Marche)

### Pour le MJ

#### Réinitialiser le Déplacement

**Méthode 1 : Manuellement** (à faire chaque tour)
```javascript
// Dans une macro ou la console
game.actors.getName("Nom du Personnage").update({
  'system.combat.deplacementGratuitUtilise': false
});
```

**Méthode 2 : Via le MovementBlocker**
```javascript
// Réinitialiser UN personnage
FFdreameMovementBlocker.resetMovement(actor);

// Réinitialiser TOUS les personnages
FFdreameMovementBlocker.resetAllMovements();
```

**Méthode 3 : Macro Automatique**

Créer une macro "Nouveau Tour" :

```javascript
// MACRO : Réinitialiser Déplacements
FFdreameMovementBlocker.resetAllMovements();
```

#### Afficher la Zone de Déplacement

Pour aider un joueur à visualiser :

```javascript
// Afficher le cercle de déplacement d'un token
const token = canvas.tokens.controlled[0];
FFdreameMovementBlocker.showMovementRange(token, 5000); // 5 secondes
```

#### Bypass (si nécessaire)

Le MJ peut déplacer n'importe quel token sans restriction.  
*(Le système détecte automatiquement si c'est le MJ)*

---

## 🧪 Tests Recommandés

### Test 1 : Athlétisme 0
1. Créer un PJ avec **Athlétisme 0**
2. Grille à **1.5m/case**
3. Déplacement max = **2m** = ~1.33 cases
4. Essayer de déplacer de 2 cases → **Doit être BLOQUÉ**

### Test 2 : Athlétisme 5
1. Créer un PJ avec **Athlétisme 5**
2. Déplacement max = **7m** = ~4.66 cases
3. Essayer de déplacer de 4 cases → **Doit passer**
4. Essayer de déplacer de 5 cases → **Doit être BLOQUÉ**

### Test 3 : Déplacement Gratuit
1. Déplacer un PJ de 1 case → **Passe**
2. Essayer de déplacer à nouveau → **BLOQUÉ**
3. Activer **🚶 MARCHE** → Déplacement possible
4. Le bouton Marche se désactive automatiquement

### Test 4 : Personnage Mort
1. Mettre PV à 0
2. Vérifier l'icône 💀 apparaît
3. Essayer de déplacer → **TOTALEMENT BLOQUÉ**
4. Remettre PV > 0
5. Icône 💀 disparaît, déplacement possible

---

## 🔧 Dépannage

### Problème : Le token se déplace quand même

**Causes possibles :**
1. Le système n'est pas chargé
   - Vérifier la console (F12)
   - Redémarrer Foundry

2. Vous êtes MJ
   - Le MJ peut bypasser les restrictions
   - Tester avec un compte joueur

3. Le type d'acteur n'est pas "character"
   - Vérifier `actor.type` dans la console
   - Seuls "character" et "cyberpunk" sont limités

### Problème : Drag Ruler ne fonctionne pas

**Solutions :**
1. Vérifier que le module est **activé**
2. Dans les paramètres Drag Ruler :
   - Speed Provider = `FFdreame`
3. Redémarrer Foundry
4. Si ça ne marche toujours pas :
   - Le blocage physique fonctionne quand même !

### Problème : Messages d'erreur dans la console

```
Error: Cannot read property 'physique' of undefined
```

**Solution :** Vérifier la structure de données de l'acteur :
```javascript
actor.system.physique.athletisme.value
```

Si la structure est différente, modifier dans `movement-blocker.js` ligne 142.

### Problème : Le déplacement ne se réinitialise pas

**Solutions :**
1. Utiliser la macro de réinitialisation
2. Vérifier que le champ existe :
   ```javascript
   actor.system.combat.deplacementGratuitUtilise
   ```
3. Réinitialiser manuellement via l'update

---

## 📊 Formules et Conversions

### Distance en Cases

```
Cases = Mètres ÷ Distance_Grille
```

**Exemple avec grille 1.5m :**
- 2m = 1.33 cases
- 5m = 3.33 cases
- 10m = 6.66 cases

### Calcul du Déplacement

```javascript
const athletisme = actor.system.physique.athletisme.value;
const deplacementMetres = 2 + athletisme;
const gridDistance = canvas.scene.grid.distance;
const deplacementCases = deplacementMetres / gridDistance;
```

---

## 🎨 Personnalisation

### Modifier les Couleurs Drag Ruler

Dans `drag-ruler-integration.js` :

```javascript
get colors() {
  return [
    { id: "normal", default: 0x00FF00, name: "..." },  // Vert
    { id: "warning", default: 0xFFAA00, name: "..." }, // Orange
    { id: "blocked", default: 0xFF0000, name: "..." }  // Rouge
  ];
}
```

### Modifier la Formule de Déplacement

Dans `movement-blocker.js` ligne 142 :

```javascript
const deplacementMaxMetres = 2 + athletisme; // Formule actuelle

// Exemples d'alternatives :
// const deplacementMaxMetres = 3 + (athletisme * 2);
// const deplacementMaxMetres = athletisme + endurance;
```

### Ajouter une Tolérance

Dans `movement-blocker.js` ligne 173 :

```javascript
const TOLERANCE = 0.05; // Tolérance en cases
```

Augmenter si les joueurs ont des problèmes de pixels.

---

## 📞 Support

En cas de problème :

1. **Vérifier la console** (F12) pour les erreurs
2. **Tester avec un personnage simple** (Athlétisme 0)
3. **Vérifier les logs** dans la console
4. **Comparer avec les tests recommandés**

Messages de debug importants :
```
🏃 Validation déplacement pour [Nom]...
✅ [Nom] - Déplacement autorisé
❌ [Nom] dépasse la limite de déplacement → BLOQUÉ
```

---

## 🎯 Résumé Rapide

| Élément | Valeur |
|---------|--------|
| **Formule** | 2m + Athlétisme |
| **Déplacement gratuit** | 1 par tour |
| **Réaction Marche** | 1 Petit PA |
| **Mort** | Déplacement impossible |
| **MJ** | Peut bypasser |
| **Module recommandé** | Drag Ruler |

---

## ✅ Checklist d'Installation

- [ ] Copier `drag-ruler-integration.js`
- [ ] Copier `movement-blocker.js`
- [ ] Modifier `ffdreame.js`
- [ ] Modifier `fr.json`
- [ ] Installer module Drag Ruler (optionnel)
- [ ] Redémarrer Foundry
- [ ] Vérifier la console
- [ ] Configurer Speed Provider
- [ ] Tester avec Athlétisme 0
- [ ] Tester déplacement gratuit
- [ ] Tester personnage mort

---

**Version du système :** v10.2  
**Date :** Février 2026  
**Auteur :** FFdreame Team
