# 🎬 GUIDE ANIMATIONS JB2A - Style MULTI

## 🎯 Prérequis

### Modules requis
1. **JB2A** (au choix) :
   - JB2A Free (gratuit) → https://foundryvtt.com/packages/JB2A_DnD5e
   - JB2A Patreon (payant, plus d'animations)

2. **Sequencer** (obligatoire) :
   - → https://foundryvtt.com/packages/sequencer

### Installation
1. Aller dans "Add-on Modules"
2. Rechercher "JB2A" et "Sequencer"
3. Installer et activer les deux modules
4. Relancer Foundry

---

## 📁 Structure des chemins JB2A

### Format du chemin
```
jb2a.[type].[variation].[couleur]
```

### Exemples
```
jb2a.explosion.orange
jb2a.fire_bolt.orange
jb2a.ray_of_frost.blue
jb2a.fireball.beam.orange
```

---

## 🔥 Animations pour TYPE CERCLE (explosions)

### Recommandées

#### Explosions classiques
```
jb2a.explosion.orange          ← Explosion feu
jb2a.explosion.blue            ← Explosion glace/énergie
jb2a.explosion.dark_red        ← Explosion sombre
jb2a.explosion.yellow          ← Explosion lumineuse
```

#### Effets de zone
```
jb2a.thunderwave.center.blue   ← Onde de choc électrique
jb2a.thunderwave.center.orange ← Onde de choc feu
jb2a.fireball.beam.orange      ← Boule de feu explosive
jb2a.impact.ground_crack.blue  ← Fissure au sol
```

#### Élémentaires
```
jb2a.ice_spikes.radial.white   ← Pics de glace radiaux
jb2a.spirit_guardians.blueyellow.ring ← Gardiens spirituels
jb2a.smoke.puff.centered.grey  ← Nuage de fumée
```

---

## ⚡ Animations pour TYPE LIGNE (rayons)

### Recommandées

#### Rayons élémentaires
```
jb2a.fire_bolt.orange          ← Lance-flammes
jb2a.ray_of_frost.blue         ← Rayon de givre
jb2a.lightning_bolt.blue       ← Éclair
jb2a.scorching_ray.01.orange   ← Rayon brûlant
```

#### Projectiles
```
jb2a.magic_missile.blue        ← Missile magique
jb2a.eldritch_blast.purple     ← Décharge occulte
jb2a.energy_beam.normal.blue   ← Rayon d'énergie
```

#### Effets spéciaux
```
jb2a.chain_lightning.primary.blue ← Éclair en chaîne
jb2a.guiding_bolt.01.blueyellow   ← Projectile guidé
```

---

## ⚙️ Configuration dans FFdreame

### Localisation du champ

Le chemin de l'animation est stocké dans :
```
technique.system.animation.jb2a
```

### Dans la fiche technique

1. Ouvrir la technique
2. Chercher l'onglet **"Effets"** ou **"Animation"**
3. Champ **"JB2A Animation"**
4. Entrer le chemin (voir exemples ci-dessous)

---

## 💡 Exemples de techniques configurées

### Boule de Feu (Type CERCLE)
```
Nom : Boule de Feu
Type : cercle
Distance max : 6m
Largeur : 4m
JB2A : jb2a.fireball.beam.orange
```

### Lance-Flammes (Type LIGNE)
```
Nom : Lance-Flammes
Type : ligne
Distance max : 3m
Largeur : 1m
JB2A : jb2a.fire_bolt.orange
```

### Blizzard (Type CERCLE)
```
Nom : Blizzard
Type : cercle
Distance max : 8m
Largeur : 6m
JB2A : jb2a.ice_spikes.radial.white
```

### Éclair (Type LIGNE)
```
Nom : Éclair
Type : ligne
Distance max : 5m
Largeur : 0.5m
JB2A : jb2a.lightning_bolt.blue
```

### Onde de Choc (Type CERCLE)
```
Nom : Onde de Choc
Type : cercle
Distance max : 2m
Largeur : 6m
JB2A : jb2a.thunderwave.center.blue
```

---

## 🔍 Trouver le bon chemin d'animation

### Méthode 1 : Utiliser le Database Viewer

1. Installer le module **"JB2A - Database Viewer"** (si disponible)
2. Ouvrir le viewer
3. Parcourir les animations
4. Copier le chemin exact

### Méthode 2 : Macro de test

Créez une macro avec ce code :
```javascript
new Sequence()
  .effect()
  .file("jb2a.explosion.orange") // ← Votre chemin ici
  .atLocation(canvas.tokens.controlled[0])
  .play();
```

1. Sélectionnez un token
2. Lancez la macro
3. Si l'animation joue → Le chemin est bon !
4. Si erreur → Vérifiez le chemin

### Méthode 3 : Console du navigateur

Ouvrez la console (F12) et tapez :
```javascript
// Lister toutes les animations JB2A disponibles
game.modules.get("JB2A_DnD5e").api
```

---

## 🐛 Erreurs courantes

### "Could not find file: jb2a.xxx"

**Causes possibles** :
1. ❌ Chemin incorrect (faute de frappe)
2. ❌ JB2A non installé/activé
3. ❌ Sequencer non installé/activé
4. ❌ Animation Patreon utilisée avec JB2A Free

**Solutions** :
1. Vérifier l'orthographe exacte du chemin
2. Activer les modules requis
3. Vérifier que l'animation existe dans votre version de JB2A

### "Sequencer is not defined"

**Cause** : Module Sequencer non activé

**Solution** :
1. Aller dans "Add-on Modules"
2. Activer "Sequencer"
3. Relancer Foundry

### Animation ne joue pas

**Vérifications** :
1. Les modules sont activés ✅
2. Le chemin est correct ✅
3. Un token est sélectionné/ciblé ✅
4. La technique a réussi (jet de dés) ✅

---

## 📚 Catalogue JB2A Free

### Explosions
- `jb2a.explosion.orange`
- `jb2a.explosion.blue`
- `jb2a.explosion.dark_red`
- `jb2a.explosion.yellow`

### Feu
- `jb2a.fire_bolt.orange`
- `jb2a.fireball.beam.orange`
- `jb2a.scorching_ray.01.orange`
- `jb2a.wall_of_fire.100ft.orange`

### Glace
- `jb2a.ice_spikes.radial.white`
- `jb2a.ray_of_frost.blue`
- `jb2a.sleet_storm.blue`

### Électricité
- `jb2a.lightning_bolt.blue`
- `jb2a.chain_lightning.primary.blue`
- `jb2a.thunderwave.center.blue`

### Énergie
- `jb2a.magic_missile.blue`
- `jb2a.eldritch_blast.purple`
- `jb2a.energy_beam.normal.blue`

### Ombre/Nécromancie
- `jb2a.darkness.black`
- `jb2a.toll_the_dead.purple.shockwave`
- `jb2a.witch_bolt.purple`

---

## 🎨 Personnalisation avancée

### Modifier la taille (scale)

Dans `multi-zone.js`, ligne ~390 :
```javascript
.scale(0.8)  // 0.8 = 80% de la taille originale
```

Valeurs recommandées :
- Petite zone : `0.5` à `0.7`
- Zone moyenne : `0.8` à `1.0`
- Grande zone : `1.2` à `1.5`

### Modifier la durée

```javascript
.waitUntilFinished(-500)  // -500ms = termine 500ms avant la fin
```

Valeurs :
- `-200` : Très rapide
- `-500` : Normal (défaut)
- `-1000` : Lent, épique

---

## 🔗 Ressources

### Liens utiles
- **JB2A Wiki** : https://github.com/Jules-Bens-Aa/JB2A_DnD5e/wiki
- **Sequencer Doc** : https://github.com/fantasycalendar/FoundryVTT-Sequencer

### Communauté
- Discord Foundry VTT
- Reddit r/FoundryVTT
- Forums officiels Foundry

---

## 💾 Template de configuration rapide

Copiez-collez ces configurations dans vos techniques :

### Feu
```
Type : cercle | JB2A : jb2a.fireball.beam.orange
Type : ligne  | JB2A : jb2a.fire_bolt.orange
```

### Glace
```
Type : cercle | JB2A : jb2a.ice_spikes.radial.white
Type : ligne  | JB2A : jb2a.ray_of_frost.blue
```

### Électricité
```
Type : cercle | JB2A : jb2a.thunderwave.center.blue
Type : ligne  | JB2A : jb2a.lightning_bolt.blue
```

### Énergie
```
Type : cercle | JB2A : jb2a.explosion.blue
Type : ligne  | JB2A : jb2a.magic_missile.blue
```

### Ombre
```
Type : cercle | JB2A : jb2a.darkness.black
Type : ligne  | JB2A : jb2a.witch_bolt.purple
```

---

**Bon jeu avec des animations épiques !** 🎬✨
