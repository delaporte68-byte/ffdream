# 🎯 RÉSUMÉ RAPIDE DES MODIFICATIONS FFdreame

## ✅ 3 MODIFICATIONS EFFECTUÉES

---

## 1️⃣ TOKEN CENTRAL INTERACTIF (Onglet Principal)

### AVANT :
```
[Compétences]     [Aptitude 1]
                  [Aptitude 2]
                  [Aptitude 3]
                  [Aptitude 4]
```

### APRÈS :
```
[Compétences]          [ATTAQUE]
                           ↑
                           |
                   [PM] ← [🖼️] → [PUISSANCE]
                           |
                           ↓
                          [PV]
```

### ✨ Fonctionnalités :
- **Clic gauche** → Changer l'image du personnage
- **Clic droit** → Ouvrir le Prototype Token
- Bordure dorée avec effet lumineux
- Animation au survol

---

## 2️⃣ SUPPRESSION GRANDE BARRE BURST (Onglet Combat)

### AVANT :
```
[Petite barre Burst en haut]
┌──────────────────────────────┐
│  ⚡ BURSTE                    │
│  ████████████░░░░  80/100    │
│  +10 par attaque | +5 coup   │
└──────────────────────────────┘
[Postures...]
```

### APRÈS :
```
[Petite barre Burst en haut] ✅ CONSERVÉE
[Postures...]
```

### 🗑️ Supprimé :
- Grande barre horizontale
- Texte explicatif
- Section qui prenait trop de place

---

## 3️⃣ SYSTÈME POSTURES/TECHNIQUES (Déjà Fonctionnel)

### Comment Utiliser :

#### A. Créer une Posture :
```
Nom : "Style Dragon"
Attaque Base : +20
Ultimate : "Dragon Céleste" (300 dégâts)
```

#### B. Créer des Techniques :
```
Technique 1:
- Nom : "Griffe du Dragon"
- Style : CAC
- Coût PM : 15
- Base Dégâts : 50
- Posture Associée : "Style Dragon" ⚠️ (NOM EXACT!)

Technique 2:
- Nom : "Souffle Enflammé"
- Style : MG
- Coût PM : 25
- Base Dégâts : 80
- Posture Associée : "Style Dragon"
```

#### C. Résultat dans la Fiche :
```
┌─────────────────────────────────┐
│  🥊 POSTURE : Style Dragon      │
│  [✓ ACTIVE] [CONFIG]            │
│                                 │
│  [⚔️ ATTAQUE DE BASE] 170 dég   │
│                                 │
│  📜 TECHNIQUES :                │
│  ┌───────────────────────────┐ │
│  │ Griffe du Dragon          │ │
│  │ 💎 15 PM | ⚔️ 50 dégâts    │ │
│  └───────────────────────────┘ │
│  ┌───────────────────────────┐ │
│  │ Souffle Enflammé          │ │
│  │ 💎 25 PM | ⚔️ 80 dégâts    │ │
│  └───────────────────────────┘ │
│                                 │
│  🔥 ULTIMATE : Dragon Céleste   │
│  🔓 DISPONIBLE (Burst = 100)    │
│  [🔥 LANCER ULTIMATE]           │
└─────────────────────────────────┘
```

---

## 📦 FICHIERS MODIFIÉS

### 1. HTML
- `templates/actor/character-sheet.html`
  - ✅ Token central ajouté
  - ✅ Grande section Burst supprimée

### 2. CSS
- `css/ffdreame.css`
  - ✅ Styles token + cercles
  - ✅ Section Burst masquée

### 3. JavaScript
- `module/sheets/actor-sheet.js`
  - ✅ Event listeners token

---

## 🚀 INSTALLATION

### Étapes :
1. **Sauvegarder** votre dossier `systems/ffdreame/` actuel
2. **Extraire** `ffdreame-modified.zip`
3. **Remplacer** le contenu dans `systems/ffdreame/`
4. **Redémarrer** Foundry VTT
5. **Rafraîchir** (F5)

### Ou Méthode Manuelle :
Remplacer uniquement ces 3 fichiers :
- `templates/actor/character-sheet.html`
- `css/ffdreame.css`
- `module/sheets/actor-sheet.js`

---

## 🎮 TESTER

### Test Token :
1. Ouvrir fiche → Onglet Principal
2. Observer le token central
3. Cliquer dessus → changer image
4. Clic droit → voir Prototype Token

### Test Burst :
1. Ouvrir fiche → Onglet Combat
2. Vérifier : grande barre disparue ✅
3. Vérifier : petite barre en haut présente ✅

### Test Techniques :
1. Créer posture "Test"
2. Créer technique avec "Posture Associée : Test"
3. Activer posture
4. Technique apparaît ✅
5. Cliquer technique → lance jet ✅

---

## ⚠️ IMPORTANT : POSTURE ASSOCIÉE

Pour qu'une technique apparaisse, le champ **"Posture Associée"** doit contenir le nom **EXACT** de la posture :

✅ **CORRECT :**
- Posture : `"Style Dragon"`
- Technique → Posture Associée : `"Style Dragon"`

❌ **INCORRECT :**
- `"style dragon"` (minuscule)
- `"Style dragon"` (pas de majuscule)
- `"StyleDragon"` (pas d'espace)
- `"Style  Dragon"` (double espace)

**SOLUTION :** Copier-coller le nom de la posture !

---

## 📊 STYLES DE TECHNIQUE

| Style | Formule | Utilisation |
|-------|---------|-------------|
| CAC | ATQ + (PM÷2) + Base | Corps à corps |
| MG | (ATQ÷2) + PM + Base | Magie pure |
| P | ATQ + PM + Base | Équilibre parfait |
| EHa | ATQ + Base (×3 jets) | Éclat Haine Attaque |
| EHm | PM + Base (×3 jets) | Éclat Haine Magie |
| EF | PM + Base + (ATQ÷2) | Éclat Foudre |
| BUFF | Pas de dégâts | Soins/Buffs |

---

## 🐛 PROBLÈMES FRÉQUENTS

### Token ne s'affiche pas ?
→ Vider cache (Ctrl+Shift+R)

### Grande barre Burst toujours là ?
→ Vérifier que le CSS est bien modifié

### Technique n'apparaît pas ?
→ Vérifier le nom EXACT de la posture

### Token ne clique pas ?
→ Vérifier console F12 pour erreurs

---

## 🎨 APERÇU VISUEL

### Onglet Principal (Nouveau) :
```
╔════════════════════════════════════════╗
║  NOM : Jean Dupont    LV: 5   Rang: B ║
╠════════════════════════════════════════╣
║                                        ║
║  [Compétences]         [⚔️ ATTAQUE]    ║
║   Physique                    ↑        ║
║   - Force: 8                  |        ║
║   - Athlétisme: 6  [💎PM] ←  🖼️ → [✨MG]
║   ...                         |        ║
║                               ↓        ║
║                          [❤️ PV]       ║
║                                        ║
║  [Talents...]                          ║
╚════════════════════════════════════════╝
```

### Onglet Combat (Modifié) :
```
╔════════════════════════════════════════╗
║  ❤️ PV  💎 PM  ⚡ Burst (petite) ✅    ║
║  [PA] [PA] [PA]                        ║
╠════════════════════════════════════════╣
║                                        ║
║  🥊 POSTURES & TECHNIQUES              ║
║  ┌──────────────┬──────────────┐      ║
║  │ Posture 1    │ Posture 2    │      ║
║  │ - Technique A│ - Technique C│      ║
║  │ - Technique B│ - Technique D│      ║
║  └──────────────┴──────────────┘      ║
║                                        ║
║  🎖️ ATOUTS                             ║
║  [Atout 1] [Atout 2] [Atout 3]        ║
╚════════════════════════════════════════╝
```

---

## ✅ CHECKLIST FINALE

Après installation, vérifier :

- [ ] Token visible au centre de l'onglet Principal
- [ ] 4 aptitudes autour du token (haut/bas/gauche/droite)
- [ ] Token cliquable (change image)
- [ ] Token clic droit (prototype)
- [ ] Grande barre Burst disparue
- [ ] Petite barre Burst présente en haut
- [ ] Postures affichables
- [ ] Techniques dans postures
- [ ] Techniques cliquables
- [ ] Jets de dégâts fonctionnent
- [ ] Ultimate disponible à Burst=100

---

**Bon jeu avec votre système FFdreame modifié ! 🎮🔥**
