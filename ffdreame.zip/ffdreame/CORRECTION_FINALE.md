# 🎯 FFdreame - Correction FINALE Style MULTI

## ✅ Corrections appliquées

### 1. Templates supprimés complètement ✅
**Problème** : Les carrés jaunes/bleus restaient sur la scène.  
**Solution** : Les templates ne sont **plus créés du tout**. L'animation JB2A suffit pour la visualisation.

### 2. Système de dégâts corrigé ✅
**Problème** : L'ordre des cibles était aléatoire.  
**Solution** : La **cible principale** (celle ciblée) reçoit TOUJOURS 100% des dégâts en premier.

### 3. PA consommés immédiatement ✅
Les PA sont consommés **avant** le jet de dés (déjà corrigé en v2).

### 4. Burste fixe à +10 ✅
Gain de +10 Burste **peu importe** le nombre de cibles (déjà corrigé en v2).

---

## 🎮 Fonctionnement final

### Type CERCLE - Exemple complet

```
Scénario :
- Goblin Chef (cible principale) au centre
- 3 autres gobelins autour de lui dans le rayon

Action :
1. Cible le Goblin Chef
2. Lance "Boule de Feu" (cercle, rayon 2m)
3. Grand PA consommé immédiatement
4. Jet de dés → Réussite !
5. Animation JB2A (pas de template jaune ✅)

Dégâts appliqués :
1. Goblin Chef [CIBLE] : 100 dégâts (100%) ← Premier !
2. Goblin 1 : 80 dégâts (80%)
3. Goblin 2 : 60 dégâts (60%)
4. Goblin 3 : 40 dégâts (40%)

Résultat :
→ 4 cibles touchées
→ PM consommés
→ Burste +10
→ Pas de templates qui restent ✅
```

### Type LIGNE - Exemple complet

```
Scénario :
- Ennemi final à 3m (cible principale)
- 2 ennemis entre le joueur et la cible

Action :
1. Cible l'ennemi final
2. Lance "Lance-Flammes" (ligne, largeur 1m)
3. Grand PA consommé immédiatement
4. Jet de dés → Réussite !
5. Animation JB2A (pas de template jaune ✅)

Dégâts appliqués :
1. Ennemi final [CIBLE] : 50 dégâts (100%) ← Premier !
2. Ennemi proche : 40 dégâts (80%)
3. Ennemi moyen : 30 dégâts (60%)

Résultat :
→ 3 cibles touchées
→ PM consommés
→ Burste +10
→ Pas de templates qui restent ✅
```

---

## 📊 Système de dégâts - Clarification

### Ordre GARANTI

La **cible que vous ciblez** (celle que vous visez) reçoit **TOUJOURS** 100% des dégâts en premier.

Les autres cibles **dans la zone** reçoivent des dégâts réduits :
- 1ère cible (principale) : **100%** des dégâts
- 2ème cible (zone) : **80%** des dégâts (-20%)
- 3ème cible (zone) : **60%** des dégâts (-40%)
- 4ème cible (zone) : **40%** des dégâts (-60%)
- 5ème cible (zone) : **20%** des dégâts (-80%)
- 6ème+ cible (zone) : **0%** des dégâts (-100%)

### Message dans le chat

```
💥 Boule de Feu (MULTI)
Cibles touchées : 4

1. Goblin Chef [CIBLE] : 100 dégâts (100%)
   PV: 150 → 50

2. Goblin Guerrier : 80 dégâts (80%)
   PV: 100 → 20

3. Goblin Archer : 60 dégâts (60%)
   PV: 80 → 20

4. Goblin Scout : 40 dégâts (40%)
   PV: 60 → 20

⚡ Burste : 30 → 40 (+10)
```

Le tag **[CIBLE]** indique la cible principale qui reçoit 100%.

---

## 🎬 Templates et animations

### Pas de templates

Les templates (zones jaunes/bleues) ne sont **plus créés du tout**.

**Pourquoi ?**
- Ils causaient des bugs (restaient sur la scène)
- Ils n'apportaient pas de valeur (animation JB2A suffit)
- Ils encombrent la carte

### Animation JB2A uniquement

Seule l'**animation JB2A** est jouée (si configurée).

**Avantages** :
- ✅ Pas de bugs de templates
- ✅ Visualisation propre
- ✅ Performance améliorée
- ✅ Carte non encombrée

---

## 🔧 Modifications techniques

### Fichiers modifiés

**`module/combat/multi-zone.js`** :
- Suppression complète de la création de templates (lignes ~145-177 et ~286-327)
- Ajout du paramètre `primaryTarget` à `_applyMultiDamage()`
- Réorganisation de l'ordre des cibles (cible principale en premier)
- Ajout du tag `[CIBLE]` dans les messages

**`module/sheets/actor-sheet.js`** :
- PA consommés avant le jet (déjà fait en v2)

### Code clé

```javascript
// S'ASSURER QUE LA CIBLE PRINCIPALE EST EN PREMIER
if (primaryTarget) {
  // Retirer la cible principale de la liste
  targets = targets.filter(t => t.id !== primaryTarget.id);
  // La remettre en premier
  targets.unshift(primaryTarget);
}

// Puis application des dégâts dans l'ordre
for (let i = 0; i < targets.length; i++) {
  const reduction = i * 0.2; // 0%, 20%, 40%, 60%...
  const pourcentage = Math.max(0, 1 - reduction);
  const degats = Math.floor(degatsBase * pourcentage);
  // ...
}
```

---

## 🎯 Cas d'usage

### Cas 1 : Cible seule (aucun ennemi dans la zone)

```
Situation : Goblin isolé

Dégâts :
1. Goblin [CIBLE] : 100 dégâts (100%)

Résultat : 1 cible, dégâts pleins
```

### Cas 2 : Cible avec 1 ennemi proche

```
Situation : Goblin + Orc dans le rayon

Dégâts :
1. Goblin [CIBLE] : 100 dégâts (100%)
2. Orc : 80 dégâts (80%)

Résultat : 2 cibles, réduction commence à la 2ème
```

### Cas 3 : Groupe serré (5+ ennemis)

```
Situation : 6 ennemis dans le rayon

Dégâts :
1. Ennemi ciblé [CIBLE] : 100 dégâts (100%)
2. Ennemi A : 80 dégâts (80%)
3. Ennemi B : 60 dégâts (60%)
4. Ennemi C : 40 dégâts (40%)
5. Ennemi D : 20 dégâts (20%)
6. Ennemi E : 0 dégâts (0%)

Résultat : 6 cibles détectées, 5 endommagées
```

### Cas 4 : Type LIGNE traversant plusieurs ennemis

```
Situation : 4 ennemis alignés entre joueur et cible

Dégâts :
1. Cible finale [CIBLE] : 100 dégâts (100%)
2. Ennemi proche : 80 dégâts (80%)
3. Ennemi moyen : 60 dégâts (60%)
4. Ennemi loin : 40 dégâts (40%)

Résultat : Tous les ennemis sur le chemin touchés
```

---

## 🐛 Dépannage

### Les templates apparaissent encore

Si vous voyez encore des carrés jaunes/bleus :
1. Vérifiez que vous avez bien installé la **version FINALE**
2. Videz le cache : **Ctrl+F5**
3. Vérifiez dans la console (F12) : vous ne devriez **PAS** voir "Template créé"

### La cible principale ne prend pas 100%

Si la cible ciblée ne reçoit pas 100% des dégâts :
1. Vérifiez le message dans le chat
2. Cherchez le tag **[CIBLE]**
3. Si absent ou sur la mauvaise cible → bug, contactez support

### Ordre bizarre des dégâts

Les dégâts devraient TOUJOURS être :
```
1. [CIBLE] : 100%
2. Autre : 80%
3. Autre : 60%
etc.
```

Si l'ordre est différent, le système n'a pas bien détecté la cible principale.

---

## 📝 Résumé des versions

### v1 (première correction)
- ✅ Ciblage au lieu de clic sur carte
- ❌ Templates restaient
- ❌ PA après réussite
- ❌ Burste par cible

### v2 (deuxième correction)
- ✅ Ciblage
- ⚠️ Templates supprimés avec délai (parfois restaient)
- ✅ PA avant jet
- ✅ Burste fixe +10

### FINALE (cette version)
- ✅ Ciblage
- ✅ **Aucun template créé**
- ✅ PA avant jet
- ✅ Burste fixe +10
- ✅ **Cible principale = 100% garantis**

---

## ⚙️ Installation

### Installation complète
```bash
1. Désactiver FFdreame
2. Supprimer Data/systems/ffdreame/
3. Extraire ffdreame-multi-final.zip dans Data/systems/
4. Réactiver FFdreame
5. Relancer Foundry (Ctrl+F5)
```

### Mise à jour depuis v2
Remplacer uniquement :
- `Data/systems/ffdreame/module/combat/multi-zone.js`

Puis **Ctrl+F5**.

---

## ✨ Améliorations futures possibles

- [ ] Option pour activer/désactiver les templates (paramètre système)
- [ ] Formule de réduction personnalisable (10%, 15%, 20%, etc.)
- [ ] Limite maximale de cibles touchées configurable
- [ ] Preview de la zone avant le jet (optionnel)

---

**Version** : FINALE  
**Date** : Février 2026  
**Compatibilité** : Foundry VTT v11/v12  
**Système** : FFdreame v8.0+

---

## 🎮 Test rapide

Pour vérifier que tout fonctionne :

1. **Créer une technique** :
   - Style : multi
   - Type : cercle
   - Distance : 6m
   - Largeur : 4m
   - Dégâts : 100

2. **Placer des tokens** :
   - 1 ennemi principal
   - 2-3 autres autour de lui

3. **Tester** :
   - Cibler l'ennemi principal
   - Utiliser la technique
   - Vérifier dans le chat :
     - [CIBLE] sur le bon ennemi ✅
     - 100% de dégâts pour lui ✅
     - 80%, 60% pour les autres ✅
     - Pas de carrés jaunes sur la carte ✅

Si tout est OK → Installation réussie ! 🎉
