# 🎮 FFDREAME - VERSION INTÉGRÉE COMPLÈTE

## ✅ Ce qui est DÉJÀ intégré dans cette version

Cette version contient TOUS les systèmes fonctionnels et prêts à l'emploi :

### 1. **📏 Système de Portée** ✅
- Toutes les techniques ont un champ "Portée"
- Vérification automatique avant lancer
- Message d'erreur si trop loin

### 2. **🎯 Combat Tracker Personnalisé** ✅  
- Affichage PV/PM/PA/Fatigue/Blessure
- Initiative 1d100 + bonus "Prend l'Initiative"
- Macro "Terminer mon Tour"
- Récupération 1 Grand PA par tour

### 3. **🐲 Fiche NPC Simplifiée** ✅
- Tout sur une page
- Mêmes mécaniques que les joueurs
- Atouts activables par le MJ

### 4. **📜 Scroll sur Fiche Technique** ✅
- Hauteur 700px avec barre de défilement
- Contenu accessible sans redimensionner

### 5. **🎯 Style CHM Enrichi** ⚠️ GUIDES FOURNIS
- Effets 1 & 2 par variante
- Animations JB2A par variante
- Support MULTI dans CHM
- **Note:** Templates HTML à intégrer manuellement (voir guides)

### 6. **🚀 Système de Téléportation** ✅
- Téléportation du lanceur (derrière/devant/gauche/droite)
- Téléportation de la cible (clic sur carte)
- Distance max configurable
- **Note:** Onglet UI à ajouter manuellement dans technique-sheet-v2.html

### 7. **🧊 Zones Persistantes** ✅
- Durée d'animation configurable (1s à permanent)
- Zones qui restent sur la carte
- Dégâts automatiques chaque tour
- **Note:** Onglet UI à ajouter manuellement dans technique-sheet-v2.html

---

## ⚙️ Installation

### Étape 1 : Sauvegarder votre système actuel
```
1. Allez dans Foundry VTT/Data/systems/ffdreame
2. Renommez le dossier en "ffdreame-backup"
```

### Étape 2 : Installer cette version
```
1. Décompressez ffdreame-INTEGRATION-COMPLETE.zip
2. Copiez le dossier "ffdreame" dans Foundry VTT/Data/systems/
3. Relancez Foundry
```

### Étape 3 : Vérifier que ça fonctionne
```
Ouvrez la console (F12) et cherchez :
✅ "FFdreame | Initialisation du système"
✅ "FFdreame | Système de combat activé"
✅ "FFdreame | Zones persistantes activées"
```

---

## 🎯 Fonctionnalités Prêtes à l'Emploi

### Portée des Techniques
```
1. Ouvrez une technique
2. Configurez "Portée maximale (mètres)"
3. Lancez la technique
→ Vérification automatique !
```

### Combat Tracker
```
1. Créez un combat
2. Ajoutez des combattants
3. Roll All pour l'initiative
→ Affichage automatique des stats !
```

### Fiche NPC
```
1. Créer un Acteur
2. Type : "NPC/Monstre"
→ Fiche simplifiée s'affiche !
```

### Téléportation (Après ajout de l'onglet UI)
```
1. Ouvrez une technique
2. Onglet "🚀 Téléportation"
3. Activez et configurez
→ Fonctionne automatiquement !
```

### Zones Persistantes (Après ajout de l'onglet UI)
```
1. Ouvrez une technique
2. Onglet "🎬 Animations"
3. Activez "Zone Persistante"
→ Fonctionne automatiquement !
```

---

## ⚠️ Ce qui reste à faire MANUELLEMENT

### 1. Ajouter l'onglet Téléportation
**Fichier:** `templates/item/technique-sheet-v2.html`
**Guide:** `TEMPLATE_ONGLET_TELEPORTATION.html`

Ajoutez l'onglet après l'onglet "Animations"

### 2. Enrichir l'onglet Animations
**Fichier:** `templates/item/technique-sheet-v2.html`
**Guide:** `TEMPLATE_ANIMATIONS_ENRICHI.html`

Remplacez l'onglet "Animations" existant

### 3. Enrichir les slots CHM
**Fichier:** `templates/item/technique-sheet-v2.html`
**Guide:** `TEMPLATE_CHM_SLOT_ENRICHI.html`

Remplacez chaque slot CHM (slot1 à slot5)

---

## 📁 Structure des Fichiers

```
ffdreame/
├── module/
│   ├── combat/
│   │   ├── combat-system.js ✅ (Combat Tracker)
│   │   ├── teleportation-system.js ✅ (Téléportation)
│   │   ├── persistent-zones.js ✅ (Zones)
│   │   └── multi-zone.js ✅ (MULTI)
│   ├── sheets/
│   │   ├── actor-sheet.js ✅ (Intégration complète)
│   │   ├── npc-sheet.js ✅ (Fiche NPC)
│   │   └── item-sheet.js ✅ (Scroll)
│   └── ffdreame.js ✅ (Imports + Init)
├── templates/
│   ├── actor/
│   │   └── npc-sheet.html ✅ (Template NPC)
│   └── item/
│       └── technique-sheet-v2.html ⚠️ (À enrichir)
├── template.json ✅ (Tous les champs ajoutés)
└── GUIDES/ (Documentation complète)
```

---

## 🐛 Dépannage

### "Rien ne se passe quand je lance une technique"
1. Ouvrez la console (F12)
2. Cherchez les erreurs en rouge
3. Vérifiez que les modules sont chargés

### "La téléportation ne fonctionne pas"
1. Vérifiez dans la console : `window.FFdreameTeleportation`
2. Si `undefined`, le module n'est pas chargé
3. Rechargez Foundry

### "Les zones persistantes n'apparaissent pas"
1. Vérifiez qu'un combat est actif
2. Vérifiez dans la console : `window.FFdreamePersistentZones`
3. La zone ne se crée que si la technique réussit

---

## 💡 Testez les Systèmes

### Test 1 : Portée
```
1. Créez une technique CAC avec portée 1.5m
2. Ciblez un ennemi à 5m
3. Lancez la technique
→ Doit afficher "Cible trop loin !"
```

### Test 2 : Combat Tracker
```
1. Créez un combat
2. Ajoutez 2 personnages
3. Roll All
→ Doit afficher PV/PM/PA dans le tracker
```

### Test 3 : NPC
```
1. Créez un acteur type "NPC/Monstre"
2. Ouvrez la fiche
→ Doit afficher la fiche simplifiée sur 1 page
```

### Test 4 : Téléportation (si UI ajoutée)
```
1. Technique avec téléportation activée
2. Ciblez un ennemi
3. Lancez la technique
→ Vous devez vous téléporter
```

### Test 5 : Zone Persistante (si UI ajoutée)
```
1. Technique avec zone persistante
2. Lancez en combat
3. Attendez le tour suivant
→ Les ennemis dans la zone prennent des dégâts
```

---

## 📚 Guides Inclus

- `GUIDE_SYSTEME_PORTEE.md` - Système de portée
- `GUIDE_SYSTEME_COMBAT.md` - Combat Tracker
- `GUIDE_FICHE_NPC.md` - Fiche NPC
- `GUIDE_ENRICHISSEMENT_CHM.md` - Style CHM enrichi
- `GUIDE_SYSTEME_TELEPORTATION.md` - Téléportation
- `GUIDE_ZONES_PERSISTANTES.md` - Zones persistantes
- `GUIDE_SCROLL_ET_ANIMATIONS.md` - Scroll + Animations

---

## ✅ Checklist de Vérification

Après installation, vérifiez que tout fonctionne :

- [ ] Console affiche "Système de combat activé"
- [ ] Console affiche "Zones persistantes activées"
- [ ] Fiche NPC accessible (type "NPC/Monstre")
- [ ] Champ "Portée" visible dans les techniques
- [ ] Combat Tracker affiche PV/PM/PA
- [ ] Scroll fonctionne sur fiche technique
- [ ] `window.FFdreameTeleportation` existe (console)
- [ ] `window.FFdreamePersistentZones` existe (console)

---

## 🆘 Support

Si quelque chose ne fonctionne pas :

1. **Console (F12)** - Regardez les erreurs
2. **Guides** - Lisez les guides correspondants
3. **Backup** - Vous pouvez toujours revenir à votre version précédente

Bon jeu ! 🎮✨
