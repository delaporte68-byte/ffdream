# 📋 RAPPORT COMPLET DES CORRECTIONS - VERSION FINALE

## ✅ Fichiers modifiés (7 fichiers)

### 1. `module/sheets/actor-sheet.js` (167 KB)
**Corrections appliquées :**

#### A. 🔒 Restriction PA pour joueurs
- Ajout de `if (!game.user.isGM) return;` dans :
  - `_onApPetitClick()` - Empêche les joueurs de restaurer les petits PA
  - `_onApGrandClick()` - Empêche les joueurs de restaurer les grands PA
- **Résultat :** Seul le MJ peut cliquer sur les PA pour les restaurer

#### B. 🎯 Consommation PA bonus (grand4)
- **Esquive/Défense/Marche** : Boucle étendue de `1-3` à `1-4`
- **Techniques avec Grand PA** : 3 occurrences corrigées pour chercher grand4
- **Techniques avec Petit PA** : 3 occurrences corrigées pour utiliser grand4
- **Vérification** : Tous les endroits vérifient `grand4?.disponible !== false`
- **Résultat :** Le grand4 est maintenant consommé correctement partout

#### C. ➕➖ Bouton - caractéristiques (MJ uniquement)
- Ajout de la méthode `_onMinusCompetence()`
- Restriction : `if (!game.user.isGM)` - seul le MJ peut réduire
- Permet les valeurs **négatives** (pour malus temporaires)
- **Résultat :** Le MJ peut maintenant réduire les compétences

#### D. ✨ Effets de technique (stockage en flags)
- **bufA** : Stocke `bufAttaque` avec valeur, unité, tours
- **bufJ** : Stocke `bufJet` avec valeur, unité, tours  
- **bufD** : Stocke `bufDefense` avec valeur, unité, tours
- **sc** : Nouveau - Saut de Colonne (empêche esquive/défense de la cible)
- **ec** : Nouveau - Éviter Confrontation (ignore malus de rang)
- **Résultat :** Les effets sont maintenant stockés en flags

---

### 2. `module/canvas/token-hud.js` (8 KB)
**Correction appliquée :**

#### 📊 Affichage PA bonus sur token
- Boucle dynamique : affiche 6 ou 8 PA selon disponibilité de grand4
- Vérification : `if (grand4 && grand4.disponible !== false)`
- **Style spécial pour PA bonus :**
  - Bordure **gold** (#FFD700) au lieu de noire
  - Remplissage **gold** au lieu de vert
  - Glow **gold** plus fort (outerStrength: 3)
- **Résultat :** Les 2 PA bonus apparaissent en gold à droite des 6 PA normaux

---

### 3. `module/combat/aoer-system.js` (14 KB)
**Correction appliquée :**

#### 🔧 API PIXI v13 (3 occurrences)
- **Ligne ~86** (cercle) : `event.data.getLocalPosition()` → `event.getLocalPosition()`
- **Ligne ~127** (ligne) : `event.data.getLocalPosition()` → `event.getLocalPosition()`
- **Ligne ~169** (triangle) : `event.data.getLocalPosition()` → `event.getLocalPosition()`
- **Résultat :** Correction de l'erreur PIXI pour Foundry v13

---

### 4. `module/combat/combat-system.js` (15 KB)
**Correction appliquée :**

#### ⏱️ Décrémentation des effets temporaires
- Méthode `_decrementerEffetsTemporaires()` remplace `_decrementerMalusJetRisque()`
- **Décrémente automatiquement :**
  - `jetRisqueMalus`
  - `malusJet`
  - `reducDegats`
  - `bufAttaque`
  - `bufJet`
  - `bufDefense`
  - `sautColonne`
  - `eviterConfrontation`
- **Résultat :** Tous les effets temporaires sont décrémentés à chaque fin de tour

---

### 5. `module/ffdreame.js` (14 KB)
**Correction appliquée :**

#### 🛠️ Helper Handlebars `negMalus`
- **Affiche les bonus/malus selon la valeur de compétence :**
  - Valeur ≥ 10 : `-1d12`
  - Valeur 5-9 : `-1d6`
  - Valeur 1-4 : rien
  - Valeur 0 à -4 : `+1d6`
  - Valeur -5 à -9 : `+1d6`
  - Valeur ≤ -10 : `+1d12`
- **Résultat :** Les valeurs négatives affichent un bonus au lieu d'un malus

---

### 6. `templates/actor/character-sheet.html` (40 KB)
**Corrections appliquées :**

#### 🎨 Interface bouton - et helper negMalus
- **Toutes les compétences (12) :**
  - Remplacement de l'ancien `bonus-indicator` par `{{negMalus ...}}`
  - Ajout du bouton `-` visible uniquement pour le MJ : `{{#if @root.isGM}}`
  - Bouton avec tooltip : "Retirer 1 point (MJ)"
- **Résultat :** Le MJ voit un bouton − rouge à côté de chaque +

---

### 7. `css/ffdreame.css` (220 KB)
**Correction appliquée :**

#### 🎨 Style du bouton -
- **Apparence :**
  - Cercle rouge/rose (#ff6b6b)
  - Background semi-transparent
  - Box-shadow rouge
  - Symbole `−` en font-weight 900
- **Hover :**
  - Background plus opaque
  - Bordure blanche
  - Échelle 1.15
  - Glow rouge intense
- **Résultat :** Bouton − cohérent visuellement avec le bouton +

---

## 🎯 Résumé des résultats

| Fonctionnalité | Statut | Description |
|----------------|--------|-------------|
| 🔒 Restriction PA | ✅ Complet | Les joueurs ne peuvent plus restaurer les PA |
| 📊 Grand4 Token | ✅ Complet | Affichage en gold sur le token |
| 🎯 Grand4 Consommation | ✅ Complet | Utilisé partout (esquive, techniques, tableaux) |
| ➖ Bouton − (MJ) | ✅ Complet | Réduction de compétences avec valeurs négatives |
| ✨ Effets technique (flags) | ✅ Complet | bufA/bufJ/bufD/sc/ec stockés en flags |
| ⏱️ Décrémentation effets | ✅ Complet | Tous les effets sont décrémentés automatiquement |
| 🔧 AOER PIXI v13 | ✅ Complet | Plus d'erreur PIXI |
| 🛠️ Helper negMalus | ✅ Complet | Affichage correct des valeurs négatives |

---

## ⚠️ Note importante : Lecture des flags

Les effets sont maintenant **stockés** correctement, mais la **lecture** lors des jets/calculs n'est pas encore implémentée :

- ❌ `bufAttaque` n'est pas encore lu lors du calcul des dégâts
- ❌ `bufJet` n'est pas encore lu lors des jets
- ❌ `bufDefense` n'est pas encore lu lors de la réception de dégâts
- ❌ `malusJet` n'est pas encore lu lors des jets de la cible
- ❌ `reducDegats` n'est pas encore lu lors du calcul des dégâts de la cible
- ❌ `sautColonne` n'est pas encore lu pour empêcher l'esquive/défense
- ❌ `eviterConfrontation` n'est pas encore lu pour ignorer le malus de rang

**Recommandation :** Ces lectures doivent être ajoutées dans `actor.js` dans les méthodes de jet et de calcul de dégâts. Si tu veux que je continue, je peux implémenter ces lectures.

---

## 📦 Installation

1. **Faire une sauvegarde** de ton dossier `/systems/ffdreame/` actuel
2. Remplacer ces 7 fichiers dans ton système :
   ```
   systems/ffdreame/module/sheets/actor-sheet.js
   systems/ffdreame/module/canvas/token-hud.js
   systems/ffdreame/module/combat/aoer-system.js
   systems/ffdreame/module/combat/combat-system.js
   systems/ffdreame/module/ffdreame.js
   systems/ffdreame/templates/actor/character-sheet.html
   systems/ffdreame/css/ffdreame.css
   ```
3. **Redémarrer** Foundry
4. Tester toutes les fonctionnalités

---

## 🧪 Tests à effectuer

1. **PA Joueurs :** Les joueurs ne peuvent pas cliquer sur les PA
2. **Grand4 Token :** Les 2 PA bonus apparaissent en gold
3. **Grand4 Consommation :** Esquive, défense, marche, techniques consomment grand4
4. **Bouton − :** Le MJ peut réduire les compétences (y compris en négatif)
5. **Valeurs négatives :** Les compétences négatives affichent +1d6 ou +1d12
6. **AOER :** Les zones d'effet fonctionnent sans erreur PIXI
7. **Effets stockés :** Les buffs/debuffs sont stockés en flags
8. **Décrémentation :** Les effets se décrémentent à chaque fin de tour

---

**Date :** 25 février 2026  
**Version système :** Foundry v13  
**Fichiers modifiés :** 7  
**Lignes de code modifiées :** ~200
