# 🧊 GUIDE : Zones Persistantes & Durée d'Animation

## 🎯 Vue d'ensemble

Deux nouvelles fonctionnalités pour les animations :

1. **⏱️ Durée d'Animation Configurable**
   - Contrôlez combien de temps l'animation reste visible
   - De 1 seconde à permanent

2. **🧊 Zones Persistantes**
   - Créez des zones qui restent sur la carte
   - Infligent des dégâts automatiques chaque tour
   - Durée configurable en nombre de tours

---

## ⏱️ Durée d'Animation

### Configuration :
```
⏱️ Durée de l'animation :
[3 secondes (Normal)] ▼

Options :
- 1 seconde (Rapide)
- 2 secondes
- 3 secondes (Normal)
- 5 secondes
- 8 secondes (Long)
- ♾️ Permanent
```

### Exemples :
**1 seconde** : Éclair rapide, coup de poing
**3 secondes** : Boule de feu, attaque magique
**8 secondes** : Explosion massive, sort puissant
**Permanent** : Aura magique, bouclier, portail

---

## 🧊 Zones Persistantes

### Qu'est-ce qu'une Zone Persistante ?

C'est une **zone dangereuse** qui reste sur la carte après l'attaque :
- ✅ Reste visible sur la scène
- ✅ Inflige des dégâts automatiques
- ✅ Chaque début de tour
- ✅ À tous les tokens dans la zone
- ✅ Disparaît après X tours

### Configuration :

```
╔══════════════════════════════════╗
║ 🧊 ZONE PERSISTANTE             ║
╠══════════════════════════════════╣
║ ☑️ Créer une zone persistante    ║
║                                  ║
║ 💥 Dégâts par tour : [10]        ║
║ ⏱️ Durée (tours) : [3]           ║
╚══════════════════════════════════╝
```

---

## 🎮 Workflow en Jeu

### Étape 1 : Lancer la Technique
```
Joueur : Utilise "Pics de Glace" (MULTI Zone)
→ Jet de dés : Réussite
→ Clic pour placer la zone
```

### Étape 2 : Zone Créée
```
✨ Zone persistante créée :
   - Nom : Pics de Glace
   - Dégâts : 15 par tour
   - Durée : 3 tours
   - Position : [X, Y]
```

### Étape 3 : Dégâts Automatiques
```
Tour 1 : 🧊 Zone active
         → Goblin entre dans la zone
         → 💥 15 dégâts infligés

Tour 2 : 🧊 Zone active
         → Bandit traverse la zone
         → 💥 15 dégâts infligés

Tour 3 : 🧊 Zone active
         → Loup dans la zone
         → 💥 15 dégâts infligés

Tour 4 : ✨ Zone disparue
```

---

## 📋 Exemples de Configuration

### Pics de Glace (Contrôle de Zone)
```
Technique : Pics de Glace
Style : MULTI (Zone, rayon 3m)
Animation : jb2a.ice_spikes.radial.white
Durée animation : 0 (Permanent)

Zone Persistante : ☑️ Activée
- Dégâts/tour : 15
- Durée : 3 tours

→ Crée une zone de glace dangereuse pendant 3 tours
→ Les pics restent visibles jusqu'à disparition
```

### Feu Persistant (Dégâts sur Durée)
```
Technique : Mur de Flammes
Style : MULTI (Ligne, 10m)
Animation : jb2a.wall_of_force.horizontal.orange
Durée animation : 0 (Permanent)

Zone Persistante : ☑️ Activée
- Dégâts/tour : 10
- Durée : 5 tours

→ Mur de feu qui bloque le passage
→ Brûle pendant 5 tours
```

### Nuage Toxique (Dangereux mais Court)
```
Technique : Nuage de Poison
Style : MULTI (Zone, rayon 4m)
Animation : jb2a.fog_cloud.2.green
Durée animation : 0 (Permanent)

Zone Persistante : ☑️ Activée
- Dégâts/tour : 20
- Durée : 2 tours

→ Très dangereux (20 dégâts)
→ Mais disparaît vite (2 tours)
```

### Zone de Soin (Dégâts Négatifs)
```
Technique : Aura de Régénération
Style : MULTI (Zone, rayon 5m)
Animation : jb2a.healing_generic.burst.greenorange
Durée animation : 0 (Permanent)

Zone Persistante : ☑️ Activée
- Dégâts/tour : -10 (SOINS)
- Durée : 4 tours

→ Zone de soins pour les alliés
→ -10 = +10 PV chaque tour
```

---

## 🎯 Tactiques de Jeu

### Contrôle de Zone :
```
Créez des zones persistantes pour :
✅ Bloquer des passages
✅ Forcer les ennemis à bouger
✅ Protéger des objectifs
✅ Diviser les groupes d'ennemis
```

### Dégâts sur Durée :
```
Zones persistantes > Dégâts directs quand :
✅ Ennemi lent (prendra plusieurs tours de dégâts)
✅ Zone de choke point (ennemis forcés de passer)
✅ Boss tanky (dégâts cumulés importants)
✅ Combat long (3+ tours)
```

### Combo avec Téléportation :
```
1. Créez une zone persistante
2. Utilisez téléportation de cible
3. Téléportez l'ennemi DANS la zone
4. L'ennemi subit des dégâts immédiats
   (au tour suivant)
```

---

## 📐 Calcul des Dégâts

### Dégâts Totaux :
```
Dégâts totaux = Dégâts/tour × Nombre de tours dans la zone

Exemple :
- Zone : 15 dégâts/tour
- Ennemi reste 3 tours dans la zone
- Total : 15 × 3 = 45 dégâts

VS Attaque directe :
- Attaque : 50 dégâts immédiats
- Zone : 45 dégâts sur 3 tours
```

### Équilibrage :
```
Dégâts/tour recommandés :
- Zone courte (2 tours) : 15-20 dégâts
- Zone moyenne (3 tours) : 10-15 dégâts
- Zone longue (5+ tours) : 5-10 dégâts

Rayon recommandé :
- 2m : Petit piège
- 3m : Zone standard
- 4m : Grande zone
- 5m+ : Zone massive
```

---

## 🎬 Animations Permanentes

### Quand utiliser l'animation permanente :

**☑️ Utilisez avec Zone Persistante :**
```
Animation : jb2a.ice_spikes.radial.white
Durée : ♾️ Permanent
Zone Persistante : ☑️ Oui

→ Les pics de glace restent visibles
→ Disparaissent avec la zone
→ Cohérence visuelle
```

**❌ N'utilisez PAS sans Zone Persistante :**
```
Animation : jb2a.fire_bolt.orange
Durée : ♾️ Permanent
Zone Persistante : ☐ Non

→ L'animation reste pour toujours
→ Encombre la scène
→ Pas de sens narratif
```

---

## ⚙️ Installation

### Fichiers Créés :
1. **`module/combat/persistent-zones.js`** ✅ - Système complet
2. **`TEMPLATE_ANIMATIONS_ENRICHI.html`** ⚠️ - À intégrer
3. **`CODE_INTEGRATION_ZONES_PERSISTANTES.js`** ⚠️ - À intégrer
4. **`template.json`** ✅ - Champs ajoutés

### Étapes :
1. Remplacer l'onglet "Animations" dans `technique-sheet-v2.html`
2. Ajouter le code d'intégration dans `actor-sheet.js`
3. Initialiser le système dans `ffdreame.js`

---

## 🛠️ Macros MJ

### Nettoyer Toutes les Zones :
```javascript
const { FFdreamePersistentZones } = await import(
  './systems/ffdreame/module/combat/persistent-zones.js'
);
await FFdreamePersistentZones.clearAllZones();
```

### Lister les Zones Actives :
```javascript
const zones = canvas.templates.placeables.filter(t => 
  t.document.getFlag('ffdreame', 'persistentZone')
);

for (const zone of zones) {
  const data = zone.document.getFlag('ffdreame', 'persistentZone');
  console.log(`${data.techniqueName}: ${data.tourActuel}/${data.dureeTours} tours`);
}
```

---

## 🐛 Dépannage

### "Aucune zone n'apparaît"
1. Vérifiez que "Zone Persistante" est ☑️
2. Vérifiez que la technique a réussi
3. Console (F12) pour voir les logs

### "L'animation ne se voit pas"
1. Vérifiez Sequencer installé et actif
2. Vérifiez le chemin de l'animation
3. Essayez une animation simple (jb2a.fire_bolt.orange)

### "Les dégâts ne s'appliquent pas"
1. Vérifiez qu'un combat est actif (Combat Tracker)
2. Les dégâts s'appliquent au DÉBUT du tour
3. Le lanceur n'est jamais blessé par sa zone

### "La zone ne disparaît pas"
1. Vérifiez que le combat est actif
2. La zone disparaît après le nombre de tours configuré
3. Utilisez la macro de nettoyage si nécessaire

---

## 💡 Idées de Techniques

### Zone de Glace Ralentissante :
```
Pics de Glace
- Animation : jb2a.ice_spikes.radial.white (Permanent)
- Zone : 15 dégâts/tour, 3 tours
- Effet 1 : Ralentissement -20% vitesse
```

### Feu Grégeois :
```
Mur de Flammes
- Animation : jb2a.wall_of_force.horizontal.orange (Permanent)
- Zone : 12 dégâts/tour, 4 tours
- Effet 1 : Brûlure continue
```

### Piège Explosif :
```
Mines Magiques
- Animation : jb2a.explosion.orange (3 secondes)
- Zone : 25 dégâts/tour, 1 tour
- Effet : Dégâts massifs mais instantanés
```

### Sanctuaire de Soin :
```
Cercle de Régénération
- Animation : jb2a.healing_generic.burst.greenorange (Permanent)
- Zone : -10 dégâts/tour (= +10 PV), 5 tours
- Pour les alliés uniquement
```

---

## 📊 Statistiques

### Dégâts Cumulés :
```
Configuration : 10 dégâts/tour, 5 tours

Scénario 1 : Ennemi reste 5 tours
→ 10 × 5 = 50 dégâts

Scénario 2 : Ennemi s'échappe au tour 2
→ 10 × 2 = 20 dégâts

Scénario 3 : 3 ennemis traversent (1 tour chacun)
→ 10 × 3 = 30 dégâts total
```

### Comparaison avec Attaque Directe :
```
Attaque directe : 50 dégâts immédiat
Zone persistante : 10 dégâts × 5 tours = 50 dégâts

Avantages zone :
✅ Peut toucher plusieurs ennemis
✅ Contrôle du terrain
✅ Force le mouvement

Avantages direct :
✅ Dégâts garantis immédiatement
✅ Pas de temps de mise en place
```

---

Créez vos champs de bataille stratégiques ! 🧊✨
