/**
 * MACRO DEBUG — Coller dans la console Foundry (F12) pour diagnostiquer
 * si le blocage de tour fonctionne pour le joueur courant
 */
(function() {
  const actor = canvas?.tokens?.controlled?.[0]?.actor;
  if (!actor) { console.warn("Sélectionne un token d'abord !"); return; }
  
  const combat = game.combat;
  const combatant = combat?.combatant;
  
  console.group("=== DEBUG BLOCAGE DE TOUR ===");
  console.log("Utilisateur GM ?", game.user.isGM);
  console.log("Combat démarré ?", !!combat?.started);
  console.log("Acteur sélectionné :", actor.name, "| ID:", actor.id);
  console.log("Combatant actuel :", combatant?.name, "| actorId:", combatant?.actorId);
  console.log("Match actorId ?", combatant?.actorId === actor.id);
  console.log("Actor isOwner ?", actor.isOwner);
  console.log("Flag actionBlocked ?", actor.getFlag('ffdreame', 'actionBlocked'));
  console.log("==> Peut agir ?", combatant?.actorId === actor.id && !actor.getFlag('ffdreame', 'actionBlocked'));
  console.groupEnd();
})();
