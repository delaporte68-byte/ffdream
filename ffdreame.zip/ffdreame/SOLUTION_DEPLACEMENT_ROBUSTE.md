# Solution Robuste pour Bloquer les Déplacements des Tokens

## 🎯 Objectif
Empêcher physiquement les tokens de se déplacer au-delà de leur limite d'athlétisme, sans possibilité de contournement.

## 🔍 Problèmes Actuels Identifiés

### 1. **Deux systèmes conflictuels**
- `movement-system.js` : Non utilisé, bon code mais jamais importé
- Code dans `ffdreame.js` (lignes 94-174) : Actif mais incomplet

### 2. **Failles du système actuel**
- Le GM peut bypasser (ligne 105)
- `preUpdateToken` avec `return false` ne bloque pas toujours
- Pas de vérification visuelle de la zone de déplacement
- Le module Drag Ruler n'est peut-être pas configuré

## ✅ SOLUTION RECOMMANDÉE : Système à Plusieurs Couches

### **Option 1 : Module Drag Ruler + Code Personnalisé** (⭐ RECOMMANDÉ)

#### Avantages :
- Indication visuelle AVANT le déplacement
- Bloque nativement le déplacement
- Interface intuitive pour les joueurs
- Très difficile à contourner

#### Étapes :

**A. Installer le module Drag Ruler**
```
Nom : Drag Ruler
URL : https://foundryvtt.com/packages/drag-ruler
```

**B. Créer l'intégration FFdreame**

Fichier : `module/helpers/drag-ruler-integration.js`
```javascript
/**
 * INTÉGRATION DRAG RULER
 * Configure Drag Ruler pour utiliser l'athlétisme FFdreame
 */
export class FFdreameDragRulerIntegration {
  
  static init() {
    // Attendre que Drag Ruler soit chargé
    Hooks.once('dragRuler.ready', (SpeedProvider) => {
      class FFdreameSpeedProvider extends SpeedProvider {
        
        get colors() {
          return [
            { id: "normal", default: 0x00FF00, name: "Déplacement Normal" },
            { id: "limit", default: 0xFFFF00, name: "Limite Athlétisme" },
            { id: "impossible", default: 0xFF0000, name: "Impossible" }
          ];
        }
        
        getRanges(token) {
          const actor = token.actor;
          
          // Par défaut pour non-PJ
          if (!actor || (actor.type !== "character" && actor.type !== "cyberpunk")) {
            return [
              { range: 999, color: "normal" }
            ];
          }
          
          // Vérifier si mort
          const pvActuel = actor.system.aptitudes?.pv?.value || 0;
          if (pvActuel <= 0) {
            return [{ range: 0, color: "impossible" }];
          }
          
          // Vérifier déplacement gratuit utilisé
          const deplacementGratuitUtilise = actor.system.combat?.deplacementGratuitUtilise || false;
          const marcheActive = actor.system.combat?.reactions?.marche || false;
          
          if (deplacementGratuitUtilise && !marcheActive) {
            return [{ range: 0, color: "impossible" }];
          }
          
          // Calculer distance max
          const athletisme = actor.system.physique?.athletisme?.value || 0;
          const deplacementMetres = 2 + athletisme;
          const gridDistance = canvas.scene.grid.distance || 1.5;
          const distanceMaxCases = deplacementMetres / gridDistance;
          
          return [
            { range: distanceMaxCases, color: "normal" },
            { range: distanceMaxCases * 1.1, color: "limit" }, // Petite marge
            { range: 999, color: "impossible" }
          ];
        }
      }
      
      dragRuler.registerSystem("ffdreame", FFdreameSpeedProvider);
      console.log("FFdreame | Drag Ruler intégré ✅");
    });
  }
}
```

**C. Bloquer physiquement les déplacements excessifs**

Fichier : `module/helpers/movement-blocker.js`
```javascript
/**
 * BLOQUEUR DE DÉPLACEMENT
 * Empêche PHYSIQUEMENT tout déplacement non autorisé
 */
export class FFdreameMovementBlocker {
  
  static init() {
    // Bloquer AVANT le déplacement (préventif)
    Hooks.on("preUpdateToken", this._blockMovement.bind(this));
  }
  
  static _blockMovement(tokenDoc, change, options, userId) {
    // Uniquement pour les changements de position
    if (!change.x && !change.y) return true;
    
    // Ne pas bloquer les mises à jour système
    if (options.ffdreameSystemMove) return true;
    
    const actor = tokenDoc.actor;
    if (!actor) return true;
    
    // Uniquement pour les PJ
    if (actor.type !== "character" && actor.type !== "cyberpunk") return true;
    
    // === VÉRIFICATION 1 : EST-IL MORT ? ===
    const pvActuel = actor.system.aptitudes?.pv?.value || 0;
    if (pvActuel <= 0) {
      ui.notifications.error("💀 Ce personnage est mort et ne peut pas se déplacer !");
      return false; // BLOQUÉ
    }
    
    // === VÉRIFICATION 2 : DÉPLACEMENT GRATUIT DISPONIBLE ? ===
    const deplacementGratuitUtilise = actor.system.combat?.deplacementGratuitUtilise || false;
    const marcheActive = actor.system.combat?.reactions?.marche || false;
    
    if (deplacementGratuitUtilise && !marcheActive) {
      ui.notifications.warn("⚠️ Déplacement gratuit déjà utilisé ! Activez 🚶 MARCHE (1 Petit PA) pour vous déplacer.");
      return false; // BLOQUÉ
    }
    
    // === VÉRIFICATION 3 : DISTANCE MAXIMALE ===
    const oldX = tokenDoc.x;
    const oldY = tokenDoc.y;
    const newX = change.x ?? oldX;
    const newY = change.y ?? oldY;
    
    const gridSize = canvas.grid.size;
    const deltaXCases = (newX - oldX) / gridSize;
    const deltaYCases = (newY - oldY) / gridSize;
    const distanceCases = Math.sqrt(deltaXCases * deltaXCases + deltaYCases * deltaYCases);
    
    const gridDistance = canvas.scene.grid.distance || 1.5;
    const athletisme = actor.system.physique?.athletisme?.value || 0;
    const deplacementMetres = 2 + athletisme;
    const distanceMaxCases = deplacementMetres / gridDistance;
    
    console.log(`🏃 ${actor.name} - Distance: ${distanceCases.toFixed(2)} cases / Max: ${distanceMaxCases.toFixed(2)} cases`);
    
    if (distanceCases > distanceMaxCases + 0.1) { // Petite tolérance d'arrondi
      ui.notifications.error(`⛔ Déplacement impossible ! Maximum: ${deplacementMetres}m (Athlétisme: ${athletisme})`);
      return false; // BLOQUÉ
    }
    
    // === DÉPLACEMENT AUTORISÉ → MARQUER COMME UTILISÉ ===
    setTimeout(async () => {
      const updateData = {
        'system.combat.deplacementGratuitUtilise': true
      };
      
      if (marcheActive) {
        updateData['system.combat.reactions.marche'] = false;
        ui.notifications.info("🚶 Marche utilisée");
      } else {
        ui.notifications.info("🏃 Déplacement gratuit utilisé");
      }
      
      await actor.update(updateData);
    }, 50);
    
    return true; // AUTORISÉ
  }
  
  /**
   * Réinitialiser le déplacement gratuit (à appeler en début de tour)
   */
  static async resetMovement(actor) {
    await actor.update({
      'system.combat.deplacementGratuitUtilise': false
    });
    ui.notifications.info(`🔄 ${actor.name} peut à nouveau se déplacer gratuitement`);
  }
}
```

**D. Modifier ffdreame.js**

Remplacer les lignes 94-174 par :
```javascript
import { FFdreameDragRulerIntegration } from "./helpers/drag-ruler-integration.js";
import { FFdreameMovementBlocker } from "./helpers/movement-blocker.js";

/* ================================
   INITIALISATION DU SYSTÈME
   ================================ */
Hooks.once('init', async function() {
  // ... code existant ...
  
  // Initialiser le bloqueur de déplacement
  FFdreameMovementBlocker.init();
});

Hooks.once('ready', async function() {
  console.log('FFdreame | Système prêt');
  
  // Initialiser Drag Ruler si disponible
  FFdreameDragRulerIntegration.init();
});
```

---

### **Option 2 : Système Pur JavaScript (Sans module externe)**

Si vous ne voulez PAS utiliser Drag Ruler :

#### Bloquer avec interception Ruler native

Fichier : `module/helpers/ruler-intercept.js`
```javascript
/**
 * INTERCEPTION DU RULER NATIF
 * Bloque le déplacement en interceptant le système de règle
 */
export class FFdreameRulerIntercept {
  
  static init() {
    // Intercepter la mesure du déplacement
    libWrapper.register('ffdreame', 'Ruler.prototype._onMouseMove', function(wrapped, event) {
      const result = wrapped(event);
      
      // Vérifier si on dépasse la limite
      const token = this.token;
      if (!token || !token.actor) return result;
      
      const actor = token.actor;
      if (actor.type !== "character" && actor.type !== "cyberpunk") return result;
      
      const athletisme = actor.system.physique?.athletisme?.value || 0;
      const deplacementMetres = 2 + athletisme;
      const gridDistance = canvas.scene.grid.distance || 1.5;
      const distanceMaxCases = deplacementMetres / gridDistance;
      
      const distance = this.totalDistance;
      
      if (distance > distanceMaxCases * gridDistance) {
        // Colorer en ROUGE
        this.color = 0xFF0000;
        ui.notifications.warn(`⚠️ Déplacement limité à ${deplacementMetres}m !`);
      } else {
        // Colorer en VERT
        this.color = 0x00FF00;
      }
      
      return result;
    }, 'WRAPPER');
    
    console.log("FFdreame | Ruler Intercept activé ✅");
  }
}
```

⚠️ **Nécessite LibWrapper** : https://foundryvtt.com/packages/lib-wrapper

---

### **Option 3 : Cercle de Vision Maximale (Visuel uniquement)**

Afficher un cercle autour du token montrant la zone de déplacement :

```javascript
/**
 * AFFICHAGE ZONE DE DÉPLACEMENT
 * Montre visuellement la limite de déplacement
 */
export class FFdreameMovementCircle {
  
  static showCircle(token) {
    const actor = token.actor;
    if (!actor) return;
    
    const athletisme = actor.system.physique?.athletisme?.value || 0;
    const deplacementMetres = 2 + athletisme;
    
    // Créer un template circulaire
    const templateData = {
      t: "circle",
      user: game.user.id,
      distance: deplacementMetres,
      x: token.center.x,
      y: token.center.y,
      fillColor: "#00FF0030",
      borderColor: "#00FF00"
    };
    
    canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]).then(templates => {
      // Supprimer après 5 secondes
      setTimeout(() => {
        canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [templates[0].id]);
      }, 5000);
    });
  }
  
  // Hook pour afficher au clic sur le token
  static init() {
    Hooks.on("controlToken", (token, controlled) => {
      if (controlled && token.actor) {
        this.showCircle(token);
      }
    });
  }
}
```

---

## 🎯 RECOMMANDATION FINALE

**Solution hybride** :
1. **Drag Ruler** → Indication visuelle CLAIRE avant le déplacement
2. **Movement Blocker** → Blocage PHYSIQUE au cas où
3. **GM Tracker** → Bouton pour réinitialiser le déplacement en début de tour

Cette approche est :
- ✅ Impossible à contourner
- ✅ Intuitive pour les joueurs
- ✅ Visuellement claire
- ✅ Facile à gérer pour le MJ

---

## 📋 Installation Étape par Étape

1. **Installer Drag Ruler** (module Foundry)
2. **Créer** `module/helpers/drag-ruler-integration.js`
3. **Créer** `module/helpers/movement-blocker.js`
4. **Modifier** `module/ffdreame.js` pour importer et initialiser
5. **Redémarrer** Foundry
6. **Tester** avec un personnage ayant Athlétisme 0, 2, 5

---

## 🧪 Comment Tester

1. Créer un PJ avec **Athlétisme 0** → Déplacement max = 2m
2. Essayer de déplacer le token de **3 cases** → Doit être BLOQUÉ
3. Activer **🚶 MARCHE** → Doit pouvoir se déplacer à nouveau
4. Mettre **PV à 0** → Déplacement totalement impossible

---

Voulez-vous que je crée directement les fichiers modifiés pour vous ?
