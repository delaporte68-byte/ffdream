# 🎮 FFdreame v3.6 - Types séparés Fantasy & Cyberpunk

## ✅ NOUVEAU SYSTÈME DE TYPES

Maintenant vous avez **3 types d'Actors différents** :
1. 📜 **Character** → Fiche Fantasy (médiévale)
2. 🌃 **Cyberpunk** → Fiche Cyberpunk (futuriste)
3. 📊 **GM Tracker** → Suivi des joueurs (MJ uniquement)

---

## 🚀 Comment créer un personnage ?

### Méthode simple :

1. **Créer un Actor**
2. **Choisir le TYPE** :
   - **Character** = Style Fantasy 📜
   - **Cyberpunk** = Style Cyberpunk 🌃
3. **Valider**
4. La fiche s'ouvre avec le bon style ! ✨

---

## 📊 Les 3 types en détail

### 📜 Type "Character" (Fantasy)

**Apparence :** Style médiéval classique
- Fond parchemin
- Couleurs or et cyan
- Design élégant

**Utilisation :**
- Campagnes fantasy
- Univers médiévaux
- Ambiance classique

**Création :**
```
Créer Actor → Type: Character
```

---

### 🌃 Type "Cyberpunk"

**Apparence :** Style futuriste néon
- Fond noir profond
- Couleurs néon (cyan, magenta, jaune)
- Effets lumineux et animations
- Design ultra-moderne

**Utilisation :**
- Campagnes cyberpunk
- Univers science-fiction
- Ambiance futuriste

**Création :**
```
Créer Actor → Type: Cyberpunk
```

---

### 📊 Type "GM Tracker"

**Apparence :** Dashboard de suivi
- Liste de tous les joueurs
- PV/PM en temps réel
- Points d'action
- Codes couleur de santé

**Utilisation :**
- Suivi du combat (MJ)
- Vue d'ensemble des joueurs

**Création :**
```
Créer Actor → Type: GM Tracker
```

---

## 🎯 Fonctionnalités identiques

**IMPORTANT :** Les deux types (Character et Cyberpunk) ont **EXACTEMENT** les mêmes fonctionnalités :
- ✅ Même système de compétences
- ✅ Même système d'aptitudes
- ✅ Même système de combat
- ✅ Mêmes calculs
- ✅ Mêmes formules
- ✅ Burste + Postures + Techniques
- ✅ Fatigue + Blessures
- ✅ Points d'action

**Seule différence :** L'apparence visuelle ! 🎨

---

## 🔄 Conversion d'un personnage

Si vous avez un personnage "Character" et voulez le passer en "Cyberpunk" :

### Méthode manuelle (recommandée) :

1. **Ouvrir** la fiche du personnage Character
2. **Copier** toutes les valeurs (compétences, aptitudes, etc.)
3. **Créer** un nouvel Actor type **Cyberpunk**
4. **Coller** toutes les valeurs
5. **Glisser** les postures et techniques dans le nouveau
6. **Supprimer** l'ancien si nécessaire

### Pourquoi pas automatique ?
Foundry ne permet pas de changer le type d'un Actor existant facilement. La conversion manuelle est plus sûre.

---

## 📦 Compatibilité Items

**Les Items sont compatibles avec tous les types !**

- ✅ Les **Postures** créées fonctionnent sur Character ET Cyberpunk
- ✅ Les **Techniques** créées fonctionnent sur Character ET Cyberpunk
- ✅ Les **Talents** créés fonctionnent sur Character ET Cyberpunk
- ✅ Les **Équipements** créés fonctionnent sur Character ET Cyberpunk

**Vous pouvez glisser-déposer les mêmes Items sur les deux types !**

---

## 🎨 Quand utiliser quel type ?

### Utilisez "Character" (Fantasy) si :
- ✅ Campagne médiévale fantasy
- ✅ Univers classique
- ✅ Préférence pour un style sobre
- ✅ Vous aimez le parchemin

### Utilisez "Cyberpunk" si :
- ✅ Campagne science-fiction
- ✅ Univers futuriste
- ✅ Vous aimez les néons et animations
- ✅ Vous voulez un style moderne

### Mix des deux :
**Possible !** Vous pouvez avoir :
- 2 joueurs en "Character"
- 2 joueurs en "Cyberpunk"
- Dans la même partie !

Chacun choisit son style préféré 😊

---

## 🔧 Technique : Comment ça marche ?

### Avant (v3.5) :
- 1 seul type "character"
- Champ "styleSheet" pour choisir
- Template dynamique (compliqué)

### Maintenant (v3.6) :
- 2 types séparés "character" et "cyberpunk"
- Chaque type a son propre template
- Plus simple et plus clair !

---

## 📝 Exemples de création

### Créer un guerrier fantasy :
```
1. Créer Actor
2. Type: Character
3. Nom: "Thorgar le Brave"
4. Ouvrir → Style Fantasy automatique
```

### Créer un hacker cyberpunk :
```
1. Créer Actor
2. Type: Cyberpunk
3. Nom: "Neon-7"
4. Ouvrir → Style Cyberpunk automatique
```

### Créer le tracker MJ :
```
1. Créer Actor
2. Type: GM Tracker
3. Nom: "Suivi Combat"
4. Ouvrir → Dashboard MJ
```

---

## ⚠️ Notes importantes

### GM Tracker
- Affiche les personnages de **type "character" ET "cyberpunk"**
- Mise à jour automatique en temps réel
- Codes couleur fonctionnent pour tous

### Migrations
- Vos anciens personnages v3.5 restent en type "character"
- Ils fonctionnent normalement
- Pas besoin de les recréer

### Nouveaux joueurs
- Demandez-leur quel style ils préfèrent
- Créez le bon type dès le départ
- Plus simple que de convertir après

---

## 🎯 Résumé rapide

| Type | Apparence | Quand l'utiliser |
|------|-----------|------------------|
| 📜 **Character** | Fantasy | Campagnes médiévales |
| 🌃 **Cyberpunk** | Futuriste | Campagnes SF |
| 📊 **GM Tracker** | Dashboard | Suivi combat (MJ) |

**Tous utilisent le même système de jeu !** 🎲

---

**Version :** 3.6  
**Système :** Types séparés  
**Compatibilité :** Foundry VTT v13  

Bonne partie ! 🎮✨
