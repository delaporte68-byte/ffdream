# 🔧 Changements Appliqués - FFdreame v1.1

## 📅 Date : 15 Février 2026

---

## 📝 Fichiers Modifiés

### 1. `templates/item/technique-sheet-v2.html`
**Ligne modifiée :** 68-70

**Avant :**
```html
<option value="cur" {{#if (eq system.style "cur")}}selected{{/if}}>❤️ CUR - Soins (Base uniquement)</option>
<option value="aoe" {{#if (eq system.style "aoe")}}selected{{/if}}>🌀 AOE - 3 jets consécutifs (60→50→40, dégâts cumulés)</option>
```

**Après :**
```html
<option value="cur" {{#if (eq system.style "cur")}}selected{{/if}}>❤️ CUR - Soins (Base uniquement, sans jet)</option>
<option value="tp" {{#if (eq system.style "tp")}}selected{{/if}}>🚀 TP - Téléportation (Déplacement instantané, sans jet)</option>
<option value="aoe" {{#if (eq system.style "aoe")}}selected{{/if}}>🌀 AOE - 3 jets consécutifs (60→50→40, dégâts cumulés)</option>
```

**Raison :**
- Ajout d'un nouveau style "TP" pour les techniques de téléportation pure
- Précision que le style "CUR" ne nécessite pas de jet de dés

---

### 2. `module/sheets/actor-sheet.js`

#### Modification 1 : Ajout des cas spéciaux (après ligne 1331)

**Avant :**
```javascript
// ===== STYLE AOER : Zone retardée =====
if (style === "aoer") {
  await this._useTechniqueAOER(technique);
  return;
}

// STYLE ULTIM : Vérifier Burste = 100
```

**Après :**
```javascript
// ===== STYLE AOER : Zone retardée =====
if (style === "aoer") {
  await this._useTechniqueAOER(technique);
  return;
}

// ===== STYLE CUR : Soins automatiques (pas de jet) =====
if (style === "cur") {
  await this._useTechniqueSoins(technique);
  return;
}

// ===== STYLE TP : Téléportation automatique (pas de jet) =====
if (style === "tp") {
  await this._useTechniqueTeleportation(technique);
  return;
}

// STYLE ULTIM : Vérifier Burste = 100
```

**Raison :**
- Les styles "CUR" et "TP" sont maintenant traités AVANT le jet de dés
- Ils fonctionnent automatiquement sans nécessiter de réussite

---

#### Modification 2 : Ajout de deux nouvelles fonctions (après ligne 1481)

**Nouvelles fonctions ajoutées :**

1. **`_useTechniqueSoins(technique)`**
   - Gère les techniques de soins automatiques
   - Applique les soins sans jet de dés
   - Consomme PM et PA
   - Augmente la Burste de +10
   - Affiche un message de chat stylisé

2. **`_useTechniqueTeleportation(technique)`**
   - Gère les techniques de téléportation automatique
   - Effectue la téléportation sans jet de dés
   - Consomme PM et PA (ou les restitue si annulé)
   - Augmente la Burste de +10
   - Affiche un message de chat stylisé

**Raison :**
- Séparation de la logique pour plus de clarté
- Les soins et téléportations ne devraient pas nécessiter de jet de chance
- Meilleure maintenabilité du code

---

## 🎯 Fonctionnalités Ajoutées

### 1. Soins Automatiques (Style CUR)
- ✅ Pas de jet de dés nécessaire
- ✅ Soins appliqués immédiatement
- ✅ Peut cibler soi-même ou un allié
- ✅ Respecte le maximum de PV
- ✅ Consomme PM et PA normalement
- ✅ Augmente la Burste

### 2. Téléportation Automatique (Style TP)
- ✅ Pas de jet de dés nécessaire
- ✅ Téléportation immédiate
- ✅ Utilise le système de téléportation existant
- ✅ Restitue les PA si annulé
- ✅ Consomme PM et PA normalement
- ✅ Augmente la Burste

---

## 🔍 Comportements Conservés

### Ce qui n'a PAS changé :

1. **Système de tableaux**
   - Déjà fonctionnel, aucune modification nécessaire
   - Les deux tableaux ne peuvent toujours pas être actifs simultanément

2. **Autres styles de techniques**
   - CAC, MAG, PUI, ATTA, ATTM, ULTIM, etc. fonctionnent toujours pareil
   - Aucun impact sur les techniques existantes

3. **Système de combat**
   - PA, PM, Burste, Réactions : tout fonctionne pareil
   - Aucun changement dans la logique de combat

---

## ⚠️ Points d'Attention

### Pour les utilisateurs :

1. **Techniques de soins existantes**
   - Si vos techniques de soins avaient un autre style, re-configurez-les en "CUR"
   - Les anciennes techniques continueront de fonctionner avec l'ancien système

2. **Techniques de téléportation**
   - Le nouveau style "TP" est pour la téléportation PURE (sans dégâts)
   - Pour les techniques avec téléportation ET dégâts, gardez l'ancien système

3. **Compatibilité**
   - Ces changements sont rétro-compatibles
   - Aucune migration de données nécessaire

---

## 📊 Statistiques

- **Lignes de code ajoutées :** ~300
- **Fichiers modifiés :** 2
- **Nouvelles fonctions :** 2
- **Nouveaux styles :** 1 (TP)
- **Bugs corrigés :** 2 (soins + téléportation)

---

## 🐛 Bugs Résolus

1. ✅ Les techniques de soins (style CUR) ne fonctionnaient pas
   - **Cause :** Traitement avec jet de dés alors qu'elles devraient être automatiques
   - **Solution :** Traitement spécial avant le jet de dés

2. ✅ Les techniques de téléportation ne fonctionnaient pas
   - **Cause :** Traitement après un jet de dés réussi
   - **Solution :** Nouveau style "TP" traité avant le jet de dés

---

## 📈 Version

- **Version précédente :** 1.0
- **Version actuelle :** 1.1
- **Type de mise à jour :** Correctif + Amélioration

---

## 🔜 Améliorations Futures Suggérées

1. Ajouter un style "BUFF" pour les buffs automatiques (sans jet)
2. Ajouter un style "DEBUFF" pour les debuffs automatiques (sans jet)
3. Améliorer la gestion des soins de zone (AOE + CUR)
4. Ajouter des animations spécifiques pour les soins et téléportations

---

**Fin du document**
