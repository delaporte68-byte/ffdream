# 🎬 GUIDE - Onglet Animation dans la Fiche Technique

## ✨ Accès rapide

1. Créez ou modifiez une **Technique**
2. Cliquez sur l'onglet **"🎬 Animation"**
3. Cochez **"Activer l'animation"**
4. Choisissez votre animation dans le dropdown
5. Ajustez les options si besoin
6. Sauvegardez !

**C'est tout !** L'animation se jouera automatiquement quand la technique réussit. ✅

---

## 📋 Interface complète

### 1. Activation
```
☐ 🎬 Activer l'animation
```
Cochez pour activer le système d'animations.

### 2. Choix de l'animation

**Bibliothèque** : JB2A Free (2D) ou Eski Effect Free (3D)

**Animation** : Menu déroulant organisé par catégories :

#### 🏹 Projectiles (JB2A)
- 🔥 Trait de feu (orange/bleu)
- ❄️ Rayon de givre
- ⚡ Éclair (étroit/large)
- ✨ Missile magique
- 🔥 Rayon scorchant
- 🧪 Projectile d'acide
- 🏹 Flèche
- 💥 Projectile (orange)

#### 💥 Explosions (JB2A)
- 🔥 Boule de feu (beam)
- 💥 Explosion (orange/bleu/vert)
- 💢 Impact au sol
- 🔥 Impact de feu
- ⚡ Onde de choc (bleu)
- 🪨 Impact de rocher

#### ⚔️ Corps à corps (JB2A)
- ⚔️ Slash
- 🔨 Coup contondant
- 🗡️ Piqûre
- 🥊 Déluge de coups

#### 💚 Soins & Buffs (JB2A)
- 💚 Soin (vert/orange)
- 💙 Soin (bleu)
- 🛡️ Bouclier (bleu)
- 🛡️ Bouclier 2 (bleu)
- ✨ Bénédiction
- ⚡ Champ d'énergie

#### 🌀 Zones d'effet (JB2A)
- 🧊 Pics de glace (radial)
- 🔥 Mur de feu
- 🌨️ Tempête de grêle
- ☁️ Nuage de brouillard
- 🔥 Souffle de feu (cône)

#### 💀 Nécromancie (JB2A)
- 💀 Glas funèbre
- ⚡ Drainement d'énergie
- 🌀 Aura sombre

#### 🎆 Projectiles 3D (Eski)
- 🔮 Orbe d'énergie (bleu)
- 💡 Rayon de lumière
- 🔥 Projectile de feu 3D

#### 💥 Explosions 3D (Eski)
- 💥 Explosion magique 3D (bleu)
- 🔥 Explosion de feu 3D

#### ✨ Buffs 3D (Eski)
- 🛡️ Bouclier 3D
- 💚 Soin divin 3D

### 3. Aperçu du chemin

Affiche le chemin technique de l'animation sélectionnée :
```
Chemin: jb2a.fireball.beam.orange
```

---

## ⚙️ Personnalisation

### Type d'animation
- 🏹 **Projectile** - Pour les sorts qui volent (traits, flèches)
- 💥 **Explosion** - Pour les impacts et explosions
- ⚔️ **Corps à corps** - Pour les attaques mêlée
- 🛡️ **Buff** - Pour les boucliers et protections
- 💚 **Soin** - Pour les soins
- 🌀 **Zone** - Pour les zones d'effet persistantes

**Le type détermine comment l'animation se comporte !**

### Taille (scale)
- `0.5` = 50% (petit)
- `1.0` = 100% (normal) ← Par défaut
- `1.5` = 150% (grand)
- `2.0` = 200% (très grand)
- `3.0` = 300% (énorme pour ultimates)

**Recommandations** :
- Projectiles simples : `0.7 - 0.9`
- Explosions : `1.0 - 1.5`
- Multi-cibles : `1.2 - 2.0`
- Ultimates : `2.0 - 3.0`

### Durée (ms)
- `500` = 0.5 seconde (rapide)
- `1000` = 1 seconde (normal) ← Par défaut
- `1500` = 1.5 secondes
- `2000` = 2 secondes (lent)

**Recommandations** :
- Attaques rapides : `500 - 800`
- Sorts normaux : `1000 - 1500`
- Explosions : `1500 - 2000`
- Buffs/soins : `2000 - 3000`

### Délai (ms)
Temps d'attente avant que l'animation démarre.
- `0` = Immédiat ← Par défaut
- `100-500` = Petit délai
- `1000+` = Grand délai

Utile pour synchroniser plusieurs animations.

### Opacité
- `0.0` = Transparent (invisible)
- `0.5` = Semi-transparent
- `1.0` = Opaque ← Par défaut

### Répétitions
- `1` = Une fois ← Par défaut
- `2-3` = Plusieurs fois
- `5+` = Effet de loop

Utile pour les buffs qui persistent.

---

## 🎯 Options de ciblage

### ☑ Étirer vers la cible
**Pour : Projectiles**

Fait "étirer" l'animation du lanceur vers la cible.

**Exemple** : Une flèche qui part du personnage et atteint l'ennemi.

✅ **Activez pour** : Traits de feu, flèches, éclairs
❌ **Désactivez pour** : Explosions, soins, buffs

### ☑ Attacher à la cible
**Pour : Buffs et Soins**

Fait "coller" l'animation sur la cible.

**Exemple** : Un bouclier qui reste sur le personnage.

✅ **Activez pour** : Boucliers, soins, buffs
❌ **Désactivez pour** : Projectiles, explosions

### ☑ Se déplacer vers
**Avancé** - L'animation se déplace vers la cible.

Rarement utilisé.

### ☑ Téléporter à la fin
**Avancé** - Le token se téléporte à la fin de l'animation.

Rarement utilisé.

---

## 💡 Exemples de configuration

### Exemple 1 : Boule de feu (MULTI)

```
✓ Activer l'animation
Bibliothèque : JB2A Free
Animation : 🔥 Boule de feu (beam)

Type : Explosion
Taille : 1.5
Durée : 1500 ms
Délai : 0 ms
Opacité : 1.0
Répétitions : 1

☐ Étirer vers la cible
☐ Attacher à la cible
☐ Se déplacer vers
☐ Téléporter à la fin
```

**Résultat** : Grande explosion de feu qui se joue sur la cible !

---

### Exemple 2 : Trait de feu (ATTM)

```
✓ Activer l'animation
Bibliothèque : JB2A Free
Animation : 🔥 Trait de feu (orange)

Type : Projectile
Taille : 0.8
Durée : 1000 ms
Délai : 0 ms
Opacité : 1.0
Répétitions : 1

☑ Étirer vers la cible ← IMPORTANT !
☐ Attacher à la cible
☐ Se déplacer vers
☐ Téléporter à la fin
```

**Résultat** : Projectile de feu qui vole du lanceur vers la cible !

---

### Exemple 3 : Soin (CUR)

```
✓ Activer l'animation
Bibliothèque : JB2A Free
Animation : 💚 Soin (vert/orange)

Type : Soin
Taille : 1.0
Durée : 2000 ms
Délai : 0 ms
Opacité : 1.0
Répétitions : 1

☐ Étirer vers la cible
☑ Attacher à la cible ← IMPORTANT !
☐ Se déplacer vers
☐ Téléporter à la fin
```

**Résultat** : Effet de soin qui apparaît sur la cible et dure 2 secondes !

---

### Exemple 4 : Slash (ATTA)

```
✓ Activer l'animation
Bibliothèque : JB2A Free
Animation : ⚔️ Slash

Type : Corps à corps
Taille : 1.0
Durée : 800 ms
Délai : 0 ms
Opacité : 1.0
Répétitions : 1

☐ Étirer vers la cible
☐ Attacher à la cible
☐ Se déplacer vers
☐ Téléporter à la fin
```

**Résultat** : Animation de slash rapide !

---

### Exemple 5 : Explosion 3D (Eski - MULTI)

```
✓ Activer l'animation
Bibliothèque : Eski Effect Free
Animation : 💥 Explosion magique 3D (bleu)

Type : Explosion
Taille : 2.0 ← Plus grande !
Durée : 1800 ms
Délai : 0 ms
Opacité : 1.0
Répétitions : 1

☐ Étirer vers la cible
☐ Attacher à la cible
☐ Se déplacer vers
☐ Téléporter à la fin
```

**Résultat** : Magnifique explosion 3D sur la zone ciblée !

---

## 📦 Modules requis

### Obligatoire
- ✅ **Sequencer** - Gestionnaire d'animations
  - https://foundryvtt.com/packages/sequencer

### Au moins un des deux
- 🎨 **JB2A Free** - Animations 2D gratuites
  - https://foundryvtt.com/packages/JB2A_DnD5e

- 🌟 **Eski Effect Free** - Animations 3D gratuites
  - https://foundryvtt.com/packages/eskieffects-free

**Sans ces modules, les animations ne fonctionneront pas.**

---

## 🎮 Fonctionnement en jeu

### Déclenchement automatique

L'animation se joue **automatiquement** quand :
1. Vous utilisez la technique
2. Le jet de dés **réussit**
3. L'animation est **activée**

**Aucune action manuelle requise !**

### Ordre des événements

```
1. Clic sur la technique
2. Jet de dés → Réussite ✓
3. 🎬 Animation se joue
4. 💥 Dégâts appliqués
5. Message dans le chat
```

---

## 🐛 Dépannage

### L'animation ne se joue pas

**Vérifications** :
1. ✅ Animation activée ?
2. ✅ Module Sequencer installé et activé ?
3. ✅ Module JB2A ou Eski installé et activé ?
4. ✅ Chemin d'animation correct ?
5. ✅ La technique a réussi (jet de dés) ?

### Message d'erreur "could not find file"

**Cause** : Le chemin de l'animation est incorrect.

**Solution** : Utilisez le dropdown pour choisir l'animation au lieu de taper manuellement.

### Animation trop petite/grande

**Solution** : Ajustez le paramètre **Taille (scale)**.

### Animation trop rapide/lente

**Solution** : Ajustez le paramètre **Durée (ms)**.

### Le projectile ne va pas vers la cible

**Solution** : Cochez **"Étirer vers la cible"** pour les projectiles.

### Le buff ne reste pas sur le personnage

**Solution** : Cochez **"Attacher à la cible"** pour les buffs/soins.

---

## 💡 Tips & Astuces

### Combiner Type + Ciblage

Pour les meilleurs résultats :

| Type | Étirer ? | Attacher ? |
|------|----------|------------|
| Projectile | ✅ Oui | ❌ Non |
| Explosion | ❌ Non | ❌ Non |
| Melee | ❌ Non | ❌ Non |
| Buff | ❌ Non | ✅ Oui |
| Soin | ❌ Non | ✅ Oui |
| Zone | ❌ Non | ❌ Non |

### Tailles recommandées par style

- **ATTA** (Corps à corps) : 0.8 - 1.0
- **ATTM** (Magie) : 0.7 - 1.2
- **MULTI** (Zone) : 1.2 - 2.0
- **ULTIM** (Ultimate) : 2.0 - 3.0
- **CUR** (Soin) : 1.0 - 1.5
- **DEF** (Défense) : 1.0 - 1.3

### Durées recommandées

- **Rapide** : 500-800 ms
- **Normal** : 1000-1500 ms
- **Lent** : 1500-2000 ms
- **Très lent** : 2000-3000 ms

---

## 🎨 Créativité

N'hésitez pas à expérimenter ! Vous pouvez :

- Utiliser une animation d'explosion pour un coup de poing
- Mettre un effet de soin sur une attaque vampirique
- Combiner plusieurs répétitions pour un effet continu
- Jouer avec l'opacité pour des effets fantomatiques

**Il n'y a pas de règles strictes - amusez-vous !** 🎉

---

**Version** : Onglet Animation intégré  
**Date** : Février 2026  
**Modules requis** : Sequencer + (JB2A ou Eski)
