# Corrections FFdreame System

## Problèmes identifiés

### 1. ✅ Tableaux simultanés (DÉJÀ CORRIGÉ)
**Statut:** Le système possède déjà la logique pour empêcher l'activation simultanée des deux tableaux.

**Localisation:** `module/sheets/actor-sheet.js`, fonction `_onToggleTableau()` (lignes 591-708)

**Comportement actuel:**
- Quand Tableau 1 est actif, cliquer dessus affiche "Tableau 1 déjà actif !"
- Quand Tableau 2 est actif, cliquer dessus affiche "Tableau 2 déjà actif !"
- Pour changer de tableau, il faut cliquer sur l'autre tableau (coût: 1 Petit PA en combat)
- Les deux tableaux ne peuvent jamais être actifs en même temps

**Conclusion:** Ce problème est déjà résolu dans le code. Si le joueur rencontre toujours ce problème, il peut s'agir d'un problème de cache du navigateur ou de données corrompues.

---

### 2. ❌ Techniques de SOINS (style "cur") - PAS DE JET DE DÉS
**Problème:** Les techniques de soins ne fonctionnent pas car elles passent par le système de jet normal alors qu'elles devraient être automatiques.

**Localisation:** `module/sheets/actor-sheet.js`, fonction `_useTableTechnique()` (ligne 1266)

**Cause:**
- Le style "cur" (soins) n'est pas traité comme cas spécial au début de la fonction
- Le code des soins (lignes 1652-1673) se trouve dans `if (success)` après un jet de dé
- Mais pour les soins, il ne devrait PAS y avoir de jet de dé
- Les soins devraient être automatiques (pas de chance d'échec)

**Solution:**
Ajouter un traitement spécial pour le style "cur" AVANT le jet de dés, similaire aux styles "chm" et "aoer".

---

### 3. ❌ Techniques de TÉLÉPORTATION - PAS DE JET DE DÉS
**Problème:** Les techniques avec téléportation ne fonctionnent pas.

**Localisation:** `module/sheets/actor-sheet.js`, fonction `_useTableTechnique()` (ligne 1266)

**Cause:**
- La téléportation est gérée aux lignes 1825-1831
- Ce code se trouve dans `if (success)` après un jet de dé réussi
- Mais certaines techniques de téléportation (comme un "dash" ou "blink") devraient être automatiques
- Elles ne devraient pas nécessiter de jet de dé

**Solution:**
Créer un nouveau style "tp" (téléportation) qui sera traité comme cas spécial AVANT le jet de dés.

---

## Corrections à appliquer

### Correction 1: Ajouter le style "tp" pour téléportation dans le template

**Fichier:** `templates/item/technique-sheet-v2.html`

**Ligne 68:** Ajouter après la ligne du style "cur":
```html
<option value="tp" {{#if (eq system.style "tp")}}selected{{/if}}>🚀 TP - Téléportation (Déplacement instantané, sans jet)</option>
```

### Correction 2: Modifier la fonction _useTableTechnique pour traiter "cur" et "tp" comme cas spéciaux

**Fichier:** `module/sheets/actor-sheet.js`

**Après la ligne 1331** (après le traitement de "aoer"), ajouter:

```javascript
    // ===== STYLE CUR : Soins automatiques (pas de jet) =====
    if (style === "cur") {
      await this._useTechniqueSoins(technique);
      return;
    }
    
    // ===== STYLE TP : Téléportation automatique (pas de jet) =====
    if (style === "tp") {
      await this._useTechniqueTeleportation(technique);
      return;
    }
```

### Correction 3: Créer la fonction _useTechniqueSoins

**Fichier:** `module/sheets/actor-sheet.js`

**Ajouter après la fonction _useTableTechnique** (après ligne 1481):

```javascript
  /* ================================
     TECHNIQUE DE SOINS (automatique)
     ================================ */
  async _useTechniqueSoins(technique) {
    // Vérifier si les actions sont bloquées
    const actionBlocked = this.actor.getFlag('ffdreame', 'actionBlocked');
    if (actionBlocked && !game.user.isGM) {
      ui.notifications.warn("🔒 Votre tour est terminé !");
      return;
    }
    
    // Vérifier PM
    const pmActuel = this.actor.system.aptitudes.pm.value;
    const coutPM = technique.system.coutPM || 0;
    
    if (pmActuel < coutPM) {
      ui.notifications.warn(`⚠️ PM insuffisants ! (${pmActuel}/${coutPM})`);
      return;
    }
    
    // Consommer PA
    const coutPA = technique.system.coutPA || "grand";
    const actionPoints = this.actor.system.combat.actionPoints;
    
    if (coutPA === "grand") {
      let grandDispo = null;
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand.petit1 && grand.petit2) {
          grandDispo = i;
          break;
        }
      }
      
      if (!grandDispo) {
        ui.notifications.warn("⚠️ Plus de grands points d'action disponibles !");
        return;
      }
      
      await this.actor.update({
        [`system.combat.actionPoints.grand${grandDispo}.petit1`]: false,
        [`system.combat.actionPoints.grand${grandDispo}.petit2`]: false
      });
      
    } else if (coutPA === "petit") {
      let petitDispo = null;
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand.petit1) {
          petitDispo = { grand: i, petit: 'petit1' };
          break;
        } else if (grand.petit2) {
          petitDispo = { grand: i, petit: 'petit2' };
          break;
        }
      }
      
      if (!petitDispo) {
        ui.notifications.warn("⚠️ Plus de petits points d'action disponibles !");
        return;
      }
      
      await this.actor.update({
        [`system.combat.actionPoints.grand${petitDispo.grand}.${petitDispo.petit}`]: false
      });
    }
    
    // Calculer les soins
    const soinsBase = technique.system.baseDegats || 0;
    const soins = soinsBase;
    
    // Déterminer la cible (cible sélectionnée ou soi-même)
    const targets = Array.from(game.user.targets);
    const cible = targets.length > 0 ? targets[0].actor : this.actor;
    
    const pvActuel = cible.system.aptitudes.pv.value;
    const pvMax = cible.system.aptitudes.pv.max;
    const nouveauPV = Math.min(pvMax, pvActuel + soins);
    
    // Appliquer les soins
    await cible.update({
      'system.aptitudes.pv.value': nouveauPV
    });
    
    // Consommer PM
    await this.actor.update({
      'system.aptitudes.pm.value': pmActuel - coutPM
    });
    
    // Message de soins
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      flavor: `<h3>❤️ ${technique.name}</h3>
               <p>Style: CUR (Soins) | Coût: ${coutPM} PM</p>`,
      content: `<div style="background: rgba(76, 175, 80, 0.2); padding: 10px; border-left: 3px solid #4CAF50;">
                  <strong>❤️ ${cible.name}</strong> a reçu <strong>${soins} soins</strong> !
                  <br/>PV: ${pvActuel}/${pvMax} → ${nouveauPV}/${pvMax}
                </div>`
    });
    
    ui.notifications.info(`❤️ +${soins} PV pour ${cible.name}`);
    
    // Jouer l'animation si présente
    await this._jouerAnimationItem(technique);
    
    // Incrémenter compteur effet et Burste
    await this._incrementerCompteurEffet();
    const bursteCurrent = this.actor.system.combat.burste || 0;
    const newBurste = Math.min(100, bursteCurrent + 10);
    await this.actor.update({
      'system.combat.burste': newBurste
    });
    
    if (newBurste === 100) {
      ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
    }
  }
```

### Correction 4: Créer la fonction _useTechniqueTeleportation

**Fichier:** `module/sheets/actor-sheet.js`

**Ajouter après _useTechniqueSoins:**

```javascript
  /* ================================
     TECHNIQUE DE TÉLÉPORTATION (automatique)
     ================================ */
  async _useTechniqueTeleportation(technique) {
    // Vérifier si les actions sont bloquées
    const actionBlocked = this.actor.getFlag('ffdreame', 'actionBlocked');
    if (actionBlocked && !game.user.isGM) {
      ui.notifications.warn("🔒 Votre tour est terminé !");
      return;
    }
    
    // Vérifier si le système de téléportation est disponible
    if (!window.FFdreameTeleportation?.isTeleportationEnabled(technique)) {
      ui.notifications.warn("⚠️ Téléportation non configurée pour cette technique !");
      return;
    }
    
    // Vérifier PM
    const pmActuel = this.actor.system.aptitudes.pm.value;
    const coutPM = technique.system.coutPM || 0;
    
    if (pmActuel < coutPM) {
      ui.notifications.warn(`⚠️ PM insuffisants ! (${pmActuel}/${coutPM})`);
      return;
    }
    
    // Consommer PA
    const coutPA = technique.system.coutPA || "grand";
    const actionPoints = this.actor.system.combat.actionPoints;
    
    if (coutPA === "grand") {
      let grandDispo = null;
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand.petit1 && grand.petit2) {
          grandDispo = i;
          break;
        }
      }
      
      if (!grandDispo) {
        ui.notifications.warn("⚠️ Plus de grands points d'action disponibles !");
        return;
      }
      
      await this.actor.update({
        [`system.combat.actionPoints.grand${grandDispo}.petit1`]: false,
        [`system.combat.actionPoints.grand${grandDispo}.petit2`]: false
      });
      
    } else if (coutPA === "petit") {
      let petitDispo = null;
      for (let i = 1; i <= 3; i++) {
        const grand = actionPoints[`grand${i}`];
        if (grand.petit1) {
          petitDispo = { grand: i, petit: 'petit1' };
          break;
        } else if (grand.petit2) {
          petitDispo = { grand: i, petit: 'petit2' };
          break;
        }
      }
      
      if (!petitDispo) {
        ui.notifications.warn("⚠️ Plus de petits points d'action disponibles !");
        return;
      }
      
      await this.actor.update({
        [`system.combat.actionPoints.grand${petitDispo.grand}.${petitDispo.petit}`]: false
      });
    }
    
    // Obtenir la cible ou le point de téléportation
    const targets = Array.from(game.user.targets);
    const targetToken = targets.length > 0 ? targets[0] : null;
    
    // Récupérer la config de téléportation
    const teleportConfig = window.FFdreameTeleportation.getTeleportationConfig(technique);
    
    // Effectuer la téléportation
    const success = await window.FFdreameTeleportation.handleTeleportation(
      this.actor, 
      targetToken, 
      teleportConfig
    );
    
    if (!success) {
      // La téléportation a échoué (annulée ou hors portée)
      // Ne pas consommer les ressources - restituer les PA
      ui.notifications.warn("⚠️ Téléportation annulée");
      
      // Restituer les PA consommés
      if (coutPA === "grand") {
        let grandDispo = null;
        for (let i = 1; i <= 3; i++) {
          const grand = actionPoints[`grand${i}`];
          if (!grand.petit1 && !grand.petit2) {
            grandDispo = i;
            break;
          }
        }
        if (grandDispo) {
          await this.actor.update({
            [`system.combat.actionPoints.grand${grandDispo}.petit1`]: true,
            [`system.combat.actionPoints.grand${grandDispo}.petit2`]: true
          });
        }
      } else if (coutPA === "petit") {
        for (let i = 1; i <= 3; i++) {
          const grand = actionPoints[`grand${i}`];
          if (!grand.petit1) {
            await this.actor.update({
              [`system.combat.actionPoints.grand${i}.petit1`]: true
            });
            break;
          } else if (!grand.petit2) {
            await this.actor.update({
              [`system.combat.actionPoints.grand${i}.petit2`]: true
            });
            break;
          }
        }
      }
      return;
    }
    
    // Consommer PM
    await this.actor.update({
      'system.aptitudes.pm.value': pmActuel - coutPM
    });
    
    // Message de téléportation
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.actor }),
      flavor: `<h3>🚀 ${technique.name}</h3>
               <p>Style: TP (Téléportation) | Coût: ${coutPM} PM</p>`,
      content: `<div style="background: rgba(0, 217, 255, 0.2); padding: 10px; border-left: 3px solid #00d9ff;">
                  <strong>🚀 ${this.actor.name}</strong> se téléporte !
                </div>`
    });
    
    ui.notifications.info(`🚀 Téléportation réussie !`);
    
    // Jouer l'animation si présente
    await this._jouerAnimationItem(technique);
    
    // Incrémenter compteur effet et Burste
    await this._incrementerCompteurEffet();
    const bursteCurrent = this.actor.system.combat.burste || 0;
    const newBurste = Math.min(100, bursteCurrent + 10);
    await this.actor.update({
      'system.combat.burste': newBurste
    });
    
    if (newBurste === 100) {
      ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
    }
  }
```

---

## Résumé des corrections

1. ✅ **Tableaux simultanés** : Déjà corrigé dans le code
2. ✅ **Soins automatiques** : Nouveau style "cur" traité avant le jet de dés
3. ✅ **Téléportation automatique** : Nouveau style "tp" traité avant le jet de dés

## Instructions d'application

1. Ouvrir `templates/item/technique-sheet-v2.html` et ajouter la ligne du style "tp"
2. Ouvrir `module/sheets/actor-sheet.js` 
3. Ajouter les appels aux nouvelles fonctions dans `_useTableTechnique` (après ligne 1331)
4. Ajouter les deux nouvelles fonctions `_useTechniqueSoins` et `_useTechniqueTeleportation`
5. Tester avec des techniques de soins et de téléportation

## Notes importantes

- Les techniques de soins (style "cur") n'ont plus besoin de jet de dés
- Les techniques de téléportation (style "tp") n'ont plus besoin de jet de dés
- Les deux types de techniques consomment toujours PM et PA
- Les deux types de techniques augmentent la Burste de +10
- La téléportation peut être annulée sans consommer les ressources
