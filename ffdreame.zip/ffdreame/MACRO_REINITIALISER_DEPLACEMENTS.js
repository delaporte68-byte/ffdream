/**
 * ============================================
 * MACRO : RÉINITIALISER LES DÉPLACEMENTS
 * ============================================
 * À utiliser en début de tour pour permettre à tous
 * les personnages de se déplacer à nouveau gratuitement
 */

// Vérifier que le système est chargé
if (!window.FFdreameMovementBlocker) {
  ui.notifications.error("❌ Le système FFdreame n'est pas chargé !");
  return;
}

// Message de confirmation
const confirmDialog = new Dialog({
  title: "Réinitialiser les Déplacements",
  content: `
    <div style="text-align: center; padding: 20px;">
      <h2 style="margin-top: 0;">🔄 Nouveau Tour</h2>
      <p>Voulez-vous réinitialiser les déplacements gratuits de <strong>tous les personnages</strong> ?</p>
      <p style="color: #666; font-size: 0.9em; margin-top: 15px;">
        Cela permettra à chaque personnage de se déplacer à nouveau gratuitement.
      </p>
    </div>
  `,
  buttons: {
    reset: {
      icon: '<i class="fas fa-redo"></i>',
      label: "Réinitialiser Tous",
      callback: async () => {
        await FFdreameMovementBlocker.resetAllMovements();
      }
    },
    cancel: {
      icon: '<i class="fas fa-times"></i>',
      label: "Annuler"
    }
  },
  default: "reset"
}).render(true);
