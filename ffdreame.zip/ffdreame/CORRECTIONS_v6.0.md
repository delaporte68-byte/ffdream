# 🔧 FFdreame v6.0 - CORRECTIONS APPLIQUÉES

## ✅ PROBLÈMES CORRIGÉS

### 1. ✅ **Tableaux désactivés impossibles à réactiver**

**Problème :** Quand on désactivait un tableau, impossible de le réactiver car `pointer-events: none` bloquait tous les clics.

**Solution :**
- Supprimé `pointer-events: none` sur `.interactive-table.table-disabled`
- Ajouté `pointer-events: none` seulement sur `.table-grid-layout`
- **Le bouton toggle reste cliquable** même quand le tableau est désactivé
- Message mis à jour : "🔒 TABLEAU DÉSACTIVÉ - Cliquer sur l'icône pour activer"

**Fichier modifié :** `css/ffdreame.css`

---

### 2. ✅ **Techniques ne consommaient pas de PM/PA et n'ajoutaient pas de Burste**

**Problème :** Les techniques utilisées depuis les tableaux ne consommaient que les PM, mais pas les Grands PA, et n'ajoutaient pas +10 Burste en cas de réussite.

**Solution :**
- Ajout de la vérification des Grands PA disponibles
- Consommation automatique d'1 Grand PA (2 petits PA)
- Ajout de +10 Burste si la technique réussit
- Notification "⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !" quand la jauge atteint 100

**Code ajouté :**
```javascript
// Vérifier grand point d'action disponible
const actionPoints = this.actor.system.combat.actionPoints;
let grandDispo = null;

for (let i = 1; i <= 3; i++) {
  const grand = actionPoints[`grand${i}`];
  if (grand.petit1 && grand.petit2) {
    grandDispo = i;
    break;
  }
}

if (!grandDispo) {
  ui.notifications.warn("⚠️ Plus de grands points d'action disponibles !");
  return;
}

// ... après le jet ...

// Consommer PM et Grand PA
const updateData = {
  'system.aptitudes.pm.value': pmActuel - coutPM,
  [`system.combat.actionPoints.grand${grandDispo}.petit1`]: false,
  [`system.combat.actionPoints.grand${grandDispo}.petit2`]: false
};

// Ajouter Burste +10 si réussite
if (success) {
  const bursteCurrent = this.actor.system.combat.burste || 0;
  const newBurste = Math.min(100, bursteCurrent + 10);
  updateData['system.combat.burste'] = newBurste;
  
  if (newBurste === 100) {
    ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
  }
}

await this.actor.update(updateData);
```

**Fichier modifié :** `module/sheets/actor-sheet.js` (méthode `_useTableTechnique`)

---

### 3. ✅ **Animations ne se lançaient pas**

**Problème :** Les animations liées aux objets (via Sequencer/JB2A) ne se déclenchaient pas lors de l'utilisation des techniques.

**Solution :**
- Création de la méthode `_jouerAnimationItem(item)` dans `actor-sheet.js`
- Appel automatique de cette méthode quand une technique réussit
- Support des animations JB2A et Sequencer personnalisées
- Support de l'animation vers une cible si un token est ciblé
- Si aucune cible : animation sur le lanceur

**Nouvelle méthode ajoutée :**
```javascript
async _jouerAnimationItem(item) {
  // Vérifier si Sequencer est disponible
  if (!game.modules.get("sequencer")?.active) {
    return; // Pas d'animation sans Sequencer
  }

  const token = this.actor.getActiveTokens()[0];
  if (!token) return;

  // Récupérer la cible (premier token ciblé)
  const targets = Array.from(game.user.targets);
  const target = targets[0];

  // Animation JB2A
  if (item.system.animation?.jb2a) {
    const sequence = new Sequence();
    
    if (target) {
      // Animation vers la cible
      sequence
        .effect()
        .file(item.system.animation.jb2a)
        .atLocation(token)
        .stretchTo(target);
    } else {
      // Animation sur le lanceur
      sequence
        .effect()
        .file(item.system.animation.jb2a)
        .atLocation(token);
    }
    
    await sequence.play();
  }

  // Animation Sequencer personnalisée
  if (item.system.animation?.sequencer) {
    const sequence = new Sequence();
    
    if (target) {
      sequence
        .effect()
        .file(item.system.animation.sequencer)
        .atLocation(token)
        .stretchTo(target);
    } else {
      sequence
        .effect()
        .file(item.system.animation.sequencer)
        .atLocation(token);
    }
    
    await sequence.play();
  }
}
```

**Fichier modifié :** `module/sheets/actor-sheet.js`

---

## ⚠️ PROBLÈME NON RÉSOLU

### 4. **Dégâts affichent 0 même quand le jet réussit**

**État :** Non résolu dans cette version

**Cause possible :**
- Les valeurs `atq` (attaque) et `pm` (puissance magique) sont peut-être à 0
- OU le problème vient de l'affichage dans le chat
- OU les dégâts ne sont pas appliqués à la cible

**Code actuel de calcul :**
```javascript
_calculateTechniqueDegats(technique) {
  const atq = this.system.aptitudes.attaque.total || 0;
  const pm = this.system.aptitudes.puissanceMagique.total || 0;
  const base = technique.system.baseDegats || 0;
  const style = technique.system.style;
  
  switch(style) {
    case 'cac': return atq + Math.floor(pm / 2) + base;
    case 'mg': return Math.floor(atq / 2) + pm + base;
    case 'p': return atq + pm + base;
    case 'eha': return atq + base;
    case 'ehm': return pm + base;
    case 'ef': return pm + base + Math.floor(atq / 2);
    case 'buff': return technique.system.buffValue || 0;
    default: return base;
  }
}
```

**Action à faire :**
1. Vérifier que `system.aptitudes.attaque.total` et `system.aptitudes.puissanceMagique.total` sont bien renseignés
2. Vérifier que `technique.system.baseDegats` existe
3. Debug avec `console.log` pour voir les valeurs

---

## 📊 RÉCAPITULATIF

| Problème | État | Fichier modifié |
|----------|------|-----------------|
| Tableaux non réactivables | ✅ CORRIGÉ | css/ffdreame.css |
| PM/PA/Burste non consommés | ✅ CORRIGÉ | module/sheets/actor-sheet.js |
| Animations ne marchent pas | ✅ CORRIGÉ | module/sheets/actor-sheet.js |
| Dégâts affichent 0 | ⚠️ À INVESTIGUER | - |

---

## 🎮 COMMENT TESTER

### Test 1 : Réactivation des tableaux
1. Ouvrir une fiche personnage
2. Onglet Combat
3. Cliquer sur l'icône toggle d'un tableau pour le désactiver
4. **Cliquer à nouveau sur l'icône** → Le tableau se réactive ✅

### Test 2 : Consommation PM/PA/Burste
1. Placer une technique dans un slot de tableau
2. S'assurer d'avoir des PM et des Grands PA
3. Cliquer sur la technique
4. Vérifier :
   - PM diminués ✅
   - 1 Grand PA consommé (2 petits) ✅
   - Burste +10 si réussite ✅

### Test 3 : Animations
1. Installer et activer le module **Sequencer**
2. Créer une technique avec un champ `animation.jb2a` ou `animation.sequencer`
3. Utiliser la technique
4. L'animation se joue ✅

---

## 🚀 PROCHAINES ÉTAPES

1. **Investiguer** le problème des dégâts à 0
2. **Ajouter** l'application automatique des dégâts à la cible
3. **Optimiser** les animations pour supporter plus de types

---

**Version :** 6.0  
**Date :** 5 février 2026  
**Correctifs :** 3/4 appliqués
