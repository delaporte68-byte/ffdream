# FFdreame - Système pour Foundry VTT v13

## 📋 Description

FFdreame est un système de JDR cyberpunk-fantasy conçu pour Foundry Virtual Tabletop version 13. Il propose un système de personnage avec des compétences, aptitudes, rangs et niveaux, avec des calculs automatiques et une interface moderne.

## 🎨 Caractéristiques

- **Interface Cyberpunk/Fantasy** : Design inspiré des circuits et néons
- **Système de Rangs** : De F à SS avec modificateurs progressifs
- **Calculs Automatiques** : Toutes les aptitudes sont calculées automatiquement
- **3 Onglets** : Principal, Combat, Équipement
- **Gestion des Permissions** : Certains champs modifiables uniquement par le MJ
- **Jets de Compétences** : Cliquez sur une compétence pour lancer un jet

## 📦 Installation

### Méthode 1 : Installation Manuelle

1. Téléchargez le dossier `ffdreame-system`
2. Placez-le dans le dossier `Data/systems/` de votre installation Foundry VTT
3. Renommez le dossier en `ffdreame` (sans "-system")
4. Redémarrez Foundry VTT
5. Créez un nouveau monde en sélectionnant "FFdreame" comme système de jeu

### Méthode 2 : Installation via Manifest (si disponible)

1. Dans Foundry VTT, allez dans "Configuration des systèmes de jeu"
2. Cliquez sur "Installer un système"
3. Collez l'URL du manifest : `[URL à définir]`
4. Cliquez sur "Installer"

## 🎮 Utilisation

### Création de Personnage

1. Créez un nouvel acteur de type "Personnage"
2. Le MJ définit le **Niveau** et le **Rang** du personnage
3. Le joueur distribue ses points de compétences
4. Les aptitudes se calculent automatiquement

### Système de Rangs

| Rang | Jet de Réussite | Points Compétences | Multiplicateur Aptitudes |
|------|----------------|-------------------|------------------------|
| F    | 40             | 0                 | ×1                     |
| D    | 45             | 5                 | ×1                     |
| C    | 50             | 5                 | ×1.2                   |
| B    | 55             | 10                | ×1.5                   |
| A    | 60             | 5                 | ×1.7                   |
| S    | 60             | 10                | ×2                     |
| SS   | 65             | 5                 | ×2                     |

### Compétences

#### Physique
- **Force** : Ajoute à l'Attaque, jets de force
- **Endurance** : Calcule les PV (×100)
- **Athlétisme** : Jets de course, défis physiques

#### Dextérité
- **Furtivité** : Jets de discrétion
- **Agilité** : Ajoute à l'Attaque
- **Perception** : Ajoute à l'Attaque, jets de perception

#### Intelligence
- **Culture** : Ajoute aux dégâts magiques
- **Magie** : Calcule les PM (×100), ajoute à la Puissance Magique
- **Volonté** : Ajoute aux PV et PM (×10)

#### Charisme
- **Intimidation** : Jets d'intimidation
- **Psychologie** : Ajoute à la Puissance Magique
- **Persuasion** : Jets de persuasion

### Bonus de Compétences

- **Niveau 5** : +1d6 aux jets liés à cette compétence
- **Niveau 10** : +2d6 aux jets liés à cette compétence

### Aptitudes (Calculs Automatiques)

#### Attaque
```
Base + Force + Agilité + Perception × Multiplicateur de Rang
```

#### Puissance Magique
```
Base + Culture + Magie + Psychologie × Multiplicateur de Rang
```

#### Points de Vie (PV)
```
Base + (Volonté × 10) + (Endurance × 100)
```

#### Points Magiques (PM)
```
Base + (Magie × 100) + (Volonté × 10)
```

### Jets de Compétence

1. **Cliquez** sur une ligne de compétence dans la fiche
2. Le système lance automatiquement : `1d100 + bonus`
3. Compare le résultat au seuil de réussite du rang
4. Affiche le résultat dans le chat

### Permissions

- **Joueurs** : Peuvent modifier leurs compétences et gérer leurs PV/PM actuels
- **MJ uniquement** : Niveau, Rang, Bases des aptitudes

## 🗂️ Structure des Fichiers

```
ffdreame/
├── system.json                 # Configuration du système
├── template.json              # Structure des données
├── css/
│   └── ffdreame.css          # Styles cyberpunk/fantasy
├── lang/
│   └── fr.json               # Traductions françaises
├── module/
│   ├── ffdreame.js           # Fichier principal
│   ├── documents/
│   │   └── actor.js          # Logique des acteurs
│   └── sheets/
│       └── actor-sheet.js    # Gestion de la feuille
└── templates/
    └── actor/
        └── character-sheet.html  # Template HTML
```

## 🔧 Configuration des Valeurs de Base

Pour modifier les valeurs de base des aptitudes (définies par le MJ au début de partie) :

1. Ouvrez la fiche de personnage
2. En tant que MJ, modifiez les champs "Base" sous chaque aptitude
3. Les totaux se recalculent automatiquement

### Valeurs recommandées de départ
- **Attaque Base** : 10-20
- **Puissance Magique Base** : 10-20
- **PV Base** : 50-100
- **PM Base** : 50-100

## 🚀 Fonctionnalités à Venir

- [ ] Système de Talents avec effets
- [ ] Techniques de Combat (onglet Combat)
- [ ] Postures de Combat
- [ ] Gestion de l'Inventaire (onglet Équipement)
- [ ] Armes et Armures avec bonus
- [ ] Journal de personnage
- [ ] Gestion de l'expérience

## 🐛 Problèmes Connus

Aucun pour le moment. Signalez les bugs sur le dépôt GitHub.

## 📝 Notes pour le MJ

1. **Attribution des Rangs** : Les rangs sont une progression importante. Ne les montez pas trop vite.
2. **Valeurs de Base** : Ajustez les valeurs de base des aptitudes pour équilibrer votre campagne.
3. **Calculs** : Tous les calculs sont automatiques. Les joueurs ne peuvent pas tricher sur leurs aptitudes.
4. **PV/PM** : Les joueurs peuvent modifier leurs PV/PM actuels, mais pas les maximums.

## 📄 Licence

Ce système est fourni "tel quel" pour usage personnel dans Foundry VTT.

## 👥 Crédits

- **Système** : FFdreame Team
- **Design** : Inspiré du style cyberpunk/fantasy
- **Foundry VTT** : Version 13+

## 📞 Support

Pour toute question ou suggestion :
- Ouvrez une issue sur GitHub
- Contactez l'équipe FFdreame

---

**Version** : 1.0.0  
**Compatible avec** : Foundry VTT v13  
**Dernière mise à jour** : Janvier 2026
