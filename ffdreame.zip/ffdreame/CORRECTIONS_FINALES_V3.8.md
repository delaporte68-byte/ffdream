# 🎮 FFdreame v3.8 - CORRECTIONS FINALES

## Date : 3 Février 2026

---

## ✅ TOUTES LES CORRECTIONS APPLIQUÉES

### 1. ✅ COMPÉTENCES CYBERPUNK - Jets de dés fonctionnels

**PROBLÈME :** Cliquer sur une compétence ne lançait pas de jet de dés

**SOLUTION :**
- Ajout de la classe `.competence-item` aux `.cyber-comp-item`
- Modification de `_onCompetenceRoll()` pour gérer les deux types de fiches
- Ajout de la gestion du span `.cyber-comp-value` (au lieu de input)
- Protection contre le clic sur le bouton + qui ne doit pas lancer de jet

**RÉSULTAT :** Cliquer sur une compétence lance maintenant un jet de d100 avec les bonus de talents actifs

---

### 2. ✅ BOUTON + COMPÉTENCES - Ajout de points fonctionnel

**PROBLÈME :** Le bouton + n'ajoutait pas les points de compétences

**SOLUTION :**
- Ajout de la classe `.btn-plus-competence` aux boutons `.cyber-btn-plus`
- Modification de `_onPlusCompetence()` pour chercher aussi `.cyber-comp-value`
- Gestion du `event.stopPropagation()` pour éviter de lancer le jet en même temps

**RÉSULTAT :** Le bouton + ajoute correctement 1 point et met à jour l'affichage

---

### 3. ✅ INDICATEURS DE BONUS +1d6 / +2d6

**PROBLÈME :** Les indicateurs de bonus n'étaient pas affichés

**SOLUTION :**
Ajout des indicateurs dans le template :
```handlebars
<span class="cyber-bonus-indicator">
  {{#if (gte system.physique.force.value 5)}}+1d6{{/if}}
  {{#if (gte system.physique.force.value 10)}} +2d6{{/if}}
</span>
```

**RÉSULTAT :** Les bonus s'affichent automatiquement à 5 et 10 points de compétence

---

### 4. ✅ SECTION TALENTS COMPLÈTE

**PROBLÈME :** Pas de section talents sur la fiche cyberpunk

**SOLUTION :**
Ajout d'une section talents complète avec :
- 4 cartes de talents
- Checkbox pour activer/désactiver
- Champ nom (éditable)
- Zone description (textarea)
- Sélecteur de type de bonus (+X ou +Xd6)
- Champ valeur du bonus

**STRUCTURE :**
```
┌────────────────────────────────┐
│ [✓] NOM DU TALENT              │
│ Description du talent...       │
│ Bonus : [+X ▼] [5]            │
└────────────────────────────────┘
```

---

### 5. ✅ STATS AUTOUR DU TOKEN SUPPRIMÉES

**PROBLÈME :** Les stats autour du token (ATQ, PM, PV, MANA) prenaient trop de place

**SOLUTION :**
- Suppression des `.cyber-token-stats`
- Simplification du `.cyber-center-panel`
- Token maintenant centré et plus visible

---

### 6. ✅ TOKEN CLIQUABLE (IMAGE)

**PROBLÈME :** Impossible de changer l'image du token sur la fiche cyberpunk

**SOLUTION :**
- **Clic gauche** : Ouvre FilePicker pour changer l'image de l'acteur
- **Clic droit** : Ouvre la configuration du Prototype Token
- Ajout d'un hint visuel au survol
- Effet hover avec scale et glow

**MÉTHODES AJOUTÉES :**
- `_onTokenImageClick()` - Gère le clic gauche
- `_onTokenConfigClick()` - Gère le clic droit

---

### 7. ✅ AFFICHAGE DES POINTS À DISTRIBUER

**PROBLÈME :** On ne voyait pas combien de points restaient

**SOLUTION :**
Ajout d'une section `.cyber-points-distribuer` affichant :
```
┌─────────────────────────────────┐
│  15 / 40                         │
│  Points de compétences          │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│  35 / 50                         │
│  Points d'aptitudes             │
└─────────────────────────────────┘
```

---

## 📊 FONCTIONNEMENT COMPLET

### 🎲 JETS DE COMPÉTENCES

**Comment ça marche :**
1. Cliquer sur une compétence (éviter le bouton +)
2. Le système lance 1d100
3. Ajoute les malus de fatigue/blessures
4. Compare au seuil de réussite selon le rang
5. Ajoute les bonus des talents actifs

**Exemple de jet :**
```
Joueur : Force = 8 (+1d6)
Talent actif : "Musculation" +2d6
Fatigue f6 : +25 au jet

Jet : 1d100 + 25
Bonus dégâts si réussite : +1d6 +2d6 = +3d6
```

---

### ➕ AJOUT DE POINTS

**Points de Compétences :**
- 15 de base au rang F
- +5, +5, +10, +5, +10, +5 en montant les rangs
- Clicker sur + ajoute 1 point
- Maximum = pointsCompetences

**Points d'Aptitudes :**
- Niveau × 5
- Niveau 1 = 5 points
- Niveau 10 = 50 points
- Répartis entre Attaque / PM / PV / Mana

---

### ⭐ TALENTS

**Activation :**
- Cocher la checkbox active le talent
- Les bonus actifs s'appliquent aux jets de compétences

**Types de bonus :**
- **+X** : Ajoute X au résultat du d100 (plus facile à réussir)
- **+Xd6** : Ajoute Xd6 aux dégâts en cas de réussite

**Exemple :**
```
Talent : "Maître d'armes"
Type : +2d6
Actif : ✓

Quand je fais une attaque réussie :
→ Dégâts normaux + 2d6
```

---

## 🖼️ GESTION DU TOKEN

### Changer l'image de l'acteur :
```
1. Clic GAUCHE sur le token
2. FilePicker s'ouvre
3. Choisir une image
4. L'image de la fiche change
```

### Configurer le Prototype Token :
```
1. Clic DROIT sur le token
2. Configuration s'ouvre
3. Régler :
   - Image du token (sur la map)
   - Taille (1×1, 2×2, etc.)
   - Vision
   - Lumières
   - Barres de ressources
```

---

## 📁 FICHIERS MODIFIÉS

### Templates
**`/templates/actor/cyberpunk-character-sheet.html`**
- ✅ Ajout classe `competence-item` aux compétences
- ✅ Ajout indicateurs de bonus (+1d6/+2d6)
- ✅ Ajout section talents complète
- ✅ Simplification du token (suppression des stats autour)
- ✅ Token maintenant cliquable
- ✅ Ajout affichage points à distribuer

### JavaScript
**`/module/sheets/actor-sheet.js`**
- ✅ `activateListeners()` : Ajout `.cyber-comp-item` pour les clics
- ✅ `_onCompetenceRoll()` : Gère les deux types de fiches
- ✅ `_onPlusCompetence()` : Gère `.cyber-comp-value`
- ✅ `_onTokenImageClick()` : Nouvelle méthode pour changer l'image
- ✅ `_onTokenConfigClick()` : Nouvelle méthode pour config token

### CSS
**`/css/cyberpunk.css`**
- ✅ `.cyber-bonus-indicator` : Style des bonus +1d6/+2d6
- ✅ `.cyber-points-distribuer` : Affichage des points
- ✅ `.cyber-talents-section` : Section talents complète
- ✅ `.cyber-talent-card` : Cartes individuelles
- ✅ Token hover avec scale et glow

---

## 🧪 TESTS À EFFECTUER

### ✅ Test 1 : Jets de Compétences
1. Créer un personnage Cyberpunk
2. Cliquer sur "Force"
3. **Vérifier** : Jet 1d100 dans le chat
4. **Vérifier** : Message avec seuil de réussite

### ✅ Test 2 : Ajout de Points Compétences
1. Cliquer sur + à côté de Force
2. **Vérifier** : Valeur passe de 0 à 1
3. **Vérifier** : Points disponibles diminuent
4. **Vérifier** : ATQ augmente automatiquement

### ✅ Test 3 : Bonus +1d6/+2d6
1. Mettre Force à 5
2. **Vérifier** : "+1d6" apparaît
3. Mettre Force à 10
4. **Vérifier** : "+1d6 +2d6" apparaît

### ✅ Test 4 : Talents
1. Remplir un talent : "Musculation" / +2d6
2. Cocher la checkbox
3. Faire un jet de Force
4. **Vérifier** : +2d6 apparaît dans le chat

### ✅ Test 5 : Token Cliquable
1. Clic GAUCHE sur le token
2. **Vérifier** : FilePicker s'ouvre
3. Clic DROIT sur le token
4. **Vérifier** : Config Prototype s'ouvre

### ✅ Test 6 : Points à Distribuer
1. Regarder la section sous les compétences
2. **Vérifier** : "X / Y Points de compétences"
3. **Vérifier** : "X / Y Points d'aptitudes"
4. Ajouter des points
5. **Vérifier** : Les compteurs se mettent à jour

---

## 🎨 CAPTURES D'ÉCRAN (Description)

### Section Compétences :
```
┌─────────────────────────────────┐
│ PHYSIQUE                         │
├─────────────────────────────────┤
│ Force           5   +1d6    [+] │
│ Athlétisme     10   +1d6+2d6 [+]│
│ Endurance       3            [+] │
└─────────────────────────────────┘
```

### Section Talents :
```
┌──────────────────┬──────────────────┐
│ [✓] MUSCULATION  │ [ ] VISION NOCTURNE│
│ Bonus de force.. │ Voir dans le noir│
│ Bonus: +2d6 [3]  │ Bonus: +X [10]   │
├──────────────────┼──────────────────┤
│ [✓] ESQUIVE      │ [ ] MÉDITATION   │
│ Éviter les coups │ Régénération PM  │
│ Bonus: +X [-5]   │ Bonus: +1d6 [2]  │
└──────────────────┴──────────────────┘
```

### Token :
```
┌───────────────┐
│               │
│  [  IMAGE  ]  │
│   DU TOKEN    │
│               │
│ (hover)       │
│ Clic : Image  │
│ Droit : Token │
└───────────────┘
```

---

## 💡 CONSEILS D'UTILISATION

### Pour les Joueurs :

**Compétences :**
- Cliquez sur une compétence pour lancer un jet
- Utilisez le bouton + pour dépenser des points
- À 5 points : +1d6 aux dégâts
- À 10 points : +2d6 aux dégâts (total +3d6)

**Talents :**
- Créez 4 talents maximum
- Cochez ceux qui sont actifs
- Les bonus s'appliquent automatiquement
- Type +X : facilite les jets
- Type +Xd6 : augmente les dégâts

**Token :**
- Clic gauche pour changer votre portrait
- Utilisez une image claire pour votre personnage

---

### Pour les MJs :

**Prototype Token :**
- Clic droit sur le token
- Configurez vision et lumière
- Associez les barres PV et PM
- Définissez la taille du token

**Talents :**
- Validez les talents créés par les joueurs
- Équilibrez les bonus (+2d6 max recommandé)
- Les talents +X au jet (négatif) rendent plus facile
- Les talents +Xd6 augmentent juste les dégâts

**Calculs :**
- Tout est automatique
- Les modificateurs de rang s'appliquent seuls
- Fatigue et blessures réduisent automatiquement

---

## ⚠️ NOTES IMPORTANTES

### Différence entre les deux types de bonus :

**+X (nombre) :**
```
Jet : 1d100 + malus - bonus_talent
Si bonus = +10 → plus facile de réussir
Exemple : Jet 60 + malus 15 - 10 = 65
```

**+Xd6 (dés) :**
```
Ne change PAS le jet de réussite
Ajoute aux dégâts EN CAS DE RÉUSSITE
Exemple : Dégâts 50 + 2d6 = 50 + [résultat]
```

### Synergie Compétences + Talents :

**Meilleure combinaison :**
```
Compétence à 10 → +3d6 de base
Talent actif +2d6 → Total +5d6 aux dégâts !
```

**Stratégie :**
1. Monter d'abord les compétences à 5 (premier bonus)
2. Ensuite créer des talents
3. Enfin monter à 10 pour le second bonus

---

## 🚀 INSTALLATION

### Nouvelle Installation :
```
1. Extraire ffdreame-v3.8-FINAL.zip
2. Placer dans Data/systems/ffdreame/
3. Redémarrer Foundry VTT
4. Créer un monde avec "FFdreame"
```

### Mise à Jour depuis v3.7 :
```
1. Sauvegarder votre dossier actuel
2. Remplacer les fichiers :
   - templates/actor/cyberpunk-character-sheet.html
   - module/sheets/actor-sheet.js
   - css/cyberpunk.css
3. Rafraîchir (F5)
```

---

## 📞 RÉCAPITULATIF COMPLET

### ✅ CE QUI FONCTIONNE :

| Fonctionnalité | Character | Cyberpunk |
|----------------|-----------|-----------|
| Jets de compétences | ✅ | ✅ |
| Bouton + compétences | ✅ | ✅ |
| Bouton + aptitudes | ✅ | ✅ |
| Indicateurs +1d6/+2d6 | ✅ | ✅ |
| Talents activables | ✅ | ✅ |
| Calculs automatiques | ✅ | ✅ |
| Modificateurs rang | ✅ | ✅ |
| Fatigue/Blessures | ✅ | ✅ |
| Points d'action | ✅ | ✅ |
| Postures | ✅ | ✅ |
| Techniques | ✅ | ✅ |
| Ultimates | ✅ | ✅ |
| Token cliquable | ❌ | ✅ |
| Scroll | ✅ | ✅ |

---

## 🎉 VERSION FINALE

**Toutes les fonctionnalités sont maintenant synchronisées entre les deux fiches !**

Les fiches Character et Cyberpunk ont maintenant :
- ✅ Les mêmes calculs
- ✅ Les mêmes fonctionnalités
- ✅ Les mêmes mécaniques de jeu
- ✅ Seul le style visuel diffère (Fantasy vs Cyberpunk)

**Bon jeu ! 🎲**

---

**Version : 3.8 FINAL**
**Date : 3 Février 2026**
**Système : FFdreame - Foundry VTT**
