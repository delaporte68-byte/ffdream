# 🔥 GUIDE COMPLET : Style AOER (AOE Retardé)

## 🎯 Qu'est-ce que le style AOER ?

**AOER** = **A**rea **O**f **E**ffect **R**etardé (Zone d'Effet Retardée)

C'est un style de technique **pour les boss/monstres** qui fonctionne en 2 phases :

### **Phase 1 : Lancement (Tour actuel)**
```
Boss utilise la technique
→ PAS de jet de dés
→ PAS de dégâts immédiats
→ Zone marquée au sol (rouge feu)
→ Message : "⚠️ ZONE DE DANGER !"
```

### **Phase 2 : Déclenchement (Round suivant)**
```
Début du prochain round
→ Animation JB2A se joue
→ Tous les tokens dans la zone :
   - Prennent les dégâts
   - Subissent les effets
→ Zone disparaît
```

---

## 📊 Formes Disponibles

### 🔴 Cercle
- Clic pour placer n'importe où
- Rayon configurable
- Exemple : Météore, Explosion

### ➡️ Ligne
- Part du token du boss
- Clic pour orienter la direction
- Largeur configurable
- Exemple : Laser, Souffle

### 🔺 Triangle (Cône)
- Part du token du boss
- Clic pour orienter la direction
- Angle configurable (90° par défaut)
- Exemple : Souffle de dragon, Onde de choc

---

## ⚙️ Configuration d'une Technique AOER

### Onglet Principal :
```
Nom : Météore Infernal
Style : AOER
Coût PM : 20
Coût PA : 1 Grand PA
Dégâts de base : 50
```

### Onglet AOER (nouveau) :
```
Forme : Cercle / Ligne / Triangle
Distance max : 15m (pour placement)
Taille : 5m (rayon ou largeur)
Angle : 90° (pour triangle uniquement)
```

### Onglet Effets :
```
Effet 1 : Brûlure
- Type : deg (dégâts sur durée)
- Valeur : 10
- Durée : 3 tours
- Condition : 100%

Effet 2 : Malus défense
- Type : malus_defense
- Valeur : 20%
- Durée : 2 tours
```

### Onglet Animations :
```
Animation JB2A : jb2a.fireball.orange
Durée : 3 secondes
```

---

## 🎮 Workflow en Jeu

### Exemple : Dragon Boss utilise "Souffle de Feu"

**Round 1, Tour du Dragon :**
```
1. MJ clique sur "Souffle de Feu" (AOER Triangle)
2. Notification : "⚠️ Dragon prépare Souffle de Feu !"
3. Clic pour orienter le triangle vers les joueurs
4. Zone triangulaire ROUGE apparaît au sol
5. Message chat : 
   "⚠️ ZONE DE DANGER !
    Dragon prépare Souffle de Feu
    Se déclenchera au Round 2
    💥 Dégâts : 50"
6. PM/PA du dragon consommés
7. Tour terminé
```

**Round 1 continue :**
```
Joueur 1 : "Oh non ! Une zone rouge !"
→ Essaie de sortir de la zone
→ Se déplace

Joueur 2 : Reste dans la zone (pas vu)

Joueur 3 : Hors de la zone
```

**Fin Round 1 → Début Round 2 :**
```
Système détecte : Round 2 commence
→ Vérifie toutes les zones AOER
→ Trouve "Souffle de Feu" (déclenchement = Round 2)
→ DÉCLENCHEMENT !

Animation : jb2a.fireball.orange se joue (3 sec)

Joueur 1 : Hors de la zone ✅ (a réussi à s'échapper)
→ Pas de dégâts

Joueur 2 : Dans la zone ❌
→ Subit 50 dégâts
→ Effet 1 : Brûlure (10 dégâts/tour, 3 tours)
→ Effet 2 : Malus défense -20% (2 tours)
→ Message : "💥 Joueur 2 subit 50 dégâts !"

Joueur 3 : Hors de la zone ✅
→ Pas de dégâts

Zone disparaît
```

---

## 🔧 Installation (Déjà fait dans le ZIP)

### Fichiers créés :
1. **`module/combat/aoer-system.js`** ✅ - Système complet
2. **`template.json`** ✅ - Champs ajoutés
3. **`module/ffdreame.js`** ✅ - Import et init
4. **`module/sheets/actor-sheet.js`** ✅ - Fonction intégrée

### Ce qui reste à faire :
⚠️ **Ajouter l'onglet AOER dans technique-sheet-v2.html**

---

## 📋 Template HTML à Ajouter

Ajoutez cet onglet dans `templates/item/technique-sheet-v2.html` :

```html
<!-- ONGLET AOER - Après l'onglet MULTI -->
<a class="item" data-tab="aoer">🔥 AOER</a>

<!-- CONTENU ONGLET AOER -->
<div class="tab aoer" data-group="item-primary" data-tab="aoer">
  <div class="technique-section" style="border-color: rgba(255, 0, 0, 0.5);">
    <h3 style="color: #ff0000;">🔥 Configuration AOER (Zone Retardée)</h3>
    
    <p style="color: #ff6666; font-size: 12px; margin-bottom: 15px;">
      Les techniques AOER marquent une zone au sol qui se déclenche au round suivant.
      Parfait pour les boss qui préparent des attaques dévastatrices !
    </p>
    
    <!-- Forme -->
    <div class="form-group">
      <label>Forme de la zone :</label>
      <select name="system.aoer.forme">
        <option value="cercle" {{#if (eq system.aoer.forme "cercle")}}selected{{/if}}>
          🔴 Cercle (explosion, météore)
        </option>
        <option value="ligne" {{#if (eq system.aoer.forme "ligne")}}selected{{/if}}>
          ➡️ Ligne (laser, souffle linéaire)
        </option>
        <option value="triangle" {{#if (eq system.aoer.forme "triangle")}}selected{{/if}}>
          🔺 Triangle/Cône (souffle de dragon)
        </option>
      </select>
    </div>

    <!-- Distance max -->
    <div class="form-group">
      <label>📏 Distance maximale (mètres) :</label>
      <input type="number" name="system.aoer.distanceMax" value="{{system.aoer.distanceMax}}" min="1" step="0.5" placeholder="10"/>
      <small style="display: block; color: #999; margin-top: 5px;">
        Distance max pour placer la zone (cercle) ou longueur (ligne/triangle)
      </small>
    </div>

    <!-- Taille -->
    <div class="form-group">
      <label>📐 Taille (rayon ou largeur en mètres) :</label>
      <input type="number" name="system.aoer.taille" value="{{system.aoer.taille}}" min="1" step="0.5" placeholder="3"/>
      <small style="display: block; color: #999; margin-top: 5px;">
        Cercle : rayon | Ligne : largeur | Triangle : portée
      </small>
    </div>

    <!-- Angle (pour triangle) -->
    <div class="form-group">
      <label>📐 Angle du cône (pour triangle uniquement) :</label>
      <input type="number" name="system.aoer.angle" value="{{system.aoer.angle}}" min="30" max="180" step="15" placeholder="90"/>
      <small style="display: block; color: #999; margin-top: 5px;">
        Angle d'ouverture du cône (90° = quart de cercle, 120° = large)
      </small>
    </div>

    <!-- Info déclenchement -->
    <div style="margin-top: 20px; padding: 15px; background: rgba(255, 0, 0, 0.1); border-left: 4px solid #ff0000; border-radius: 4px;">
      <p style="margin: 0; color: #ff0000; font-weight: bold;">⏱️ Déclenchement Retardé</p>
      <ul style="margin: 10px 0 0 20px; padding: 0; font-size: 12px;">
        <li>La zone est marquée en <strong>rouge</strong> au sol</li>
        <li>Se déclenche au <strong>début du prochain round</strong></li>
        <li>L'animation configurée se joue au déclenchement</li>
        <li>Tous les tokens dans la zone subissent dégâts + effets</li>
        <li>Le lanceur n'est <strong>jamais</strong> touché par sa propre zone</li>
      </ul>
    </div>

    <!-- Exemples -->
    <div style="margin-top: 15px; padding: 15px; background: rgba(255, 221, 0, 0.1); border-left: 4px solid #ffdd00; border-radius: 4px;">
      <p style="margin: 0; color: #ffdd00; font-weight: bold;">💡 Exemples</p>
      <ul style="margin: 10px 0 0 20px; padding: 0; font-size: 12px;">
        <li><strong>Météore :</strong> Cercle 5m, 50 dégâts, effet brûlure</li>
        <li><strong>Souffle Dragon :</strong> Triangle 10m/90°, 60 dégâts, effet peur</li>
        <li><strong>Laser :</strong> Ligne 15m/2m, 40 dégâts, effet ralentissement</li>
        <li><strong>Tremblement :</strong> Cercle 8m, 30 dégâts, effet étourdissement</li>
      </ul>
    </div>

    <!-- Schéma visuel -->
    <div style="margin-top: 15px; padding: 15px; background: rgba(0, 0, 0, 0.3); border-radius: 8px; text-align: center;">
      <p style="margin: 0 0 10px 0; color: #ff0000; font-weight: bold;">📍 Formes Disponibles</p>
      <div style="font-size: 12px; color: #999;">
        <p>🔴 <strong>Cercle</strong> : Explosion centrée</p>
        <p>➡️ <strong>Ligne</strong> : Depuis le boss → direction</p>
        <p>🔺 <strong>Triangle</strong> : Depuis le boss → cône</p>
      </div>
    </div>
  </div>
</div>
```

---

## 🎨 Apparence des Zones

### Zone Cercle :
```
        🔴
      🔴🔴🔴
    🔴🔴🔴🔴🔴
      🔴🔴🔴
        🔴
```

### Zone Ligne :
```
🐲 Boss ➡️➡️➡️➡️➡️➡️➡️
```

### Zone Triangle :
```
      ➡️➡️➡️➡️
    ➡️➡️➡️➡️➡️
  ➡️➡️➡️➡️➡️➡️
🐲➡️➡️➡️➡️➡️➡️➡️
  ➡️➡️➡️➡️➡️➡️
    ➡️➡️➡️➡️➡️
      ➡️➡️➡️➡️
```

---

## 🔥 Exemples de Techniques AOER

### 1. Météore Infernal (Cercle)
```
Style : AOER
Forme : Cercle
Distance max : 20m (peut placer n'importe où)
Taille : 5m (rayon)
Dégâts : 50
Effet 1 : Brûlure (10 dégâts/tour, 3 tours)
Animation : jb2a.fireball.orange
```

### 2. Souffle de Dragon (Triangle)
```
Style : AOER
Forme : Triangle
Distance max : 10m
Taille : 10m (portée)
Angle : 90°
Dégâts : 60
Effet 1 : Peur (malus jets -20%, 2 tours)
Animation : jb2a.breath_weapons.fire.cone.orange
```

### 3. Laser Orbital (Ligne)
```
Style : AOER
Forme : Ligne
Distance max : 15m
Taille : 2m (largeur)
Dégâts : 40
Effet 1 : Ralentissement (malus agilité -30%, 3 tours)
Animation : jb2a.energy_beam.normal.bluepurple
```

### 4. Tremblement de Terre (Cercle)
```
Style : AOER
Forme : Cercle
Distance max : 0 (centré sur le boss)
Taille : 8m
Dégâts : 30
Effet 1 : Étourdissement (malus jets -15%, 2 tours)
Animation : jb2a.ground_cracks.orange
```

---

## 🎯 Tactiques de Jeu

### Pour le MJ (Boss) :
```
1. Utiliser AOER en début de combat
   → Force les joueurs à bouger
   → Crée de la pression

2. Alterner AOER + attaques normales
   → Pendant que zone AOER attend
   → Attaque directe avec autre compétence

3. Zones qui se chevauchent
   → Lancer 2 AOER consécutifs
   → Couvrir toute la zone
```

### Pour les Joueurs :
```
1. FUIR la zone rouge immédiatement
   → Ne restez pas dans la zone !

2. Anticiper le pattern du boss
   → Si cercle → S'éloigner
   → Si ligne → Se déplacer sur le côté

3. Utiliser le délai à son avantage
   → Attaquer le boss pendant qu'il prépare
   → Positionner des pièges
```

---

## 📊 Différences avec les Autres Styles

| Caractéristique | MULTI | Zones Persistantes | AOER |
|-----------------|-------|-------------------|------|
| **Jet de dés** | ✅ Oui | ✅ Oui | ❌ Non |
| **Déclenchement** | Immédiat | Immédiat | **Round suivant** |
| **Durée** | Instantané | Plusieurs tours | 1 déclenchement |
| **Dégâts par tour** | Non | Oui | Non |
| **Esquivable** | Réaction | Non | **Fuite possible** |
| **Visuel avant** | Non | Zone verte/bleue | **Zone rouge** |

---

## ⚠️ Points Importants

### 1. Pas de Jet de Dés
- AOER n'utilise **PAS** de jet d'attaque
- Les dégâts sont **automatiques** si dans la zone
- Les joueurs peuvent esquiver en **sortant** de la zone

### 2. Déclenchement au Round Suivant
- Pas au tour suivant
- Au **ROUND** suivant (quand tous ont joué)
- Système détecte automatiquement

### 3. Zone Visible
- La zone ROUGE est visible par tous
- Les joueurs savent où ne pas aller
- Tactique : forcer le mouvement

### 4. Le Boss Peut Bouger
- Après avoir placé la zone
- Le boss peut continuer à agir
- La zone reste à sa position

---

## 🐛 Dépannage

### "La zone ne se déclenche pas"
1. Vérifiez qu'un combat est actif
2. Console (F12) : Cherchez "🔥 AOER : Vérification"
3. La zone se déclenche au ROUND suivant, pas au tour

### "Pas de dégâts appliqués"
1. Vérifiez que les tokens sont bien dans la zone
2. Console : Nombre de tokens détectés
3. Le lanceur ne prend jamais de dégâts

### "Zone ne s'affiche pas"
1. Vérifiez Sequencer installé (pour l'effet rouge)
2. Le template Foundry s'affiche toujours (rouge)

---

## ✅ Checklist de Test

- [ ] Créer une technique AOER (Cercle)
- [ ] Boss utilise la technique
- [ ] Zone rouge apparaît
- [ ] Message "⚠️ ZONE DE DANGER"
- [ ] Attendre le prochain round
- [ ] Animation se joue
- [ ] Dégâts appliqués aux joueurs dans la zone
- [ ] Zone disparaît après déclenchement
- [ ] Effets appliqués correctement

---

## 🎭 Scénarios Épiques

### Boss Multi-Phases
```
Phase 1 : Combat normal
Phase 2 (50% PV) : Commence à utiliser AOER
Phase 3 (25% PV) : AOER multiples + rage
```

### Puzzle de Boss
```
Boss invincible
Utilise AOER Triangle (souffle)
Joueurs doivent :
1. Éviter les zones rouges
2. Attaquer pendant qu'il charge
3. Casser des cristaux pour le rendre vulnérable
```

### Boss Kamikaze
```
Boss utilise AOER Cercle géant centré sur lui
Se sacrifie pour tuer les joueurs
Compte à rebours : 1 round pour fuir !
```

---

Bon massacre avec les zones AOER ! 🔥💥
