# 🔧 GUIDE DE TEST ET DÉBOGAGE - Techniques dans Postures

## ⚠️ PROBLÈME RÉSOLU

Les techniques ne s'affichaient pas dans les postures car :
1. Les items n'étaient pas passés au contexte du template
2. Les références `@root.actor.items` étaient incorrectes

## ✅ CORRECTIONS APPLIQUÉES

### 1. Fichier JavaScript (`module/sheets/actor-sheet.js`)
La méthode `getData()` a été corrigée pour passer les items :

```javascript
async getData() {
  const context = super.getData();
  
  const actorData = this.actor.toObject(false);
  context.system = actorData.system;
  context.flags = actorData.flags;

  // ✅ AJOUT IMPORTANT : Passer les items au contexte
  context.items = this.actor.items.contents;
  context.actor = this.actor;

  context.isGM = game.user.isGM;
  context.rangInfo = this._getRangInfo(context.system.rang);

  return context;
}
```

### 2. Fichier Template (`templates/actor/character-sheet.html`)
Les références aux items ont été corrigées :

**AVANT (incorrect) :**
```handlebars
{{#each actor.items as |item|}}
{{#each @root.actor.items as |tech|}}
```

**APRÈS (correct) :**
```handlebars
{{#each items as |item|}}
{{#each @root.items as |tech|}}
```

## 🧪 PROCÉDURE DE TEST COMPLÈTE

### Étape 1 : Créer une Posture

1. Ouvrir Foundry VTT
2. Cliquer sur **"Créer un Item"**
3. Choisir **Type : "Posture"**
4. Remplir :
   - **Nom** : `Combat Rapide` (notez bien le nom exact !)
   - **Description** : Une posture axée sur la vitesse
   - **Attaque Base** : `20`
   - **Ultimate Nom** : `Tornade de Feu` (optionnel)
   - **Ultimate Dégâts** : `300` (optionnel)
5. **Sauvegarder** l'item

### Étape 2 : Créer une Technique

1. Cliquer sur **"Créer un Item"**
2. Choisir **Type : "Technique"**
3. Dans l'onglet **Description** :
   - **Nom** : `Coup Éclair`
   - **Description** : Une attaque fulgurante
   - **Posture Associée** : `Combat Rapide` ⚠️ **EXACTEMENT comme le nom de la posture !**

4. Dans l'onglet **Coût PM** :
   - **Coût PM** : `15`

5. Dans l'onglet **Dégâts** :
   - **Style** : `CAC` (Corps à Corps)
   - **Base Dégâts** : `30`

6. **Sauvegarder** l'item

### Étape 3 : Créer une 2ème Technique (même posture)

1. Créer un nouvel item **Technique**
2. Remplir :
   - **Nom** : `Frappe Tourbillon`
   - **Posture Associée** : `Combat Rapide` (copier-coller depuis la posture !)
   - **Style** : `CAC`
   - **Coût PM** : `25`
   - **Base Dégâts** : `50`
3. **Sauvegarder**

### Étape 4 : Créer une 2ème Posture

1. Créer un item **Posture**
2. Remplir :
   - **Nom** : `Défense Absolue`
   - **Attaque Base** : `10`
3. **Sauvegarder**

### Étape 5 : Créer une Technique pour la 2ème Posture

1. Créer un item **Technique**
2. Remplir :
   - **Nom** : `Bouclier Magique`
   - **Posture Associée** : `Défense Absolue`
   - **Style** : `BUFF`
   - **Coût PM** : `20`
3. **Sauvegarder**

### Étape 6 : Vérifier l'Affichage

1. Ouvrir la **fiche du personnage**
2. Aller dans l'onglet **Combat**
3. Scroller jusqu'à la section **"Postures & Techniques"**

**Vous devriez voir :**

```
┌─────────────────────────┬─────────────────────────┐
│  🥊 Combat Rapide       │  🥊 Défense Absolue    │
│  [○ Inactive]           │  [○ Inactive]           │
│                         │                         │
│  [⚔️ ATTAQUE DE BASE]   │  [⚔️ ATTAQUE DE BASE]  │
│  20 dégâts              │  10 dégâts              │
│                         │                         │
│  📜 Techniques:         │  📜 Techniques:         │
│  ┌───────────────────┐ │  ┌───────────────────┐ │
│  │ Coup Éclair       │ │  │ Bouclier Magique  │ │
│  │ 💎 15 PM          │ │  │ 💎 20 PM          │ │
│  │ ⚔️ 30 dégâts      │ │  │ 🛡️ BUFF           │ │
│  └───────────────────┘ │  └───────────────────┘ │
│  ┌───────────────────┐ │                         │
│  │ Frappe Tourbillon │ │                         │
│  │ 💎 25 PM          │ │                         │
│  │ ⚔️ 50 dégâts      │ │                         │
│  └───────────────────┘ │                         │
│                         │                         │
│  🔥 ULTIMATE            │                         │
│  Tornade de Feu         │                         │
└─────────────────────────┴─────────────────────────┘
```

## 🐛 SI LES TECHNIQUES NE S'AFFICHENT TOUJOURS PAS

### Diagnostic 1 : Console de Développement

1. Appuyez sur **F12** pour ouvrir la console
2. Tapez et exécutez cette commande :

```javascript
// Remplacez "Nom du Personnage" par le vrai nom
let actor = game.actors.getName("Nom du Personnage");
console.log("Items:", actor.items.contents);
console.log("Postures:", actor.items.filter(i => i.type === "posture"));
console.log("Techniques:", actor.items.filter(i => i.type === "technique"));
```

**Résultat attendu :**
```
Items: [Array of items]
Postures: [{name: "Combat Rapide", ...}, {name: "Défense Absolue", ...}]
Techniques: [{name: "Coup Éclair", system: {postureAssociee: "Combat Rapide"}}, ...]
```

### Diagnostic 2 : Vérifier le Nom de la Posture Associée

```javascript
let tech = game.items.getName("Coup Éclair");
console.log("Posture associée:", tech.system.postureAssociee);
// Doit afficher EXACTEMENT le nom de la posture
```

### Diagnostic 3 : Test Manuel de Correspondance

```javascript
let actor = game.actors.getName("Nom du Personnage");
let posture = actor.items.find(i => i.name === "Combat Rapide");
let techniques = actor.items.filter(i => 
  i.type === "technique" && 
  i.system.postureAssociee === posture.name
);
console.log("Techniques trouvées:", techniques);
```

## 🔧 SOLUTIONS AUX PROBLÈMES COURANTS

### Problème 1 : Nom de Posture Incorrect
**Symptôme :** Les techniques ne s'affichent pas

**Solution :**
1. Ouvrir l'item Posture
2. **Copier** le nom exact (Ctrl+C)
3. Ouvrir l'item Technique
4. **Coller** le nom dans "Posture Associée" (Ctrl+V)
5. Sauvegarder

### Problème 2 : Items Mondiaux (World Items)
**Symptôme :** L'item technique existe mais n'est pas sur le personnage

**Solution :**
1. Vérifier que l'item a été **ajouté au personnage**
2. Glisser-déposer l'item depuis le répertoire Items vers la fiche
3. OU créer l'item directement depuis la fiche du personnage

### Problème 3 : Cache du Navigateur
**Symptôme :** Modifications non visibles

**Solution :**
1. Appuyer sur **Ctrl+Shift+R** (recharger sans cache)
2. OU vider le cache du navigateur
3. Redémarrer Foundry VTT

### Problème 4 : Fichier Mal Remplacé
**Symptôme :** Rien ne fonctionne

**Solution :**
1. Vérifier que le fichier `module/sheets/actor-sheet.js` contient bien :
```javascript
context.items = this.actor.items.contents;
context.actor = this.actor;
```

2. Vérifier que le fichier `templates/actor/character-sheet.html` utilise bien :
```handlebars
{{#each items as |item|}}
```

## 📊 STRUCTURE DES DONNÉES

### Structure d'une Posture
```javascript
{
  name: "Combat Rapide",
  type: "posture",
  system: {
    description: "...",
    attaqueBase: 20,
    effetType: "aucun",
    active: false,
    ultimateNom: "Tornade de Feu",
    ultimateDegats: 300
  }
}
```

### Structure d'une Technique
```javascript
{
  name: "Coup Éclair",
  type: "technique",
  system: {
    description: "...",
    style: "cac",
    coutPM: 15,
    baseDegats: 30,
    postureAssociee: "Combat Rapide"  // ⚠️ DOIT ÊTRE EXACT
  }
}
```

## ✅ CHECKLIST FINALE

Après avoir créé vos postures et techniques, vérifiez :

- [ ] 2 postures créées maximum
- [ ] Les postures sont bien dans la fiche du personnage (pas seulement dans Items)
- [ ] Les techniques sont bien dans la fiche du personnage
- [ ] Le champ "Posture Associée" de chaque technique contient le nom **EXACT** de la posture
- [ ] Pas d'espaces en trop, pas de différence de casse (majuscules/minuscules)
- [ ] Les fichiers modifiés sont bien en place
- [ ] Foundry VTT a été redémarré
- [ ] La page a été rafraîchie (F5 ou Ctrl+R)
- [ ] La fiche du personnage affiche bien les 2 colonnes de postures
- [ ] Chaque posture affiche ses techniques associées
- [ ] Les boutons d'activation fonctionnent
- [ ] Les techniques sont cliquables quand la posture est active

## 🎯 RÉSULTAT ATTENDU

Quand tout fonctionne correctement :

1. **2 postures côte à côte** dans l'onglet Combat
2. **Bouton ACTIVER/DÉSACTIVER** sur chaque posture
3. **Une seule posture active** à la fois
4. **Techniques listées** sous leur posture respective
5. **Boutons techniques** cliquables quand posture active
6. **Affichage du coût PM et dégâts** sur chaque technique
7. **Ultimate visible** si défini (et Burst ≥ 100)

## 💡 ASTUCE PRO

Pour éviter les erreurs de frappe dans "Posture Associée" :

1. Créer d'abord TOUTES les postures
2. Dans la fiche du personnage, noter les noms exacts
3. Utiliser **COPIER-COLLER** pour remplir "Posture Associée"
4. Ne jamais taper manuellement le nom

## 📞 SI RIEN NE FONCTIONNE

1. Vérifier la console F12 pour des erreurs JavaScript
2. Restaurer les fichiers .backup si nécessaire
3. Créer un nouveau personnage test
4. Créer 1 posture et 1 technique pour tester
5. Vérifier que les 3 fichiers modifiés sont bien en place :
   - `module/sheets/actor-sheet.js`
   - `templates/actor/character-sheet.html`
   - `css/ffdreame.css`

---

**Bon test ! 🎮**
