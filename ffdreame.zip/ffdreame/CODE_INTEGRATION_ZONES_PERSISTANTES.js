// ============================================
// CODE D'INTÉGRATION DES ZONES PERSISTANTES
// ============================================

// 1. IMPORTER LE MODULE dans actor-sheet.js (au début avec les autres imports)
import { FFdreamePersistentZones } from "../combat/persistent-zones.js";

// 2. INITIALISER LE SYSTÈME dans ffdreame.js (dans le hook 'ready')
Hooks.once('ready', async function() {
  console.log('FFdreame | Système prêt');
  
  // ... autres initialisations ...
  
  // Initialiser le système de zones persistantes
  FFdreamePersistentZones.init();
});


// 3. CRÉER LA ZONE APRÈS UNE TECHNIQUE RÉUSSIE (dans actor-sheet.js)

// A. Pour les techniques normales (ligne ~1663, après _jouerAnimationItem)
// Remplacer cette section :
/*
    if (success) {
      await this._jouerAnimationItem(technique);
      
      // ===== GESTION DE LA TÉLÉPORTATION =====
      const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
      if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
        const targets = Array.from(game.user.targets);
        const targetToken = targets.length > 0 ? targets[0] : null;
        
        await FFdreameTeleportation.handleTeleportation(this.actor, targetToken, teleportConfig);
      }
      
      // ===== GESTION DES EFFETS DE TABLEAUX =====
      await this._incrementerCompteurEffet();
    }
*/

// PAR :
    if (success) {
      await this._jouerAnimationItem(technique);
      
      // ===== GESTION DE LA TÉLÉPORTATION =====
      const teleportConfig = FFdreameTeleportation.getTeleportationConfig(technique);
      if (FFdreameTeleportation.isTeleportationEnabled(technique)) {
        const targets = Array.from(game.user.targets);
        const targetToken = targets.length > 0 ? targets[0] : null;
        
        await FFdreameTeleportation.handleTeleportation(this.actor, targetToken, teleportConfig);
      }
      
      // ===== GESTION DES ZONES PERSISTANTES =====
      if (technique.system.animation?.persistante) {
        const targets = Array.from(game.user.targets);
        const targetToken = targets.length > 0 ? targets[0] : null;
        
        const zoneConfig = {
          persistante: true,
          degatsParTour: technique.system.animation.degatsParTour || 0,
          dureeTours: technique.system.animation.dureeTours || 3,
          animation: technique.system.animation.jb2a
        };
        
        await FFdreamePersistentZones.createPersistentZone(
          this.actor,
          targetToken || { x: token.center.x, y: token.center.y },
          zoneConfig,
          technique
        );
      }
      
      // ===== GESTION DES EFFETS DE TABLEAUX =====
      await this._incrementerCompteurEffet();
    }


// B. Pour les techniques MULTI (dans multi-zone.js, ligne ~170 et ~330)
// Après l'application des dégâts et avant le setTimeout de suppression du template

      // ===== GESTION DES ZONES PERSISTANTES =====
      if (technique.system.animation?.persistante) {
        const { FFdreamePersistentZones } = await import('./persistent-zones.js');
        
        const zoneConfig = {
          persistante: true,
          degatsParTour: technique.system.animation.degatsParTour || 0,
          dureeTours: technique.system.animation.dureeTours || 3,
          animation: technique.system.animation.jb2a
        };
        
        await FFdreamePersistentZones.createPersistentZone(
          actor,
          pos, // La position cliquée pour la zone
          zoneConfig,
          technique
        );
      }


// 4. MODIFIER LA DURÉE DE L'ANIMATION (dans actor-sheet.js, fonction _jouerAnimationItem)
// Remplacer cette fonction (ligne ~2099) :

async _jouerAnimationItem(item) {
  // Vérifier si Sequencer est disponible
  if (!game.modules.get("sequencer")?.active) {
    return; // Pas d'animation sans Sequencer
  }

  const token = this.actor.getActiveTokens()[0];
  if (!token) return;

  // Récupérer la cible (premier token ciblé)
  const targets = Array.from(game.user.targets);
  const target = targets[0];
  
  // Récupérer la durée configurée (0 = permanent)
  const duree = item.system.animation?.duree || 3;
  const isPermanent = duree === 0;

  // Animation JB2A
  if (item.system.animation?.jb2a) {
    try {
      const sequence = new Sequence();
      
      if (target) {
        // Animation vers la cible
        const effect = sequence
          .effect()
          .file(item.system.animation.jb2a)
          .atLocation(token)
          .stretchTo(target);
        
        // Appliquer la durée
        if (isPermanent) {
          effect.persist().name(`permanent-anim-${item.id}-${Date.now()}`);
        } else {
          effect.duration(duree * 1000); // Convertir en millisecondes
        }
      } else {
        // Animation sur le lanceur
        const effect = sequence
          .effect()
          .file(item.system.animation.jb2a)
          .atLocation(token);
        
        // Appliquer la durée
        if (isPermanent) {
          effect.persist().name(`permanent-anim-${item.id}-${Date.now()}`);
        } else {
          effect.duration(duree * 1000);
        }
      }
      
      await sequence.play();
    } catch (error) {
      console.error("Erreur lors de l'animation JB2A:", error);
    }
  }

  // Animation Sequencer personnalisée
  if (item.system.animation?.sequencer) {
    try {
      const sequence = new Sequence();
      
      if (target) {
        const effect = sequence
          .effect()
          .file(item.system.animation.sequencer)
          .atLocation(token)
          .stretchTo(target);
        
        if (isPermanent) {
          effect.persist().name(`permanent-anim-${item.id}-${Date.now()}`);
        } else {
          effect.duration(duree * 1000);
        }
      } else {
        const effect = sequence
          .effect()
          .file(item.system.animation.sequencer)
          .atLocation(token);
        
        if (isPermanent) {
          effect.persist().name(`permanent-anim-${item.id}-${Date.now()}`);
        } else {
          effect.duration(duree * 1000);
        }
      }
      
      await sequence.play();
    } catch (error) {
      console.error("Erreur lors de l'animation Sequencer:", error);
    }
  }
}


// ============================================
// MACROS UTILES POUR LE MJ
// ============================================

// MACRO : Nettoyer toutes les zones persistantes
const { FFdreamePersistentZones } = await import('./systems/ffdreame/module/combat/persistent-zones.js');
await FFdreamePersistentZones.clearAllZones();


// MACRO : Afficher toutes les zones actives
const zones = canvas.templates.placeables.filter(t => 
  t.document.getFlag('ffdreame', 'persistentZone')
);

console.log(`🧊 ${zones.length} zone(s) persistante(s) active(s):`);
for (const zone of zones) {
  const data = zone.document.getFlag('ffdreame', 'persistentZone');
  console.log(`- ${data.techniqueName}: ${data.tourActuel}/${data.dureeTours} tours, ${data.degatsParTour} dégâts/tour`);
}


// ============================================
// NOTES IMPORTANTES
// ============================================

/**
 * ORDRE D'EXÉCUTION :
 * 1. Jet de dés réussi
 * 2. Dégâts appliqués
 * 3. Animation jouée
 * 4. Téléportation (si activée)
 * 5. Zone persistante créée (si activée)
 * 6. Incrémentation compteur effets
 * 
 * GESTION DES TOURS :
 * - Les dégâts sont appliqués au DÉBUT de chaque tour
 * - Les zones sont nettoyées APRÈS avoir atteint leur durée
 * - Le round de création n'inflige PAS de dégâts (dégâts à partir du tour suivant)
 * 
 * COMPATIBILITÉ :
 * - Fonctionne avec tous les styles (CAC, MAG, MULTI, AOE, etc.)
 * - Compatible avec les zones MULTI (cercle et ligne)
 * - Le lanceur n'est jamais blessé par sa propre zone
 */
