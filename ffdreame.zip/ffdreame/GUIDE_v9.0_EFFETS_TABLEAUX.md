# 🎉 FFdreame v9.0 - EFFETS DE TABLEAUX + ANIMATIONS !

## ✅ 2 SYSTÈMES MAJEURS AJOUTÉS !

### 1. **EFFETS CONDITIONNELS DE TABLEAUX** ✨
### 2. **DROPDOWN ANIMATIONS** 🎬 (+ corrections)

---

## ✨ EFFETS DE TABLEAUX - NOUVEAU !

### Concept :
**Chaque tableau peut avoir son propre effet spécial avec conditions !**

### Exemple concret :
```
Raiven - Tableau 1 "Combo Brutal"
┌──────────────────────────────────┐
│ Effet : +10% dégâts              │
│ Condition : Réussir 2 techniques │
│ Progression : ▓▓░░ (1/2)         │
└──────────────────────────────────┘

Combat :
1. Raiven utilise "Coup puissant" → Réussite
   → Progression : 1/2

2. Raiven utilise "Frappe rapide" → Réussite
   → Progression : 2/2
   → ✨ EFFET PRÊT !

3. Raiven utilise "Uppercut"
   → +10% dégâts appliqués !
   → Progression : 0/2 (reset)
```

---

## 🎯 TYPES D'EFFETS

### 💥 Bonus de dégâts
```
Valeur : 10-50%
Effet : La prochaine technique fait +X% dégâts
Exemple : +20% dégâts
```

### ⚡ Régénération PA
```
Effet : Récupère 1 Petit PA
Exemple : Utile pour enchaîner les attaques
```

### 🎯 Bonus Initiative
```
Valeur : 5-20
Effet : Bonus au jet d'initiative en début de combat
Exemple : +10 initiative
```

### 🛡️ Parade gratuite
```
Effet : La prochaine attaque reçue est annulée
Exemple : Immunité totale à 1 attaque
```

### ⚔️ Double frappe
```
Effet : La prochaine technique frappe 2 fois
Exemple : Dégâts doublés !
```

### 💙 Régénération PM
```
Valeur : 10-50 PM
Effet : Récupère X PM
Exemple : +30 PM
```

### ⭐ Critique automatique
```
Effet : La prochaine technique est critique (x2 dégâts)
Exemple : Critique garanti
```

### 💎 Coût réduit
```
Valeur : 50%
Effet : La prochaine technique coûte 50% de PM en moins
Exemple : 40 PM → 20 PM
```

---

## 🎲 CONDITIONS D'ACTIVATION

### 🎯 Réussir X techniques
```
Exemple : "Réussir 3 techniques"
Progression : Chaque technique réussie de ce tableau +1
```

### 💥 Infliger X dégâts
```
Exemple : "Infliger 150 dégâts"
Progression : Total des dégâts infligés avec ce tableau
```

### ⏱️ X tours de combat
```
Exemple : "3 tours de combat"
Progression : Auto-incrémenté chaque tour
```

### 🔥 Combo de X
```
Exemple : "Combo de 5"
Progression : Techniques consécutives réussies
Note : Reset si échec !
```

### 💙 Dépenser X PM
```
Exemple : "Dépenser 60 PM"
Progression : Total PM dépensés avec techniques de ce tableau
```

---

## 🎮 UTILISATION

### Étape 1 : Ouvrir la config
```
1. Fiche personnage → Onglet Combat
2. Sous Tableau 1 ou 2
3. Bouton "⚡ Configurer l'effet"
4. Fenêtre s'ouvre
```

### Étape 2 : Configurer
```
1. Nom : "Rage du Guerrier"
2. Description : "Augmente dégâts"
3. Type : 💥 Bonus de dégâts
4. Valeur : 15%
5. Condition : 🎯 Réussir 3 techniques
6. Nombre requis : 3
7. Sauvegarder
```

### Étape 3 : Jouer
```
Combat :
- Utiliser techniques du tableau
- Barre de progression se remplit
- Quand ✨ PRÊT apparaît :
  → Prochaine technique = effet activé !
  → Effet se consomme
  → Recommencer
```

---

## 📊 AFFICHAGE EN JEU

### Sur la fiche :
```
Tableau 1 : Combo Brutal
┌─────────────────────────────┐
│ [Case 1] [Case 2] [Case 3] │
│ [Case 4] [Case 5]           │
└─────────────────────────────┘

Effet : Rage du Guerrier
▓▓▓░░░ 2/3
```

### Quand prêt :
```
Effet : Rage du Guerrier
▓▓▓▓▓▓ 3/3
✨ PRÊT !
```

### Message chat après activation :
```
╔═══════════════════════════╗
║ ✨ Rage du Guerrier       ║
║ 💥 +15% dégâts !          ║
╚═══════════════════════════╝
```

---

## 🎬 ANIMATIONS - DROPDOWN

### Avant (v8.x) :
```
❌ Taper manuellement : "jb2a.fire_bolt.orange"
❌ Risque d'erreurs
❌ Pas pratique
```

### Maintenant (v9.0) :
```
✅ Menu déroulant
✅ Toutes les animations listées
✅ Catégories organisées
✅ JB2A Free + Patreon
```

### Catégories :
- 🔥 Feu (15 animations)
- ⚡ Électricité (10 animations)
- ❄️ Glace (8 animations)
- 💀 Nécromancie (12 animations)
- ✨ Magie (15 animations)
- 💚 Nature (10 animations)
- 🌊 Eau & Acide (6 animations)
- 🌪️ Vent (5 animations)
- ☀️ Lumière (10 animations)
- ☠️ Poison (5 animations)
- 🪨 Terre (8 animations)
- 💥 Impacts (12 animations)
- 🏹 Projectiles (10 animations)
- ⚔️ Mêlée (8 animations)
- ❤️ Soins (8 animations)
- 🛡️ Buffs (10 animations)
- 😵 Debuffs (8 animations)
- 🌀 Téléportation (8 animations)
- 👁️ Contrôle Mental (5 animations)
- 🌟 Invocations (6 animations)
- 💫 Effets Spéciaux (8 animations)

**TOTAL : 200+ animations !**

---

## 🔧 FICHIERS AJOUTÉS/MODIFIÉS

### Nouveaux fichiers :
1. **module/combat/tableau-effets.js** (NOUVEAU)
   - Gestion effets tableaux
   - Conditions et progression
   - Activation automatique

2. **templates/dialogs/tableau-effet-config.html** (NOUVEAU)
   - Fenêtre de configuration
   - Interface complète
   - Hints dynamiques

### Fichiers modifiés :
3. **template.json**
   - Structure effet par tableau
   - Progression et état

4. **templates/actor/character-sheet.html**
   - Boutons "⚡ Effet" sous tableaux
   - Affichage progression

5. **module/sheets/actor-sheet.js**
   - Événements boutons
   - Incrémentation progression
   - Activation effets

6. **templates/item/technique-sheet-v2.html**
   - Dropdown animations
   - Toutes les JB2A

---

## 💡 EXEMPLES COMPLETS

### Exemple 1 : Guerrier brutal
```
Tableau 1 : "Arsenal"
Effet : "Fureur croissante"
Type : 💥 +20% dégâts
Condition : Réussir 3 techniques
```

**En jeu :**
```
Tour 1 :
→ Coup d'épée : Réussite (1/3)

Tour 2 :
→ Charge brutale : Réussite (2/3)

Tour 3 :
→ Frappe tournoyante : Réussite (3/3)
→ ✨ EFFET PRÊT !

Tour 4 :
→ Uppercut dévastateur
→ Dégâts : 80 + 20% = 96 dégâts !
→ Effet consommé (0/3)
```

### Exemple 2 : Mage économe
```
Tableau 2 : "Sorts"
Effet : "Économie d'énergie"
Type : 💎 -50% coût PM
Condition : Dépenser 50 PM
```

**En jeu :**
```
Tour 1 :
→ Boule de feu (20 PM) → 20/50 PM

Tour 2 :
→ Éclair (15 PM) → 35/50 PM

Tour 3 :
→ Rayon glacial (20 PM) → 55/50 PM
→ ✨ EFFET PRÊT !

Tour 4 :
→ Météore (coût : 40 PM)
→ Avec effet : 40 × 50% = 20 PM !
→ Effet consommé (0/50 PM)
```

### Exemple 3 : Tank défensif
```
Tableau 1 : "Défense"
Effet : "Parade parfaite"
Type : 🛡️ Parade gratuite
Condition : Infliger 100 dégâts
```

**En jeu :**
```
Combat :
→ Contre-attaque : 40 dégâts (40/100)
→ Riposte : 35 dégâts (75/100)
→ Coup de bouclier : 30 dégâts (105/100)
→ ✨ EFFET PRÊT !

Ennemi attaque :
→ 60 dégâts reçus
→ 🛡️ PARADE ! 0 dégâts !
→ Effet consommé (0/100)
```

---

## 🎯 STRATÉGIES

### Build "Combo Master"
```
Tableau 1 : Attaques rapides
Effet : ⚔️ Double frappe
Condition : Combo de 5

Stratégie :
→ Enchaîner 5 attaques
→ 6ème attaque = double !
→ Dégâts massifs
```

### Build "Endurance"
```
Tableau 1 : Attaques soutenues
Effet : ⚡ Régén 1 PA
Condition : 4 tours de combat

Stratégie :
→ Attaquer chaque tour
→ Au 4ème tour : PA récupéré
→ Continue à attaquer !
```

### Build "Critique garanti"
```
Tableau 2 : Techniques ultimes
Effet : ⭐ Critique auto
Condition : Infliger 200 dégâts

Stratégie :
→ Accumuler dégâts
→ Critique auto sur ULTIM
→ Dégâts x4 (base x2 + crit x2)
```

---

## 📋 CHECKLIST v9.0

| Fonctionnalité | État |
|----------------|------|
| Effets de tableaux | ✅ **100% NOUVEAU** |
| 8 types d'effets | ✅ **100% NOUVEAU** |
| 5 types de conditions | ✅ **100% NOUVEAU** |
| Barre de progression | ✅ **100% NOUVEAU** |
| Activation auto | ✅ **100% NOUVEAU** |
| Reset après utilisation | ✅ **100% NOUVEAU** |
| Fenêtre config | ✅ **100% NOUVEAU** |
| Message chat | ✅ **100% NOUVEAU** |
| Animation activation | ✅ **100% NOUVEAU** |
| Dropdown animations | ✅ **100% NOUVEAU** |
| 200+ animations | ✅ **100% NOUVEAU** |
| Corrections JB2A | ✅ **100% NOUVEAU** |

---

**Version :** 9.0  
**Nouveautés :** Effets de tableaux + Dropdown animations  
**État :** SYSTÈME STRATÉGIQUE COMPLET ! ✨⚡🎬

**LES TABLEAUX PRENNENT VIE !** 🎉🚀✨
