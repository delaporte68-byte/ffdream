/**
 * Feuille d'item pour FFdreame (talents, techniques, équipement)
 */
export class FFdreameItemSheet extends ItemSheet {

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "item"],
      width: 600,
      height: 700,
      resizable: true,
      scrollY: [".item-sheet-body"],
      tabs: [{
        navSelector: ".item-sheet-tabs",
        contentSelector: ".item-sheet-body",
        initial: "description"
      }]
    });
  }

  /* Route vers le bon template selon le type d'item */
  get template() {
    const type = this.item.type;
    if (type === "technique") return "systems/ffdreame/templates/item/technique-sheet-v2.html";
    if (type === "posture") return "systems/ffdreame/templates/item/posture-sheet.html";
    if (type === "attaque") return "systems/ffdreame/templates/item/attaque-sheet.html";
    if (type === "ultimate") return "systems/ffdreame/templates/item/ultimate-sheet.html";
    return "systems/ffdreame/templates/item/talent-sheet.html";
  }

  async getData() {
    const context = super.getData();
    const itemData = this.item.toObject(false);
    
    context.system = itemData.system;
    context.flags = itemData.flags;
    context.item = this.item;
    context.isGM = game.user.isGM;

    // Pour les techniques : label du style
    if (this.item.type === "technique") {
      context.styleLabel = this._getStyleLabel(context.system.style);
    }

    // Pour les postures : label de l'effet
    if (this.item.type === "posture") {
      context.effetLabel = this._getEffetLabel(context.system.effetType);
    }

    return context;
  }

  _getStyleLabel(style) {
    const labels = {
      "cac":  "CAC — Corps à Corps",
      "mg":   "MG — Magie Guidée",
      "p":    "P — Parfait",
      "eha":  "EHa — Éclat Haine (Attaque)",
      "ehm":  "EHm — Éclat Haine (Magie)",
      "ef":   "EF — Éclat Foudre",
      "buff": "BUFF — Technique de Soutien"
    };
    return labels[style] || style;
  }

  _getEffetLabel(effetType) {
    const labels = {
      "aucun": "Aucun effet",
      "bonus_degats": "Bonus de dégâts %",
      "regen_pa": "Régénération PA",
      "contre": "Contre sans PA",
      "esquive": "Esquive sans PA",
      "initiative": "Prise d'initiative"
    };
    return labels[effetType] || effetType;
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.isEditable) return;

    // Ajouter une technique (postures)
    html.find('.btn-add-technique').on('click', this._onAddTechnique.bind(this));

    // Supprimer une technique (postures)
    html.find('.btn-delete-technique').on('click', this._onDeleteTechnique.bind(this));
  }

  /* ================================
     AJOUTER UNE TECHNIQUE
     ================================ */
  async _onAddTechnique(event) {
    event.preventDefault();
    
    const techniques = this.item.system.techniques || [];
    const newTechnique = {
      nom: "",
      description: "",
      effets: "",
      style: "cac",
      coutPM: 10,
      baseDegats: 0
    };
    
    techniques.push(newTechnique);
    
    await this.item.update({ "system.techniques": techniques });
  }

  /* ================================
     SUPPRIMER UNE TECHNIQUE
     ================================ */
  async _onDeleteTechnique(event) {
    event.preventDefault();
    
    const index = parseInt(event.currentTarget.dataset.index);
    const techniques = foundry.utils.duplicate(this.item.system.techniques || []);
    
    techniques.splice(index, 1);
    
    await this.item.update({ "system.techniques": techniques });
  }
}
