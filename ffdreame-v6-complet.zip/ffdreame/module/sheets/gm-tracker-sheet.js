/**
 * FEUILLE GM TRACKER V2 - CENTRE DE CONTRÔLE COMPLET
 * Gestion complète du combat et des joueurs pour le MJ
 */
export class FFdreameGMTrackerSheet extends ActorSheet {

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "gm-tracker", "gm-tracker-v2"],
      template: "systems/ffdreame/templates/actor/gm-tracker-sheet.html",
      width: 1200,
      height: 800,
      resizable: true,
      scrollY: [".gm-tracker-body"]
    });
  }

  async getData() {
    const context = super.getData();
    
    // Récupérer tous les personnages joueurs (character + cyberpunk)
    const characters = game.actors.filter(a => a.type === "character" || a.type === "cyberpunk");
    
    // Trier par initiative du Combat Tracker de Foundry
    const sortedCharacters = this._sortByInitiative(characters);
    
    // Préparer les données de chaque joueur
    context.trackedPlayers = sortedCharacters.map(actor => {
      return this._preparePlayerData(actor);
    });
    
    // Récupérer le mode de dés (flag global)
    context.manualDiceMode = game.settings.get('ffdreame', 'manualDiceMode') || false;
    
    return context;
  }

  /**
   * Trier les acteurs par initiative (utilise le Combat Tracker de Foundry)
   */
  _sortByInitiative(characters) {
    const combat = game.combat;
    
    if (!combat) {
      // Pas de combat actif, trier par nom
      return characters.sort((a, b) => a.name.localeCompare(b.name));
    }
    
    return characters.sort((a, b) => {
      const combatantA = combat.combatants.find(c => c.actorId === a.id);
      const combatantB = combat.combatants.find(c => c.actorId === b.id);
      
      const initA = combatantA?.initiative || -999;
      const initB = combatantB?.initiative || -999;
      
      // Initiative DÉCROISSANTE (le plus haut en premier)
      return initB - initA;
    });
  }

  /**
   * Préparer les données d'un joueur
   */
  _preparePlayerData(actor) {
    const system = actor.system;
    
    // PV
    const pvCurrent = system.aptitudes?.pv?.value || 0;
    const pvMax = system.aptitudes?.pv?.max || 1;
    const pvPercent = Math.round((pvCurrent / pvMax) * 100);
    const pvStatus = this._getHealthStatus(pvPercent);
    
    // PM
    const pmCurrent = system.aptitudes?.pm?.value || 0;
    const pmMax = system.aptitudes?.pm?.max || 1;
    const pmPercent = Math.round((pmCurrent / pmMax) * 100);
    const pmStatus = this._getHealthStatus(pmPercent);
    
    // Burste
    const burste = system.combat?.burste || 0;
    const burstePercent = burste;
    
    // Points d'Action (structure modifiée pour faciliter l'affichage)
    const actionPoints = system.combat?.actionPoints || {};
    const pa = {
      grand1: {
        disponible: actionPoints.grand1?.disponible || false,
        petit1: actionPoints.grand1?.petit1 || false,
        petit2: actionPoints.grand1?.petit2 || false
      },
      grand2: {
        disponible: actionPoints.grand2?.disponible || false,
        petit1: actionPoints.grand2?.petit1 || false,
        petit2: actionPoints.grand2?.petit2 || false
      },
      grand3: {
        disponible: actionPoints.grand3?.disponible || false,
        petit1: actionPoints.grand3?.petit1 || false,
        petit2: actionPoints.grand3?.petit2 || false
      }
    };
    
    // Fatigue & Blessures (tableau de 10 cases chacun)
    const fatigue = [];
    const blessure = [];
    for (let i = 1; i <= 10; i++) {
      fatigue.push(system.combat?.fatigue?.[`case${i}`] || false);
      blessure.push(system.combat?.blessure?.[`case${i}`] || false);
    }
    
    // Initiative (du Combat Tracker Foundry)
    const combat = game.combat;
    const combatant = combat?.combatants?.find(c => c.actorId === actor.id);
    const initiative = combatant?.initiative || null;
    const inCombat = !!combatant;
    
    // État bloqué (flag personnalisé)
    const actionBlocked = actor.getFlag('ffdreame', 'actionBlocked') || false;
    
    return {
      id: actor.id,
      name: actor.name,
      pvCurrent,
      pvMax,
      pvPercent,
      pvStatus,
      pmCurrent,
      pmMax,
      pmPercent,
      pmStatus,
      burste,
      burstePercent,
      pa,
      fatigue,
      blessure,
      initiative,
      inCombat,
      actionBlocked,
      healthStatus: pvStatus // Pour la classe CSS du background
    };
  }

  /**
   * Déterminer le statut de santé (couleur)
   */
  _getHealthStatus(percent) {
    if (percent > 70) return 'healthy';
    if (percent > 30) return 'injured';
    return 'critical';
  }

  /* ================================
     EVENT LISTENERS
     ================================ */
  activateListeners(html) {
    super.activateListeners(html);
    
    // Bouton Initiative (ouvre le Combat Tracker)
    html.find('.btn-init-combat').click(this._onInitCombat.bind(this));
    
    // Bouton Nouveau Tour
    html.find('.btn-nouveau-tour').click(this._onNouveauTour.bind(this));
    
    // Toggle Mode Dés (Auto/Manuel)
    html.find('.btn-dice-mode').click(this._onToggleDiceMode.bind(this));
    
    // Bouton Rafraîchir
    html.find('.btn-refresh-tracker').click(() => this.render(true));
    
    // Clic sur PA (Grand ou Petit)
    html.find('.pa-grand-box, .pa-petit-box').click(this._onTogglePA.bind(this));
    
    // Clic sur Fatigue/Blessure
    html.find('.penalty-box').click(this._onTogglePenalty.bind(this));
    
    // Bouton Fin d'Action
    html.find('.btn-end-action').click(this._onToggleActionBlock.bind(this));
    
    // Bouton Reset PA individuel
    html.find('.btn-reset-pa-player').click(this._onResetPlayerPA.bind(this));
    
    // Bouton Ouvrir fiche
    html.find('.btn-open-sheet').click(this._onOpenSheet.bind(this));
  }

  /* ================================
     ACTIONS MJ
     ================================ */
  
  /**
   * Toggle Mode Dés (Auto/Manuel)
   */
  async _onToggleDiceMode(event) {
    event.preventDefault();
    const mode = event.currentTarget.dataset.mode;
    
    const isManual = mode === 'manual';
    
    await game.settings.set('ffdreame', 'manualDiceMode', isManual);
    
    const modeLabel = isManual ? 'MANUEL' : 'AUTO';
    const modeIcon = isManual ? '✍️' : '🎲';
    
    ui.notifications.info(`${modeIcon} Mode ${modeLabel} activé`);
    
    this.render(false);
  }
  
  /**
   * Lancer l'initiative (ouvre le Combat Tracker de Foundry)
   */
  async _onInitCombat(event) {
    event.preventDefault();
    
    // Si combat déjà actif, demander confirmation
    if (game.combat) {
      const confirm = await Dialog.confirm({
        title: "Combat en cours",
        content: "<p>Un combat est déjà en cours. Voulez-vous le terminer et en créer un nouveau ?</p>",
        yes: () => true,
        no: () => false
      });
      
      if (!confirm) return;
      
      // Terminer le combat actuel
      await game.combat.delete();
    }
    
    // Créer un nouveau combat
    const combat = await Combat.create({
      scene: canvas.scene?.id,
      active: true
    });
    
    // Ajouter tous les personnages joueurs au combat
    const characters = game.actors.filter(a => a.type === "character" || a.type === "cyberpunk");
    const createData = [];
    
    for (const actor of characters) {
      const tokens = actor.getActiveTokens();
      if (tokens.length > 0) {
        createData.push({
          tokenId: tokens[0].id,
          sceneId: canvas.scene.id,
          actorId: actor.id,
          hidden: false
        });
      }
    }
    
    if (createData.length > 0) {
      await combat.createEmbeddedDocuments("Combatant", createData);
      
      // Lancer l'initiative pour tous
      await combat.rollAll();
      
      // === INITIATIVE ASSURÉE ===
      // Appliquer directement après rollAll() : chercher les acteurs avec l'effet actif
      for (const combatant of combat.combatants) {
        const actor = combatant.actor;
        if (!actor) continue;
        
        // Chercher l'effet "initiative_assuree" sur le tableau ACTIF
        let hasInitAssuree = false;
        for (const key of ['tableau1', 'tableau2']) {
          const tab = actor.system?.combat?.[key];
          if (!tab?.actif) continue;
          const effet = tab.effet;
          if (effet && effet.type === 'initiative_assuree' && 
              (effet.actif || effet.condition === 'permanent')) {
            hasInitAssuree = true;
            break;
          }
        }
        if (!hasInitAssuree) continue;
        
        // Vérifier flag "déjà utilisé ce combat"
        let dejaUtilise = false;
        try { dejaUtilise = await actor.getFlag('ffdreame', 'initiativeAssureePrise'); } catch(e) {}
        if (dejaUtilise) continue;
        
        console.log(`FFdreame | Initiative Assurée → ${actor.name}`);
        
        // Marquer comme utilisé pour ce combat
        await actor.setFlag('ffdreame', 'initiativeAssureePrise', true);
        
        // Forcer initiative à 999 (toujours premier)
        await combat.setInitiative(combatant.id, 999);
        
        // Message chat
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div style="background:rgba(255,215,0,0.08);border:1px solid #ffd700;border-radius:8px;padding:10px;">
            <h3 style="color:#ffd700;margin:0 0 5px;">⚡ Initiative Assurée !</h3>
            <p style="margin:0;color:#ddd;"><b>${actor.name}</b> agit en premier grâce à son effet de tableau.<br>
            <em style="color:#aaa;font-size:0.9em;">(Une seule fois par combat)</em></p></div>`
        });
      }
      // === FIN INITIATIVE ASSURÉE ===
      
      ui.notifications.info("🎲 Initiative lancée pour tous les joueurs !");
    } else {
      ui.notifications.warn("⚠️ Aucun token de joueur trouvé sur la scène active !");
    }
    
    // Ouvrir le Combat Tracker
    ui.combat.render(true);
    
    this.render(false);
  }

  /**
   * Nouveau Tour : réinitialise les PA de tous les joueurs ET reset le round
   */
  async _onNouveauTour(event) {
    event.preventDefault();
    
    const confirm = await Dialog.confirm({
      title: "Nouveau Tour",
      content: `
        <p>Réinitialiser les Points d'Action de <strong>tous les joueurs</strong> ?</p>
        <p>Les 3 Grands PA (avec leurs Petits PA) seront restaurés.</p>
        <p><strong>Le tour recommencera au premier joueur de l'initiative.</strong></p>
      `,
      yes: () => true,
      no: () => false
    });
    
    if (!confirm) return;
    
    const characters = game.actors.filter(a => a.type === "character" || a.type === "cyberpunk");
    
    console.log(`🔄 NOUVEAU TOUR - Réinitialisation pour ${characters.length} joueurs`);
    
    // Réinitialiser les PA de chaque joueur
    for (const actor of characters) {
      console.log(`  → ${actor.name}: Réinitialisation PA...`);
      
      // Créer un objet actionPoints complet
      const newActionPoints = {
        grand1: {
          disponible: true,
          petit1: true,
          petit2: true
        },
        grand2: {
          disponible: true,
          petit1: true,
          petit2: true
        },
        grand3: {
          disponible: true,
          petit1: true,
          petit2: true
        }
      };
      
      // Mettre à jour en une seule fois
      await actor.update({
        'system.combat.actionPoints': newActionPoints,
        'system.combat.deplacementGratuitUtilise': false // Reset déplacement gratuit
      });
      
      // Débloquer le joueur
      await actor.setFlag('ffdreame', 'actionBlocked', false);
      
      console.log(`  ✅ ${actor.name}: 3 Grands PA restaurés + débloqué`);
    }
    
    // RESET LE ROUND DANS LE COMBAT TRACKER
    if (game.combat) {
      console.log("🎲 Reset du round au début (tour 1, combattant 1)");
      
      // Passer au round suivant
      await game.combat.nextRound();
      
      ui.notifications.info(`🔄 Nouveau tour ! Round ${game.combat.round} - PA réinitialisés.`);
    } else {
      ui.notifications.info(`🔄 Nouveau tour ! PA réinitialisés pour ${characters.length} joueur(s).`);
    }
    
    this.render(false);
  }

  /**
   * Toggle PA (Grand ou Petit)
   */
  async _onTogglePA(event) {
    event.preventDefault();
    const btn = event.currentTarget;
    
    const actorId = btn.dataset.actorId;
    const grand = btn.dataset.grand;
    const type = btn.dataset.type;
    const petit = btn.dataset.petit;
    
    const actor = game.actors.get(actorId);
    if (!actor) return;
    
    console.log(`⚡ Toggle PA - Actor: ${actor.name}, Type: ${type}, Grand: ${grand}, Petit: ${petit}`);
    
    if (type === 'grand') {
      // Toggle Grand PA
      const currentValue = actor.system.combat?.actionPoints?.[`grand${grand}`]?.disponible;
      const newValue = currentValue === undefined ? false : !currentValue;
      
      console.log(`  → Grand PA ${grand}: ${currentValue} → ${newValue}`);
      
      await actor.update({
        [`system.combat.actionPoints.grand${grand}.disponible`]: newValue,
        [`system.combat.actionPoints.grand${grand}.petit1`]: newValue,
        [`system.combat.actionPoints.grand${grand}.petit2`]: newValue
      });
      
      console.log(`  → ✅ Grand PA ${grand} mis à jour`);
    } else if (type === 'petit') {
      // Toggle Petit PA
      const currentValue = actor.system.combat?.actionPoints?.[`grand${grand}`]?.[`petit${petit}`];
      const newValue = currentValue === undefined ? false : !currentValue;
      
      console.log(`  → Petit PA ${grand}.${petit}: ${currentValue} → ${newValue}`);
      
      await actor.update({
        [`system.combat.actionPoints.grand${grand}.petit${petit}`]: newValue
      });
      
      console.log(`  → ✅ Petit PA ${grand}.${petit} mis à jour`);
    }
    
    this.render(false);
  }

  /**
   * Toggle Fatigue/Blessure
   */
  async _onTogglePenalty(event) {
    event.preventDefault();
    const btn = event.currentTarget;
    
    const actorId = btn.dataset.actorId;
    const type = btn.dataset.type; // 'fatigue' ou 'blessure'
    const index = parseInt(btn.dataset.index);
    
    const actor = game.actors.get(actorId);
    if (!actor) return;
    
    const caseNum = index + 1;
    const currentValue = actor.system.combat?.[type]?.[`case${caseNum}`] || false;
    
    await actor.update({
      [`system.combat.${type}.case${caseNum}`]: !currentValue
    });
    
    const label = type === 'fatigue' ? 'Fatigue' : 'Blessure';
    ui.notifications.info(`${label} ${caseNum} ${!currentValue ? 'activée' : 'désactivée'} pour ${actor.name}`);
    
    this.render(false);
  }

  /**
   * Toggle Action Bloquée
   */
  async _onToggleActionBlock(event) {
    event.preventDefault();
    const btn = event.currentTarget;
    
    const actorId = btn.dataset.actorId;
    const actor = game.actors.get(actorId);
    if (!actor) return;
    
    const currentValue = actor.getFlag('ffdreame', 'actionBlocked') || false;
    await actor.setFlag('ffdreame', 'actionBlocked', !currentValue);
    
    if (!currentValue) {
      ui.notifications.info(`🔒 ${actor.name} ne peut plus agir jusqu'au prochain tour.`);
    } else {
      ui.notifications.info(`🔓 ${actor.name} peut à nouveau agir.`);
    }
    
    this.render(false);
  }

  /**
   * Reset PA d'un joueur spécifique
   */
  async _onResetPlayerPA(event) {
    event.preventDefault();
    event.stopPropagation();
    
    const actorId = event.currentTarget.dataset.actorId;
    const actor = game.actors.get(actorId);
    if (!actor) return;
    
    console.log(`🔄 Reset PA pour ${actor.name}`);
    
    // Créer un objet actionPoints complet
    const newActionPoints = {
      grand1: {
        disponible: true,
        petit1: true,
        petit2: true
      },
      grand2: {
        disponible: true,
        petit1: true,
        petit2: true
      },
      grand3: {
        disponible: true,
        petit1: true,
        petit2: true
      }
    };
    
    await actor.update({
      'system.combat.actionPoints': newActionPoints
    });
    
    console.log(`✅ ${actor.name}: 3 Grands PA restaurés`);
    
    ui.notifications.info(`🔄 PA réinitialisés pour ${actor.name}`);
    
    this.render(false);
  }

  /**
   * Ouvrir la fiche du joueur
   */
  _onOpenSheet(event) {
    event.preventDefault();
    const actorId = event.currentTarget.dataset.actorId;
    const actor = game.actors.get(actorId);
    if (actor) {
      actor.sheet.render(true);
    }
  }
}
