/**
 * Feuille de personnage NPC simplifiée pour FFdreame
 */
export class FFdreameNPCSheet extends ActorSheet {

  /* ================================
     OPTIONS DE LA FEUILLE
     ================================ */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "actor", "npc"],
      template: "systems/ffdreame/templates/actor/npc-sheet.html",
      width: 800,
      height: 700,
      resizable: true
    });
  }

  /* ================================
     PRÉPARATION DES DONNÉES
     ================================ */
  async getData() {
    const context = super.getData();
    
    const actorData = this.actor.toObject(false);
    context.system = actorData.system;
    context.flags = actorData.flags;
    
    // Préparer les items pour les lookups dans le template
    context.items = {};
    for (const item of this.actor.items) {
      context.items[item.id] = {
        id: item.id,
        name: item.name,
        img: item.img,
        type: item.type,
        system: item.system
      };
    }
    
    return context;
  }

  /* ================================
     ACTIVATION DES ÉVÉNEMENTS
     ================================ */
  activateListeners(html) {
    super.activateListeners(html);

    // Boutons de réaction
    html.find('.btn-reaction').on('click', this._onToggleReaction.bind(this));

    // Slots du tableau (drag & drop)
    html.find('.table-slot').on('click', this._onSlotClick.bind(this));
    html.find('.table-slot').on('dragstart', this._onDragStart.bind(this));
    html.find('.table-slot').on('dragover', this._onDragOver.bind(this));
    html.find('.table-slot').on('drop', this._onDrop.bind(this));
  }

  /* ================================
     TOGGLE RÉACTIONS
     ================================ */
  async _onToggleReaction(event) {
    event.preventDefault();
    const button = event.currentTarget;
    const reactionType = button.dataset.reaction;
    
    // Vérifier si bloqué
    const actionBlocked = this.actor.getFlag('ffdreame', 'actionBlocked');
    if (actionBlocked) {
      ui.notifications.warn("🔒 Les actions sont bloquées !");
      return;
    }
    
    const currentState = this.actor.system.combat.reactions[reactionType];
    
    if (currentState) {
      // Désactiver
      await this.actor.update({
        [`system.combat.reactions.${reactionType}`]: false
      });
      
      const labels = {
        esquive: 'Esquive',
        defense: 'Défense',
        marche: 'Marche'
      };
      
      ui.notifications.info(`${labels[reactionType]} désactivée`);
    } else {
      // Activer → Consommer 1 Petit PA
      const actionPoints = this.actor.system.combat.actionPoints;
      let petitDispo = null;
      
      for (let g = 1; g <= 3; g++) {
        for (let p = 1; p <= 2; p++) {
          if (actionPoints[`grand${g}`]?.[`petit${p}`]) {
            petitDispo = { grand: g, petit: p };
            break;
          }
        }
        if (petitDispo) break;
      }
      
      if (!petitDispo) {
        ui.notifications.warn("⚠️ Pas de Petit PA disponible !");
        return;
      }
      
      await this.actor.update({
        [`system.combat.actionPoints.grand${petitDispo.grand}.petit${petitDispo.petit}`]: false,
        [`system.combat.reactions.${reactionType}`]: true
      });
      
      const labels = {
        esquive: 'Esquive',
        defense: 'Défense', 
        marche: 'Marche'
      };
      
      const icons = {
        esquive: '🤸',
        defense: '🛡️',
        marche: '🚶'
      };
      
      ui.notifications.info(`${icons[reactionType]} ${labels[reactionType]} activée !`);
    }
  }

  /* ================================
     GESTION DES SLOTS DU TABLEAU
     ================================ */
  async _onSlotClick(event) {
    event.preventDefault();
    const slot = event.currentTarget;
    const slotKey = slot.dataset.slot;
    const itemId = slot.dataset.itemId;
    
    if (!itemId) return;
    
    // Utiliser la technique
    const item = this.actor.items.get(itemId);
    if (item && item.type === 'technique') {
      await this._useTableTechnique(item);
    }
  }

  _onDragStart(event) {
    const slot = event.currentTarget;
    const itemId = slot.dataset.itemId;
    
    if (!itemId) return;
    
    const item = this.actor.items.get(itemId);
    if (!item) return;
    
    event.dataTransfer.setData('text/plain', JSON.stringify({
      type: 'Item',
      uuid: item.uuid
    }));
  }

  _onDragOver(event) {
    event.preventDefault();
    return false;
  }

  async _onDrop(event) {
    event.preventDefault();
    
    const data = JSON.parse(event.dataTransfer.getData('text/plain'));
    if (data.type !== 'Item') return;
    
    const item = await fromUuid(data.uuid);
    if (!item || item.type !== 'technique') {
      ui.notifications.warn("Seules les techniques peuvent être ajoutées !");
      return;
    }
    
    const slot = event.currentTarget;
    const slotKey = slot.dataset.slot;
    
    await this.actor.update({
      [`system.combat.tableau.slots.${slotKey}`]: item.id
    });
    
    ui.notifications.info(`${item.name} ajouté au tableau !`);
  }

  /* ================================
     UTILISER UNE TECHNIQUE (Simplifié pour NPC)
     ================================ */
  async _useTableTechnique(technique) {
    // Vérifier si bloqué
    const actionBlocked = this.actor.getFlag('ffdreame', 'actionBlocked');
    if (actionBlocked && !game.user.isGM) {
      ui.notifications.warn("🔒 Les actions sont bloquées !");
      return;
    }
    
    // Utiliser la même logique que les joueurs
    // On importe simplement la méthode de FFdreameActorSheet
    const FFdreameActorSheet = await import('./actor-sheet.js').then(m => m.FFdreameActorSheet);
    
    // Appeler la méthode du joueur
    await FFdreameActorSheet.prototype._useTableTechnique.call(this, technique);
  }
}
