/**
 * Feuille de personnage Cyberpunk pour FFdreame
 * Utilise le même code que FFdreameActorSheet mais avec un template différent
 */
import { FFdreameActorSheet } from "./actor-sheet.js";

export class FFdreameCyberpunkSheet extends FFdreameActorSheet {

  /* ================================
     OPTIONS DE LA FEUILLE CYBERPUNK
     ================================ */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["ffdreame", "sheet", "actor", "cyberpunk"],
      template: "systems/ffdreame/templates/actor/cyberpunk-character-sheet.html",
      width: 1000,
      height: 800,
      resizable: true,
      tabs: [{ 
        navSelector: ".cyber-tabs", 
        contentSelector: ".cyber-body", 
        initial: "principal" 
      }]
    });
  }

  /* Tout le reste est hérité de FFdreameActorSheet */
}
