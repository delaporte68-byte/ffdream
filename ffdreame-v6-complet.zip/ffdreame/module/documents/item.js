/**
 * Extension de la classe Item pour FFdreame
 */
export class FFdreameItem extends Item {
  
  prepareData() {
    super.prepareData();
  }

  prepareDerivedData() {
    super.prepareDerivedData();
  }
}
