/* ============================================
   DRAG & DROP TECHNIQUES → MACRO BAR
   ============================================ */

export class FFdreameTechniqueMacro {
  
  /* ================================
     RENDRE LES TECHNIQUES DRAGGABLES
     ================================ */
  static makeTechniquesDraggable(html, actor) {
    // Tous les slots de tableaux
    html.find('.table-slot.slot-filled').each((i, slot) => {
      const itemId = $(slot).data('item-id');
      if (!itemId) return;
      
      const item = actor.items.get(itemId);
      if (!item || item.type !== 'technique') return;
      
      // Rendre draggable
      slot.setAttribute('draggable', 'true');
      
      slot.addEventListener('dragstart', (event) => {
        // Données à transférer
        const dragData = {
          type: 'Macro',
          actorId: actor.id,
          itemId: item.id,
          itemName: item.name,
          itemType: item.type
        };
        
        event.dataTransfer.setData('text/plain', JSON.stringify(dragData));
      });
    });
  }
  
  /* ================================
     CRÉER UNE MACRO DEPUIS UNE TECHNIQUE
     ================================ */
  static async createTechniqueMacro(actorId, itemId, itemName, slot) {
    // Vérifier si une macro existe déjà
    const existingMacro = game.macros.find(m => 
      m.name === itemName && m.command.includes(itemId)
    );
    
    if (existingMacro) {
      // Assigner à la hotbar
      game.user.assignHotbarMacro(existingMacro, slot);
      return;
    }
    
    // Créer la nouvelle macro
    const macroData = {
      name: itemName,
      type: "script",
      img: "icons/svg/dice-target.svg",
      command: `
// Macro FFdreame - ${itemName}
const actorId = "${actorId}";
const itemId = "${itemId}";

const actor = game.actors.get(actorId);
if (!actor) {
  ui.notifications.warn("Personnage introuvable !");
  return;
}

const item = actor.items.get(itemId);
if (!item) {
  ui.notifications.warn("Technique introuvable !");
  return;
}

// Vérifier que c'est bien une technique
if (item.type !== "technique") {
  ui.notifications.warn("Cet item n'est pas une technique !");
  return;
}

// Utiliser la technique
const sheet = actor.sheet;
if (sheet && sheet._useTableTechnique) {
  await sheet._useTableTechnique(item);
} else {
  ui.notifications.error("Impossible d'utiliser la technique !");
}
      `,
      flags: {
        ffdreame: {
          actorId: actorId,
          itemId: itemId,
          techniqueType: "technique"
        }
      }
    };
    
    const macro = await Macro.create(macroData);
    game.user.assignHotbarMacro(macro, slot);
    
    ui.notifications.info(`Macro "${itemName}" créée !`);
  }
}

/* ================================
   HOOK POUR LE DROP SUR LA HOTBAR
   ================================ */
Hooks.on("hotbarDrop", async (bar, data, slot) => {
  // Vérifier si c'est une technique FFdreame
  if (data.type === "Macro" && data.itemType === "technique") {
    await FFdreameTechniqueMacro.createTechniqueMacro(
      data.actorId,
      data.itemId,
      data.itemName,
      slot
    );
    return false; // Empêcher le comportement par défaut
  }
});
