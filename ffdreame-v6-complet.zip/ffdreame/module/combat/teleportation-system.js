/**
 * ============================================
 * SYSTÈME DE TÉLÉPORTATION FFDREAME
 * ============================================
 * Gère les déplacements du lanceur et de la cible
 * après l'utilisation d'une technique
 */

export class FFdreameTeleportation {
  
  /**
   * Gérer la téléportation après une technique réussie
   * @param {Actor} lanceur - L'acteur qui lance la technique
   * @param {Token} cibleToken - Le token ciblé (optionnel)
   * @param {Object} teleportConfig - Configuration de la téléportation
   */
  static async handleTeleportation(lanceur, cibleToken, teleportConfig) {
    console.log('🚀🚀🚀 === DÉBUT TÉLÉPORTATION === 🚀🚀🚀');
    console.log('Lanceur:', lanceur.name);
    console.log('Cible token:', cibleToken?.name);
    console.log('Config:', teleportConfig);
    
    if (!teleportConfig || !teleportConfig.actif) {
      console.log('❌ Téléportation non activée dans la config');
      return; // Pas de téléportation
    }
    
    const lanceurToken = lanceur.getActiveTokens()[0];
    if (!lanceurToken) {
      console.error("❌ Token du lanceur introuvable");
      return;
    }
    
    console.log('✅ Token lanceur trouvé:', lanceurToken.name);
    
    const type = teleportConfig.type; // "lanceur" ou "cible"
    const distanceMax = teleportConfig.distanceMax || 5;
    
    console.log(`📍 Type: ${type}, Distance max: ${distanceMax}m`);
    
    if (type === "lanceur") {
      console.log('🎯 Téléportation du lanceur...');
      await this._teleporterLanceur(lanceurToken, cibleToken, teleportConfig);
    } else if (type === "cible") {
      console.log('🎯 Téléportation de la cible...');
      await this._teleporterCible(lanceurToken, cibleToken, teleportConfig);
    } else {
      console.error(`❌ Type de téléportation inconnu: ${type}`);
    }
    
    console.log('🚀🚀🚀 === FIN TÉLÉPORTATION === 🚀🚀🚀\n');
  }
  
  /**
   * Téléporter le lanceur autour de la cible
   */
  static async _teleporterLanceur(lanceurToken, cibleToken, config) {
    if (!cibleToken) {
      ui.notifications.warn("⚠️ Pas de cible pour la téléportation !");
      return;
    }
    
    const position = config.position || "derriere";
    const gridSize = canvas.grid.size;
    
    // Calculer la position relative à la cible
    let offsetX = 0;
    let offsetY = 0;
    
    switch (position) {
      case "derriere":
        offsetY = -gridSize; // Derrière = en haut sur la grille
        break;
      case "devant":
        offsetY = gridSize; // Devant = en bas
        break;
      case "gauche":
        offsetX = -gridSize; // Gauche
        break;
      case "droite":
        offsetX = gridSize; // Droite
        break;
    }
    
    // Calculer la nouvelle position
    const newX = cibleToken.x + offsetX;
    const newY = cibleToken.y + offsetY;
    
    // Vérifier que la position est dans les limites de la scène
    if (newX < 0 || newY < 0 || newX > canvas.scene.width || newY > canvas.scene.height) {
      ui.notifications.warn("⚠️ Position de téléportation hors de la scène !");
      return;
    }
    
    // Vérifier la distance depuis la position d'origine
    const deltaX = (newX - lanceurToken.x) / gridSize;
    const deltaY = (newY - lanceurToken.y) / gridSize;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    const gridDistance = canvas.scene.grid.distance || 1.5;
    const distanceMetres = distance * gridDistance;
    
    if (distanceMetres > config.distanceMax) {
      ui.notifications.warn(
        `⚠️ Téléportation trop loin !<br>` +
        `Distance: ${distanceMetres.toFixed(1)}m<br>` +
        `Max: ${config.distanceMax}m`
      );
      return;
    }
    
    // Téléporter le token
    await lanceurToken.document.update({
      x: newX,
      y: newY
    }, { animate: false, isTeleportation: true });
    
    // Animation visuelle (si Sequencer disponible)
    await this._jouerAnimationTeleportation(lanceurToken, newX, newY);
    
    const positionLabels = {
      derriere: "derrière",
      devant: "devant",
      gauche: "à gauche de",
      droite: "à droite de"
    };
    
    ui.notifications.info(`✨ ${lanceurToken.name} se téléporte ${positionLabels[position]} ${cibleToken.name} !`);
    
    console.log(`✨ Téléportation lanceur: ${lanceurToken.name} → ${position} de ${cibleToken.name}`);
  }
  
  /**
   * Téléporter la cible vers un point choisi par le joueur
   */
  static async _teleporterCible(lanceurToken, cibleToken, config) {
    if (!cibleToken) {
      ui.notifications.warn("⚠️ Pas de cible pour la téléportation !");
      return;
    }
    
    const distanceMax = config.distanceMax || 5;
    const gridSize = canvas.grid.size;
    const gridDistance = canvas.scene.grid.distance || 1.5;
    
    ui.notifications.info("🎯 Cliquez pour choisir la destination de la téléportation");
    
    return new Promise((resolve) => {
      const clickHandler = async (event) => {
        const pos = event.data.getLocalPosition(canvas.tokens);
        
        // Calculer la distance depuis la position actuelle de la cible
        const deltaX = (pos.x - cibleToken.x) / gridSize;
        const deltaY = (pos.y - cibleToken.y) / gridSize;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        const distanceMetres = distance * gridDistance;
        
        if (distanceMetres > distanceMax) {
          ui.notifications.warn(
            `⚠️ Téléportation trop loin !<br>` +
            `Distance: ${distanceMetres.toFixed(1)}m<br>` +
            `Max: ${distanceMax}m`
          );
          canvas.stage.off("click", clickHandler);
          canvas.stage.off("contextmenu", cancelHandler);
          resolve(false);
          return;
        }
        
        // Téléporter la cible
        await cibleToken.document.update({
          x: pos.x - (cibleToken.width * gridSize / 2),
          y: pos.y - (cibleToken.height * gridSize / 2)
        }, { animate: false, isTeleportation: true });
        
        // Animation visuelle
        await this._jouerAnimationTeleportation(cibleToken, pos.x, pos.y);
        
        ui.notifications.info(`✨ ${cibleToken.name} est téléporté(e) !`);
        
        console.log(`✨ Téléportation cible: ${cibleToken.name} → (${pos.x}, ${pos.y})`);
        
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        resolve(true);
      };
      
      const cancelHandler = () => {
        canvas.stage.off("click", clickHandler);
        canvas.stage.off("contextmenu", cancelHandler);
        ui.notifications.info("❌ Téléportation annulée");
        resolve(false);
      };
      
      canvas.stage.on("click", clickHandler);
      canvas.stage.on("contextmenu", cancelHandler);
    });
  }
  
  /**
   * Jouer une animation de téléportation (si Sequencer disponible)
   */
  static async _jouerAnimationTeleportation(token, newX, newY) {
    if (typeof Sequence === 'undefined') return;
    
    try {
      const sequence = new Sequence();
      
      // Animation de départ
      sequence
        .effect()
        .file("jb2a.misty_step.01.blue")
        .atLocation(token)
        .fadeIn(200)
        .fadeOut(200);
      
      // Animation d'arrivée
      sequence
        .effect()
        .file("jb2a.misty_step.02.blue")
        .atLocation({ x: newX, y: newY })
        .delay(300)
        .fadeIn(200)
        .fadeOut(200);
      
      await sequence.play();
    } catch (error) {
      console.warn("Animation de téléportation impossible:", error);
    }
  }
  
  /**
   * Vérifier si la téléportation est configurée pour une technique
   */
  static isTeleportationEnabled(technique) {
    return technique?.system?.teleportation?.actif || false;
  }
  
  /**
   * Obtenir la configuration de téléportation
   */
  static getTeleportationConfig(technique) {
    return technique?.system?.teleportation || null;
  }
}
