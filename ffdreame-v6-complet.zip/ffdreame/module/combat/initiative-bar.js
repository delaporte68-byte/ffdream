/**
 * ============================================
 * BARRE D'INITIATIVE HORIZONTALE (Style BG3)
 * ============================================
 * Affiche une barre en haut de l'écran avec les portraits
 * des combattants dans l'ordre d'initiative
 */

export class FFdreameInitiativeBar {
  
  /**
   * Initialiser le système
   */
  static init() {
    console.log('FFdreame | Initiative Bar - Initialisation...');
    
    // Hook pour créer/mettre à jour la barre
    Hooks.on("updateCombat", this._onUpdateCombat.bind(this));
    Hooks.on("createCombat", this._onCreateCombat.bind(this));
    Hooks.on("deleteCombat", this._onDeleteCombat.bind(this));
    
    // Hook pour recréer la barre quand un combattant est ajouté/retiré
    Hooks.on("createCombatant", this._onCombatantChange.bind(this));
    Hooks.on("deleteCombatant", this._onCombatantChange.bind(this));
    
    console.log('FFdreame | Initiative Bar - Activée ✅');
  }
  
  /**
   * Créer la barre au début du combat
   */
  static _onCreateCombat(combat) {
    console.log('FFdreame | Combat créé, affichage de la barre');
    this._createBar(combat);
  }
  
  /**
   * Mettre à jour la barre quand le tour change
   */
  static _onUpdateCombat(combat, changed) {
    if (changed.turn !== undefined || changed.round !== undefined) {
      console.log('FFdreame | Tour/Round changé, mise à jour de la barre');
      this._updateBar(combat);
    }
  }
  
  /**
   * Supprimer la barre à la fin du combat
   */
  static _onDeleteCombat() {
    console.log('FFdreame | Combat terminé, suppression de la barre');
    this._removeBar();
  }
  
  /**
   * Mettre à jour la barre quand les combattants changent
   */
  static _onCombatantChange(combatant) {
    if (game.combat) {
      this._updateBar(game.combat);
    }
  }
  
  /**
   * Créer la barre HTML
   */
  static _createBar(combat) {
    // Supprimer l'ancienne barre si elle existe
    this._removeBar();
    
    if (!combat || !combat.started) return;
    
    // Créer le conteneur
    const barContainer = document.createElement('div');
    barContainer.id = 'ffdreame-initiative-bar';
    barContainer.innerHTML = `
      <div class="initiative-track">
        <div class="initiative-portraits"></div>
      </div>
    `;
    
    // Ajouter au DOM
    document.body.appendChild(barContainer);
    
    // Remplir avec les combattants
    this._updateBar(combat);
  }
  
  /**
   * Mettre à jour le contenu de la barre
   */
  static _updateBar(combat) {
    const bar = document.getElementById('ffdreame-initiative-bar');
    if (!bar) {
      this._createBar(combat);
      return;
    }
    
    const portraitsContainer = bar.querySelector('.initiative-portraits');
    if (!portraitsContainer) return;
    
    // Vider le contenu
    portraitsContainer.innerHTML = '';
    
    if (!combat || !combat.started) {
      this._removeBar();
      return;
    }
    
    // Récupérer tous les combattants triés par initiative
    const combatants = combat.turns;
    const currentIndex = combat.turn ?? 0;
    
    // Créer les portraits
    combatants.forEach((combatant, index) => {
      const portrait = this._createPortrait(combatant, index, currentIndex, combat);
      portraitsContainer.appendChild(portrait);
    });
    
    // Scroll vers le combattant actif
    this._scrollToActive();
  }
  
  /**
   * Créer un portrait de combattant
   */
  static _createPortrait(combatant, index, currentIndex, combat) {
    const div = document.createElement('div');
    div.classList.add('initiative-portrait');
    
    // Déterminer le statut
    if (index === currentIndex) {
      div.classList.add('active'); // C'est son tour
    } else if (index < currentIndex) {
      div.classList.add('played'); // A déjà joué
    } else {
      div.classList.add('waiting'); // Attend son tour
    }
    
    // Récupérer les infos
    const actor = combatant.actor;
    const tokenImg = combatant.img || actor?.img || 'icons/svg/mystery-man.svg';
    const name = combatant.name || actor?.name || 'Inconnu';
    const initiative = combatant.initiative ?? 0;
    
    // PV si disponibles
    let pvInfo = '';
    if (actor) {
      const pv = actor.system.aptitudes?.pv?.value ?? 0;
      const pvMax = actor.system.aptitudes?.pv?.max ?? 0;
      const pvPercent = pvMax > 0 ? (pv / pvMax) * 100 : 0;
      
      let pvColor = '#00ff00'; // Vert
      if (pvPercent <= 25) pvColor = '#ff0000'; // Rouge
      else if (pvPercent <= 50) pvColor = '#ff9900'; // Orange
      
      pvInfo = `
        <div class="portrait-hp-bar">
          <div class="portrait-hp-fill" style="width: ${pvPercent}%; background: ${pvColor};"></div>
        </div>
      `;
    }
    
    // Construire le HTML
    div.innerHTML = `
      <div class="portrait-image-wrapper">
        <img src="${tokenImg}" alt="${name}" class="portrait-image" />
        ${combatant.defeated ? '<div class="portrait-defeated">💀</div>' : ''}
      </div>
      ${pvInfo}
      <div class="portrait-name">${name}</div>
      <div class="portrait-init">${initiative}</div>
    `;
    
    // Événement click pour cibler/voir
    div.addEventListener('click', () => {
      this._onPortraitClick(combatant, combat);
    });
    
    return div;
  }
  
  /**
   * Gérer le clic sur un portrait
   */
  static _onPortraitClick(combatant, combat) {
    const token = combatant.token?.object;
    if (token) {
      // Centrer la caméra sur le token
      canvas.animatePan({ x: token.center.x, y: token.center.y, duration: 250 });
      
      // Sélectionner le token si c'est le sien ou si on est MJ
      if (token.actor?.isOwner || game.user.isGM) {
        token.control({ releaseOthers: true });
      }
    }
  }
  
  /**
   * Scroll automatique vers le combattant actif
   */
  static _scrollToActive() {
    setTimeout(() => {
      const activePortrait = document.querySelector('.initiative-portrait.active');
      if (activePortrait) {
        activePortrait.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'nearest', 
          inline: 'center' 
        });
      }
    }, 100);
  }
  
  /**
   * Supprimer la barre
   */
  static _removeBar() {
    const bar = document.getElementById('ffdreame-initiative-bar');
    if (bar) {
      bar.remove();
    }
  }
}
