/**
 * ============================================
 * SYSTÈME DE ZONES PERSISTANTES FFDREAME
 * ============================================
 * Gère les zones d'effet qui restent sur la carte
 * et infligent des dégâts aux tokens qui y entrent
 */

export class FFdreamePersistentZones {
  
  /**
   * Créer une zone persistante
   * @param {Actor} lanceur - L'acteur qui crée la zone
   * @param {Object} position - Position {x, y} ou token ciblé
   * @param {Object} zoneConfig - Configuration de la zone
   * @param {Object} technique - La technique utilisée
   */
  static async createPersistentZone(lanceur, position, zoneConfig, technique) {
    if (!zoneConfig || !zoneConfig.persistante) {
      return null; // Pas de zone persistante
    }
    
    console.log(`🧊 Création d'une zone persistante : ${technique.name}`);
    
    // Créer le template Foundry qui représente la zone
    const templateData = await this._createZoneTemplate(position, zoneConfig, technique);
    
    if (!templateData) {
      console.warn("Impossible de créer le template de zone");
      return null;
    }
    
    const templates = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]);
    const template = templates[0];
    
    // Stocker les données de la zone dans les flags
    await template.setFlag('ffdreame', 'persistentZone', {
      lanceurId: lanceur.id,
      techniqueName: technique.name,
      degatsParTour: zoneConfig.degatsParTour || 0,
      dureeTours: zoneConfig.dureeTours || 3,
      tourActuel: 0,
      animation: zoneConfig.animation || technique.system.animation?.jb2a,
      createdRound: game.combat?.round || 0
    });
    
    // Jouer l'animation persistante si disponible
    await this._playPersistentAnimation(template, zoneConfig, technique);
    
    // Afficher un message
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: lanceur }),
      content: `
        <div style="background: rgba(138, 43, 226, 0.2); padding: 15px; border-left: 4px solid #8a2be2; border-radius: 8px;">
          <h3 style="margin: 0 0 10px 0; color: #8a2be2;">🧊 Zone Persistante Créée</h3>
          <p><strong>${technique.name}</strong></p>
          <p>💥 Dégâts par tour : <strong>${zoneConfig.degatsParTour}</strong></p>
          <p>⏱️ Durée : <strong>${zoneConfig.dureeTours} tours</strong></p>
          <p style="font-size: 12px; color: #999; margin-top: 10px;">
            Les tokens dans cette zone subiront des dégâts à chaque tour.
          </p>
        </div>
      `
    });
    
    ui.notifications.info(`🧊 Zone persistante créée : ${technique.name} (${zoneConfig.dureeTours} tours)`);
    
    return template;
  }
  
  /**
   * Créer le template de la zone
   */
  static async _createZoneTemplate(position, zoneConfig, technique) {
    let templateData = {
      t: "circle",
      user: game.user.id,
      distance: 2, // Rayon par défaut
      fillColor: game.user.color || "#8a2be2",
      borderColor: "#8a2be2",
      flags: {
        ffdreame: {
          persistentZone: true
        }
      }
    };
    
    // Si c'est une position {x, y}
    if (position && position.x !== undefined && position.y !== undefined) {
      templateData.x = position.x;
      templateData.y = position.y;
    }
    // Si c'est un token
    else if (position && position.center) {
      templateData.x = position.center.x;
      templateData.y = position.center.y;
    }
    else {
      return null;
    }
    
    // Si la technique est MULTI, utiliser sa config
    if (technique.system.style === 'multi' && technique.system.multi) {
      const multiConfig = technique.system.multi;
      
      if (multiConfig.type === 'zone') {
        templateData.t = "circle";
        templateData.distance = multiConfig.largeur / 2; // Rayon = largeur / 2
      } else if (multiConfig.type === 'ligne') {
        templateData.t = "ray";
        templateData.distance = multiConfig.distanceMax;
        templateData.width = multiConfig.largeur;
      }
    }
    
    return templateData;
  }
  
  /**
   * Jouer l'animation persistante
   */
  static async _playPersistentAnimation(template, zoneConfig, technique) {
    if (typeof Sequence === 'undefined') {
      console.log("Sequencer non disponible pour l'animation persistante");
      return;
    }
    
    const animation = zoneConfig.animation || technique.system.animation?.jb2a;
    if (!animation) return;
    
    try {
      const sequence = new Sequence();
      
      // Animation qui reste en boucle
      sequence
        .effect()
        .file(animation)
        .atLocation({ x: template.x, y: template.y })
        .size(template.distance * 2 * canvas.grid.size, { gridUnits: false })
        .persist()
        .name(`persistent-zone-${template.id}`)
        .fadeIn(500)
        .fadeOut(500);
      
      await sequence.play();
      
      console.log(`🎬 Animation persistante lancée pour zone ${template.id}`);
    } catch (error) {
      console.warn("Erreur animation persistante:", error);
    }
  }
  
  /**
   * Initialiser le système (appeler au démarrage)
   */
  static init() {
    console.log('FFdreame | Initialisation des zones persistantes...');
    
    // Hook pour vérifier les tokens dans les zones à chaque tour
    Hooks.on("updateCombat", this._onCombatUpdate.bind(this));
    
    // Hook pour nettoyer les zones expirées
    Hooks.on("updateCombat", this._cleanupExpiredZones.bind(this));
    
    console.log('FFdreame | Zones persistantes activées ✅');
  }
  
  /**
   * Gérer le changement de tour (appliquer dégâts)
   */
  static async _onCombatUpdate(combat, changed, options, userId) {
    // Détecter le changement de round
    if (changed.round === undefined) return;
    
    console.log(`🔄 Nouveau round ${changed.round} - Vérification des zones persistantes`);
    
    // Récupérer toutes les zones persistantes
    const zones = canvas.templates.placeables.filter(t => 
      t.document.getFlag('ffdreame', 'persistentZone')
    );
    
    if (zones.length === 0) return;
    
    console.log(`🧊 ${zones.length} zone(s) persistante(s) trouvée(s)`);
    
    for (const zone of zones) {
      await this._processZoneDamage(zone, combat);
    }
  }
  
  /**
   * Traiter les dégâts d'une zone
   */
  static async _processZoneDamage(zoneTemplate, combat) {
    const zoneData = zoneTemplate.document.getFlag('ffdreame', 'persistentZone');
    if (!zoneData) return;
    
    const lanceur = game.actors.get(zoneData.lanceurId);
    if (!lanceur) return;
    
    // Incrémenter le tour actuel
    zoneData.tourActuel++;
    await zoneTemplate.document.setFlag('ffdreame', 'persistentZone', zoneData);
    
    console.log(`🧊 Zone "${zoneData.techniqueName}" - Tour ${zoneData.tourActuel}/${zoneData.dureeTours}`);
    
    // Trouver les tokens dans la zone
    const tokensInZone = this._getTokensInZone(zoneTemplate);
    
    if (tokensInZone.length === 0) {
      console.log(`   Aucun token dans la zone`);
      return;
    }
    
    console.log(`   ${tokensInZone.length} token(s) dans la zone`);
    
    // Appliquer les dégâts à chaque token
    for (const token of tokensInZone) {
      // Ne pas blesser le lanceur (optionnel)
      if (token.actor.id === zoneData.lanceurId) {
        console.log(`   Ignoré: ${token.name} (lanceur)`);
        continue;
      }
      
      const degats = zoneData.degatsParTour;
      const pvActuel = token.actor.system.aptitudes?.pv?.value || 0;
      const nouveauPV = Math.max(0, pvActuel - degats);
      
      await token.actor.update({
        'system.aptitudes.pv.value': nouveauPV
      });
      
      console.log(`   💥 ${token.name}: ${pvActuel} → ${nouveauPV} (-${degats})`);
      
      // Message de dégâts
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: lanceur }),
        content: `
          <div style="background: rgba(138, 43, 226, 0.2); padding: 10px; border-left: 3px solid #8a2be2;">
            <strong>🧊 ${zoneData.techniqueName}</strong><br/>
            <strong>${token.name}</strong> subit <strong>${degats} dégâts</strong> de la zone !<br/>
            <small>PV: ${pvActuel} → ${nouveauPV}</small>
          </div>
        `
      });
      
      if (nouveauPV === 0) {
        ui.notifications.warn(`💀 ${token.name} est K.O. à cause de la zone !`);
      }
    }
  }
  
  /**
   * Récupérer les tokens dans une zone
   */
  static _getTokensInZone(zoneTemplate) {
    const tokens = [];
    
    for (const token of canvas.tokens.placeables) {
      if (this._isTokenInZone(token, zoneTemplate)) {
        tokens.push(token);
      }
    }
    
    return tokens;
  }
  
  /**
   * Vérifier si un token est dans une zone
   */
  static _isTokenInZone(token, zoneTemplate) {
    const template = zoneTemplate.document;
    
    if (template.t === "circle") {
      // Zone circulaire
      const dx = token.center.x - template.x;
      const dy = token.center.y - template.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const radius = template.distance * canvas.grid.size;
      
      return distance <= radius;
    }
    else if (template.t === "ray") {
      // Zone linéaire (à implémenter si nécessaire)
      // Pour l'instant, on considère que c'est dans la zone
      return false;
    }
    
    return false;
  }
  
  /**
   * Nettoyer les zones expirées
   */
  static async _cleanupExpiredZones(combat, changed, options, userId) {
    if (changed.round === undefined) return;
    
    const zones = canvas.templates.placeables.filter(t => 
      t.document.getFlag('ffdreame', 'persistentZone')
    );
    
    for (const zone of zones) {
      const zoneData = zone.document.getFlag('ffdreame', 'persistentZone');
      if (!zoneData) continue;
      
      // Vérifier si la zone a expiré
      if (zoneData.tourActuel >= zoneData.dureeTours) {
        console.log(`🧊 Zone "${zoneData.techniqueName}" expirée (${zoneData.tourActuel}/${zoneData.dureeTours})`);
        
        // Supprimer l'animation
        if (typeof Sequencer !== 'undefined') {
          Sequencer.EffectManager.endEffects({ name: `persistent-zone-${zone.id}` });
        }
        
        // Supprimer le template
        await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [zone.id]);
        
        ui.notifications.info(`🧊 Zone "${zoneData.techniqueName}" a disparu`);
      }
    }
  }
  
  /**
   * Supprimer toutes les zones (fin de combat)
   */
  static async clearAllZones() {
    const zones = canvas.templates.placeables.filter(t => 
      t.document.getFlag('ffdreame', 'persistentZone')
    );
    
    if (zones.length === 0) return;
    
    console.log(`🧹 Nettoyage de ${zones.length} zone(s) persistante(s)`);
    
    for (const zone of zones) {
      if (typeof Sequencer !== 'undefined') {
        Sequencer.EffectManager.endEffects({ name: `persistent-zone-${zone.id}` });
      }
      await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [zone.id]);
    }
    
    ui.notifications.info(`🧹 ${zones.length} zone(s) nettoyée(s)`);
  }
}
