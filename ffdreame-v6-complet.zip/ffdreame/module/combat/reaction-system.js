/**
 * ============================================
 * SYSTÈME D'ESQUIVE ET DÉFENSE AUTOMATIQUE
 * ============================================
 * Gère les réactions automatiques lors des attaques
 * avec calcul de réduction de dégâts selon les marges
 */

export class FFdreameReactionSystem {
  
  /**
   * Lancer une attaque avec gestion automatique des réactions
   * 
   * @param {Token} attaquantToken - Token de l'attaquant
   * @param {Token} cibleToken - Token de la cible
   * @param {number} degatsBase - Dégâts de base de l'attaque
   * @param {number} pourcentageAttaque - Résultat du jet d'attaque (1-100)
   * @returns {Object} - Résultat de l'attaque avec tous les détails
   */
  static async processAttaque(attaquantToken, cibleToken, degatsBase, pourcentageAttaque = null) {
    
    const attaquant = attaquantToken.actor;
    const defenseur = cibleToken.actor;
    
    if (!attaquant || !defenseur) {
      ui.notifications.error("❌ Attaquant ou défenseur invalide !");
      return null;
    }
    
    // ==========================================
    // ÉTAPE 1 : JET D'ATTAQUE (si pas fourni)
    // ==========================================
    let jetAttaque = pourcentageAttaque;
    
    if (!jetAttaque) {
      const roll = new Roll("1d100");
      await roll.evaluate();
      jetAttaque = roll.total;
      
      // Afficher le jet d'attaque
      await roll.toMessage({
        speaker: ChatMessage.getSpeaker({ token: attaquantToken }),
        flavor: `
          <div class="ffdreame-attack-roll">
            <h3>⚔️ Attaque de ${attaquant.name}</h3>
            <p><strong>Cible :</strong> ${defenseur.name}</p>
            <p><strong>Dégâts potentiels :</strong> ${degatsBase}</p>
          </div>
        `
      });
    }
    
    console.log(`⚔️ ATTAQUE : ${attaquant.name} → ${defenseur.name} | Jet: ${jetAttaque}% | Dégâts: ${degatsBase}`);
    
    // ==========================================
    // ÉTAPE 2 : VÉRIFIER LES RÉACTIONS ACTIVES
    // ==========================================
    const reactions = defenseur.system.combat?.reactions || {};
    const esquiveActive = reactions.esquive || false;
    const defenseActive = reactions.defense || false;
    
    if (!esquiveActive && !defenseActive) {
      // Aucune réaction → Dégâts complets
      const result = await this._appliquerDegats(defenseur, degatsBase, degatsBase, null, jetAttaque);
      
      await this._afficherResultat(attaquant, defenseur, jetAttaque, degatsBase, degatsBase, null, result.nouveauPV, result.pvActuel);
      
      return {
        reactionUtilisee: null,
        degatsFinaux: degatsBase,
        pvActuel: result.pvActuel,
        nouveauPV: result.nouveauPV
      };
    }
    
    // ==========================================
    // ÉTAPE 3 : CHOISIR LA RÉACTION À UTILISER
    // ==========================================
    let reactionType = null;
    
    if (esquiveActive && defenseActive) {
      // Les deux sont actives → Demander au joueur
      reactionType = await this._demanderReaction(defenseur);
      if (!reactionType) return null; // Annulé
    } else if (esquiveActive) {
      reactionType = 'esquive';
    } else if (defenseActive) {
      reactionType = 'defense';
    }
    
    console.log(`🎯 Réaction choisie: ${reactionType}`);
    
    // ==========================================
    // ÉTAPE 4 : CALCULER LE SEUIL DE RÉUSSITE
    // ==========================================
    let bonusCompetence = 0;
    let competenceNom = "";
    
    if (reactionType === 'esquive') {
      // ESQUIVE : Agilité
      bonusCompetence = defenseur.system.dexterite?.agilite?.value || 0;
      competenceNom = "Agilité";
    } else {
      // DÉFENSE : Endurance
      bonusCompetence = defenseur.system.physique?.endurance?.value || 0;
      competenceNom = "Endurance";
    }
    
    // Seuil = Jet Attaquant + Bonus Compétence
    const seuilReussite = jetAttaque + bonusCompetence;
    
    console.log(`📊 Seuil de réussite: ${seuilReussite}% (${jetAttaque}% + ${bonusCompetence} ${competenceNom})`);
    
    // ==========================================
    // ÉTAPE 5 : JET DE RÉACTION
    // ==========================================
    const rollReaction = new Roll("1d100");
    await rollReaction.evaluate();
    const jetReaction = rollReaction.total;
    
    // Afficher le jet de réaction
    const reactionLabel = reactionType === 'esquive' ? '🤸 ESQUIVE' : '🛡️ DÉFENSE';
    const reactionIcon = reactionType === 'esquive' ? '🤸' : '🛡️';
    
    await rollReaction.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: defenseur }),
      flavor: `
        <div class="ffdreame-reaction-roll">
          <h3>${reactionLabel} de ${defenseur.name}</h3>
          <p><strong>Jet d'attaque :</strong> ${jetAttaque}%</p>
          <p><strong>${competenceNom} :</strong> +${bonusCompetence}%</p>
          <p><strong>Seuil de réussite :</strong> ≤ ${seuilReussite}%</p>
        </div>
      `
    });
    
    console.log(`🎲 Jet de réaction: ${jetReaction}% | Seuil: ${seuilReussite}%`);
    
    // ==========================================
    // ÉTAPE 6 : CALCULER LA MARGE ET RÉDUCTION
    // ==========================================
    const marge = jetReaction - jetAttaque; // Marge par rapport au jet d'attaque
    let reduction = 0;
    let messageReduction = "";
    
    if (jetReaction > jetAttaque) {
      // ÉCHEC : Au-dessus du jet d'attaquant
      reduction = 0;
      messageReduction = `❌ ${reactionLabel} échouée ! (Marge: +${marge}%)`;
      
    } else if (marge >= -15) {
      // RÉUSSITE PARTIELLE : Entre jet attaquant et -15%
      reduction = 0.4; // 60% des dégâts = réduction de 40%
      messageReduction = `${reactionIcon} Réaction partielle ! Dégâts réduits à 60% (Marge: ${marge}%)`;
      
    } else if (marge >= -25) {
      // BONNE RÉUSSITE : Entre -15% et -25%
      reduction = 0.5; // 50% des dégâts = réduction de 50%
      messageReduction = `${reactionIcon} Bonne réaction ! Dégâts réduits à 50% (Marge: ${marge}%)`;
      
    } else {
      // RÉUSSITE CRITIQUE : -25% ou moins
      reduction = 1.0; // 0% des dégâts = réduction de 100%
      messageReduction = `${reactionIcon} ✨ <strong>RÉACTION PARFAITE !</strong> ✨ Attaque complètement évitée ! (Marge: ${marge}%)`;
    }
    
    // Vérifier le critique (1-5)
    if (jetReaction <= 5) {
      reduction = 1.0;
      messageReduction = `${reactionIcon} ⭐ <strong>CRITIQUE !</strong> ⭐ Attaque complètement évitée ! (Jet: ${jetReaction}%)`;
    }
    
    const degatsFinaux = Math.floor(degatsBase * (1 - reduction));
    
    console.log(`💥 Réduction: ${(reduction * 100)}% | Dégâts: ${degatsBase} → ${degatsFinaux}`);
    
    // ==========================================
    // ÉTAPE 7 : DÉSACTIVER LA RÉACTION
    // ==========================================
    await defenseur.update({
      [`system.combat.reactions.${reactionType}`]: false
    });
    
    console.log(`✅ ${reactionLabel} désactivée après utilisation`);
    
    // ==========================================
    // ÉTAPE 8 : APPLIQUER LES DÉGÂTS
    // ==========================================
    const result = await this._appliquerDegats(defenseur, degatsBase, degatsFinaux, reactionType, jetAttaque);
    
    // ==========================================
    // ÉTAPE 9 : AFFICHER LE RÉSULTAT FINAL
    // ==========================================
    await this._afficherResultat(
      attaquant, 
      defenseur, 
      jetAttaque, 
      degatsBase, 
      degatsFinaux, 
      {
        type: reactionType,
        jet: jetReaction,
        seuil: seuilReussite,
        competence: competenceNom,
        bonus: bonusCompetence,
        marge: marge,
        message: messageReduction,
        reduction: reduction
      },
      result.nouveauPV,
      result.pvActuel
    );
    
    return {
      reactionUtilisee: reactionType,
      jetReaction: jetReaction,
      seuilReussite: seuilReussite,
      marge: marge,
      reduction: reduction,
      degatsBase: degatsBase,
      degatsFinaux: degatsFinaux,
      pvActuel: result.pvActuel,
      nouveauPV: result.nouveauPV
    };
  }
  
  /**
   * Demander au joueur quelle réaction utiliser
   */
  static async _demanderReaction(defenseur) {
    return new Promise((resolve) => {
      new Dialog({
        title: "Choisir une Réaction",
        content: `
          <div style="text-align: center; padding: 20px;">
            <h3>${defenseur.name}</h3>
            <p>Vous avez <strong>Esquive</strong> ET <strong>Défense</strong> actives !</p>
            <p>Laquelle voulez-vous utiliser ?</p>
          </div>
        `,
        buttons: {
          esquive: {
            icon: '<i class="fas fa-running"></i>',
            label: "🤸 Esquive (Agilité)",
            callback: () => resolve('esquive')
          },
          defense: {
            icon: '<i class="fas fa-shield-alt"></i>',
            label: "🛡️ Défense (Endurance)",
            callback: () => resolve('defense')
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Annuler",
            callback: () => resolve(null)
          }
        },
        default: "esquive"
      }).render(true);
    });
  }
  
  /**
   * Appliquer les dégâts aux PV
   */
  static async _appliquerDegats(defenseur, degatsBase, degatsFinaux, reactionType, jetAttaque) {
    const pvActuel = defenseur.system.aptitudes?.pv?.value || 0;
    const nouveauPV = Math.max(0, pvActuel - degatsFinaux);
    
    await defenseur.update({
      'system.aptitudes.pv.value': nouveauPV
    });
    
    return { pvActuel, nouveauPV };
  }
  
  /**
   * Afficher le résultat final dans le chat
   */
  static async _afficherResultat(attaquant, defenseur, jetAttaque, degatsBase, degatsFinaux, reactionInfo, nouveauPV, pvActuel) {
    
    let messageReaction = "";
    
    if (reactionInfo) {
      const reactionLabel = reactionInfo.type === 'esquive' ? '🤸 ESQUIVE' : '🛡️ DÉFENSE';
      messageReaction = `
        <div style="background: rgba(0, 150, 255, 0.1); padding: 10px; margin: 10px 0; border-left: 4px solid #0096ff; border-radius: 4px;">
          <h4 style="margin-top: 0;">${reactionLabel}</h4>
          <p><strong>Jet de réaction :</strong> ${reactionInfo.jet}%</p>
          <p><strong>Seuil :</strong> ≤ ${reactionInfo.seuil}% (${jetAttaque}% + ${reactionInfo.bonus} ${reactionInfo.competence})</p>
          <p><strong>Marge :</strong> ${reactionInfo.marge}%</p>
          <p>${reactionInfo.message}</p>
          <p><strong>Réduction :</strong> ${Math.round(reactionInfo.reduction * 100)}%</p>
        </div>
      `;
    } else {
      messageReaction = `
        <div style="background: rgba(255, 0, 0, 0.1); padding: 10px; margin: 10px 0; border-left: 4px solid #ff0000; border-radius: 4px;">
          <p>❌ <strong>Aucune réaction active</strong></p>
          <p>Dégâts complets subis !</p>
        </div>
      `;
    }
    
    const messageFinal = `
      <div class="ffdreame-attack-result" style="background: rgba(255, 255, 255, 0.05); padding: 15px; border: 2px solid #ff0000; border-radius: 8px; margin: 10px 0;">
        <h2 style="margin-top: 0; text-align: center;">⚔️ RÉSULTAT D'ATTAQUE</h2>
        
        <div style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 10px; align-items: center; margin: 15px 0;">
          <div style="text-align: right;">
            <strong>${attaquant.name}</strong><br/>
            <span style="font-size: 0.9em; color: #999;">Attaquant</span>
          </div>
          <div style="font-size: 32px;">⚔️</div>
          <div style="text-align: left;">
            <strong>${defenseur.name}</strong><br/>
            <span style="font-size: 0.9em; color: #999;">Défenseur</span>
          </div>
        </div>
        
        <hr style="border-color: rgba(255, 255, 255, 0.2);"/>
        
        <p><strong>Jet d'attaque :</strong> ${jetAttaque}%</p>
        
        ${messageReaction}
        
        <hr style="border-color: rgba(255, 255, 255, 0.2);"/>
        
        <div style="text-align: center; margin: 15px 0;">
          <p style="margin: 5px 0;"><strong>Dégâts de base :</strong> ${degatsBase}</p>
          <p style="margin: 5px 0;"><strong>Dégâts infligés :</strong> <span style="font-size: 28px; color: #ff0000; font-weight: bold;">${degatsFinaux}</span></p>
        </div>
        
        <hr style="border-color: rgba(255, 255, 255, 0.2);"/>
        
        <div style="text-align: center; margin: 15px 0;">
          <p><strong>Points de Vie :</strong></p>
          <p style="font-size: 24px;">
            ${pvActuel} 
            <span style="color: #999;">→</span> 
            <span style="color: ${nouveauPV === 0 ? '#ff0000' : (nouveauPV < pvActuel / 2 ? '#ff9900' : '#00ff00')}; font-weight: bold;">
              ${nouveauPV}
            </span>
          </p>
          ${nouveauPV === 0 ? '<p style="color: #ff0000; font-size: 24px; font-weight: bold; margin: 10px 0;">💀 K.O. !</p>' : ''}
        </div>
      </div>
    `;
    
    await ChatMessage.create({
      content: messageFinal,
      speaker: ChatMessage.getSpeaker({ actor: attaquant })
    });
    
    // Notification
    const notifMessage = reactionInfo 
      ? `⚔️ ${degatsFinaux} dégâts à ${defenseur.name} (${Math.round(reactionInfo.reduction * 100)}% réduit)`
      : `⚔️ ${degatsFinaux} dégâts à ${defenseur.name}`;
    
    ui.notifications.info(notifMessage);
  }
}
