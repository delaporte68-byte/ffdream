/* ============================================
   SYSTÈME DE ZONES D'EFFET - STYLE MULTI v2
   ─────────────────────────────────────────
   ▸ Preview PIXI live qui suit la souris
   ▸ Indicateur de distance en temps réel
   ▸ Animations Sequencer corrigées par type
   ▸ Feedback clair dans le chat
   ============================================ */

export class FFdreameMultiZone {

  /* ================================
     POINT D'ENTRÉE PRINCIPAL
     ================================ */
  static async useTechniqueMulti(actor, technique) {
    const multiConfig = technique.system.multi || { type: "zone", distanceMax: 6, largeur: 2 };
    const token = actor.getActiveTokens()[0];

    if (!token) {
      ui.notifications.warn("❌ Aucun token trouvé pour ce personnage !");
      return { success: false, consumed: false };
    }

    if (multiConfig.type === "ligne") {
      return await this._placeLigne(actor, technique, token, multiConfig);
    } else {
      return await this._placeCercle(actor, technique, token, multiConfig);
    }
  }

  /* ================================================
     CERCLE — Preview live qui suit la souris
     ================================================ */
  static async _placeCercle(actor, technique, token, config) {
    const distanceMax = config.distanceMax || 6;
    const diametre    = config.largeur    || 2;
    const rayon       = diametre / 2;
    const gridSize    = canvas.grid.size;
    const rayonPx     = rayon * gridSize;

    const preview = this._createPreviewCercle();
    canvas.stage.addChild(preview);

    ui.notifications.info(`🎯 <b>${technique.name}</b> — Cliquez pour placer le cercle (rayon ${rayon} case, max ${distanceMax} cases) | Clic droit = annuler`);

    return new Promise((resolve) => {
      let lastPos = null;

      const onMove = (e) => {
        const pos = e.data.getLocalPosition(canvas.stage);
        lastPos = pos;
        const dist = this._distanceCases(token.center, pos, gridSize);
        this._updatePreviewCercle(preview, pos, rayonPx, dist <= distanceMax, dist, distanceMax);
      };

      const onClick = async (e) => {
        if (!lastPos) return;
        const pos = lastPos;
        const dist = this._distanceCases(token.center, pos, gridSize);
        cleanup();
        if (dist > distanceMax) {
          ui.notifications.warn(`❌ Trop loin ! (${dist.toFixed(1)} cases, max ${distanceMax})`);
          resolve({ success: false, outOfRange: true, consumed: false });
          return;
        }
        resolve(await this._executerCercle(actor, technique, token, pos, rayon, gridSize, dist));
      };

      const onCancel = () => { cleanup(); ui.notifications.info("❌ Annulé"); resolve({ success: false, consumed: false }); };
      const onKeyDown = (e) => { if (e.key === "Escape") onCancel(); };

      const cleanup = () => {
        canvas.stage.off("pointermove", onMove);
        canvas.stage.off("click",       onClick);
        canvas.stage.off("rightclick",  onCancel);
        window.removeEventListener("keydown", onKeyDown);
        try { preview.destroy(); } catch(e) {}
      };

      canvas.stage.on("pointermove", onMove);
      canvas.stage.on("click",       onClick);
      canvas.stage.on("rightclick",  onCancel);
      window.addEventListener("keydown", onKeyDown);
    });
  }

  static async _executerCercle(actor, technique, token, pos, rayon, gridSize, dist) {
    const rayonPx = rayon * gridSize;
    const { total, success, critSuccess, critFailure, formula, seuilReussite, malusInfo } = await this._lancerDe(actor);

    await this._chatJet(actor, technique, formula, total, seuilReussite, success, critSuccess, critFailure, malusInfo,
      `💥 Cercle — Rayon ${rayon} case | Distance ${dist.toFixed(1)} cases`);

    if (!success) { ui.notifications.warn("❌ Technique ratée !"); return { success: false, failed: true, consumed: true }; }

    const tokensHit = this._tokensInCercle(pos.x, pos.y, rayonPx);

    const tpl = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [{
      t: "circle", user: game.user.id, distance: rayon, direction: 0, x: pos.x, y: pos.y, fillColor: game.user.color
    }]);

    await this._animerCercle(technique, token, pos, rayonPx);
    const nbCibles = await this._applyMultiDamage(actor, technique, tokensHit, token, critSuccess, total);
    await this._gainBurste(actor, nbCibles);

    setTimeout(() => canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [tpl[0].id]), 2000);
    return { success: true, nbCibles, consumed: true };
  }

  /* ================================================
     LIGNE — Preview live + clic sur cible
     ================================================ */
  static async _placeLigne(actor, technique, token, config) {
    const distanceMax = config.distanceMax || 6;
    const largeurCase = config.largeur    || 1;
    const gridSize    = canvas.grid.size;
    const largeurPx   = largeurCase * gridSize;

    const preview = this._createPreviewLigne();
    canvas.stage.addChild(preview);

    ui.notifications.info(`🎯 <b>${technique.name}</b> — Cliquez sur une cible pour la ligne (largeur ${largeurCase} case, max ${distanceMax} cases) | Clic droit = annuler`);

    return new Promise((resolve) => {
      let lastPos = null;

      const onMove = (e) => {
        const pos = e.data.getLocalPosition(canvas.stage);
        lastPos = pos;
        const dist = this._distanceCases(token.center, pos, gridSize);
        this._updatePreviewLigne(preview, token.center, pos, largeurPx, dist <= distanceMax, dist, distanceMax);
      };

      const onClick = async (e) => {
        if (!lastPos) return;
        const targetToken = canvas.tokens.hover;
        const targetPos   = targetToken ? targetToken.center : lastPos;
        const dist = this._distanceCases(token.center, targetPos, gridSize);
        cleanup();
        if (dist > distanceMax) {
          ui.notifications.warn(`❌ Trop loin ! (${dist.toFixed(1)} cases, max ${distanceMax})`);
          resolve({ success: false, outOfRange: true, consumed: false });
          return;
        }
        resolve(await this._executerLigne(actor, technique, token, targetToken, targetPos, largeurPx, gridSize, dist));
      };

      const onCancel = () => { cleanup(); ui.notifications.info("❌ Annulé"); resolve({ success: false, consumed: false }); };
      const onKeyDown = (e) => { if (e.key === "Escape") onCancel(); };

      const cleanup = () => {
        canvas.stage.off("pointermove", onMove);
        canvas.stage.off("click",       onClick);
        canvas.stage.off("rightclick",  onCancel);
        window.removeEventListener("keydown", onKeyDown);
        try { preview.destroy(); } catch(e) {}
      };

      canvas.stage.on("pointermove", onMove);
      canvas.stage.on("click",       onClick);
      canvas.stage.on("rightclick",  onCancel);
      window.addEventListener("keydown", onKeyDown);
    });
  }

  static async _executerLigne(actor, technique, token, targetToken, targetPos, largeurPx, gridSize, dist) {
    const { total, success, critSuccess, critFailure, formula, seuilReussite, malusInfo } = await this._lancerDe(actor);

    await this._chatJet(actor, technique, formula, total, seuilReussite, success, critSuccess, critFailure, malusInfo,
      `🗡️ Ligne — Largeur ${largeurPx/gridSize} case | Distance ${dist.toFixed(1)} cases`);

    if (!success) { ui.notifications.warn("❌ Technique ratée !"); return { success: false, failed: true, consumed: true }; }

    const tokensHit = this._tokensInLigne(token, targetPos, largeurPx);

    const ray = new Ray(token.center, targetPos);
    const tpl = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [{
      t: "ray", user: game.user.id, distance: dist,
      direction: Math.toDegrees(ray.angle), width: largeurPx / gridSize,
      x: token.x, y: token.y, fillColor: game.user.color
    }]);

    await this._animerLigne(technique, token, targetToken || targetPos);
    const nbCibles = await this._applyMultiDamage(actor, technique, tokensHit, token, critSuccess, total);
    await this._gainBurste(actor, nbCibles);

    setTimeout(() => canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [tpl[0].id]), 2000);
    return { success: true, nbCibles, consumed: true };
  }

  /* ================================================
     PIXI PREVIEW CERCLE
     ================================================ */
  static _createPreviewCercle() {
    const g = new PIXI.Container();
    g._circle = new PIXI.Graphics();
    g._text   = new PIXI.Text("", { fontFamily: "Arial", fontSize: 14, fill: 0xffffff, stroke: 0x000000, strokeThickness: 3, align: "center" });
    g.addChild(g._circle);
    g.addChild(g._text);
    return g;
  }

  static _updatePreviewCercle(preview, pos, rayonPx, inRange, dist, distMax) {
    const color  = inRange ? 0x00d9ff : 0xff4444;
    const alpha  = inRange ? 0.18    : 0.08;

    const c = preview._circle;
    c.clear();
    c.lineStyle(2, color, 0.9);
    c.beginFill(color, alpha);
    c.drawCircle(pos.x, pos.y, rayonPx);
    c.endFill();
    // Croix centrale
    c.lineStyle(1, color, 0.5);
    c.moveTo(pos.x - 8, pos.y); c.lineTo(pos.x + 8, pos.y);
    c.moveTo(pos.x, pos.y - 8); c.lineTo(pos.x, pos.y + 8);

    const t = preview._text;
    t.text = `${dist.toFixed(1)} / ${distMax}`;
    t.style.fill = inRange ? 0x00d9ff : 0xff4444;
    t.x = pos.x - t.width / 2;
    t.y = pos.y + rayonPx + 5;
  }

  /* ================================================
     PIXI PREVIEW LIGNE
     ================================================ */
  static _createPreviewLigne() {
    const g = new PIXI.Container();
    g._line = new PIXI.Graphics();
    g._text = new PIXI.Text("", { fontFamily: "Arial", fontSize: 14, fill: 0xffffff, stroke: 0x000000, strokeThickness: 3 });
    g.addChild(g._line);
    g.addChild(g._text);
    return g;
  }

  static _updatePreviewLigne(preview, src, dst, largeurPx, inRange, dist, distMax) {
    const color = inRange ? 0xffd700 : 0xff4444;
    const alpha = inRange ? 0.18    : 0.08;

    const dx = dst.x - src.x, dy = dst.y - src.y;
    const len = Math.sqrt(dx*dx + dy*dy) || 1;
    const ux = dx/len, uy = dy/len;
    const px = -uy * largeurPx/2, py = ux * largeurPx/2;

    const l = preview._line;
    l.clear();
    l.lineStyle(2, color, 0.9);
    l.beginFill(color, alpha);
    l.moveTo(src.x+px, src.y+py);
    l.lineTo(dst.x+px, dst.y+py);
    l.lineTo(dst.x-px, dst.y-py);
    l.lineTo(src.x-px, src.y-py);
    l.closePath();
    l.endFill();
    l.lineStyle(1, color, 0.6);
    l.moveTo(src.x, src.y);
    l.lineTo(dst.x, dst.y);

    const t = preview._text;
    t.text = `${dist.toFixed(1)} / ${distMax}`;
    t.style.fill = inRange ? 0xffd700 : 0xff4444;
    t.x = (src.x+dst.x)/2 - t.width/2;
    t.y = (src.y+dst.y)/2 - 20;
  }

  /* ================================================
     ANIMATIONS SEQUENCER
     ================================================ */
  static async _animerCercle(technique, sourceToken, pos, rayonPx) {
    const jb2aAnim = technique.system.animation?.jb2a;
    if (!jb2aAnim || typeof Sequence === "undefined") return;
    try {
      await new Sequence()
        .effect()
          .file(jb2aAnim)
          .atLocation(pos)
          .scale(Math.max(0.5, rayonPx / 200))
          .fadeIn(150).fadeOut(300)
        .play();
    } catch(e) { console.error("FFdreame | Anim cercle :", e); }
  }

  static async _animerLigne(technique, sourceToken, target) {
    const jb2aAnim = technique.system.animation?.jb2a;
    if (!jb2aAnim || typeof Sequence === "undefined") return;
    try {
      await new Sequence()
        .effect()
          .file(jb2aAnim)
          .atLocation(sourceToken)
          .stretchTo(target)
          .fadeIn(100).fadeOut(200)
        .play();
    } catch(e) { console.error("FFdreame | Anim ligne :", e); }
  }

  /* ================================================
     JET DE DÉS
     ================================================ */
  static async _lancerDe(actor) {
    const seuil = actor._getRangModifier(actor.system.rang).jetReussite;
    const malus = actor._calculateFatigueMalus() + actor._calculateBlessureMalus();
    const formula = malus > 0 ? `1d100 + ${malus}` : "1d100";
    const roll = new Roll(formula);
    await roll.evaluate();
    const total = roll.total;
    const success = total <= seuil;
    return {
      roll, total, success,
      critSuccess: total <= 5 && success,
      critFailure: total >= 95,
      formula, seuilReussite: seuil,
      malusInfo: malus > 0 ? `<p style="color:#ff6b6b;font-size:11px">⚠️ Malus : +${malus}</p>` : ""
    };
  }

  static async _chatJet(actor, technique, formula, total, seuil, success, critSuccess, critFailure, malusInfo, infoZone) {
    let txt = success ? "✓ Réussite" : "✗ Échec";
    let css = success ? "success" : "failure";
    if (critSuccess) { txt = "⭐ SUCCÈS CRITIQUE !"; css = "critical-success"; }
    if (critFailure) { txt = "💀 ÉCHEC CRITIQUE !";  css = "critical-failure"; }

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor: `<h3>⚡ ${technique.name} — MULTI</h3>
               <p style="color:#aaa;font-size:11px">${infoZone} | Seuil ≤ ${seuil}</p>${malusInfo}`,
      content: `<div class="dice-roll">
        <div class="dice-result">
          <div class="dice-formula">${formula}</div>
          <div class="dice-total ${css}">${total} ${txt}</div>
        </div>
      </div>`
    });
  }

  /* ================================================
     DÉGÂTS MULTI-CIBLES
     ================================================ */
  static async _applyMultiDamage(actor, technique, tokensHit, sourceToken, isCritical, jetAttaque) {
    const targets = tokensHit.filter(t => t.id !== sourceToken.id);
    if (targets.length === 0) { ui.notifications.warn("Aucune cible dans la zone !"); return 0; }

    const degatsBase = actor._calculateTechniqueDegats(technique);
    const degatsMax  = isCritical ? degatsBase * 2 : degatsBase;

    let rows = "";
    for (let i = 0; i < targets.length; i++) {
      const target = targets[i];
      const pct    = Math.max(0, 1 - i * 0.2);
      let degats   = Math.floor(degatsMax * pct);
      let reacInfo = "";

      if (target.actor) {
        const r = await this._gererReaction(target.actor, target.actor.system.combat?.reactions || {}, jetAttaque, degats);
        degats   = r.degats;
        reacInfo = r.info;

        const pvAvant = target.actor.system.aptitudes.pv.value;
        const pvApres = Math.max(0, pvAvant - degats);
        await target.actor.update({ "system.aptitudes.pv.value": pvApres });

        rows += `<div style="background:rgba(0,0,0,.3);border-radius:4px;padding:4px 8px;font-size:11px;margin-bottom:3px">
          <b>${i+1}. ${target.actor.name}</b>
          ${i > 0 ? `<span style="color:#666"> (${Math.round(pct*100)}%)</span>` : ""}
          — <span style="color:#ff4444">${degats} dégâts</span>
          <span style="color:#555"> | ${pvAvant}→${pvApres} PV</span>
          ${reacInfo}
          ${pvApres === 0 ? " 💀 <b>K.O.</b>" : ""}
        </div>`;
      }
    }

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<div style="background:rgba(255,215,0,.06);border-left:3px solid #d4af37;padding:8px 12px;border-radius:6px">
        <h3 style="color:#d4af37;margin:0 0 6px">💥 ${technique.name}${isCritical?" — CRITIQUE ×2":""}</h3>
        <p style="font-size:11px;color:#aaa;margin:0 0 8px"><b>${targets.length}</b> cible(s)</p>
        ${rows}
      </div>`
    });

    return targets.length;
  }

  static async _gererReaction(actorCible, reactions, jetAttaque, degats) {
    const esquive = reactions?.esquive || false;
    const defense = reactions?.defense || false;
    if (!esquive && !defense) return { degats, info: "" };

    let type = esquive && defense
      ? await new Promise(resolve => new Dialog({
          title: `Réaction — ${actorCible.name}`,
          content: `<p><b>${actorCible.name}</b> a Esquive ET Défense actives.</p>`,
          buttons: {
            esquive: { label: "🏃 Esquive",  callback: () => resolve("esquive") },
            defense: { label: "🛡️ Défense", callback: () => resolve("defense") },
            aucune:  { label: "❌ Aucune",   callback: () => resolve(null) }
          }
        }).render(true))
      : (esquive ? "esquive" : "defense");

    if (!type) return { degats, info: "" };

    const compVal = type === "esquive"
      ? (actorCible.system.dexterite?.agilite?.value || 0)
      : (actorCible.system.physique?.endurance?.value || 0);

    const seuil = jetAttaque + compVal;
    const jet = new Roll("1d100");
    await jet.evaluate();
    const res    = jet.total;
    const reussi = res <= seuil;
    const marge  = res - seuil;

    const icon  = type === "esquive" ? "🏃" : "🛡️";
    const label = type === "esquive" ? "Esquive" : "Défense";
    const comp  = type === "esquive" ? "Agilité" : "Endurance";

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: actorCible }),
      content: `<div style="background:rgba(0,217,255,.06);border-left:3px solid #00d9ff;padding:5px 10px;border-radius:5px;font-size:11px">
        <b>${icon} ${label} — ${actorCible.name}</b><br>
        Jet : <b>${res}</b> | Seuil ≤${seuil} (${jetAttaque} + ${comp} ${compVal})<br>
        ${reussi ? "✅ <b>Réussi !</b>" : "❌ <b>Raté</b>"}
      </div>`
    });

    let reduction = 0, info = "";
    if (reussi) {
      if (marge <= -20 || res <= 5) { reduction = 1.0; info = ` ${icon} Annulé !`; }
      else if (marge <= -15)        { reduction = 0.5; info = ` ${icon} -50%`; }
      else                          { reduction = 0.2; info = ` ${icon} -20%`; }
    } else { info = ` ${label} ratée`; }

    await actorCible.update({ [`system.combat.reactions.${type}`]: false });
    return { degats: Math.floor(degats * (1 - reduction)), info };
  }

  /* ================================================
     BURSTE
     ================================================ */
  static async _gainBurste(actor, nbCibles) {
    if (nbCibles <= 0) return;
    const next = Math.min(100, (actor.system.combat.burste || 0) + nbCibles * 10);
    await actor.update({ "system.combat.burste": next });
    if (next >= 100) ui.notifications.info("⚡ BURSTE À 100 ! ULTIMATE DISPONIBLE !");
  }

  /* ================================================
     UTILITAIRES GÉOMÉTRIE
     ================================================ */
  static _distanceCases(a, b, gs) {
    return Math.sqrt(((b.x-a.x)/gs)**2 + ((b.y-a.y)/gs)**2);
  }

  static _tokensInCercle(cx, cy, rayonPx) {
    return canvas.tokens.placeables.filter(t => {
      const dx = t.center.x - cx, dy = t.center.y - cy;
      return Math.sqrt(dx*dx + dy*dy) <= rayonPx;
    });
  }

  static _tokensInLigne(srcToken, dstPos, largeurPx) {
    const ax = srcToken.center.x, ay = srcToken.center.y;
    const bx = dstPos.x,          by = dstPos.y;
    const dx = bx-ax, dy = by-ay;
    const len = Math.sqrt(dx*dx + dy*dy);
    if (len === 0) return [];
    return canvas.tokens.placeables
      .filter(t => {
        if (t.id === srcToken.id) return false;
        const qx = t.center.x-ax, qy = t.center.y-ay;
        const proj = (qx*dx + qy*dy) / len;
        if (proj < 0 || proj > len) return false;
        return Math.abs((qx*dy - qy*dx) / len) <= largeurPx/2;
      })
      .sort((a,b) => {
        const pa = ((a.center.x-ax)*dx + (a.center.y-ay)*dy)/len;
        const pb = ((b.center.x-ax)*dx + (b.center.y-ay)*dy)/len;
        return pa-pb;
      });
  }
}
