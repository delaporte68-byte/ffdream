/**
 * ============================================
 * SYSTÈME DE NOTIFICATIONS UNIFIÉ FFdreame
 * ============================================
 * - Intercepte ui.notifications natif Foundry
 * - Hook createChatMessage → détecte tous les jets
 * - Affiche en HAUT À DROITE, style combat bar, format CARRÉ
 * - Max 2 slots simultanés, FIFO
 * - Fermeture manuelle avec ✕
 */

export class FFdreameNotifications {

  static _container = null;
  static _intercepted = false;
  static _msgQueue = []; // [slot0 (ancien), slot1 (récent)]

  /* =========================================
     INIT
     ========================================= */
  static init() {
    console.log('FFdreame | Notifications - Initialisation...');
    Hooks.once('ready', () => {
      FFdreameNotifications._createContainer();
      FFdreameNotifications._interceptFoundry();
      FFdreameNotifications._hookChatMessages();
      console.log('FFdreame | Notifications ✅');
    });
  }

  /* =========================================
     CONTENEUR
     ========================================= */
  static _createContainer() {
    document.getElementById('ffdreame-notif-container')?.remove();
    const container = document.createElement('div');
    container.id = 'ffdreame-notif-container';
    document.body.appendChild(container);
    FFdreameNotifications._container = container;
    FFdreameNotifications._injectCSS();
  }

  /* =========================================
     HOOK CHAT → détecte les jets de dés
     Lit les classes CSS du message pour extraire :
     critical-success, critical-failure, success, failure
     ========================================= */
  static _hookChatMessages() {
    Hooks.on('createChatMessage', (message) => {
      try {
        const content = message.content || '';
        if (!content.includes('dice-total')) return; // Pas un jet de dés

        // Extraire le nom du speaker
        const speaker = message.speaker?.alias || message.speaker?.actor || '???';

        // Extraire le résultat numérique du jet (le nombre dans dice-total)
        const totalMatch = content.match(/dice-total[^>]*>\s*(\d+)/);
        const jetValue = totalMatch ? totalMatch[1] : '?';

        // Détecter le type de résultat via les classes CSS
        let type, label, icon;
        if (content.includes('critical-success')) {
          type = 'crit-success'; label = 'SUCCÈS CRITIQUE'; icon = '⭐';
        } else if (content.includes('critical-failure')) {
          type = 'crit-failure'; label = 'ÉCHEC CRITIQUE'; icon = '💀';
        } else if (content.includes('"success"') || content.includes("'success'") || content.includes('class="dice-total success')) {
          type = 'success'; label = 'Réussite'; icon = '✓';
        } else if (content.includes('"failure"') || content.includes("'failure'") || content.includes('class="dice-total failure')) {
          type = 'failure'; label = 'Échec'; icon = '✗';
        } else {
          return; // Type non reconnu
        }

        // Extraire le nom de la technique (dans flavor)
        const flavor = message.flavor || '';
        const techMatch = flavor.match(/<h3[^>]*>⚡\s*([^<]+)<\/h3>/);
        const techName = techMatch ? techMatch[1].trim() : '';

        FFdreameNotifications._pushDice({
          speaker, jetValue, type, label, icon, techName
        });
      } catch(e) {
        console.warn('FFdreame | Erreur hook chat:', e);
      }
    });
  }

  /* =========================================
     POUSSER UN JET DE DÉS (carré)
     ========================================= */
  static _pushDice({ speaker, jetValue, type, label, icon, techName }) {
    if (!FFdreameNotifications._container) return;

    const el = document.createElement('div');
    el.className = `ffdreame-notif ffdreame-notif-dice notif-${type}`;
    el.innerHTML = `
      <button class="notif-close" title="Fermer">✕</button>
      <div class="notif-dice-icon">${icon}</div>
      <div class="notif-dice-value">${jetValue}</div>
      <div class="notif-dice-label">${label}</div>
      <div class="notif-dice-actor">${speaker}${techName ? `<br><em>${techName}</em>` : ''}</div>
    `;

    el.querySelector('.notif-close').addEventListener('click', (e) => {
      e.stopPropagation();
      FFdreameNotifications._removeEl(el);
    });

    FFdreameNotifications._addToContainer(el);
  }

  /* =========================================
     POUSSER UN MESSAGE TEXTE (rectangle court)
     ========================================= */
  static push(message, type = 'info') {
    if (!FFdreameNotifications._container) return;

    const clean = FFdreameNotifications._cleanMessage(message);
    const icon = { info: 'ℹ️', warn: '⚠️', error: '❌', success: '✅' }[type] || 'ℹ️';
    const cssType = { info: 'notif-info', warn: 'notif-warn', error: 'notif-error', success: 'notif-success' }[type] || 'notif-info';

    const el = document.createElement('div');
    el.className = `ffdreame-notif ffdreame-notif-text ${cssType}`;
    el.innerHTML = `
      <span class="notif-icon">${icon}</span>
      <span class="notif-text">${clean}</span>
      <button class="notif-close" title="Fermer">✕</button>
    `;

    el.querySelector('.notif-close').addEventListener('click', (e) => {
      e.stopPropagation();
      FFdreameNotifications._removeEl(el);
    });

    FFdreameNotifications._addToContainer(el);
  }

  /* =========================================
     LOGIQUE FIFO 2 SLOTS
     ========================================= */
  static _addToContainer(el) {
    const container = FFdreameNotifications._container;
    const existing = container.querySelectorAll('.ffdreame-notif');

    // Si déjà 2 → supprimer le plus ancien
    if (existing.length >= 2) {
      FFdreameNotifications._removeEl(existing[0], true);
    }

    container.appendChild(el);

    // Animation d'entrée
    requestAnimationFrame(() => el.classList.add('notif-show'));
  }

  static _removeEl(el, instant = false) {
    if (!el || !el.parentNode) return;
    if (instant) {
      el.remove();
    } else {
      el.classList.remove('notif-show');
      setTimeout(() => el.remove(), 250);
    }
  }

  /* =========================================
     INTERCEPTER ui.notifications FOUNDRY
     ========================================= */
  static _interceptFoundry() {
    if (FFdreameNotifications._intercepted) return;
    if (!ui?.notifications) {
      setTimeout(() => FFdreameNotifications._interceptFoundry(), 500);
      return;
    }

    // Override toutes les méthodes
    ['notify', 'info', 'warn', 'error'].forEach(method => {
      const type = method === 'notify' ? 'info' : method;
      const original = ui.notifications[method].bind(ui.notifications);
      ui.notifications[method] = (message, ...args) => {
        FFdreameNotifications.push(message, type);
        // Ne pas appeler l'original → on remplace complètement
      };
    });

    // Masquer la barre native Foundry
    const hide = () => {
      const bar = document.getElementById('notifications');
      if (bar) bar.style.cssText = 'display:none!important';
    };
    hide();
    new MutationObserver(hide).observe(document.body, { childList: true, subtree: true });

    FFdreameNotifications._intercepted = true;
    console.log('FFdreame | ui.notifications intercepté ✅');
  }

  /* =========================================
     API PUBLIQUE (appelée par le code existant)
     ========================================= */
  static async showCritical(type, actorName, jetValue) {
    if (type === 'success') {
      FFdreameNotifications._pushDice({ speaker: actorName, jetValue, type: 'crit-success', label: 'SUCCÈS CRITIQUE', icon: '⭐' });
    } else {
      FFdreameNotifications._pushDice({ speaker: actorName, jetValue, type: 'crit-failure', label: 'ÉCHEC CRITIQUE', icon: '💀' });
    }
  }

  static async showTurnStart(actorName) {
    FFdreameNotifications.push(`▶️ <b>Tour de ${actorName}</b>`, 'info');
  }
  static async showTurnEnd(actorName) {
    FFdreameNotifications.push(`🔒 <b>${actorName}</b> a terminé son tour`, 'warn');
  }
  static async showNewRound(roundNumber) {
    FFdreameNotifications.push(`⚔️ <b>Round ${roundNumber}</b> — 1 Grand PA récupéré`, 'info');
  }
  static async showAOERWarning(actorName, techniqueName) {
    FFdreameNotifications.push(`⚠️ <b>Zone de danger</b> — ${actorName} prépare <b>${techniqueName}</b>`, 'error');
  }
  static async showTeleportation(actorName, direction) {
    const dirs = { derriere: 'derrière la cible', devant: 'devant la cible', gauche: 'à gauche', droite: 'à droite' };
    FFdreameNotifications.push(`✨ <b>Téléportation</b> — ${actorName} ${dirs[direction] || ''}`, 'info');
  }
  static async showKnockout(actorName) {
    FFdreameNotifications.push(`💀 <b>K.O. !</b> — ${actorName} hors de combat`, 'error');
  }
  static async showMassiveDamage(actorName, degats) {
    FFdreameNotifications.push(`💥 <b>${actorName}</b> subit <b>${degats}</b> dégâts`, 'error');
  }
  static async showNotification(options) {
    const msg = [options.title, options.subtitle].filter(Boolean).join(' — ');
    const type = options.shake ? 'error' : options.color === '#FF9900' ? 'warn' : 'info';
    FFdreameNotifications.push(msg, type);
  }

  /* =========================================
     UTILITAIRES
     ========================================= */
  static _cleanMessage(msg) {
    if (typeof msg !== 'string') return String(msg);
    return msg.replace(/<\/?p>/gi, ' ').replace(/<br\s*\/?>/gi, ' ')
              .replace(/<\/?div[^>]*>/gi, '').replace(/<\/?h[1-6][^>]*>/gi, '').trim();
  }

  /* =========================================
     CSS
     ========================================= */
  static _injectCSS() {
    if (document.getElementById('ffdreame-notif-css')) return;
    const style = document.createElement('style');
    style.id = 'ffdreame-notif-css';
    style.textContent = `
      /* ===== CONTENEUR HAUT DROITE ===== */
      #ffdreame-notif-container {
        position: fixed;
        top: 10px;
        right: 10px;
        z-index: 99999;
        display: flex;
        flex-direction: column;
        gap: 6px;
        pointer-events: none;
        width: 130px; /* Carré */
      }

      /* ===== BASE NOTIFICATION ===== */
      .ffdreame-notif {
        /* Même fond + bordure que la combat bar */
        background: linear-gradient(180deg, rgba(20,20,20,0.97) 0%, rgba(10,10,10,0.99) 100%);
        border: 2px solid rgba(139, 69, 19, 0.8);
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.8), inset 0 0 8px rgba(0,0,0,0.4);
        backdrop-filter: blur(5px);
        pointer-events: auto;
        opacity: 0;
        transform: translateX(20px);
        transition: opacity 0.25s ease, transform 0.25s ease;
        position: relative;
        overflow: hidden;
        width: 130px;
      }
      .ffdreame-notif.notif-show {
        opacity: 1;
        transform: translateX(0);
      }

      /* ===== BOUTON FERMER ===== */
      .notif-close {
        position: absolute;
        top: 3px; right: 4px;
        background: none; border: none;
        color: #444; font-size: 9px; cursor: pointer;
        padding: 1px 3px; border-radius: 3px;
        line-height: 1; transition: all 0.15s;
        z-index: 2;
      }
      .notif-close:hover { color: #fff; background: rgba(255,255,255,0.1); }

      /* ===== FORMAT CARRÉ : JET DE DÉS ===== */
      .ffdreame-notif-dice {
        width: 130px;
        height: 130px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
        padding: 10px 8px 8px;
        text-align: center;
      }

      /* Barre top colorée selon résultat */
      .ffdreame-notif-dice::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        border-radius: 8px 8px 0 0;
      }
      .notif-crit-success::before { background: #ffd700; box-shadow: 0 0 8px #ffd700; }
      .notif-crit-failure::before { background: #ff2222; box-shadow: 0 0 8px #ff2222; }
      .notif-success::before      { background: #44ff88; box-shadow: 0 0 6px #44ff88; }
      .notif-failure::before      { background: #ff6644; box-shadow: 0 0 6px #ff6644; }

      /* Icône (⭐ 💀 ✓ ✗) */
      .notif-dice-icon {
        font-size: 18px;
        line-height: 1;
        margin-bottom: 1px;
      }

      /* Valeur du dé - GRAND */
      .notif-dice-value {
        font-size: 38px;
        font-weight: bold;
        line-height: 1;
        font-family: 'Georgia', serif;
        text-shadow: 0 0 10px currentColor, 2px 2px 4px rgba(0,0,0,0.8);
      }
      .notif-crit-success .notif-dice-value { color: #ffd700; }
      .notif-crit-failure .notif-dice-value { color: #ff2222; }
      .notif-success .notif-dice-value      { color: #44ff88; }
      .notif-failure .notif-dice-value      { color: #ff6644; }

      /* Label résultat */
      .notif-dice-label {
        font-size: 9px;
        font-weight: bold;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        color: #ccc;
        line-height: 1;
      }
      .notif-crit-success .notif-dice-label { color: #ffd700; }
      .notif-crit-failure .notif-dice-label { color: #ff2222; }
      .notif-success .notif-dice-label      { color: #44ff88; }
      .notif-failure .notif-dice-label      { color: #ff6644; }

      /* Nom acteur + technique */
      .notif-dice-actor {
        font-size: 8px;
        color: #888;
        line-height: 1.3;
        margin-top: 3px;
        max-width: 110px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .notif-dice-actor em {
        color: #666;
        font-style: italic;
        display: block;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 110px;
      }

      /* ===== FORMAT TEXTE : messages ui.notifications ===== */
      .ffdreame-notif-text {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 22px 6px 8px; /* droite pour le bouton ✕ */
        width: 130px;
        /* Barre colorée gauche */
        border-left-width: 3px;
        border-left-style: solid;
      }
      .ffdreame-notif-text.notif-info  { border-left-color: #00d9ff; }
      .ffdreame-notif-text.notif-warn  { border-left-color: #ffd700; }
      .ffdreame-notif-text.notif-error { border-left-color: #ff4444; }
      .ffdreame-notif-text.notif-success { border-left-color: #44ff88; }

      .notif-icon { font-size: 11px; flex-shrink: 0; }
      .notif-text {
        flex: 1;
        font-size: 9.5px;
        color: #ddd;
        line-height: 1.35;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
        word-break: break-word;
      }
      .notif-text b, .notif-text strong { color: #fff; font-weight: bold; }

      /* Masquer barre native Foundry */
      #notifications { display: none !important; }

      /* Responsive */
      @media (max-width: 768px) {
        #ffdreame-notif-container { right: 5px; top: 5px; width: 110px; }
        .ffdreame-notif { width: 110px; }
        .ffdreame-notif-dice { width: 110px; height: 110px; }
        .notif-dice-value { font-size: 30px; }
      }
    `;
    document.head.appendChild(style);
  }
}
