/**
 * ============================================
 * BARRE DE COMBAT STYLE BG3 (en bas)
 * ============================================
 * VERSION v4 - Corrections :
 * - Ciblage via canvas.tokens.hover (même chemin que Foundry)
 * - Fin Tour = actionBlocked sur acteur + game.combat.nextTurn()
 * - Réactions ignorent le blocage (utilisables après Fin Tour)
 * - Techniques grisées visuellement quand tour terminé
 */

export class FFdreameCombatBar {
  
  static currentActor = null;
  static targetMode = false;
  static _initialized = false;
  
  static init() {
    console.log('FFdreame | Combat Bar v4 - Initialisation...');
    
    try {
      Hooks.once("ready", () => {
        console.log('FFdreame | Combat Bar - Hook ready ✅');
        setTimeout(() => {
          try { FFdreameCombatBar._createBar(); }
          catch(err) { console.error('FFdreame | Combat Bar - ERREUR _createBar():', err); }
        }, 1000);
      });
      
      // Ne PAS changer d'acteur si mode ciblage actif
      Hooks.on("controlToken", (token, controlled) => {
        if (FFdreameCombatBar.targetMode) return;
        try {
          if (controlled && token?.actor) {
            FFdreameCombatBar._switchToActor(token.actor);
          }
        } catch(err) { console.error('FFdreame | Combat Bar - ERREUR controlToken:', err); }
      });
      
      Hooks.on("updateItem", (item) => {
        try {
          if (FFdreameCombatBar.currentActor && item.parent?.id === FFdreameCombatBar.currentActor.id) {
            FFdreameCombatBar._updateTechniques();
          }
        } catch(err) {}
      });
      
      Hooks.on("updateActor", (actor) => {
        try {
          if (FFdreameCombatBar.currentActor && actor.id === FFdreameCombatBar.currentActor.id) {
            FFdreameCombatBar._updateBar();
          }
        } catch(err) {}
      });
      
      console.log('FFdreame | Combat Bar - Hooks enregistrés ✅');
    } catch(err) {
      console.error('FFdreame | Combat Bar - ERREUR CRITIQUE init():', err);
    }
  }
  
  static _createBar() {
    console.log('FFdreame | Combat Bar - Création barre...');
    if (!document?.body) { console.error('FFdreame | document.body non disponible !'); return; }
    
    document.getElementById('ffdreame-combat-bar')?.remove();
    document.body.classList.add('has-combat-bar');
    
    const bar = document.createElement('div');
    bar.id = 'ffdreame-combat-bar';
    bar.innerHTML = `
      <div class="combat-bar-content">
        <div class="combat-bar-portrait" title="Ouvrir la fiche">
          <img src="icons/svg/mystery-man.svg" class="portrait-img" alt="Portrait" />
          <div class="portrait-name">Aucun</div>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-actions">
          <button class="action-btn target-btn" title="Cibler un token (comme clic droit Foundry)">
            <i class="fas fa-crosshairs"></i><span>Cibler</span>
          </button>
          <button class="action-btn end-turn-btn" title="Fin de tour → passe au combattant suivant">
            <i class="fas fa-forward"></i><span>Fin Tour</span>
          </button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-tableaux">
          <button class="tableau-btn" data-tableau="1"><span class="tableau-name">Tableau 1</span></button>
          <button class="tableau-btn" data-tableau="2"><span class="tableau-name">Tableau 2</span></button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-reactions">
          <button class="reaction-btn" data-reaction="esquive" title="Esquive (1 Petit PA) - disponible même après Fin Tour">
            <i class="fas fa-running"></i>
          </button>
          <button class="reaction-btn" data-reaction="defense" title="Défense (1 Petit PA) - disponible même après Fin Tour">
            <i class="fas fa-shield-alt"></i>
          </button>
          <button class="reaction-btn" data-reaction="marche" title="Marche (1 Petit PA) - disponible même après Fin Tour">
            <i class="fas fa-walking"></i>
          </button>
        </div>
        <div class="combat-bar-separator"></div>
        <div class="combat-bar-techniques">
          <div class="techniques-container">
            <div class="techniques-empty-hint">Sélectionnez un token</div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(bar);
    FFdreameCombatBar._initialized = true;
    
    const cs = window.getComputedStyle(document.getElementById('ffdreame-combat-bar'));
    console.log(`✅ Combat Bar créée | bottom=${cs.bottom} z-index=${cs.zIndex} display=${cs.display}`);
    
    FFdreameCombatBar._attachEvents();
    
    try {
      const t = canvas?.tokens?.controlled?.[0];
      if (t?.actor) FFdreameCombatBar._switchToActor(t.actor);
    } catch(e) {}
  }
  
  static _attachEvents() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar) return;
    
    bar.querySelector('.combat-bar-portrait')?.addEventListener('click', () => {
      try { if (FFdreameCombatBar.currentActor) FFdreameCombatBar.currentActor.sheet.render(true); } catch(e) {}
    });
    
    bar.querySelector('.target-btn')?.addEventListener('click', () => {
      try { FFdreameCombatBar._toggleTargetMode(); } catch(e) { console.error(e); }
    });
    
    bar.querySelector('.end-turn-btn')?.addEventListener('click', () => {
      try { FFdreameCombatBar._endTurn(); } catch(e) { console.error(e); }
    });
    
    bar.querySelectorAll('.tableau-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        try { FFdreameCombatBar._toggleTableau(e.currentTarget.dataset.tableau); } catch(e) {}
      });
    });
    
    bar.querySelectorAll('.reaction-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        try { FFdreameCombatBar._toggleReaction(e.currentTarget.dataset.reaction); } catch(e) { console.error(e); }
      });
    });
  }
  
  static _switchToActor(actor) {
    if (!actor) return;
    console.log(`Combat Bar | Token: ${actor.name}`);
    FFdreameCombatBar.currentActor = actor;
    FFdreameCombatBar._updateBar();
  }
  
  static _updateBar() {
    if (!FFdreameCombatBar.currentActor) return;
    if (!document.getElementById('ffdreame-combat-bar')) { FFdreameCombatBar._createBar(); return; }
    try { FFdreameCombatBar._updatePortrait(); } catch(e) {}
    try { FFdreameCombatBar._updateTableaux(); } catch(e) {}
    try { FFdreameCombatBar._updateReactions(); } catch(e) {}
    try { FFdreameCombatBar._updateTechniques(); } catch(e) {}
    try { FFdreameCombatBar._updateEndTurnButton(); } catch(e) {}
  }
  
  static _updateEndTurnButton() {
    const btn = document.querySelector('.end-turn-btn');
    if (!btn) return;
    const noCombat = !game.combat?.started;
    btn.classList.toggle('disabled', noCombat);
    btn.disabled = noCombat;
  }
  
  static _updatePortrait() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar || !FFdreameCombatBar.currentActor) return;
    const img = bar.querySelector('.portrait-img');
    const nameEl = bar.querySelector('.portrait-name');
    
    // Afficher visuellement si le tour est terminé
    let isBlocked = false;
    try { isBlocked = FFdreameCombatBar.currentActor.getFlag('ffdreame', 'actionBlocked'); } catch(e) {}
    
    if (img) img.src = FFdreameCombatBar.currentActor.img || 'icons/svg/mystery-man.svg';
    if (nameEl) {
      nameEl.textContent = FFdreameCombatBar.currentActor.name || '???';
      nameEl.style.color = isBlocked ? '#ff6b6b' : '';
      nameEl.title = isBlocked ? '🔒 Tour terminé' : '';
    }
    
    // Indicateur "tour terminé" sur le portrait
    const portrait = bar.querySelector('.combat-bar-portrait');
    if (portrait) portrait.classList.toggle('turn-ended', !!isBlocked);
  }
  
  static _updateTableaux() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar || !FFdreameCombatBar.currentActor) return;
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) return;
    const t1Btn = bar.querySelector('.tableau-btn[data-tableau="1"]');
    const t2Btn = bar.querySelector('.tableau-btn[data-tableau="2"]');
    if (t1Btn && combat.tableau1) {
      t1Btn.querySelector('.tableau-name').textContent = combat.tableau1.nom || 'Tableau 1';
      t1Btn.classList.toggle('active', !!combat.tableau1.actif);
    }
    if (t2Btn && combat.tableau2) {
      t2Btn.querySelector('.tableau-name').textContent = combat.tableau2.nom || 'Tableau 2';
      t2Btn.classList.toggle('active', !!combat.tableau2.actif);
    }
  }
  
  static _updateReactions() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar || !FFdreameCombatBar.currentActor) return;
    const reactions = FFdreameCombatBar.currentActor.system?.combat?.reactions;
    bar.querySelectorAll('.reaction-btn').forEach(btn => {
      btn.classList.toggle('active', reactions?.[btn.dataset.reaction] === true);
      // Les réactions sont TOUJOURS disponibles (pas grisées même si tour terminé)
      btn.classList.remove('disabled');
      btn.disabled = false;
    });
  }
  
  static _updateTechniques() {
    const bar = document.getElementById('ffdreame-combat-bar');
    if (!bar || !FFdreameCombatBar.currentActor) return;
    const container = bar.querySelector('.techniques-container');
    if (!container) return;
    container.innerHTML = '';
    
    // Vérifier si le tour est terminé → griser les techniques
    let isBlocked = false;
    try { isBlocked = FFdreameCombatBar.currentActor.getFlag('ffdreame', 'actionBlocked'); } catch(e) {}
    
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) { container.innerHTML = '<div class="techniques-empty-hint">Aucune donnée combat</div>'; return; }
    
    const t1Actif = !!combat.tableau1?.actif;
    const t2Actif = !!combat.tableau2?.actif;
    let hasContent = false;
    
    if (combat.tableau1) {
      for (let i = 1; i <= 8; i++) {
        const itemId = combat.tableau1.slots?.[`slot${i}`];
        const item = itemId ? FFdreameCombatBar.currentActor.items.get(itemId) : null;
        if (item || i <= 4) {
          // Désactiver si tableau inactif OU si tour terminé
          const slotDisabled = !t1Actif || isBlocked;
          container.appendChild(FFdreameCombatBar._createTechniqueSlot(item, slotDisabled, 1, i, isBlocked));
          hasContent = true;
        }
      }
    }
    if (combat.tableau1 && combat.tableau2) {
      const sep = document.createElement('div'); sep.className = 'techniques-separator'; container.appendChild(sep);
    }
    if (combat.tableau2) {
      for (let i = 1; i <= 8; i++) {
        const itemId = combat.tableau2.slots?.[`slot${i}`];
        const item = itemId ? FFdreameCombatBar.currentActor.items.get(itemId) : null;
        if (item || i <= 4) {
          const slotDisabled = !t2Actif || isBlocked;
          container.appendChild(FFdreameCombatBar._createTechniqueSlot(item, slotDisabled, 2, i, isBlocked));
          hasContent = true;
        }
      }
    }
    if (!hasContent) container.innerHTML = '<div class="techniques-empty-hint">Aucune technique assignée</div>';
    
    // Afficher un bandeau "Tour terminé" si bloqué
    if (isBlocked) {
      const notice = document.createElement('div');
      notice.className = 'techniques-blocked-notice';
      notice.innerHTML = '🔒 Tour terminé';
      container.prepend(notice);
    }
  }
  
  static _createTechniqueSlot(item, disabled, tableauNum, slotNum, isBlocked) {
    const slot = document.createElement('div');
    slot.classList.add('technique-slot');
    if (disabled) slot.classList.add('disabled');
    if (isBlocked && item) slot.classList.add('turn-ended');
    if (!item) slot.classList.add('empty');
    if (item) {
      const pm = item.system?.coutPM || 0;
      slot.innerHTML = `
        <img src="${item.img || 'icons/svg/mystery-man.svg'}" alt="${item.name}" class="technique-img" onerror="this.src='icons/svg/mystery-man.svg'" />
        <div class="technique-name">${item.name}</div>
        ${pm > 0 ? `<div class="technique-pm">${pm}PM</div>` : ''}
      `;
      slot.title = item.name + (isBlocked ? ' (Tour terminé)' : '');
      if (!disabled) {
        slot.addEventListener('click', () => { try { FFdreameCombatBar._useTechnique(item); } catch(e) { console.error(e); } });
      }
      slot.addEventListener('mouseenter', (e) => { try { FFdreameCombatBar._showTooltip(item, e.currentTarget); } catch(e) {} });
      slot.addEventListener('mouseleave', () => { try { FFdreameCombatBar._hideTooltip(); } catch(e) {} });
    } else {
      slot.innerHTML = `<div class="slot-empty-icon" title="T${tableauNum}-Slot${slotNum}">·</div>`;
    }
    return slot;
  }
  
  static _showTooltip(item, element) {
    FFdreameCombatBar._hideTooltip();
    try {
      const pm = item.system?.coutPM || 0, pa = item.system?.coutPA || '', portee = item.system?.portee || 0;
      const desc = item.system?.description || '';
      const shortDesc = desc.length > 100 ? desc.substring(0, 97) + '...' : desc;
      const tt = document.createElement('div');
      tt.id = 'technique-tooltip'; tt.className = 'technique-tooltip';
      tt.innerHTML = `
        <div class="tt-h"><b>${item.name}</b></div>
        <div class="tt-c">
          ${pm ? `<span class="tt-pm">✨${pm}PM</span>` : ''}
          ${pa ? `<span class="tt-pa">⚡${pa}</span>` : ''}
          ${portee ? `<span class="tt-r">📍${portee}m</span>` : ''}
        </div>
        ${shortDesc ? `<div class="tt-t">${shortDesc}</div>` : ''}
      `;
      document.body.appendChild(tt);
      const r = element.getBoundingClientRect(), tr = tt.getBoundingClientRect();
      let top = r.top - tr.height - 8, left = r.left + r.width/2 - tr.width/2;
      if (top < 5) top = r.bottom + 8;
      if (left < 5) left = 5;
      if (left + tr.width > window.innerWidth - 5) left = window.innerWidth - tr.width - 5;
      tt.style.top = top + 'px'; tt.style.left = left + 'px';
      requestAnimationFrame(() => tt.classList.add('show'));
    } catch(e) {}
  }
  
  static _hideTooltip() { document.getElementById('technique-tooltip')?.remove(); }
  
  static async _useTechnique(item) {
    if (!FFdreameCombatBar.currentActor || !item) return;
    const sheet = FFdreameCombatBar.currentActor.sheet;
    if (sheet && typeof sheet._useTableTechnique === 'function') {
      await sheet._useTableTechnique(item);
    } else if (sheet && typeof sheet._useTechnique === 'function') {
      await sheet._useTechnique(item);
    } else if (typeof item.roll === 'function') {
      await item.roll();
    } else {
      ui.notifications.warn(`Technique: ${item.name}`);
    }
  }
  
  /**
   * ============================================
   * CIBLAGE - MÊME CHEMIN QUE FOUNDRY
   * ============================================
   * Foundry utilise canvas.tokens.hover pour connaître le token sous la souris.
   * Au clic → on appelle token.setTarget() exactement comme le clic droit Foundry.
   */
  static _toggleTargetMode() {
    FFdreameCombatBar.targetMode = !FFdreameCombatBar.targetMode;
    const btn = document.querySelector('.target-btn');
    if (btn) btn.classList.toggle('active', FFdreameCombatBar.targetMode);
    
    if (FFdreameCombatBar.targetMode) {
      ui.notifications.info("🎯 Mode ciblage — Survolez un token et cliquez");
      document.body.style.cursor = 'crosshair';
      
      // Écouter le clic sur le canvas Foundry (stage PIXI) en capture
      // → se déclenche AVANT les handlers Foundry natifs
      FFdreameCombatBar._targetClickHandler = (e) => {
        e.stopPropagation();
        e.preventDefault();
        FFdreameCombatBar._doTarget();
      };
      
      // On cible le canvas WebGL/HTML directement
      const canvasEl = document.getElementById('board');
      if (canvasEl) {
        FFdreameCombatBar._targetCanvas = canvasEl;
        canvasEl.addEventListener('pointerup', FFdreameCombatBar._targetClickHandler, { capture: true, once: true });
      } else {
        // Fallback : écouter sur le document
        document.addEventListener('pointerup', FFdreameCombatBar._targetClickHandler, { capture: true, once: true });
        FFdreameCombatBar._targetCanvas = document;
      }
      
    } else {
      FFdreameCombatBar._cancelTargetMode();
    }
  }
  
  static _cancelTargetMode() {
    FFdreameCombatBar.targetMode = false;
    document.body.style.cursor = '';
    const btn = document.querySelector('.target-btn');
    if (btn) btn.classList.remove('active');
    // Nettoyer le listener si annulé avant le clic
    if (FFdreameCombatBar._targetClickHandler && FFdreameCombatBar._targetCanvas) {
      try {
        FFdreameCombatBar._targetCanvas.removeEventListener('pointerup', FFdreameCombatBar._targetClickHandler, { capture: true });
      } catch(e) {}
      FFdreameCombatBar._targetClickHandler = null;
      FFdreameCombatBar._targetCanvas = null;
    }
  }
  
  /**
   * Effectuer le ciblage en utilisant canvas.tokens.hover
   * C'est exactement la même logique que Foundry en interne lors du clic droit
   */
  static _doTarget() {
    // Réinitialiser le mode ciblage
    FFdreameCombatBar.targetMode = false;
    document.body.style.cursor = '';
    const btn = document.querySelector('.target-btn');
    if (btn) btn.classList.remove('active');
    FFdreameCombatBar._targetClickHandler = null;
    FFdreameCombatBar._targetCanvas = null;
    
    try {
      // canvas.tokens.hover = le token actuellement sous le curseur de la souris
      // C'est la même variable que Foundry utilise pour son ciblage natif
      const hoveredToken = canvas.tokens?.hover;
      
      if (!hoveredToken) {
        ui.notifications.warn("⚠️ Survolez un token avant de cliquer !");
        return;
      }
      
      // setTarget avec releaseOthers=true → cible uniquement ce token
      // Exactement comme le clic droit Foundry → "Cibler"
      hoveredToken.setTarget(true, { user: game.user, releaseOthers: true });
      ui.notifications.info(`🎯 Cible : <b>${hoveredToken.name}</b>`);
      
    } catch(err) {
      console.error('FFdreame | Erreur ciblage:', err);
      ui.notifications.error("❌ Erreur lors du ciblage");
    }
  }
  
  /**
   * ============================================
   * FIN DE TOUR CORRIGÉ
   * ============================================
   * 1. Bloque l'acteur courant (actionBlocked = true)
   * 2. Appelle game.combat.nextTurn() → fait avancer l'initiative Foundry
   */
  static async _endTurn() {
    if (!FFdreameCombatBar.currentActor) {
      ui.notifications.warn("⚠️ Aucun personnage sélectionné !");
      return;
    }
    if (!game.combat?.started) {
      ui.notifications.warn("⚠️ Aucun combat en cours !");
      return;
    }
    
    // Vérifier que c'est bien le tour de ce personnage (sauf MJ)
    const currentCombatant = game.combat.combatant;
    const isMyTurn = currentCombatant?.actorId === FFdreameCombatBar.currentActor.id;
    if (!isMyTurn && !game.user.isGM) {
      ui.notifications.warn("⚠️ Ce n'est pas votre tour !");
      return;
    }
    
    try {
      // 1. Bloquer l'acteur → les techniques sont bloquées, les réactions restent disponibles
      await FFdreameCombatBar.currentActor.setFlag('ffdreame', 'actionBlocked', true);
      
      // 2. Mettre à jour visuellement la barre
      FFdreameCombatBar._updateBar();
      
      // 3. Passer au tour suivant dans Foundry (met à jour l'initiative tracker)
      await game.combat.nextTurn();
      
      ui.notifications.info("⏭️ Tour terminé → au suivant !");
      
    } catch(err) {
      console.error("FFdreame | Erreur _endTurn:", err);
      ui.notifications.error("❌ Erreur fin de tour !");
    }
  }
  
  /**
   * TOGGLE TABLEAU (consomme 1 Petit PA en combat, comme la fiche)
   */
  static async _toggleTableau(tableauNum) {
    if (!FFdreameCombatBar.currentActor) return;
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) return;
    
    let blocked = false;
    try { blocked = FFdreameCombatBar.currentActor.getFlag('ffdreame', 'actionBlocked'); } catch(e) {}
    if (blocked && !game.user.isGM) {
      ui.notifications.warn("🔒 Votre tour est terminé !");
      return;
    }
    
    if (tableauNum === "1") {
      if (combat.tableau1?.actif) { ui.notifications.warn("⚠️ Tableau 1 déjà actif !"); return; }
    } else {
      if (combat.tableau2?.actif) { ui.notifications.warn("⚠️ Tableau 2 déjà actif !"); return; }
    }
    
    const enCombat = game.combat?.started;
    if (enCombat) {
      const actionPoints = combat.actionPoints;
      let petitDispo = null;
      for (let g = 1; g <= 3; g++) {
        for (let p = 1; p <= 2; p++) {
          if (actionPoints?.[`grand${g}`]?.[`petit${p}`]) { petitDispo = { grand: g, petit: p }; break; }
        }
        if (petitDispo) break;
      }
      if (!petitDispo) { ui.notifications.warn("⚠️ Pas de Petit PA disponible !"); return; }
      await FFdreameCombatBar.currentActor.update({
        [`system.combat.actionPoints.grand${petitDispo.grand}.petit${petitDispo.petit}`]: false,
        'system.combat.tableau1.actif': tableauNum === "1",
        'system.combat.tableau2.actif': tableauNum === "2"
      });
      ui.notifications.info(`✅ Tableau ${tableauNum} activé (-1 Petit PA)`);
    } else {
      await FFdreameCombatBar.currentActor.update({
        'system.combat.tableau1.actif': tableauNum === "1",
        'system.combat.tableau2.actif': tableauNum === "2"
      });
      ui.notifications.info(`✅ Tableau ${tableauNum} activé`);
    }
    FFdreameCombatBar._updateBar();
  }
  
  /**
   * TOGGLE RÉACTION - IDENTIQUE À LA FICHE (_onToggleReaction dans actor-sheet.js)
   * ⚠️ Les réactions N'ont PAS de vérification actionBlocked
   * → Elles restent disponibles même après Fin Tour (comme demandé)
   */
  static async _toggleReaction(reaction) {
    if (!FFdreameCombatBar.currentActor) {
      ui.notifications.warn("⚠️ Aucun personnage sélectionné !");
      return;
    }
    
    const combat = FFdreameCombatBar.currentActor.system?.combat;
    if (!combat) { console.error("FFdreame | Structure combat manquante !"); return; }
    
    // Initialiser reactions si nécessaire
    if (!combat.reactions) {
      await FFdreameCombatBar.currentActor.update({
        'system.combat.reactions': { esquive: false, defense: false, marche: false }
      });
    }
    
    const currentState = FFdreameCombatBar.currentActor.system?.combat?.reactions?.[reaction] ?? false;
    const labels = { esquive: 'Esquive', defense: 'Défense', marche: 'Marche' };
    const icons  = { esquive: '🤸',     defense: '🛡️',       marche: '🚶' };
    
    if (currentState) {
      // Désactiver (toujours possible)
      await FFdreameCombatBar.currentActor.update({ [`system.combat.reactions.${reaction}`]: false });
      ui.notifications.info(`${labels[reaction]} désactivée`);
    } else {
      // Activer → Consommer 1 Petit PA (comme la fiche)
      const actionPoints = combat.actionPoints;
      let petitDispo = null;
      for (let g = 1; g <= 3; g++) {
        for (let p = 1; p <= 2; p++) {
          if (actionPoints?.[`grand${g}`]?.[`petit${p}`]) { petitDispo = { grand: g, petit: p }; break; }
        }
        if (petitDispo) break;
      }
      if (!petitDispo) { ui.notifications.warn("⚠️ Pas de Petit PA disponible !"); return; }
      
      await FFdreameCombatBar.currentActor.update({
        [`system.combat.actionPoints.grand${petitDispo.grand}.petit${petitDispo.petit}`]: false,
        [`system.combat.reactions.${reaction}`]: true
      });
      ui.notifications.info(`${icons[reaction]} ${labels[reaction]} activée ! (1 Petit PA consommé)`);
    }
    
    FFdreameCombatBar._updateReactions();
  }
  
  // Console : FFdreameCombatBar.forceShow()
  static forceShow() {
    console.log('FFdreame | Combat Bar - Forçage affichage...');
    FFdreameCombatBar._createBar();
  }
}

window.FFdreameCombatBar = FFdreameCombatBar;
