/**
 * HELPER POUR LES JETS DE DÉS
 * Gère les modes Auto et Manuel
 */

export class FFdreameDiceHelper {
  
  /**
   * Effectuer un jet de dés (auto ou manuel selon le setting)
   * @param {string} formula - Formule du dé (ex: "1d100")
   * @param {string} flavor - Description du jet
   * @param {Actor} actor - Acteur qui lance le dé
   * @returns {Promise<{total: number, roll: Roll}>}
   */
  static async rollDice(formula, flavor = "", actor = null) {
    const isManual = game.settings.get('ffdreame', 'manualDiceMode');
    
    if (isManual) {
      // Mode Manuel : Demander le résultat au MJ
      return await this._manualRoll(formula, flavor, actor);
    } else {
      // Mode Auto : Lancer automatiquement
      return await this._autoRoll(formula, flavor, actor);
    }
  }
  
  /**
   * Jet automatique (mode par défaut)
   */
  static async _autoRoll(formula, flavor, actor) {
    const roll = new Roll(formula);
    await roll.evaluate();
    
    // Afficher dans le chat
    await roll.toMessage({
      speaker: actor ? ChatMessage.getSpeaker({ actor }) : null,
      flavor: flavor
    });
    
    return {
      total: roll.total,
      roll: roll
    };
  }
  
  /**
   * Jet manuel (MJ entre le résultat)
   */
  static async _manualRoll(formula, flavor, actor) {
    // Extraire les bornes de la formule (ex: "1d100" → min=1, max=100)
    const match = formula.match(/(\d+)d(\d+)/);
    const diceCount = match ? parseInt(match[1]) : 1;
    const diceSize = match ? parseInt(match[2]) : 100;
    const min = diceCount;
    const max = diceCount * diceSize;
    
    // Extraire les modificateurs (ex: "1d100 + 15" → +15)
    const modMatch = formula.match(/[+-]\s*(\d+)/g);
    let totalMod = 0;
    if (modMatch) {
      totalMod = modMatch.reduce((sum, mod) => {
        return sum + parseInt(mod.replace(/\s/g, ''));
      }, 0);
    }
    
    const minFinal = min + totalMod;
    const maxFinal = max + totalMod;
    
    // Demander le résultat au MJ
    const result = await new Promise((resolve) => {
      new Dialog({
        title: "🎲 Jet Manuel",
        content: `
          <div style="padding: 10px;">
            <h3>${flavor || "Jet de dés"}</h3>
            <p><strong>Formule :</strong> ${formula}</p>
            <p><strong>Résultat attendu :</strong> ${minFinal} - ${maxFinal}</p>
            ${actor ? `<p><strong>Personnage :</strong> ${actor.name}</p>` : ''}
            <hr/>
            <div class="form-group">
              <label>Entrez le résultat du jet :</label>
              <input type="number" name="result" value="${Math.floor((minFinal + maxFinal) / 2)}" min="${minFinal}" max="${maxFinal}" style="width: 100%; padding: 8px; font-size: 18px;" autofocus />
            </div>
          </div>
        `,
        buttons: {
          ok: {
            icon: '<i class="fas fa-check"></i>',
            label: "Valider",
            callback: (html) => {
              const value = parseInt(html.find('[name="result"]').val());
              resolve(value);
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Annuler",
            callback: () => resolve(null)
          }
        },
        default: "ok",
        render: (html) => {
          // Focus et sélection automatique
          const input = html.find('[name="result"]');
          input.focus();
          input.select();
          
          // Validation sur Enter
          input.on('keypress', (e) => {
            if (e.which === 13) {
              html.find('.dialog-button.ok').click();
            }
          });
        }
      }, {
        width: 400
      }).render(true);
    });
    
    if (result === null) {
      ui.notifications.warn("Jet annulé");
      return { total: 0, roll: null };
    }
    
    // Créer un faux Roll pour la cohérence
    const fakeRoll = {
      total: result,
      formula: formula,
      terms: [],
      _evaluated: true
    };
    
    // Afficher dans le chat
    const messageContent = `
      <div class="dice-roll">
        <div class="dice-result">
          <div class="dice-formula">${formula} <span style="color: #ff6600;">(Manuel)</span></div>
          <div class="dice-total">
            <span class="total">${result}</span>
          </div>
        </div>
      </div>
    `;
    
    await ChatMessage.create({
      speaker: actor ? ChatMessage.getSpeaker({ actor }) : null,
      flavor: flavor,
      content: messageContent
    });
    
    return {
      total: result,
      roll: fakeRoll
    };
  }
}
