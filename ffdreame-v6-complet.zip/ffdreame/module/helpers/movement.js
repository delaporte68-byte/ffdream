/**
 * SYSTÈME DE DÉPLACEMENT LIÉ À L'ATHLÉTISME
 */

export class FFdreameMovement {
  
  /**
   * Calculer le déplacement maximum en fonction de l'athlétisme
   * @param {Actor} actor - L'acteur
   * @returns {number} - Déplacement en mètres
   */
  static calculateMovement(actor) {
    const athletisme = actor.system?.physique?.athletisme?.value || 0;
    const deplacement = 2 + athletisme; // 2m de base + athlétisme
    return deplacement;
  }
  
  /**
   * Mettre à jour le déplacement du token
   * @param {Actor} actor - L'acteur
   */
  static async updateTokenMovement(actor) {
    const deplacementMetres = this.calculateMovement(actor);
    
    console.log(`🏃 ${actor.name} - Déplacement: ${deplacementMetres}m`);
    
    // Mettre à jour le prototype token (pour les futurs tokens)
    await actor.update({
      'prototypeToken.flags.ffdreame.movementMax': deplacementMetres
    });
    
    // Mettre à jour tous les tokens existants
    for (const token of actor.getActiveTokens()) {
      await token.document.update({
        'flags.ffdreame.movementMax': deplacementMetres
      });
    }
    
    return deplacementMetres;
  }
  
  /**
   * Initialiser le système Drag Ruler (si le module est installé)
   */
  static initDragRuler() {
    Hooks.once('dragRuler.ready', (SpeedProvider) => {
      class FFdreameSpeedProvider extends SpeedProvider {
        get colors() {
          return [
            {id: "walk", default: 0x00FF00, name: "Marche"},
            {id: "dash", default: 0xFFFF00, name: "Course"},
            {id: "max", default: 0xFF0000, name: "Maximum"}
          ];
        }

        getRanges(token) {
          const actor = token.actor;
          if (!actor) return [];
          
          const deplacementMetres = FFdreameMovement.calculateMovement(actor);
          
          // Conversion en unités de grille
          const gridDistance = canvas.scene.grid.distance || 1.5;
          const gridSize = canvas.grid.size;
          const unitsPerMeter = gridSize / gridDistance;
          
          const deplacementUnits = deplacementMetres * unitsPerMeter;
          
          return [
            {range: deplacementUnits, color: "walk"}
          ];
        }
      }

      dragRuler.registerSystem("ffdreame", FFdreameSpeedProvider);
      console.log("🏃 Drag Ruler configuré pour FFdreame");
    });
  }
}
