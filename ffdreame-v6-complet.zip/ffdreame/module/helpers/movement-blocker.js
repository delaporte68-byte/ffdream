/**
 * ============================================
 * BLOQUEUR DE DÉPLACEMENT FFDREAME
 * ============================================
 * Empêche PHYSIQUEMENT tout déplacement non autorisé
 * Système de sécurité ultime - IMPOSSIBLE À CONTOURNER
 */

export class FFdreameMovementBlocker {
  
  /**
   * Initialiser le système de blocage
   */
  static init() {
    console.log('FFdreame | Initialisation du bloqueur de déplacement...');
    
    // Hook AVANT la mise à jour du token (blocage préventif)
    Hooks.on("preUpdateToken", this._validateMovement.bind(this));
    
    console.log('FFdreame | Bloqueur de déplacement activé ✅');
  }
  
  /**
   * Valider et potentiellement bloquer un déplacement
   * @param {TokenDocument} tokenDoc - Document du token
   * @param {Object} change - Changements à appliquer
   * @param {Object} options - Options de mise à jour
   * @param {string} userId - ID de l'utilisateur
   * @returns {boolean} - true pour autoriser, false pour bloquer
   */
  static _validateMovement(tokenDoc, change, options, userId) {
    // ==========================================
    // VÉRIFICATION 0 : S'AGIT-IL D'UN DÉPLACEMENT ?
    // ==========================================
    if (!change.x && !change.y) {
      return true; // Pas de déplacement, autoriser
    }
    
    // ==========================================
    // VÉRIFICATION 0.5 : COMBAT ACTIF ?
    // ==========================================
    // ⭐ SI PAS DE COMBAT → DÉPLACEMENT LIBRE
    const combat = game.combat;
    if (!combat || !combat.started) {
      console.log('🏃 Pas de combat actif → Déplacement libre sans restriction');
      return true; // ✅ LIBRE HORS COMBAT
    }
    
    // ==========================================
    // VÉRIFICATION 1 : MISE À JOUR SYSTÈME ?
    // ==========================================
    // Permettre les mises à jour système (anti-boucle infinie)
    if (options.ffdreameSystemMove || options.ffdreameBypass) {
      return true;
    }
    
    // ==========================================
    // VÉRIFICATION 2 : ACTEUR VALIDE ?
    // ==========================================
    const actor = tokenDoc.actor;
    if (!actor) {
      return true; // Pas d'acteur, autoriser (tokens vides, etc.)
    }
    
    // ==========================================
    // VÉRIFICATION 3 : TYPE DE PERSONNAGE
    // ==========================================
    // Uniquement pour les personnages joueurs
    if (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc") {
      return true; // PNJ, monstre, etc. → Pas de limite
    }
    
    console.log(`🏃 Validation déplacement pour ${actor.name}...`);
    
    // ==========================================
    // VÉRIFICATION 4 : PERSONNAGE MORT ?
    // ==========================================
    const pvActuel = actor.system.aptitudes?.pv?.value || 0;
    if (pvActuel <= 0) {
      console.warn(`FFdreame | ${actor.name} est mort → DÉPLACEMENT BLOQUÉ`);
      ui.notifications.error("💀 Ce personnage est mort et ne peut pas se déplacer !");
      return false; // ❌ BLOQUÉ
    }
    
    // ==========================================
    // VÉRIFICATION 5 : DÉPLACEMENT GRATUIT DISPONIBLE ?
    // ==========================================
    const deplacementGratuitUtilise = actor.system.combat?.deplacementGratuitUtilise || false;
    const marcheActive = actor.system.combat?.reactions?.marche || false;
    
    if (deplacementGratuitUtilise && !marcheActive) {
      console.warn(`FFdreame | ${actor.name} a déjà utilisé son déplacement gratuit → BLOQUÉ`);
      ui.notifications.warn(
        `⚠️ ${actor.name} a déjà utilisé son déplacement gratuit !<br>` +
        `Activez 🚶 <strong>MARCHE</strong> (1 Petit PA) pour vous déplacer à nouveau.`
      );
      return false; // ❌ BLOQUÉ
    }
    
    // ==========================================
    // VÉRIFICATION 6 : DISTANCE MAXIMALE
    // ==========================================
    
    // Calculer la distance parcourue
    const oldX = tokenDoc.x;
    const oldY = tokenDoc.y;
    const newX = change.x ?? oldX;
    const newY = change.y ?? oldY;
    
    const gridSize = canvas.grid.size;
    const deltaXPixels = newX - oldX;
    const deltaYPixels = newY - oldY;
    const distancePixels = Math.sqrt(deltaXPixels * deltaXPixels + deltaYPixels * deltaYPixels);
    const distanceCases = distancePixels / gridSize;
    
    // Récupérer les paramètres de la scène
    const gridDistance = canvas.scene.grid.distance || 1.5; // Distance par case (ex: 1.5m)
    const distanceMetresParcourue = distanceCases * gridDistance;
    
    // Calculer le maximum autorisé
    const athletisme = actor.system.physique?.athletisme?.value || 0;
    const deplacementMaxMetres = 2 + athletisme; // Formule: 2m base + Athlétisme
    const deplacementMaxCases = deplacementMaxMetres / gridDistance;
    
    console.log(
      `🏃 ${actor.name} - Déplacement:\n` +
      `   Distance parcourue: ${distanceMetresParcourue.toFixed(2)}m (${distanceCases.toFixed(2)} cases)\n` +
      `   Distance max: ${deplacementMaxMetres}m (${deplacementMaxCases.toFixed(2)} cases)\n` +
      `   Athlétisme: ${athletisme} | Grille: ${gridDistance}m/case`
    );
    
    // Tolérance d'arrondi (0.05 cases pour éviter les erreurs de pixels)
    const TOLERANCE = 0.05;
    
    if (distanceCases > deplacementMaxCases + TOLERANCE) {
      console.warn(`FFdreame | ${actor.name} dépasse la limite de déplacement → BLOQUÉ`);
      
      ui.notifications.error(
        `⛔ Déplacement impossible !<br>` +
        `<strong>${actor.name}</strong> peut se déplacer maximum <strong>${deplacementMaxMetres}m</strong><br>` +
        `(Athlétisme: ${athletisme})`
      );
      
      return false; // ❌ BLOQUÉ
    }
    
    // ==========================================
    // DÉPLACEMENT AUTORISÉ
    // ==========================================
    console.log(`✅ ${actor.name} - Déplacement autorisé (${distanceMetresParcourue.toFixed(2)}m / ${deplacementMaxMetres}m)`);
    
    // Marquer le déplacement comme utilisé (en asynchrone pour ne pas bloquer)
    setTimeout(async () => {
      await this._markMovementUsed(actor, marcheActive);
    }, 50);
    
    return true; // ✅ AUTORISÉ
  }
  
  /**
   * Marquer le déplacement comme utilisé
   * @param {Actor} actor - L'acteur qui s'est déplacé
   * @param {boolean} wasMarche - Si la marche était active
   */
  static async _markMovementUsed(actor, wasMarche) {
    try {
      const updateData = {
        'system.combat.deplacementGratuitUtilise': true
      };
      
      // Si c'était une marche, désactiver le bouton
      if (wasMarche) {
        updateData['system.combat.reactions.marche'] = false;
        console.log(`🚶 ${actor.name} - Marche utilisée et désactivée`);
        ui.notifications.info(`🚶 ${actor.name} a utilisé sa Marche`);
      } else {
        console.log(`🏃 ${actor.name} - Déplacement gratuit utilisé`);
        ui.notifications.info(`🏃 ${actor.name} a utilisé son déplacement gratuit`);
      }
      
      await actor.update(updateData, { ffdreameSystemMove: true });
      
    } catch (error) {
      console.error('FFdreame | Erreur lors de la mise à jour du déplacement:', error);
    }
  }
  
  /**
   * Réinitialiser le déplacement gratuit d'un acteur
   * @param {Actor} actor - L'acteur à réinitialiser
   */
  static async resetMovement(actor) {
    if (!actor) return;
    
    try {
      await actor.update({
        'system.combat.deplacementGratuitUtilise': false
      }, { ffdreameSystemMove: true });
      
      console.log(`🔄 ${actor.name} - Déplacement gratuit réinitialisé`);
      ui.notifications.info(`🔄 ${actor.name} peut à nouveau se déplacer gratuitement`);
      
    } catch (error) {
      console.error('FFdreame | Erreur lors de la réinitialisation du déplacement:', error);
    }
  }
  
  /**
   * Réinitialiser le déplacement de tous les acteurs
   * Utile en début de round/tour
   */
  static async resetAllMovements() {
    const actors = game.actors.filter(a => 
      (a.type === "character" || a.type === "cyberpunk") && 
      a.system.combat?.deplacementGratuitUtilise
    );
    
    console.log(`🔄 Réinitialisation de ${actors.length} personnages...`);
    
    for (const actor of actors) {
      await this.resetMovement(actor);
    }
    
    ui.notifications.info(`🔄 Déplacements réinitialisés pour ${actors.length} personnages`);
  }
  
  /**
   * Afficher la zone de déplacement d'un token
   * @param {Token} token - Le token pour lequel afficher la zone
   * @param {number} duration - Durée d'affichage en ms (défaut: 3000)
   */
  static async showMovementRange(token, duration = 3000) {
    if (!token || !token.actor) return;
    
    const actor = token.actor;
    if (actor.type !== "character" && actor.type !== "cyberpunk" && actor.type !== "npc") return;
    
    const athletisme = actor.system.physique?.athletisme?.value || 0;
    const deplacementMetres = 2 + athletisme;
    
    // Créer un template circulaire temporaire
    const templateData = {
      t: "circle",
      user: game.user.id,
      distance: deplacementMetres,
      x: token.center.x,
      y: token.center.y,
      fillColor: "#00FF0030", // Vert transparent
      borderColor: "#00FF00"
    };
    
    const templates = await canvas.scene.createEmbeddedDocuments("MeasuredTemplate", [templateData]);
    
    console.log(`📍 Zone de déplacement affichée pour ${actor.name}: ${deplacementMetres}m`);
    
    // Supprimer après la durée spécifiée
    setTimeout(async () => {
      await canvas.scene.deleteEmbeddedDocuments("MeasuredTemplate", [templates[0].id]);
    }, duration);
  }
}
